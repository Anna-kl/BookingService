﻿using FluentValidation.Results;

using MediatR;

using Supply.Dashboards.App.UseCases.Charts.HseIndicators.Output;
using Supply.Dashboards.App.UseCases.Charts.HseIndicators.Types;

using System;
using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.Charts.HseIndicators.Input
{
    public sealed class HseIndicatorsQuery
        : IRequest<(ValidationResult validationResult, HseIndicatorsOutput? output)>
    {
        private readonly List<HseIndicatorType> _lastIncidentTypes;
        private readonly List<Guid> _locationsIds;
        private readonly List<Guid> _customersIds;

        public HseIndicatorsQuery(
            DateTime startPeriod,
            DateTime? endPeriod,
            List<HseIndicatorType> lastIncidentTypes,
            List<Guid> locationsIds,
            List<Guid> customersIds)
        {
            StartPeriod = startPeriod;
            EndPeriod = endPeriod;
            _lastIncidentTypes = lastIncidentTypes;
            _locationsIds = locationsIds;
            _customersIds = customersIds;

            ValidationResult = new HseIndicatorsValidator()
                .Validate(this);
        }

        public DateTime StartPeriod { get; }
        public DateTime? EndPeriod { get; }

        public IEnumerable<HseIndicatorType> LastIncidentTypes =>
            _lastIncidentTypes.AsReadOnly();

        public IEnumerable<Guid> LocationsIds =>
            _locationsIds.AsReadOnly();

        public IEnumerable<Guid> CustomersIds =>
            _customersIds.AsReadOnly();

        public ValidationResult ValidationResult { get; }
    }
}
