﻿using FluentValidation.Results;

using MediatR;

using System;
using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.ContextUserSettings.ContextUserSettingsAddOrUpdate.Input
{
    public sealed class ContextUserSettingsAddOrUpdateQuery
        : IRequest<(ValidationResult validationResult, bool result)>
    {
        public ContextUserSettingsAddOrUpdateQuery(
            int userId,
            int contextId,
            string dashboardsState)
        {
            UserId = userId;
            ContextId = contextId;
            DashboardsState = dashboardsState;

            ValidationResult = new ContextUserSettingsAddOrUpdateValidator()
                .Validate(this);
        }

        public int UserId { get; }
        public int ContextId { get; }
        public string DashboardsState { get; }

        public ValidationResult ValidationResult { get; }
    }
}
