﻿using Supply.Dashboards.App.Types;

using System;

namespace Supply.Dashboards.App.UseCases.Contexts.GetContextList.Output
{
    public sealed class GetContextListUserItemOutput
    {
        public GetContextListUserItemOutput(
            Guid id,
            AppStatusType status,
            string nameIdentifier,
            string fullName)
        {
            Id = id;
            Status = status;
            NameIdentifier = nameIdentifier;
            FullName = fullName;
        }

        public Guid Id { get; }
        public AppStatusType Status { get; }

        public string NameIdentifier { get; }
        public string FullName { get; }
    }
}
