﻿using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.Charts.CargoGroupByLocations.Output
{
    public sealed class CargoGroupByLocationsOutput
    {
        private readonly List<CargoGroupByLocationsParamOutput> _locations;

        internal CargoGroupByLocationsOutput(List<CargoGroupByLocationsParamOutput> locations)
        {
            _locations = locations;
        }

        public IEnumerable<CargoGroupByLocationsParamOutput> Locations =>
            _locations.OrderBy(_ => _.LocationId).ToList().AsReadOnly();
    }
}
