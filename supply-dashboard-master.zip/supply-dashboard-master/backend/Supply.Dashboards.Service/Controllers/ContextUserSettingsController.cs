﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Supply.Dashboards.App.UseCases.ContextUserSettings.ContextUserSettingsAddOrUpdate.Input;
using Supply.Dashboards.App.UseCases.ContextUserSettings.GetContextUserSettings.Input;
using Supply.Dashboards.App.UserInfo;
using Supply.Dashboards.Shared.ViewModels.ContextUserSettings.ContextUserSettingsAddOrUpdate;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.Service.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public sealed class ContextUserSettingsController : ControllerBase
    {
        private readonly ILogger<ContextsController> _logger;
        private readonly IMediator _mediator;
        private readonly IAuthInfo _authInfo;

        public ContextUserSettingsController(
            ILogger<ContextsController> logger,
            IMediator mediator,
            IAuthInfo authInfo)
        {
            _logger = logger;
            _mediator = mediator;
            _authInfo = authInfo;
        }

        [HttpPost("get")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> Get(CancellationToken cancellationToken)
        {

            var userId = _authInfo.GetUserByNameIdentifier(UserInfo.NameIdentifier()!)!.Id;

            var getSettingsQuery = new GetContextUserSettingsQuery(userId, UserInfo.Context!.Id);

            if (!getSettingsQuery.ValidationResult.IsValid)
                return BadRequest(getSettingsQuery
                    .ValidationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            var (validationResult, settingsOutput) = await _mediator.Send(
                getSettingsQuery,
                cancellationToken);

            if (!validationResult.IsValid)
                return BadRequest(validationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));



            return Ok(settingsOutput);
        }

        [HttpPost("save")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> Save([FromBody] ContextUserSettingsAddOrUpdateRequestViewModel request, CancellationToken cancellationToken)
        {
            var userId = _authInfo.GetUserByNameIdentifier(UserInfo.NameIdentifier()!)!.Id;

            var settingsQuery = new ContextUserSettingsAddOrUpdateQuery(userId, UserInfo.Context!.Id, request.DashboardsState);

            if (!settingsQuery.ValidationResult.IsValid)
                return BadRequest(settingsQuery
                    .ValidationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            var (validationResult, result) = await _mediator.Send(
                settingsQuery,
                cancellationToken);

            if (!validationResult.IsValid)
                return BadRequest(validationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));



            return Ok(result);

        }
    }
}
