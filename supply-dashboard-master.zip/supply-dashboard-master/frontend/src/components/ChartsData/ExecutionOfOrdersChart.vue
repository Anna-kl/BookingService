<template>
  <div class="module-inner-container">
    <DxChart
      :data-source="dataSource"
      :argument-axis="customizeArgumentAxis"
      class="chart-module"
    >
      <DxCommonSeriesSettings
        :argument-field="config.columns"
        type="spline"
        hover-mode="allArgumentPoints"
        selection-mode="allArgumentPoints"
      >
        <DxLabel :visible="true" backgroundColor="none" :rotationAngle="-55">
          <DxFormat :precision="0" type="fixedPoint" />
          <DxFont color="white" />
        </DxLabel>
      </DxCommonSeriesSettings>
      <DxSeries
        v-for="seriesItem in series.filter((s) => s.value)"
        :key="seriesItem.id"
        :value-field="seriesItem.id"
        :name="seriesItem.name"
        :color="seriesItem.color"
      />
      <DxTitle text="Исполнение заявок" horizontalAlignment="left">
        <DxSubtitle text="количество">
          <DxFont color="#42a2f6" />
        </DxSubtitle>
      </DxTitle>
      <DxLegend vertical-alignment="bottom" horizontal-alignment="center" />
      <DxTooltip :enabled="true" :customize-tooltip="customizeTooltip">
        <DxFormat :precision="3" type="fixedPoint" />
      </DxTooltip>
    </DxChart>
  </div>
</template>

<script lang='ts'>
import Chart from "@/components/ChartsData/chart";
import {
  DxChart,
  DxSeries,
  DxCommonSeriesSettings,
  DxLabel,
  DxFormat,
  DxLegend,
  DxTooltip,
  DxTitle,
  DxSubtitle,
  DxFont,
} from "devextreme-vue/chart";
import { Component, Prop } from "vue-property-decorator";
import config from "@/config";
import notify from "devextreme/ui/notify";
import {
  GraphLocationGroupEnum,
  IModuleConfig,
  IModuleSeries,
} from "@/dto/Dashboards";
import { ChartDataService } from "@/services/chartDataService";
import DxButton from "devextreme-vue/button";
import DxToolbar, { DxItem } from "devextreme-vue/toolbar";
import {
  IExecutionOfOrdersDataRequest,
  IExecutionOfOrdersDataResponse,
  IExecutionOfOrdersChartData,
} from "@/dto/ExecutionOfOrdersData";
import { roundDate, utcFromLocalDate, yesterdayDate } from "@/helpers";
import { ITreeListItemRelation } from "../InputData/common/models";
import { ITreeListSelectedItem } from "../controls/filterTree/types";
import { MtrItemTypeEnum } from "@/dto/InputData";
import { ToolbarItem } from "node_modules/devextreme/ui/popup";
import { dxToolbarOptions } from "node_modules/devextreme/ui/toolbar";
import DxDateBox from "devextreme-vue/date-box";
import { DateTime } from "luxon";

interface IGroupDataByParent {
  id: string;
  dbId: string;
  title: string;
  selected: boolean;
  childrenGroups: IGroupDataByParent[];
}

@Component({
  components: {
    DxChart,
    DxSeries,
    DxCommonSeriesSettings,
    DxLabel,
    DxFormat,
    DxLegend,
    DxTooltip,
    DxTitle,
    DxSubtitle,
    DxFont,
    DxButton,
    DxToolbar,
    DxItem,
    DxDateBox,
  },
})
export default class ExecutionOfOrdersChart extends Chart {
  @Prop({ type: Object, required: false }) public config!: IModuleConfig;
  @Prop({ type: Array, required: false }) public series!: IModuleSeries[];

  private url: string =
    config.remoteHost + "/api/dashboards/execution-of-orders-chart";
  private dataSource: IExecutionOfOrdersChartData[] = [];
  private curDate: Date = yesterdayDate();
  private navigateHistory: string[] = [];
  private customizeArgumentAxis = {
    label: {
      overlappingBehavior: "none",
      textOverflow: "ellipsis",
    },
  };

  private _chartDataService!: ChartDataService;

  public update() {
    this.getData(this.curDate);
  }

  private created() {
    this._chartDataService = new ChartDataService();
  }

  private mounted(): void {
    this.getData(this.curDate);
  }

  private async getData(curDate: Date) {
    this.dataSource = [];
    const dateTime = utcFromLocalDate(curDate);
    const request: IExecutionOfOrdersDataRequest = {
      startPeriod: dateTime,
      locationsIds: this.config.locationsIds
        ?.filter((f) => f.selected)
        .map<string>((s) => s.dbId),
      customersIds: this.config.customersIds,
    };
    await this._chartDataService
      .getExecutionOfOrdersData(this.url, request)
      .then((data) => {
        if (data) {
          this.loadToDataSource(data);
        }
      })
      .catch((error: any) => {
        notify(error, "error", 2000);
        throw new Error(error);
      });
  }

  private loadToDataSource(data: IExecutionOfOrdersDataResponse[]) {
    this.dataSource.push(...this.transformChartData(data));
  }

  private transformChartData(
    data: IExecutionOfOrdersDataResponse[]
  ): IExecutionOfOrdersChartData[] {
    const retData: IExecutionOfOrdersChartData[] = [];
    data.forEach((value) => {
      retData.push({
        date: this.formatDate(value.date),
        plan: value.plan,
        forecast: value.forecast,
        totalFact: value.totalFact,
      });
    });

    return retData;
  }

  private formatDate(date: DateTime) {
    const value = DateTime.fromISO(date.toString());
    const day = value.day < 10 ? "0" + value.day : value.day;
    const month = value.month < 10 ? "0" + value.month : value.month;
    return day + "." + month;
  }

  private customizeTooltip(pointInfo: any) {
    return {
      text: `<b>${pointInfo.argument}</b><br />${pointInfo.seriesName}: ${pointInfo.valueText}`,
    };
  }
}
</script>
<style scoped>
.dx-toolbar {
  background: none;
}
</style>