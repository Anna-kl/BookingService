﻿using Common.Extensions;

using FluentValidation.Results;

using MediatR;

using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.UseCases.Charts.OtifChart.Input;
using Supply.Dashboards.App.UseCases.Charts.OtifChart.Output;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.Types;

using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.Charts.OtifChart
{
    public sealed class OtifChartUseCase
        : IRequestHandler<OtifChartQuery, (ValidationResult validationResult, OtifChartOutput? output)>
    {
        private readonly ILogger<OtifChartUseCase> _logger;
        private readonly IMediator _mediator;
        private readonly IOtifChart _otifChart;

        private List<Customer> _customers;
        private List<Location> _locations;
        private ValidationResult _validationResult;
        private readonly List<StatusType> _selectStatus;

        public OtifChartUseCase(
            ILogger<OtifChartUseCase> logger,
            IMediator mediator,
            IOtifChart otifChart)
        {
            _logger = logger;
            _mediator = mediator;
            _otifChart = otifChart;

            _customers = new List<Customer>();
            _locations = new List<Location>();
            _validationResult = new ValidationResult();
            _selectStatus = new List<StatusType> { StatusType.Active };
        }

        public async Task<(ValidationResult validationResult, OtifChartOutput? output)> Handle(
            OtifChartQuery request,
            CancellationToken cancellationToken)
        {
            _validationResult = request.ValidationResult;

            // If there are validation errors, abort the method and return errors.
            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            await Customers(request, cancellationToken);
            await Locations(request, cancellationToken);

            // If there are validation errors, abort the method and return errors.
            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            var records = (await _otifChart.GetRecords(
                    request.StartPeriod,
                    request.EndPeriod,
                    _locations,
                    _customers,
                    cancellationToken))
                .ToList();

            var scheduledFact = records.Count(_ => _.Payload.Type == BidType.ScheduledFact);
            var plan = records.Count(_ => _.Payload.Type == BidType.Plan);
            var totalFact = records.Count(_ => _.Payload.Type == BidType.TotalFact);

            OtifChartOutput? result;

            if (scheduledFact == 0 || plan == 0 || totalFact == 0)
                result = new OtifChartOutput(
                    0,
                    100);
            else
            {
                var ot = (double)scheduledFact / plan;
                var @if = (double)totalFact / plan;
                var otif = ot * @if * 100;
                double notOtif = 0;

                if (otif < 100)
                    notOtif = 100 - otif;

                result = new OtifChartOutput(
                    otif,
                    notOtif);
            }

            return (_validationResult, result);
        }

        private async Task Customers(
            OtifChartQuery query,
            CancellationToken cancellationToken)
        {
            var existingIdsFromFilter = (await _otifChart.GetCustomersExistingIds(
                _selectStatus,
                query.CustomersIds.ToList(),
                cancellationToken)).ToList();
            var nonExistentIdsFromFilter = query
                .CustomersIds
                .Except(existingIdsFromFilter)
                .ToList();

            if (nonExistentIdsFromFilter.Any())
            {
                foreach (var id in nonExistentIdsFromFilter)
                    _validationResult.Errors.Add(new ValidationFailure(
                        "CustomerId",
                        $"{nameof(Customer)} with id \"{id}\" is not exist."));

                return;
            }

            var allCustomers = (await _otifChart.GetCustomers(
                _selectStatus,
                cancellationToken))
                .Where(_ => _.SourceEdges == null || !_.SourceEdges.Any())
                .SelectMany(_ => _.DepthFirstSearch(
                    edge => edge.Destination,
                    customer => customer.DestinationEdges,
                    _ => { }))
                .ToList();
            var allCustomersIds = allCustomers
                .Select(_ => _.InnerId)
                .ToList();
            var allCustomersEdges = (await _otifChart.GetCustomersEdges(
                allCustomersIds,
                cancellationToken)).ToList();

            foreach (var customer in allCustomers)
            {
                var sourceIds = allCustomersEdges
                    .Where(_ => _.DestinationId == customer.Id)
                    .Select(_ => _.SourceId);
                var sourcesVertex = allCustomers.Where(_ => sourceIds.Contains(_.Id));
                customer.AddSourceEdges(sourcesVertex.Select(_ => new CustomerEdge(_, customer)));

                var destinationIds = allCustomersEdges
                    .Where(_ => _.SourceId == customer.Id)
                    .Select(_ => _.DestinationId);
                var destinationVertex = allCustomers.Where(_ => destinationIds.Contains(_.Id));
                customer.AddDestinationEdges(destinationVertex.Select(_ => new CustomerEdge(customer, _)));
            }

            if (!query.CustomersIds.Any())
            {
                _customers = allCustomers;
                return;
            }

            var customersFromFilter = new List<Customer>();

            foreach (var customer in allCustomers)
            {
                customer.DepthFirstSearch(
                    _ => _.Destination,
                    _ => _.DestinationEdges!,
                    _ =>
                    {
                        if (existingIdsFromFilter.Contains(_.InnerId))
                            customersFromFilter.Add(_);
                    });
            }

            var customers = new List<Customer>();

            foreach (var customer in customersFromFilter)
            {
                customers.AddRange(customer.DepthFirstSearch(
                    _ => _.Destination,
                    _ => _.DestinationEdges!,
                    _ => { }));
            }

            if (!customers.Any())
                customers = allCustomers;

            _customers = customers
                .Distinct()
                .ToList();
        }

        private async Task Locations(
            OtifChartQuery query,
           CancellationToken cancellationToken)
        {
            var existingIdsFromFilter = (await _otifChart.GetLocationsExistingIds(
                _selectStatus,
                query.LocationsIds.ToList(),
                cancellationToken)).ToList();
            var nonExistentIdsFromFilter = query
                .LocationsIds
                .Except(existingIdsFromFilter)
                .ToList();

            if (nonExistentIdsFromFilter.Any())
            {
                foreach (var id in nonExistentIdsFromFilter)
                    _validationResult.Errors.Add(new ValidationFailure(
                        "LocationId",
                        $"{nameof(Location)} with id \"{id}\" is not exist."));

                return;
            }

            var allLocations = (await _otifChart.GetLocations(
                _selectStatus,
                cancellationToken))
                .Where(_ => _.SourceEdges == null || !_.SourceEdges.Any())
                .SelectMany(_ => _.DepthFirstSearch(
                    edge => edge.Destination,
                    location => location.DestinationEdges,
                    _ => { }))
                .ToList();
            var allLocationsIds = allLocations
                .Select(_ => _.InnerId)
                .ToList();
            var allLocationsEdges = (await _otifChart.GetLocationsEdges(
                allLocationsIds,
                cancellationToken)).ToList();

            foreach (var location in allLocations)
            {
                var sourceIds = allLocationsEdges
                    .Where(_ => _.DestinationId == location.Id)
                    .Select(_ => _.SourceId);
                var sourcesVertex = allLocations.Where(_ => sourceIds.Contains(_.Id));
                location.AddSourceEdges(sourcesVertex.Select(_ => new LocationEdge(_, location)));

                var destinationIds = allLocationsEdges
                    .Where(_ => _.SourceId == location.Id)
                    .Select(_ => _.DestinationId);
                var destinationVertex = allLocations.Where(_ => destinationIds.Contains(_.Id));
                location.AddDestinationEdges(destinationVertex.Select(_ => new LocationEdge(location, _)));
            }

            if (!query.LocationsIds.Any())
            {
                _locations = allLocations;
                return;
            }

            var locationsFromFilter = new List<Location>();

            foreach (var location in allLocations)
            {
                location.DepthFirstSearch(
                    _ => _.Destination,
                    _ => _.DestinationEdges!,
                    _ =>
                    {
                        if (existingIdsFromFilter.Contains(_.InnerId))
                            locationsFromFilter.Add(_);
                    });
            }

            var locations = new List<Location>();

            foreach (var location in locationsFromFilter)
            {
                locations.AddRange(location.DepthFirstSearch(
                    _ => _.Destination,
                    _ => _.DestinationEdges!,
                    _ => { }));
            }

            if (!locations.Any())
                locations = allLocations;

            _locations = locations
                .Distinct()
                .ToList();
        }
    }
}
