﻿using Supply.Dashboards.Domain.AggregatesModel.WeatherRestrictions;
using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.WeatherRestrictions.GetWeatherRestrictionsList.Output
{
    public sealed class GetWeatherRestrictionsListOutput
    {
        private readonly List<GetWeatherRestrictionsListItemOutput> _weatherRestrictions;

        public GetWeatherRestrictionsListOutput(IEnumerable<WeatherRestriction>? weatherRestrictions)
        {
            _weatherRestrictions = weatherRestrictions
                ?.Select(ToGetWeatherRestrictionsListItemOutput)
                .ToList() ?? new List<GetWeatherRestrictionsListItemOutput>();
        }

        public IEnumerable<GetWeatherRestrictionsListItemOutput> Items =>
            _weatherRestrictions.AsReadOnly();

        private static GetWeatherRestrictionsListItemOutput ToGetWeatherRestrictionsListItemOutput(WeatherRestriction weatherRestriction)
        {
            return new(
                weatherRestriction.InnerId,
                weatherRestriction.Payload.DateTime,
                weatherRestriction.Payload.Customer?.InnerId,
                weatherRestriction.Payload.Location!.InnerId,
                weatherRestriction.Payload.Location!.Payload.Title,
                weatherRestriction.Payload.Location!.Payload.Latitude ?? 0,
                weatherRestriction.Payload.Location!.Payload.Longitude ?? 0,
                weatherRestriction.Payload.Temperature,
                weatherRestriction.Payload.WindSpeed,
                weatherRestriction.Payload.Aktirovka);
        }
    }
}
