﻿using Supply.Dashboards.Shared.Types;

using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Charts.CargoGroupByPeriods
{
    public sealed class CargoGroupByPeriodsRequestViewModel
    {
        public ChartPeriodEnum Period { get; set; }
        public ChartDataEnum DataType { get; set; }

        public DateTime StartPeriod { get; set; }
        public TimeSpan? Duration { get; set; }

        public List<Guid>? LocationsIds { get; set; }
        public List<Guid>? CustomersIds { get; set; }
        public List<Guid>? MtrTypesIds { get; set; }
    }
}
