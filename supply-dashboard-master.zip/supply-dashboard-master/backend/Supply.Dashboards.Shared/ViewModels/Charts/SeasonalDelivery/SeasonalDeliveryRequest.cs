﻿
using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Charts.SeasonalDelivery
{
    public sealed class SeasonalDeliveryRequest
    {
        /// <summary>
        /// DateTime (required)
        /// </summary>
        public DateTime DateTime { get; set; }

        public Guid? ParentLocationId { get; set; }

        /// <summary>
        /// Locations ids (optional)
        /// </summary>
        public List<Guid>? LocationsIds { get; set; }

        /// <summary>
        /// Customers ids (optional)
        /// </summary>
        public List<Guid>? CustomersIds { get; set; }

        /// <summary>
        /// Classifier MTR types ids (optional)
        /// </summary>
        public List<Guid>? MtrTypesIds { get; set; }
    }
}
