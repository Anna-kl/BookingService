﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supply.Dashboards.Shared.ViewModels.Charts.TransportResources
{
    public sealed class TransportResourcesByLocationsParamResponseViewModel
    {
        public Guid LocationId { get; set; }
        public string? LocationTitle { get; set; }

        public List<TransportResourcesUnitResponseViewModel>? Units { get; set; }
    }
}
