﻿using Supply.Dashboards.Shared.Types;

using System;

namespace Supply.Dashboards.Shared.ViewModels.Import.ImportDirectories.Request
{
    public sealed class ImportDirectoriesLocationRequestViewModel
    {
        public Guid Id { get; set; }
        public uint RowVersion { get; set; }
        public LocationTypeEnum Type { get; set; }
        public string? Title { get; set; }
        public string? Description { get; set; }

        public double? Longitude { get; set; }
        public double? Latitude { get; set; }
        public double? Diameter { get; set; }

        public bool? IsObsolete { get; set; }
    }
}
