﻿using FluentValidation;

namespace Supply.Dashboards.App.UseCases.ContextUserSettings.GetContextUserSettings.Input
{
    public sealed class GetContextUserSettingsValidator
        : AbstractValidator<GetContextUserSettingsQuery>
    {
        public GetContextUserSettingsValidator()
        {
            ValidateContextId();
            ValidateUserId();
        }

        private void ValidateContextId() =>
            RuleFor(_ => _.ContextId)
                .Must(_ => _ > 0);

        private void ValidateUserId() =>
            RuleFor(_ => _.UserId)
                .Must(_ => _ > 0);

    }
}
