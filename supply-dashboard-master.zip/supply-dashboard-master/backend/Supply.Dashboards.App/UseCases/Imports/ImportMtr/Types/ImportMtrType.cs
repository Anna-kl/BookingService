﻿using Common.SeedWork;

using Supply.Dashboards.App.Exceptions;
using Supply.Dashboards.Domain.Types;

namespace Supply.Dashboards.App.UseCases.Imports.ImportMtr.Types
{
    public sealed class ImportMtrType : Enumeration
    {
#pragma warning disable CA2211 // Non-constant fields should not be visible
        public static ImportMtrType Default = new(0, "Default");

        public static ImportMtrType CargoHandlingFact = new(100, "CargoHandlingFact");
        public static ImportMtrType CargoHandlingPlan = new(101, "CargoHandlingPlan");
        public static ImportMtrType CargoHandlingAdjustedPlan = new(102, "CargoHandlingAdjustedPlan");
        public static ImportMtrType CargoHandlingDailyPlan = new(103, "CargoHandlingDailyPlan");

        public static ImportMtrType FreightTurnoverFact = new(200, "FreightTurnoverFact");
        public static ImportMtrType FreightTurnoverPlan = new(201, "FreightTurnoverPlan");
        public static ImportMtrType FreightTurnoverAdjustedPlan = new(202, "FreightTurnoverAdjustedPlan");
        public static ImportMtrType FreightTurnoverDailyPlan = new(203, "FreightTurnoverDailyPlan");

        public static ImportMtrType ArrivalFact = new(204, "ArrivalFact");
        public static ImportMtrType ArrivalPlan = new(205, "ArrivalPlan");
        public static ImportMtrType ArrivalAdjustedPlan = new(206, "ArrivalAdjustedPlan");
        public static ImportMtrType ArrivalDailyPlan = new(207, "ArrivalDailyPlan");

        public static ImportMtrType ExpenditureFact = new(208, "ExpenditureFact");
        public static ImportMtrType ExpenditurePlan = new(209, "ExpenditurePlan");
        public static ImportMtrType ExpenditureAdjustedPlan = new(210, "ExpenditureAdjustedPlan");
        public static ImportMtrType ExpenditureDailyPlan = new(211, "ExpenditureDailyPlan");

        public static ImportMtrType SeasonalDeliveryFact = new(300, "SeasonalDeliveryFact");
        public static ImportMtrType SeasonalDeliveryPlan = new(301, "SeasonalDeliveryPlan");
        public static ImportMtrType SeasonalDeliveryAdjustedPlan = new(302, "SeasonalDeliveryAdjustedPlan");
        public static ImportMtrType SeasonalDeliveryDailyPlan = new(303, "SeasonalDeliveryDailyPlan");

        public static ImportMtrType AccountingMtrTotalSupplies = new(400, "AccountingMtrTotalSupplies");
        public static ImportMtrType AccountingMtrProcessing = new(401, "AccountingMtrProcessing");
        public static ImportMtrType AccountingMtrUncapitalize0_14 = new(402, "AccountingMtrUncapitalize0_14");
        public static ImportMtrType AccountingMtrUncapitalize15_30 = new(403, "AccountingMtrUncapitalize15_30");
        public static ImportMtrType AccountingMtrUncapitalize31_60 = new(404, "AccountingMtrUncapitalize31_60");
        public static ImportMtrType AccountingMtrUncapitalize61More = new(405, "AccountingMtrUncapitalize61More");

        public static ImportMtrType BidPlan = new(500, "BidPlan");
        public static ImportMtrType BidForecast = new(501, "BidForecast");
        public static ImportMtrType BidTotalFact = new(502, "BidTotalFact");
        public static ImportMtrType BidScheduledFact = new(503, "BidScheduledFact");
        public static ImportMtrType BidUnplanned = new(504, "BidUnplanned");

        public static ImportMtrType HseDeath = new(600, "HseDeath");
        public static ImportMtrType HseDisability = new(601, "HseDisability");
        public static ImportMtrType HseMedicalCare = new(602, "HseMedicalCare");
        public static ImportMtrType HseNearMiss = new(603, "HseNearMiss");
        public static ImportMtrType HseDangerWarning = new(604, "HseDangerWarning");

        public static ImportMtrType TransportPlan = new(701, "TransportPlan");
        public static ImportMtrType TransportFact = new(702, "TransportFact");
        public static ImportMtrType GPMPlan = new(703, "GPMPlan");
        public static ImportMtrType GPMFact = new(704, "GPMFact");
        public static ImportMtrType LaborResourcesPlan = new(705, "LaborResourcesPlan");
        public static ImportMtrType LaborResourcesFact = new(706, "LaborResourcesFact");

        public static ImportMtrType FullnessBasesTotalSquare = new(801, "FullnessBasesTotalSquare");
        public static ImportMtrType FullnessBasesLoaded = new(802, "FullnessBasesLoaded");
        public static ImportMtrType FullnessBasesLoadedRubles = new(803, "FullnessBasesLoadedRubles");
        public static ImportMtrType FullnessBasesLoadedWeight = new(804, "FullnessBasesLoadedWeight");
#pragma warning restore CA2211 // Non-constant fields should not be visible

        public ImportMtrType(int id, string name) : base(id, name)
        {
        }

        #region ValueRecords

        internal static bool IsValueRecordType(ImportMtrType type)
        {
            return type.Name switch
            {
                nameof(Default) => false,

                nameof(CargoHandlingFact) => true,
                nameof(CargoHandlingPlan) => true,
                nameof(CargoHandlingAdjustedPlan) => true,
                nameof(CargoHandlingDailyPlan) => true,

                nameof(FreightTurnoverFact) => true,
                nameof(FreightTurnoverPlan) => true,
                nameof(FreightTurnoverAdjustedPlan) => true,
                nameof(FreightTurnoverDailyPlan) => true,

                nameof(ArrivalFact) => true,
                nameof(ArrivalPlan) => true,
                nameof(ArrivalAdjustedPlan) => true,
                nameof(ArrivalDailyPlan) => true,

                nameof(ExpenditureFact) => true,
                nameof(ExpenditurePlan) => true,
                nameof(ExpenditureAdjustedPlan) => true,
                nameof(ExpenditureDailyPlan) => true,

                nameof(SeasonalDeliveryFact) => true,
                nameof(SeasonalDeliveryPlan) => true,
                nameof(SeasonalDeliveryAdjustedPlan) => true,
                nameof(SeasonalDeliveryDailyPlan) => true,

                nameof(AccountingMtrTotalSupplies) => true,
                nameof(AccountingMtrProcessing) => true,
                nameof(AccountingMtrUncapitalize0_14) => true,
                nameof(AccountingMtrUncapitalize15_30) => true,
                nameof(AccountingMtrUncapitalize31_60) => true,
                nameof(AccountingMtrUncapitalize61More) => true,

                nameof(TransportPlan) => true,
                nameof(TransportFact) => true,
                nameof(GPMPlan) => true,
                nameof(GPMFact) => true,
                nameof(LaborResourcesPlan) => true,
                nameof(LaborResourcesFact) => true,

                nameof(FullnessBasesTotalSquare) => true,
                nameof(FullnessBasesLoaded) => true,
                nameof(FullnessBasesLoadedRubles) => true,
                nameof(FullnessBasesLoadedWeight) => true,

                _ => false
            };
        }

        internal static ValueRecordType GetValueRecordType(ImportMtrType type)
        {
            var name = type.Name switch
            {
                nameof(Default) => throw new AppException(nameof(Default)),

                nameof(CargoHandlingFact) => ValueRecordType.CargoHandlingFact.Name,
                nameof(CargoHandlingPlan) => ValueRecordType.CargoHandlingPlan.Name,
                nameof(CargoHandlingAdjustedPlan) => ValueRecordType.CargoHandlingAdjustedPlan.Name,
                nameof(CargoHandlingDailyPlan) => ValueRecordType.CargoHandlingDailyPlan.Name,

                nameof(FreightTurnoverFact) => ValueRecordType.FreightTurnoverFact.Name,
                nameof(FreightTurnoverPlan) => ValueRecordType.FreightTurnoverPlan.Name,
                nameof(FreightTurnoverAdjustedPlan) => ValueRecordType.FreightTurnoverAdjustedPlan.Name,
                nameof(FreightTurnoverDailyPlan) => ValueRecordType.FreightTurnoverDailyPlan.Name,

                nameof(ArrivalFact) => ValueRecordType.ArrivalFact.Name,
                nameof(ArrivalPlan) => ValueRecordType.ArrivalPlan.Name,
                nameof(ArrivalAdjustedPlan) => ValueRecordType.ArrivalAdjustedPlan.Name,
                nameof(ArrivalDailyPlan) => ValueRecordType.ArrivalDailyPlan.Name,

                nameof(ExpenditureFact) => ValueRecordType.ExpenditureFact.Name,
                nameof(ExpenditurePlan) => ValueRecordType.ExpenditurePlan.Name,
                nameof(ExpenditureAdjustedPlan) => ValueRecordType.ExpenditureAdjustedPlan.Name,
                nameof(ExpenditureDailyPlan) => ValueRecordType.ExpenditureDailyPlan.Name,

                nameof(SeasonalDeliveryFact) => ValueRecordType.SeasonalDeliveryFact.Name,
                nameof(SeasonalDeliveryPlan) => ValueRecordType.SeasonalDeliveryPlan.Name,
                nameof(SeasonalDeliveryAdjustedPlan) => ValueRecordType.SeasonalDeliveryAdjustedPlan.Name,
                nameof(SeasonalDeliveryDailyPlan) => ValueRecordType.SeasonalDeliveryDailyPlan.Name,

                nameof(AccountingMtrTotalSupplies) => ValueRecordType.AccountingMtrTotalSupplies.Name,
                nameof(AccountingMtrProcessing) => ValueRecordType.AccountingMtrProcessing.Name,
                nameof(AccountingMtrUncapitalize0_14) => ValueRecordType.AccountingMtrUncapitalize0_14.Name,
                nameof(AccountingMtrUncapitalize15_30) => ValueRecordType.AccountingMtrUncapitalize15_30.Name,
                nameof(AccountingMtrUncapitalize31_60) => ValueRecordType.AccountingMtrUncapitalize31_60.Name,
                nameof(AccountingMtrUncapitalize61More) => ValueRecordType.AccountingMtrUncapitalize61More.Name,

                nameof(TransportPlan) => ValueRecordType.TransportPlan.Name,
                nameof(TransportFact) => ValueRecordType.TransportFact.Name,
                nameof(GPMPlan) => ValueRecordType.GPMPlan.Name,
                nameof(GPMFact) => ValueRecordType.GPMFact.Name,
                nameof(LaborResourcesPlan) => ValueRecordType.LaborResourcesPlan.Name,
                nameof(LaborResourcesFact) => ValueRecordType.LaborResourcesFact.Name,

                nameof(FullnessBasesTotalSquare) => ValueRecordType.FullnessBasesTotalSquare.Name,
                nameof(FullnessBasesLoaded) => ValueRecordType.FullnessBasesLoaded.Name,
                nameof(FullnessBasesLoadedRubles) => ValueRecordType.FullnessBasesLoadedRubles.Name,
                nameof(FullnessBasesLoadedWeight) => ValueRecordType.FullnessBasesLoadedWeight.Name,

                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<ValueRecordType>(name)!;
        }

        internal static ImportMtrType GetImportMtrType(ValueRecordType type)
        {
            var name = type.Name switch
            {
                nameof(ValueRecordType.CargoHandlingFact) => CargoHandlingFact.Name,
                nameof(ValueRecordType.CargoHandlingPlan) => CargoHandlingPlan.Name,
                nameof(ValueRecordType.CargoHandlingAdjustedPlan) => CargoHandlingAdjustedPlan.Name,
                nameof(ValueRecordType.CargoHandlingDailyPlan) => CargoHandlingDailyPlan.Name,

                nameof(ValueRecordType.FreightTurnoverFact) => FreightTurnoverFact.Name,
                nameof(ValueRecordType.FreightTurnoverPlan) => FreightTurnoverPlan.Name,
                nameof(ValueRecordType.FreightTurnoverAdjustedPlan) => FreightTurnoverAdjustedPlan.Name,
                nameof(ValueRecordType.FreightTurnoverDailyPlan) => FreightTurnoverDailyPlan.Name,

                nameof(ValueRecordType.ArrivalFact) => ArrivalFact.Name,
                nameof(ValueRecordType.ArrivalPlan) => ArrivalPlan.Name,
                nameof(ValueRecordType.ArrivalAdjustedPlan) => ArrivalAdjustedPlan.Name,
                nameof(ValueRecordType.ArrivalDailyPlan) => ArrivalDailyPlan.Name,

                nameof(ValueRecordType.ExpenditureFact) => ExpenditureFact.Name,
                nameof(ValueRecordType.ExpenditurePlan) => ExpenditurePlan.Name,
                nameof(ValueRecordType.ExpenditureAdjustedPlan) => ExpenditureAdjustedPlan.Name,
                nameof(ValueRecordType.ExpenditureDailyPlan) => ExpenditureDailyPlan.Name,

                nameof(ValueRecordType.SeasonalDeliveryFact) => SeasonalDeliveryFact.Name,
                nameof(ValueRecordType.SeasonalDeliveryPlan) => SeasonalDeliveryPlan.Name,
                nameof(ValueRecordType.SeasonalDeliveryAdjustedPlan) => SeasonalDeliveryAdjustedPlan.Name,
                nameof(ValueRecordType.SeasonalDeliveryDailyPlan) => SeasonalDeliveryDailyPlan.Name,

                nameof(ValueRecordType.AccountingMtrTotalSupplies) => AccountingMtrTotalSupplies.Name,
                nameof(ValueRecordType.AccountingMtrProcessing) => AccountingMtrProcessing.Name,
                nameof(ValueRecordType.AccountingMtrUncapitalize0_14) => AccountingMtrUncapitalize0_14.Name,
                nameof(ValueRecordType.AccountingMtrUncapitalize15_30) => AccountingMtrUncapitalize15_30.Name,
                nameof(ValueRecordType.AccountingMtrUncapitalize31_60) => AccountingMtrUncapitalize31_60.Name,
                nameof(ValueRecordType.AccountingMtrUncapitalize61More) => AccountingMtrUncapitalize61More.Name,

                nameof(ValueRecordType.TransportPlan) => TransportPlan.Name,
                nameof(ValueRecordType.TransportFact) => TransportFact.Name,
                nameof(ValueRecordType.GPMPlan) => GPMPlan.Name,
                nameof(ValueRecordType.GPMFact) => GPMFact.Name,
                nameof(ValueRecordType.LaborResourcesPlan) => LaborResourcesPlan.Name,
                nameof(ValueRecordType.LaborResourcesFact) => LaborResourcesFact.Name,

                nameof(ValueRecordType.FullnessBasesTotalSquare) => FullnessBasesTotalSquare.Name,
                nameof(ValueRecordType.FullnessBasesLoaded) => FullnessBasesLoaded.Name,
                nameof(ValueRecordType.FullnessBasesLoadedRubles) => FullnessBasesLoadedRubles.Name,
                nameof(ValueRecordType.FullnessBasesLoadedWeight) => FullnessBasesLoadedWeight.Name,

                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<ImportMtrType>(name)!;
        }

        internal static bool IsPlanning(ImportMtrType type)
        {
            return type.Name switch
            {
                nameof(ValueRecordType.CargoHandlingPlan) => true,
                nameof(ValueRecordType.CargoHandlingAdjustedPlan) => true,
                nameof(ValueRecordType.CargoHandlingDailyPlan) => true,
                nameof(ValueRecordType.FreightTurnoverPlan) => true,
                nameof(ValueRecordType.FreightTurnoverAdjustedPlan) => true,
                nameof(ValueRecordType.FreightTurnoverDailyPlan) => true,
                nameof(ValueRecordType.SeasonalDeliveryPlan) => true,
                nameof(ValueRecordType.SeasonalDeliveryAdjustedPlan) => true,
                nameof(ValueRecordType.SeasonalDeliveryDailyPlan) => true,
                nameof(ValueRecordType.AccountingMtrTotalSupplies) => true,
                "BidPlan" => true,
                _ => false
            };
        }

        #endregion

        #region HseIncidents

        internal static bool IsHseIncidentType(ImportMtrType type) =>
            type.Name switch
            {
                nameof(Default) => false,
                nameof(HseDeath) => true,
                nameof(HseDisability) => true,
                nameof(HseMedicalCare) => true,
                nameof(HseNearMiss) => true,
                nameof(HseDangerWarning) => true,
                _ => false
            };

        internal static HseIncidentType GetHseIncidentType(ImportMtrType type)
        {
            var name = type.Name switch
            {
                nameof(Default) => throw new AppException(nameof(Default)),
                nameof(HseDeath) => HseIncidentType.Death.Name,
                nameof(HseDisability) => HseIncidentType.Disability.Name,
                nameof(HseMedicalCare) => HseIncidentType.MedicalCare.Name,
                nameof(HseNearMiss) => HseIncidentType.NearMiss.Name,
                nameof(HseDangerWarning) => HseIncidentType.DangerWarning.Name,
                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<HseIncidentType>(name)!;
        }

        internal static ImportMtrType GetImportMtrType(HseIncidentType type)
        {
            var name = type.Name switch
            {
                nameof(HseIncidentType.Death) => HseDeath.Name,
                nameof(HseIncidentType.Disability) => HseDisability.Name,
                nameof(HseIncidentType.MedicalCare) => HseMedicalCare.Name,
                nameof(HseIncidentType.NearMiss) => HseNearMiss.Name,
                nameof(HseIncidentType.DangerWarning) => HseDangerWarning.Name,
                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<ImportMtrType>(name)!;
        }

        #endregion

        #region Bids

        internal static bool IsBidType(ImportMtrType type) =>
            type.Name switch
            {
                nameof(Default) => false,
                nameof(BidPlan) => true,
                nameof(BidForecast) => true,
                nameof(BidTotalFact) => true,
                nameof(BidScheduledFact) => true,
                nameof(BidUnplanned) => true,
                _ => false
            };

        internal static BidType GetBidType(ImportMtrType type)
        {
            var name = type.Name switch
            {
                nameof(Default) => throw new AppException(nameof(Default)),
                nameof(BidPlan) => BidType.Plan.Name,
                nameof(BidForecast) => BidType.Forecast.Name,
                nameof(BidTotalFact) => BidType.TotalFact.Name,
                nameof(BidScheduledFact) => BidType.ScheduledFact.Name,
                nameof(BidUnplanned) => BidType.Unplanned.Name,
                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<BidType>(name)!;
        }

        internal static ImportMtrType GetImportMtrType(BidType type)
        {
            var name = type.Name switch
            {
                nameof(BidType.Plan) => BidPlan.Name,
                nameof(BidType.Forecast) => BidForecast.Name,
                nameof(BidType.TotalFact) => BidTotalFact.Name,
                nameof(BidType.ScheduledFact) => BidScheduledFact.Name,
                nameof(BidType.Unplanned) => BidUnplanned.Name,
                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<ImportMtrType>(name)!;
        }

        #endregion
    }
}
