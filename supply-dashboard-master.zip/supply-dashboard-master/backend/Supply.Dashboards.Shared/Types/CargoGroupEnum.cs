﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supply.Dashboards.Shared.Types
{
    public enum CargoGroupEnum
    {
        CargoHandlingFact = 1,
        CargoHandlingPlan = 2,
        CargoHandlingAdjustedPlane = 3,
        CargoHandlingDailyPlan = 4,
        FreightTurnoverFact = 5,
        FreightTurnoverPlan = 6,
        FreightTurnoverAdjustedPlan = 7,
        FreightTurnoverDailyPlan = 8
    }
}
