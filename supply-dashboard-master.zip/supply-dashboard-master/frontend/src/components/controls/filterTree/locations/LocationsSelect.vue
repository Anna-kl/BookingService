<template>
  <div>
    <LocationEdit
      ref="locationEditRef"
      :reloadTree="reloadLocationTree"
      :loadDataItemFromApi="loadLocationFromApi"
      :loadDataItemsFromApi="loadLocationsFromApi"
    />
    <DirectoryTree
      ref="locationsDirectoryTreeRef"
      treeRef="locationsTreeRef"
      :loadDataItemFromApi="loadLocationFromApi"
      :loadDataItemsFromApi="loadLocationsFromApi"
      :createRootItem="createLocationsTreeRoot"
      :deleteDataItem="deleteLocation"
      :addDataItem="addLocation"
      :editDataItem="editLocation"
      :setSelectedDataItems="setSelectedLocations"
      :refreshTree="refreshLocationsTree"
      :pageType="pageType"
    />
  </div>
</template>

<script lang='ts'>
import Vue from "vue";
import { DxCheckBox } from "devextreme-vue/check-box";
import { Component, Prop, Watch } from "vue-property-decorator";
import DxButton from "devextreme-vue/button";
import { InputDataState, SettingsState } from "@/store";
import { InputDataService } from "@/services/inputDataService";
import { Guid } from "@/helpers/guid";
import { confirm } from "devextreme/ui/dialog";
import notify from "devextreme/ui/notify";
import DirectoryTree from "../DirectoryTree.vue";
import LocationEdit from "./LocationEdit.vue";
import {
  IDirectoryDataItem,
  IDirectoryTreeDataItem,
  ILocationDataItem,
  ISelectedLocation,
  ILocation,
  LocationTypeEnum,
  IRelation,
  ITreeListItemRelation,
  ITreeListSelectedItem,
} from "../types";
import { ILocationForGrid } from "@/components/InputData/common/models";

@Component({
  components: {
    DxCheckBox,
    LocationEdit,
    DxButton,
    DirectoryTree,
  },
})
export default class LocationsForm extends Vue {
  @Prop({ type: String, required: true }) public pageType!: string;

  private currentVisibleCheck: string = "";
  private locationTreeData: ILocationDataItem[] = [];
  private _inputDataService!: InputDataService;
  private contextMenuClickItem!: any;
  private showTreeEdit: boolean = false;
  private customLoadTree: boolean = false;
  private currentParentIdForLoad: string = "";
  private focusedRowKey: string = "";
  private menuItems!: any[];
  private rootTreeListId = Guid.newGuid();
  private idRelations: any[] = [];

  private created() {
    this._inputDataService = new InputDataService();
  }

  private refreshLocationsTree() {
    const pickedLocationsIds =
      SettingsState.pickedDashboardItem?.config?.locationsIds;
    const items: string[] = [];

    pickedLocationsIds?.forEach((relation: ITreeListItemRelation) => {
      items.push(relation.id);
    });

    const directoryTree = this.locationsTree.directoryTree;
    SettingsState.setReadOnly(true);
    directoryTree.clearSelection();
    SettingsState.setReadOnly(false);
    directoryTree.selectRows(items, false);
  }

  private addLocation(parentDbId: string) {
    this.showTreeEdit = true;
    const newLocation = {
      id: Guid.newGuid(),
      rowVersion: 0,
      hasItems: false,
      type:
        parentDbId === ""
          ? LocationTypeEnum.Division
          : LocationTypeEnum.Direction,
      parentIds: [parentDbId],
      title: "",
      description: "",
      longitude: 0,
      latitude: 0,
      diameter: 1,
      childrenIds: [],
    };

    this.locationEdit.add(newLocation);
  }

  private get locationEdit() {
    return this.$refs["locationEditRef"] as LocationEdit;
  }

  private get locationsTree() {
    return this.$refs["locationsDirectoryTreeRef"] as DirectoryTree;
  }

  private createLocationsTreeRoot(
    rootId: string,
    childrenIds: string[]
  ): IDirectoryTreeDataItem {
    return {
      id: rootId,
      rowVersion: 0,
      title: "Дивизионы",
      description: "Корневой элемент",
      hasItems: childrenIds.length > 0 ? true : false,
      parentId: "",
    };
  }

  private async editLocation(dbId: string) {
    const location = await this._inputDataService.getLocationForId(dbId);

    if (location === null) {
      return;
    }

    this.locationEdit.edit({
      id: location.id,
      parentIds: location.parentIds === undefined ? [] : location.parentIds!,
      rowVersion: location.rowVersion,
      type: location.type,
      title: location.title === undefined ? "" : location.title,
      description:
        location.description === undefined ? "" : location.description,
      childrenIds: location.childrenIds,
      longitude: location.longitude,
      latitude: location.latitude,
      diameter: location.diameter,
    } as ILocationDataItem);
  }

  private async deleteLocation(dbId: string) {
    const location = await this._inputDataService.getLocationForId(dbId);

    if (location === null) {
      return;
    }

    const relations: IRelation[] = [];

    location!.childrenIds.forEach((childrenId) => {
      relations.push({
        sourceId: location!.id,
        destinationId: childrenId,
        isObsolete: true,
      });
    });

    location!.parentIds!.forEach((parentDbId) => {
      relations.push({
        sourceId: parentDbId,
        destinationId: location.id,
        isObsolete: true,
      });
    });

    await this._inputDataService
      .saveLocation(
        {
          id: location.id,
          rowVersion: location.rowVersion,
          isObsolete: true,
          title: location.title,
          type: location.type,
          childrenIds: location.childrenIds,
        },
        relations
      )
      .then(() => {
        this.reloadLocationTree();
      });
  }

  private async loadLocationFromApi(
    dbId: string
  ): Promise<IDirectoryDataItem | null> {
    const location = await this._inputDataService.getLocationForId(dbId);
    if (location !== undefined && location !== null) {
      return {
        id: location.id,
        rowVersion: location.rowVersion,
        parentIds: location.parentIds === undefined ? [] : location.parentIds!,
        title: location.title === undefined ? "" : location.title,
        description: location.description,
        childrenIds: location.childrenIds,
      };
    } else {
      return null;
    }
  }

  private async loadLocationsFromApi(
    parentDbIds: any[],
    types: any[]
  ): Promise<IDirectoryDataItem[]> {
    const locations: ILocation[] = await this._inputDataService.getActiveLocationsForParentIds(
      parentDbIds,
      types
    );

    if (locations !== undefined && locations !== null) {
      return locations.map((s) => {
        return {
          id: s.id,
          rowVersion: s.rowVersion,
          parentIds: s.parentIds === undefined ? [] : s.parentIds!,
          title: s.title === undefined ? "" : s.title,
          childrenIds: s.childrenIds,
          description: s.description,
        };
      });
    } else {
      return [];
    }
  }

  private async setSelectedLocations(items: ITreeListSelectedItem[]) {
    if (this.pageType === "graph") {
      SettingsState.setSelectedLocations(items);
    }

    if (this.pageType === "inputData") {
      const ids = items.filter((a) => a.selected).map<string>((s) => s.dbId);

      const finedEmptyItem = ids.find((s) => s === "");

      if (finedEmptyItem === undefined) {
        const locations: ILocation[] = await this._inputDataService.getActiveLocationsForIds(
          ids,
          []
        );
        const finedLocations = locations.map<ILocationForGrid>((s) => {
          return {
            id: s.id,
            title: s.title!,
            type: s.type,
            longitude: s.longitude,
            latitude: s.latitude,
          };
        });
        InputDataState.setSelectedLocations(finedLocations);
      } else {
        InputDataState.clearSelectedLocations();
      }
    }
  }

  public reloadLocationTree(): any {
    this.locationsTree.reloadTree();
  }
}
</script>

<style scoped>
.location-item-container {
  overflow: hidden;
  width: 100%;
  height: 26px;
}
.box {
  white-space: inherit;
}
.box div {
  width: 34px;
  float: left;
}
.box div.location-title {
  width: 300px;
  float: left;
  padding-left: 34px;
}

.action-buttons {
  position: absolute;
  left: 320px;
  width: 110px;
  margin-top: -5px;
}

.action-buttons div {
  float: left;
}
</style>