﻿using Common.SeedWork;

using Supply.Dashboards.Domain.Exceptions;
using Supply.Dashboards.Domain.Types;

using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Domain.AggregatesModel.MtrTypes
{
    /// <summary>
    ///     Material technical resource directory
    /// </summary>
    public sealed class MtrType : Aggregate
    {
        private readonly List<MtrTypeEdge>? _sourceEdges;
        private readonly List<MtrTypeEdge>? _destinationEdges;

        #region c'tors

        public MtrType(
            Guid id,
            MtrTypePayload payload)
        {
            Id = default;
            InnerId = id == default
                ? throw new DomainException($"{nameof(id)} can't be null.")
                : id;
            XMin = default;
            CreateAt = DateTime.UtcNow;
            UpdateAt = DateTime.UtcNow;
            Status = StatusType.Active;

            Payload = payload
                      ?? throw new DomainException($"{nameof(payload)} can't be null.");

            _sourceEdges = new List<MtrTypeEdge>();
            _destinationEdges = new List<MtrTypeEdge>();

            AddDomainEvent(new Event(InnerId.ToString(), Status, Payload));
        }

#pragma warning disable 8618
        // ReSharper disable once UnusedMember.Local
        private MtrType()
        {
        }
#pragma warning restore 8618

        #endregion

        #region props

        public uint XMin { get; private set; }
        public DateTime CreateAt { get; init; }
        public DateTime UpdateAt { get; private set; }
        public StatusType Status { get; private set; }

        public MtrTypePayload Payload { get; private set; }

        public IEnumerable<MtrTypeEdge>? SourceEdges =>
            _sourceEdges?.AsReadOnly();

        public IEnumerable<MtrTypeEdge>? DestinationEdges =>
            _destinationEdges?.AsReadOnly();

        #endregion

        #region methods

        public void ChangeStatus(StatusType status)
        {
            UpdateAt = DateTime.UtcNow;
            Status = status
                     ?? throw new DomainException($"{nameof(status)} can't be null.");

            AddDomainEvent(new Event(InnerId.ToString(), Status, Payload));
        }

        public void Update(MtrTypePayload payload)
        {
            UpdateAt = DateTime.UtcNow;
            Payload = payload
                      ?? throw new DomainException($"{nameof(payload)} can't be null.");

            AddDomainEvent(new Event(InnerId.ToString(), Status, Payload));
        }

        public void AddSourceEdges(IEnumerable<MtrTypeEdge> edges)
        {
            _sourceEdges?.AddRange(edges);
            AddDomainEvent(new Event(InnerId.ToString(), Status, Payload));
        }

        public void AddDestinationEdges(IEnumerable<MtrTypeEdge> edges)
        {
            _destinationEdges?.AddRange(edges);
            AddDomainEvent(new Event(InnerId.ToString(), Status, Payload));
        }

        #endregion
    }
}
