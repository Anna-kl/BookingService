﻿using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;
using Supply.Dashboards.Domain.AggregatesModel.ValueRecords;
using Supply.Dashboards.Domain.Types;

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.Charts.SeasonalDelivery
{
    public interface ISeasonalDelivery
    {
        #region customers

        Task<IEnumerable<Guid>> GetCustomersExistingIds(
            List<StatusType> statuses,
            List<Guid> ids,
            CancellationToken cancellationToken);

        Task<IEnumerable<Customer>> GetCustomers(
            List<StatusType> statuses,
            CancellationToken cancellationToken);

        Task<IEnumerable<CustomerEdge>> GetCustomersEdges(
            List<Guid> ids,
            CancellationToken cancellationToken);

        #endregion

        #region locations

        Task<IEnumerable<Guid>> GetLocationsExistingIds(
            List<StatusType> statuses,
            List<Guid> ids,
            CancellationToken cancellationToken);

        Task<IEnumerable<Location>> GetLocations(
            List<StatusType> statuses,
            CancellationToken cancellationToken);

        Task<IEnumerable<LocationEdge>> GetLocationsEdges(
            List<Guid> ids,
            CancellationToken cancellationToken);

        #endregion

        #region mtr types

        Task<IEnumerable<Guid>> GetMtrTypesExistingIds(
            List<StatusType> statuses,
            List<Guid> ids,
            CancellationToken cancellationToken);

        Task<IEnumerable<MtrType>> GetMtrTypes(
            List<StatusType> statuses,
            CancellationToken cancellationToken);

        Task<IEnumerable<MtrTypeEdge>> GetMtrTypesEdges(
            List<Guid> ids,
            CancellationToken cancellationToken);

        #endregion

        Task<DateTime?> GetStartPeriodWithoutNull(
            List<ValueRecordType> recordsTypes,
            DateTime dateTime,
            List<Guid>? locations,
            List<Guid>? customers,
            List<Guid>? mtrTypes,
            CancellationToken cancellationToken);

        Task<(
                IEnumerable<ValueRecord> subset,
                IEnumerable<ValueRecord> superset,
                IEnumerable<ValueRecord> crossing)>
            GetRecords(
                List<ValueRecordType> recordsTypes,
                DateTime startPeriod,
                DateTime? endPeriod,
                List<Location>? locations,
                List<Customer>? customers,
                List<MtrType>? mtrTypes,
                CancellationToken cancellationToken);
    }
}
