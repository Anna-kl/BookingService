﻿using Common.SeedWork;

using Supply.Dashboards.Domain.Exceptions;
using Supply.Dashboards.Domain.Types;

using System;

namespace Supply.Dashboards.Domain.AggregatesModel.Core
{
    public sealed class ExternalSystem : Entity
    {
        #region c'tors

        public ExternalSystem(
            Guid id,
            StatusType status,
            string title)
        {
            Id = default;
            InnerId = id == default
                ? throw new DomainException($"{nameof(id)} can't be null.")
                : id;
            XMin = default;
            CreateAt = DateTime.UtcNow;
            UpdateAt = DateTime.UtcNow;
            Status = status;
            Title = string.IsNullOrWhiteSpace(title)
                ? throw new DomainException($"{nameof(title)} can't be null or white-space.")
                : title;
        }

#pragma warning disable 8618
        // ReSharper disable once UnusedMember.Local
        private ExternalSystem()
        {
        }
#pragma warning restore 8618

        #endregion

        #region props

        public uint XMin { get; private set; }
        public DateTime CreateAt { get; init; }
        public DateTime UpdateAt { get; private set; }
        public StatusType Status { get; private set; }

        public string Title { get; private set; }

        #endregion

        #region methods

        public void ChangeStatus(StatusType status)
        {
            UpdateAt = DateTime.UtcNow;
            Status = status
                     ?? throw new DomainException($"{nameof(status)} can't be null.");
        }

        public void UpdateTitle(string title)
        {
            UpdateAt = DateTime.UtcNow;
            Title = string.IsNullOrWhiteSpace(title)
                ? throw new DomainException($"{nameof(title)} can't be null or white-space.")
                : title;
        }

        #endregion
    }
}
