﻿using Common.SeedWork;

using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;
using Supply.Dashboards.Domain.Types;

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.Imports.ImportDirectories
{
    public interface IImportDirectories
        : IRepository<Customer>
    {
        #region customers

        Task<IEnumerable<Customer>> GetCustomersByInnerIds(
            List<StatusType> statuses,
            List<Guid> innerIds,
            CancellationToken cancellationToken);

        Task<IEnumerable<Customer>> AddCustomers(
            List<Customer> customers,
            CancellationToken cancellationToken);

        Task<CustomerEdge> AddCustomerEdge(
            CustomerEdge edge,
            CancellationToken cancellationToken);

        Task<List<CustomerEdge>> RemoveCustomerEdges(
            List<CustomerEdge> edges,
            CancellationToken cancellationToken);

        #endregion

        #region locations

        Task<IEnumerable<Location>> GetLocationsByInnerIds(
            List<StatusType> statuses,
            List<Guid> ids,
            CancellationToken cancellationToken);

        Task<IEnumerable<Location>> AddLocations(
            List<Location> locations,
            CancellationToken cancellationToken);

        Task<LocationEdge> AddLocationEdge(
            LocationEdge edge,
            CancellationToken cancellationToken);

        Task<List<LocationEdge>> RemoveLocationEdges(
            List<LocationEdge> edges,
            CancellationToken cancellationToken);

        #endregion

        #region mtr types

        Task<IEnumerable<MtrType>> GetMtrTypesByInnerIds(
            List<StatusType> statuses,
            List<Guid> innerIds,
            CancellationToken cancellationToken);

        Task<IEnumerable<MtrType>> AddMtrTypes(
            List<MtrType> mtrTypes,
            CancellationToken cancellationToken);

        Task<MtrTypeEdge> AddMtrTypeEdge(
            MtrTypeEdge edge,
            CancellationToken cancellationToken);

        Task<List<MtrTypeEdge>> RemoveMtrTypeEdges(
            List<MtrTypeEdge> edges,
            CancellationToken cancellationToken);

        #endregion
    }
}
