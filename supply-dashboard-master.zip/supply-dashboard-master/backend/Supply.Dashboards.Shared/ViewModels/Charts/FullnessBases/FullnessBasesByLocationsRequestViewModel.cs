﻿using Supply.Dashboards.Shared.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supply.Dashboards.Shared.ViewModels.Charts.FullnessBases
{
    public sealed class FullnessBasesByLocationsRequestViewModel
    {
        public ChartLocationEnum LocationType { get; set; }

        /// <summary>
        /// Start period (required)
        /// </summary>
        public DateTime StartPeriod { get; set; }

        /// <summary>
        /// Duration (optional)
        /// </summary>
        public TimeSpan? Duration { get; set; }

        public Guid? ParentLocationId { get; set; }

        /// <summary>
        /// Locations ids (optional)
        /// </summary>
        public List<Guid>? LocationsIds { get; set; }

        /// <summary>
        /// Customers ids (optional)
        /// </summary>
        public List<Guid>? CustomersIds { get; set; }

        public List<Guid>? MtrTypesIds { get; set; }
    }
}
