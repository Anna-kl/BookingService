export interface IContextUserSettingsResponse {
    dashboardsState: string;
}
