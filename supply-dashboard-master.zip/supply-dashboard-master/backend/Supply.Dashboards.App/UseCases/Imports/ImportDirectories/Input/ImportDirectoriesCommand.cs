﻿using FluentValidation.Results;

using MediatR;

using Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Output;
using Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Validator;

using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Input
{
    public sealed class ImportDirectoriesCommand
        : IRequest<(ValidationResult validationResult, ImportDirectoriesOutput? output)>
    {
        private readonly List<ImportDirectoriesCustomerInput> _customers;
        private readonly List<ImportDirectoriesCustomerEdgeInput> _customersEdges;
        private readonly List<ImportDirectoriesLocationInput> _location;
        private readonly List<ImportDirectoriesLocationEdgeInput> _locationEdges;
        private readonly List<ImportDirectoriesMtrTypeInput> _mtrTypes;
        private readonly List<ImportDirectoriesMtrTypeEdgeInput> _mtrTypesEdges;

        public ImportDirectoriesCommand(
            IEnumerable<ImportDirectoriesCustomerInput>? customers,
            IEnumerable<ImportDirectoriesCustomerEdgeInput>? customersEdges,
            IEnumerable<ImportDirectoriesLocationInput>? location,
            IEnumerable<ImportDirectoriesLocationEdgeInput>? locationEdges,
            IEnumerable<ImportDirectoriesMtrTypeInput>? mtrTypes,
            IEnumerable<ImportDirectoriesMtrTypeEdgeInput>? mtrTypesEdges)
        {
            _customers = customers?.ToList() ?? new List<ImportDirectoriesCustomerInput>();
            _customersEdges = customersEdges?.ToList() ?? new List<ImportDirectoriesCustomerEdgeInput>();
            _location = location?.ToList() ?? new List<ImportDirectoriesLocationInput>();
            _locationEdges = locationEdges?.ToList() ?? new List<ImportDirectoriesLocationEdgeInput>();
            _mtrTypes = mtrTypes?.ToList() ?? new List<ImportDirectoriesMtrTypeInput>();
            _mtrTypesEdges = mtrTypesEdges?.ToList() ?? new List<ImportDirectoriesMtrTypeEdgeInput>();

            ValidationResult = new ImportDirectoriesValidator()
                .Validate(this);
        }

        public IEnumerable<ImportDirectoriesCustomerInput> Customers =>
            _customers.AsReadOnly();

        public IEnumerable<ImportDirectoriesCustomerEdgeInput> CustomersEdges =>
            _customersEdges.AsReadOnly();

        public IEnumerable<ImportDirectoriesLocationInput> Locations =>
            _location.AsReadOnly();

        public IEnumerable<ImportDirectoriesLocationEdgeInput> LocationsEdges =>
            _locationEdges.AsReadOnly();

        public IEnumerable<ImportDirectoriesMtrTypeInput> MtrTypes =>
            _mtrTypes.AsReadOnly();

        public IEnumerable<ImportDirectoriesMtrTypeEdgeInput> MtrTypesEdges =>
            _mtrTypesEdges.AsReadOnly();

        public ValidationResult ValidationResult { get; }
    }
}
