﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Supply.Dashboards.App.UserInfo;
using Supply.Dashboards.Domain.AggregatesModel.Core;
using Supply.Dashboards.Domain.Types;
using Supply.Dashboards.Infrastructure.Data;
using System;
using System.Linq;

namespace Supply.Dashboards.Infrastructure.UseCasesRepositories
{
    public sealed class UserRepository : IAuthInfo
    {
        private readonly ILogger<UserRepository> _logger;
        private readonly DashboardsContext _dashboardsContext;
        private static readonly object Locker = new();

        public UserRepository(
            ILogger<UserRepository> logger,
            DashboardsContext dashboardsContext)
        {
            _logger = logger;
            _dashboardsContext = dashboardsContext;
        }

        public Context? GetContextById(string userNameIdentifier, int contextId) =>
            _dashboardsContext
                .Contexts
                .Include(_ => _.ContextUsers)
                .ThenInclude(_ => _.User)
                .Where(_ => _.Id == contextId)
                .SingleOrDefault(_ => _.ContextUsers.Select(user => user.User.NameIdentifier).FirstOrDefault() == userNameIdentifier);

        public void CreateUser(
            string userNameIdentifier,
            Context context)
        {
            lock (Locker)
            {
                var user = _dashboardsContext
                    .Users
                    .SingleOrDefault(_ => _.NameIdentifier == userNameIdentifier);

                if (user != null)
                    return;

                _dashboardsContext
                    .Users
                    .Add(new User(
                        Guid.NewGuid(),
                        userNameIdentifier,
                        StatusType.Active,
                        "NO NAME",
                        context));

                _dashboardsContext.SaveChanges();
            }
        }

        public Context? GetContextByInnerId(Guid innerId)
        {
            return _dashboardsContext
                .Contexts
                .SingleOrDefault(_ => _.InnerId == innerId);
        }

        public Context? GetContextById(int id)
        {
            return _dashboardsContext
                .Contexts
                .SingleOrDefault(_ => _.Id == id);
        }

        public User? GetUserByNameIdentifier(string userNameIdentifier)
        {
            return _dashboardsContext
                .Users
                .SingleOrDefault(_ => _.NameIdentifier == userNameIdentifier);
        }

    }
}
