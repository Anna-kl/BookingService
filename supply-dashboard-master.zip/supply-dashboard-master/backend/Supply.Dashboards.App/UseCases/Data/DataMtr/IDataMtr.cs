﻿using Supply.Dashboards.Domain.AggregatesModel.Bids;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.HseIncidents;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;
using Supply.Dashboards.Domain.AggregatesModel.ValueRecords;
using Supply.Dashboards.Domain.Types;

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.Data.DataMtr
{
    public interface IDataMtr
    {
        public Task<IEnumerable<ValueRecord>> ValueRecordsGet(
            List<ValueRecordType> recordsTypes,
            DateTime startPeriod,
            DateTime? endPeriod,
            List<Guid>? locationsInnerIds,
            List<Guid>? customersInnerIds,
            List<Guid>? mtrTypesInnerIds,
            CancellationToken cancellationToken);

        Task<IEnumerable<HseIncident>> HseIncidentGet(
            List<HseIncidentType> incidentTypes,
            DateTime startPeriod,
            DateTime? endPeriod,
            List<Guid>? locationsInnerIds,
            List<Guid>? customersInnerIds,
            CancellationToken cancellationToken);

        Task<IEnumerable<Bid>> BidsGet(
            List<BidType> bidTypes,
            DateTime startPeriod,
            DateTime? endPeriod,
            List<Guid>? locationsInnerIds,
            List<Guid>? customersInnerIds,
            CancellationToken cancellationToken);

        Task<IEnumerable<Customer>> GetCustomersByInnerIds(
            List<Guid> innerIds,
            CancellationToken cancellationToken);

        Task<IEnumerable<Location>> GetLocationsByInnerIds(
            List<Guid> ids,
            CancellationToken cancellationToken);

        Task<IEnumerable<MtrType>> GetMtrTypesByInnerIds(
            List<Guid> innerIds,
            CancellationToken cancellationToken);
    }
}
