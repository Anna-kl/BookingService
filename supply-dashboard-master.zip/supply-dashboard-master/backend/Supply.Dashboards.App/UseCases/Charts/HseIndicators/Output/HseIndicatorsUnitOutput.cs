﻿using Supply.Dashboards.App.UseCases.Charts.HseIndicators.Types;

namespace Supply.Dashboards.App.UseCases.Charts.HseIndicators.Output
{
    public sealed class HseIndicatorsUnitOutput
    {
        public HseIndicatorsUnitOutput(
            HseIndicatorType type,
            int count)
        {
            Type = type;
            Count = count;
        }

        public HseIndicatorType Type { get; }
        public int Count { get; }
    }
}
