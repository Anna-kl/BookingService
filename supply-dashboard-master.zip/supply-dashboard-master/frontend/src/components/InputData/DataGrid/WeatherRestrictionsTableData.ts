import { daysInMonth, getMonthEnd, getMonthStart, utcFromLocalDate } from '@/helpers/utils';
import { InputDataService } from '@/services/inputDataService';
import { DateTime, Interval } from 'luxon';
import { TimeSpan } from '@/helpers/timeSpan';
import DataSource from 'devextreme/data/data_source';
import { Column, dxDataGridColumn, dxDataGridOptions } from "devextreme/ui/data_grid";
import { ICustomerForGrid, ILocationForGrid, } from '../common/models';
import notify from "devextreme/ui/notify";
import CustomStore from 'devextreme/data/custom_store';
import { LoadOptions } from 'devextreme/data/load_options';
import { dxElement } from 'devextreme/core/element';

export class WeatherRestrictionsTableData {

    public tableConfig: dxDataGridOptions;
    private _inputDataService = new InputDataService();
    private firstDayMonth: string;
    private lastDayMonth: string;
    private locations: ILocationForGrid[];
    private customers: ICustomerForGrid[];

    constructor(date: Date, locations: ILocationForGrid[], customers: ICustomerForGrid[]) {

        this.firstDayMonth = getMonthStart(date);
        this.lastDayMonth = getMonthEnd(date);
        this.customers = customers.map<ICustomerForGrid>((s) => {
            return { id: s.id, title: s.title }
        });

        this.locations = locations;

        this.tableConfig = this.createTableConfig();
    }

    private getGridDataSource() {
        const me = this;

        return new DataSource({
            load: (loadOptions: LoadOptions) => me.loadData(loadOptions),
            update: (data: any, values: any) => me.updateData(data, values),
            insert: (values: any) => me.insertData(values),
            remove: (data: any) => me.removeData(data.id),
        });
    }

    private async loadData(loadOptions: LoadOptions): Promise<any> {
        const response = await this._inputDataService.getWeatherRestrictionsForTable(this.firstDayMonth, this.lastDayMonth, this.locations.map(s => s.id), this.customers.map(s => s.id!))
        return {
            data: response.items
        };
    }

    private async updateData(data: any, values: any): Promise<any> {
        values.customerId = values.customerId ?? data.customerId;
        values.aktirovka = values.aktirovka ?? data.aktirovka;
        values.dateTime = values.dateTime ?? data.dateTime;
        values.locationId = values.locationId ?? data.locationId;
        values.temperature = values.temperature ?? data.temperature;
        values.windSpeed = values.windSpeed ?? data.windSpeed;
        await this._inputDataService.addOrUpdateWeatherRestriction(data.id, values)
            .then((data) => {
                notify("Данные успешно сохранены.", "success", 3000);

            })
            .catch((error) => {
                notify(`${error.message}`, "error", 3000);
            });
    }

    private async removeData(id: string): Promise<any> {
        await this._inputDataService.removeWeatherRestriction(id)
            .then((data) => {
                notify("Запись успешно удалена.", "success", 3000);

            })
            .catch((error) => {
                notify(`${error.message}`, "error", 3000);
            });
    }

    private async insertData(values: any): Promise<any> {
        await this._inputDataService.addOrUpdateWeatherRestriction(values.id, values)
            .then((data) => {
                notify("Данные успешно сохранены.", "success", 3000);

            })
            .catch((error) => {
                notify(`${error.message}`, "error", 3000);
            });
    }

    private createTableConfig(): dxDataGridOptions {
        const config: dxDataGridOptions = {
            columns: this.columns(),
            dataSource: this.getGridDataSource(),
            allowColumnResizing: true,
            showBorders: true,
            columnResizingMode: "widget",
            width: "100%",
            selection: { mode: "none" },
            groupPanel: { visible: true },
            onRowDblClick: (e: any) => e.component.editRow(e.rowIndex),
            editing: {
                allowAdding: true,
                allowUpdating: true,
                allowDeleting: true,
                mode: "popup",
                useIcons: true,
                confirmDelete: true,
                popup: {
                    width: 480,
                    height: 470,
                    showTitle: true,
                    title: "Изменение/добавление"
                }
            },
            paging: { enabled: true, pageSize: 20 },
            columnFixing: { enabled: true },
            export: { enabled: true },
            scrolling: {
                mode: 'virtual',
                useNative: false,
                scrollByThumb: true,
                scrollByContent: true,
                showScrollbar: 'always',
            },
            filterRow: {
                visible: true
            },
            remoteOperations: {
                filtering: false,
                sorting: false,
                paging: false
            }
        };

        return config;
    }

    private columns(): Column[] {
        const retData: Column[] = [
            {
                caption: "География",
                dataField: "locationId",
                groupIndex: 0,
                allowEditing: true,
                allowFiltering: false,
                fixed: true,
                sortOrder: "asc",
                formItem: {
                    colSpan: 2,
                },
                lookup: {
                    dataSource: this.locations,
                    valueExpr: "id",
                    displayExpr: "title"
                },
                groupCellTemplate: (e: any, cellInfo: any) => this.setGroupText(e, cellInfo, this.locations)
            },
            {
                caption: "Заказчик",
                dataField: "customerId",
                sortOrder: "asc",
                fixed: true,
                allowEditing: true,
                allowFiltering: false,
                width: 300,
                formItem: {
                    colSpan: 2,
                },
                lookup: {
                    dataSource: this.customers,
                    valueExpr: "id",
                    displayExpr: "title"
                }
            },
            {
                caption: "Дата",
                dataField: "dateTime",
                dataType: "date",
                width: 120,
                formItem: {
                    colSpan: 2,
                },
            },
            {
                caption: "Температура",
                dataField: "temperature",
                dataType: "number",
                width: 120,

            },
            {
                caption: "Скорость ветра",
                dataField: "windSpeed",
                dataType: "number",
                width: 120,
            },
            {
                caption: "Актировка",
                dataField: "aktirovka",
                dataType: "string",
                formItem: {
                    colSpan: 2,
                    editorOptions: { height: 100 },
                    editorType: "dxTextArea"
                }
            }

        ];

        return retData;
    }

    private setGroupText(element: any, cellInfo: any, locations: ILocationForGrid[]) {
        const location: ILocationForGrid = locations.find(s => s.id === cellInfo.value)!;
        if (location.latitude !== undefined && location.longitude !== undefined && location.latitude !== 0 && location.longitude !== 0) {
            element.innerHTML = `<a href="https://www.windy.com/?${location.longitude},${location.latitude},11" target="_blank">${cellInfo.displayValue}</a>`;
        } else {
            element.innerHTML = `${cellInfo.displayValue}`;
        }

    }

}