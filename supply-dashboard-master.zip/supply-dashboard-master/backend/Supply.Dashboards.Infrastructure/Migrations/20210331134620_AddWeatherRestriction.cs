﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

namespace Supply.Dashboards.Infrastructure.Migrations
{
    public partial class AddWeatherRestriction : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "weather_restrictions",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    createat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    updateat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    payload_datetime = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    payload_customerid = table.Column<int>(type: "integer", nullable: true),
                    payload_locationid = table.Column<int>(type: "integer", nullable: true),
                    payload_inputtype = table.Column<int>(type: "integer", nullable: false),
                    payload_temperature = table.Column<double>(type: "double precision", nullable: false),
                    payload_windspeed = table.Column<double>(type: "double precision", nullable: false),
                    payload_aktirovka = table.Column<string>(type: "text", nullable: true),
                    contextid = table.Column<int>(type: "integer", nullable: false),
                    innerid = table.Column<Guid>(type: "uuid", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_weather_restrictions", x => x.id);
                    table.UniqueConstraint("AK_weather_restrictions_innerid", x => x.innerid);
                    table.ForeignKey(
                        name: "FK_weather_restrictions_contexts_contextid",
                        column: x => x.contextid,
                        principalTable: "contexts",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_weather_restrictions_customers_payload_customerid",
                        column: x => x.payload_customerid,
                        principalTable: "customers",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_weather_restrictions_locations_payload_locationid",
                        column: x => x.payload_locationid,
                        principalTable: "locations",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_weather_restrictions_contextid",
                table: "weather_restrictions",
                column: "contextid");

            migrationBuilder.CreateIndex(
                name: "IX_weather_restrictions_payload_customerid",
                table: "weather_restrictions",
                column: "payload_customerid");

            migrationBuilder.CreateIndex(
                name: "IX_weather_restrictions_payload_locationid",
                table: "weather_restrictions",
                column: "payload_locationid");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "weather_restrictions");
        }
    }
}
