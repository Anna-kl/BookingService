﻿using Supply.Dashboards.App.Types;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;
using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Output
{
    public sealed class ImportDirectoriesOutput
    {
        private readonly List<ImportDirectoriesCustomerOutput> _addedCustomers;
        private readonly List<ImportDirectoriesCustomerOutput> _updatedCustomers;
        private readonly List<ImportDirectoriesCustomerOutput> _removedCustomers;

        private readonly List<ImportDirectoriesCustomerEdgeOutput> _addedCustomersRelations;
        private readonly List<ImportDirectoriesCustomerEdgeOutput> _removedCustomersRelations;

        private readonly List<ImportDirectoriesLocationOutput> _addedLocations;
        private readonly List<ImportDirectoriesLocationOutput> _updatedLocations;
        private readonly List<ImportDirectoriesLocationOutput> _removedLocations;

        private readonly List<ImportDirectoriesLocationEdgeOutput> _addedLocationsRelations;
        private readonly List<ImportDirectoriesLocationEdgeOutput> _removedLocationsRelations;

        private readonly List<ImportDirectoriesMtrTypeOutput> _addedMtrTypes;
        private readonly List<ImportDirectoriesMtrTypeOutput> _updatedMtrTypes;
        private readonly List<ImportDirectoriesMtrTypeOutput> _removedMtrTypes;

        private readonly List<ImportDirectoriesMtrTypeEdgeOutput> _addedMtrTypesRelations;
        private readonly List<ImportDirectoriesMtrTypeEdgeOutput> _removedMtrTypesRelations;

        public ImportDirectoriesOutput(
            IEnumerable<Customer> addedCustomers,
            IEnumerable<Customer> updatedCustomers,
            IEnumerable<Customer> removedCustomers,
            IEnumerable<CustomerEdge> addedCustomersRelations,
            IEnumerable<CustomerEdge> removedCustomersRelations,

            IEnumerable<Location> addedLocations,
            IEnumerable<Location> updatedLocations,
            IEnumerable<Location> removedLocations,
            IEnumerable<LocationEdge> addedLocationsRelations,
            IEnumerable<LocationEdge> removedLocationsRelations,

            IEnumerable<MtrType> addedMtrTypes,
            IEnumerable<MtrType> updatedMtrTypes,
            IEnumerable<MtrType> removedMtrTypes,
            IEnumerable<MtrTypeEdge> addedMtrTypesRelations,
            IEnumerable<MtrTypeEdge> removedMtrTypesRelations)
        {
            _addedCustomers = addedCustomers.Select(ToImportDirectoriesCustomerOutput).ToList();
            _updatedCustomers = updatedCustomers.Select(ToImportDirectoriesCustomerOutput).ToList();
            _removedCustomers = removedCustomers.Select(ToImportDirectoriesCustomerOutput).ToList();
            _addedCustomersRelations = addedCustomersRelations.Select(ToImportDirectoriesCustomerEdgeOutput).ToList();
            _removedCustomersRelations = removedCustomersRelations.Select(ToImportDirectoriesCustomerEdgeOutput).ToList();

            _addedLocations = addedLocations.Select(ToImportDirectoriesLocationOutput).ToList();
            _updatedLocations = updatedLocations.Select(ToImportDirectoriesLocationOutput).ToList();
            _removedLocations = removedLocations.Select(ToImportDirectoriesLocationOutput).ToList();
            _addedLocationsRelations = addedLocationsRelations.Select(ToImportDirectoriesLocationEdgeOutput).ToList();
            _removedLocationsRelations = removedLocationsRelations.Select(ToImportDirectoriesLocationEdgeOutput).ToList();

            _addedMtrTypes = addedMtrTypes.Select(ToImportDirectoriesMtrTypeOutput).ToList();
            _updatedMtrTypes = updatedMtrTypes.Select(ToImportDirectoriesMtrTypeOutput).ToList();
            _removedMtrTypes = removedMtrTypes.Select(ToImportDirectoriesMtrTypeOutput).ToList();
            _addedMtrTypesRelations = addedMtrTypesRelations.Select(ToImportDirectoriesMtrTypeEdgeOutput).ToList();
            _removedMtrTypesRelations = removedMtrTypesRelations.Select(ToImportDirectoriesMtrTypeEdgeOutput).ToList();
        }

        public IEnumerable<ImportDirectoriesCustomerOutput> AddedCustomers => _addedCustomers.AsReadOnly();
        public IEnumerable<ImportDirectoriesCustomerOutput> UpdatedCustomers => _updatedCustomers.AsReadOnly();
        public IEnumerable<ImportDirectoriesCustomerOutput> RemovedCustomers => _removedCustomers.AsReadOnly();
        public IEnumerable<ImportDirectoriesCustomerEdgeOutput> AddedCustomersRelations => _addedCustomersRelations.AsReadOnly();
        public IEnumerable<ImportDirectoriesCustomerEdgeOutput> RemovedCustomersRelations => _removedCustomersRelations.AsReadOnly();

        public IEnumerable<ImportDirectoriesLocationOutput> AddedLocations => _addedLocations.AsReadOnly();
        public IEnumerable<ImportDirectoriesLocationOutput> UpdatedLocations => _updatedLocations.AsReadOnly();
        public IEnumerable<ImportDirectoriesLocationOutput> RemovedLocations => _removedLocations.AsReadOnly();
        public IEnumerable<ImportDirectoriesLocationEdgeOutput> AddedLocationsRelations => _addedLocationsRelations.AsReadOnly();
        public IEnumerable<ImportDirectoriesLocationEdgeOutput> RemovedLocationsRelations => _removedLocationsRelations.AsReadOnly();

        public IEnumerable<ImportDirectoriesMtrTypeOutput> AddedMtrTypes => _addedMtrTypes.AsReadOnly();
        public IEnumerable<ImportDirectoriesMtrTypeOutput> UpdatedMtrTypes => _updatedMtrTypes.AsReadOnly();
        public IEnumerable<ImportDirectoriesMtrTypeOutput> RemovedMtrTypes => _removedMtrTypes.AsReadOnly();
        public IEnumerable<ImportDirectoriesMtrTypeEdgeOutput> AddedMtrTypesRelations => _addedMtrTypesRelations.AsReadOnly();
        public IEnumerable<ImportDirectoriesMtrTypeEdgeOutput> RemovedMtrTypesRelations => _removedMtrTypesRelations.AsReadOnly();

        private static ImportDirectoriesCustomerOutput ToImportDirectoriesCustomerOutput(Customer customer)
        {
            return new(
                customer.InnerId,
                customer.XMin,
                AppStatusType.GetAppStatusType(customer.Status),
                AppCustomerType.GetAppCustomerType(customer.Payload.Type),
                customer.Payload.Title,
                customer.Payload.Description);
        }

        private static ImportDirectoriesCustomerEdgeOutput ToImportDirectoriesCustomerEdgeOutput(CustomerEdge edge)
        {
            return new(
                edge.SourceInnerId,
                edge.DestinationInnerId);
        }

        private static ImportDirectoriesLocationOutput ToImportDirectoriesLocationOutput(Location location)
        {
            return new(
                location.InnerId,
                location.XMin,
                AppStatusType.GetAppStatusType(location.Status),
                AppLocationType.GetAppLocationType(location.Payload.Type),
                location.Payload.Title,
                location.Payload.Description,
                location.Payload.Longitude,
                location.Payload.Latitude,
                location.Payload.Diameter);
        }

        private static ImportDirectoriesLocationEdgeOutput ToImportDirectoriesLocationEdgeOutput(LocationEdge edge)
        {
            return new(
                edge.SourceInnerId,
                edge.DestinationInnerId);
        }

        private static ImportDirectoriesMtrTypeOutput ToImportDirectoriesMtrTypeOutput(MtrType mtrType)
        {
            return new(
                mtrType.InnerId,
                mtrType.XMin,
                AppStatusType.GetAppStatusType(mtrType.Status),
                mtrType.Payload.Title);
        }

        private static ImportDirectoriesMtrTypeEdgeOutput ToImportDirectoriesMtrTypeEdgeOutput(MtrTypeEdge edge)
        {
            return new(
                edge.SourceInnerId,
                edge.DestinationInnerId);
        }
    }
}
