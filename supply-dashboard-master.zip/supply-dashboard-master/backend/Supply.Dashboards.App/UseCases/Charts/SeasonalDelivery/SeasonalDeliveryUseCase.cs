﻿using FluentValidation.Results;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Supply.Dashboards.App.UseCases.Charts.SeasonalDelivery.Input;
using Supply.Dashboards.App.UseCases.Charts.SeasonalDelivery.Output;
using Supply.Dashboards.App.UseCases.Charts.SeasonalDelivery.Types;
using Supply.Dashboards.App.UseCases.ValueRecords;
using Supply.Dashboards.Domain.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.Charts.SeasonalDelivery
{
    public sealed class SeasonalDeliveryUseCase
        : IRequestHandler<SeasonalDeliveryQuery, (ValidationResult validationResult, SeasonalDeliveryOutput? output)>
    {
        private readonly ILogger<SeasonalDeliveryUseCase> _logger;
        private readonly IMediator _mediator;
        private readonly IValueRecords _valueRecordsRepo;

        private ValidationResult _validationResult;
        private readonly List<StatusType> _selectStatus;

        public SeasonalDeliveryUseCase(
            ILogger<SeasonalDeliveryUseCase> logger,
            IMediator mediator,
            IValueRecords valueRecordsRepo)
        {
            _logger = logger;
            _mediator = mediator;
            _valueRecordsRepo = valueRecordsRepo;
            _validationResult = new ValidationResult();
            _selectStatus = new List<StatusType> { StatusType.Active };
        }

        public async Task<(ValidationResult validationResult, SeasonalDeliveryOutput? output)> Handle(
            SeasonalDeliveryQuery request,
            CancellationToken cancellationToken)
        {
            _validationResult = request.ValidationResult;

            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            var valueRecordTypes = new List<ValueRecordType>
            {
                ValueRecordType.SeasonalDeliveryFact,
                ValueRecordType.SeasonalDeliveryPlan,
                ValueRecordType.SeasonalDeliveryAdjustedPlan,
                ValueRecordType.SeasonalDeliveryDailyPlan
            };

            var resultItems = new List<SeasonalDeliveryParamOutput>();

            // период вычислений, запроса всех исходных данных, отсечение лишних для повышения производительносьти,
            // условно год назад, если данные вводятся корректно, то этого периода должно быть более чем достаточно
            var startDate = request.DateTime.AddYears(-1);

            var valueRecordsAsQueryable = _valueRecordsRepo.GetRecords(
                valueRecordTypes,
                null,
                request.ParentLocationId,
                request.LocationsIds,
                request.CustomersIds,
                request.MtrTypesIds,
                _selectStatus,
                cancellationToken
            );

            var allRecordsToSelectedDate = await valueRecordsAsQueryable.Where(record =>
                    record.Payload.StartPeriod <= request.DateTime
                    && record.Payload.StartPeriod >= startDate)
                .Select(_ => new
                {
                    location = _.Payload.Location!,
                    type = _.Payload.Type,
                    startDate = _.Payload.StartPeriod,
                    endDate = _.Payload.EndPeriod,
                    value = _.Payload.Value
                }).ToListAsync(cancellationToken);

            // вычисляем дату начала периода для каждой локации
            foreach (var currentLocation in allRecordsToSelectedDate.Select(_ => _.location).Distinct())
            {
                var currentLocationRecords =
                    allRecordsToSelectedDate.Where(_ => _.location == currentLocation).ToList();
                var currentDate = request.DateTime;
                var finedNotEmptyValue = false;

                // идет по данным назад по дате, ищем условие начала периода, значения всех типов данных на день должно быть равно 0 или отсутствовать
                for (var i = 1; i < (request.DateTime - startDate).Days; i++)
                {
                    currentDate = request.DateTime.AddDays(-i);
                    var date = currentDate;
                    var tmpData = currentLocationRecords.Where(_ =>
                        _.startDate == date && _.endDate == date.AddDays(1)
                        || _.startDate <= date && _.endDate >= date && (_.type == ValueRecordType.SeasonalDeliveryPlan ||
                                                                        _.type == ValueRecordType.SeasonalDeliveryAdjustedPlan));
                    var notEmpty = tmpData.Any();
                    if (!notEmpty)
                    {
                        if (finedNotEmptyValue)
                            // нашли начало периода, причем после него есть значения
                            break;
                    }
                    else
                    {
                        finedNotEmptyValue = true;
                    }
                }

                // искомый набор данных для локации
                var finedData = currentLocationRecords.Where(_ =>
                        _.startDate >= currentDate ||
                        _.startDate < currentDate && _.endDate >= request.DateTime.AddDays(1))
                    .ToList();

                // вычисляем для каждого типа
                var factData = finedData.Where(_ => _.type == ValueRecordType.SeasonalDeliveryFact).Sum(_ => _.value);

                var dailyPlanData = finedData.Where(_ => _.type == ValueRecordType.SeasonalDeliveryDailyPlan)
                    .Sum(_ => _.value);

                // все значения до месяца, в котором дата окончания периода
                var planData = finedData
                    .Where(_ =>
                        _.endDate <= request.DateTime.AddDays(1)
                        && _.type == ValueRecordType.SeasonalDeliveryPlan)
                    .Sum(_ => _.value);
                var planDataInEndPeriodMonth = finedData
                    .FirstOrDefault(_ => _.endDate > request.DateTime.AddDays(1) && _.type == ValueRecordType.SeasonalDeliveryPlan);

                if (planDataInEndPeriodMonth != null)
                    planData += planDataInEndPeriodMonth.value /
                        DateTime.DaysInMonth(request.DateTime.Year, request.DateTime.Month) * request.DateTime.Day;

                var adjustedPlanDataList = finedData.Where(_ =>
                        _.endDate <= request.DateTime.AddDays(1) &&
                        _.type == ValueRecordType.SeasonalDeliveryAdjustedPlan)
                    .ToList(); // все значения до месяца, в котором дата окончания периода
                var adjustedPlanData = adjustedPlanDataList.Sum(_ => _.value);
                var adjustedPlanDataInEndPeriodMonth = finedData
                    .FirstOrDefault(_ => _.endDate > request.DateTime.AddDays(1) &&
                                         _.type == ValueRecordType.SeasonalDeliveryAdjustedPlan);
                if (adjustedPlanDataInEndPeriodMonth != null)
                    adjustedPlanData += adjustedPlanDataInEndPeriodMonth.value / DateTime.DaysInMonth(request.DateTime.Year, request.DateTime.Month) * request.DateTime.Day;
                // если значения отсутствуют, то берем из плана
                if (adjustedPlanDataList.Count == 0 && adjustedPlanDataInEndPeriodMonth == null)
                    adjustedPlanData = planData;

                if (!(factData == 0 && dailyPlanData == 0 && planData == 0 && adjustedPlanData == 0))
                    resultItems.Add(new SeasonalDeliveryParamOutput(
                        currentLocation.InnerId,
                        currentLocation.Payload.Title,
                        new List<SeasonalDeliveryUnitOutput>()
                        {
                            new(
                                SeasonalDeliveryType.GetSeasonalDeliveryType(ValueRecordType.SeasonalDeliveryFact),
                                factData),
                            new(
                                SeasonalDeliveryType.GetSeasonalDeliveryType(ValueRecordType.SeasonalDeliveryDailyPlan),
                                dailyPlanData),
                            new(
                                SeasonalDeliveryType.GetSeasonalDeliveryType(ValueRecordType.SeasonalDeliveryPlan),
                                planData),
                            new(
                                SeasonalDeliveryType.GetSeasonalDeliveryType(ValueRecordType
                                    .SeasonalDeliveryAdjustedPlan),
                                adjustedPlanData)
                        }
                    ));
            }

            return (_validationResult, new SeasonalDeliveryOutput(resultItems));
        }
    }
}