﻿using FluentValidation;

namespace Supply.Dashboards.App.UseCases.Charts.OtifChart.Input
{
    public sealed class OtifChartValidator
        : AbstractValidator<OtifChartQuery>
    {
        public OtifChartValidator()
        {
            ValidateStartPeriod();
            ValidateEndPeriod();
            ValidateCustomersIds();
            ValidateLocationsIds();
        }

        private void ValidateStartPeriod() =>
            RuleFor(_ => _.StartPeriod)
                .NotEmpty();

        private void ValidateEndPeriod() =>
            RuleFor(_ => _.EndPeriod)
                .NotEmpty();

        private void ValidateCustomersIds() =>
            RuleForEach(_ => _.CustomersIds);

        private void ValidateLocationsIds() =>
            RuleForEach(_ => _.LocationsIds);
    }
}
