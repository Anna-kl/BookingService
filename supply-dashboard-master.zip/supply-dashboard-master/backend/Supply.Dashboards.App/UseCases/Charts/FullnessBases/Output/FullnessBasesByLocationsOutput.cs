﻿using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.Charts.FullnessBases.Output
{
    public sealed class FullnessBasesByLocationsOutput
    {
        private readonly List<FullnessBasesByLocationsParamOutput> _locations;

        internal FullnessBasesByLocationsOutput(List<FullnessBasesByLocationsParamOutput> locations)
        {
            _locations = locations;
        }
        public IEnumerable<FullnessBasesByLocationsParamOutput> Locations =>
            _locations.OrderBy(_ => _.LocationTitle).ToList().AsReadOnly();

    }
}
