﻿using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;
using Supply.Dashboards.Domain.Types;

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.MtrTypes.GetMtrTypeList
{
    public interface IGetMtrTypeList
    {
        Task<IEnumerable<MtrType>> Get(
            List<StatusType> statuses,
            List<MtrType>? destinationList,
            List<Guid>? ids,
            bool includeRoot,
            CancellationToken cancellationToken);

        Task<IEnumerable<MtrType>> GetByIds(
            List<StatusType> statuses,
            List<Guid> ids,
            CancellationToken cancellationToken);
    }
}
