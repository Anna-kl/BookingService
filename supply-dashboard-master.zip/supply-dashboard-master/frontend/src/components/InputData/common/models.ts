import { CustomerTypeEnum, LocationTypeEnum, MtrItemTypeEnum } from "@/dto/InputData";
import { DateTime } from "luxon";

export interface ICustomerForGrid {
    id: string | null;
    title: string;
}

export interface ILocationForGrid {
    id: string;
    type: LocationTypeEnum;
    title: string;
    longitude?: number;
    latitude?: number;
}

export interface IDirectoryDataItem {
    id: string;
    rowVersion: number;
    parentIds: any[];
    title: string;
    childrenIds: string[];
    description?: string;
}
export interface ILocationDataItem extends IDirectoryDataItem {
    rowVersion: number;
    longitude?: number;
    latitude?: number;
    diameter?: number;
    type: LocationTypeEnum;
}
export interface ICustomerDataItem extends IDirectoryDataItem {
    type: CustomerTypeEnum;
}

export interface IMtrTypeDataItem extends IDirectoryDataItem {

}

export interface ITreeEditItem {
    id: string;
    rowVersion: number;
    parentId: string;
    title: string;
    description?: string;
    hasItems: boolean;
}

export interface ITreeListItemRelation {
    id: string;
    dbId: string;
    parentId: string;
}

export interface IDirectoryTreeDataItem {
    id: string;
    rowVersion: number;
    parentId: string;
    title: string;
    hasItems: boolean;
    description?: string;
}


export enum InputDataTypeEnum {
    WeatherRestrictions = "WeatherRestrictions",
    CommonTable = "CommonTable"
}

export interface IInputDataType {
    id: InputDataTypeEnum;
    name: string;
}

export interface ITreeListMtrItemDataType {
    id: string;
    parentId: string;
    name: string;
    selected?: boolean;
    type?: MtrItemTypeEnum;
}

export interface IMtrItemTransformed {
    rowVersion: number;
    startPeriod: DateTime;
    dateType: DateTypeEnum;
    year: number;
    month?: number;
    week?: number;
    day?: number;
    customerId: string | null;
    locationId?: string;
    mtrTypeId?: string;
    type: string;
    value?: number | null;
}

export enum DateTypeEnum {
    Year,
    Month,
    Week,
    Day
}
