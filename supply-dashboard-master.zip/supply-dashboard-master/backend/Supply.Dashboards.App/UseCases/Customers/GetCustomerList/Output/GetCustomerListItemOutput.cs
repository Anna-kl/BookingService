﻿using Supply.Dashboards.App.Types;
using Supply.Dashboards.Domain.Types;

using System;
using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.Customers.GetCustomerList.Output
{
    public sealed class GetCustomerListItemOutput
    {
        internal GetCustomerListItemOutput(
            Guid id,
            uint xmin,
            List<Guid> sourceIds,
            List<Guid> destinationIds,
            StatusType status,
            AppCustomerType type,
            string title,
            string? description)
        {
            Id = id;
            RowVersion = xmin;
            SourceIds = sourceIds;
            DestinationIds = destinationIds;
            Status = status;
            Type = type;
            Title = title;
            Description = description;
        }

        public Guid Id { get; }
        public uint RowVersion { get; }

        public List<Guid> SourceIds { get; }
        public List<Guid> DestinationIds { get; }

        public StatusType Status { get; }
        public AppCustomerType Type { get; }
        public string Title { get; set; }
        public string? Description { get; set; }
    }
}
