﻿using Common.SeedWork;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Supply.Dashboards.App.UserInfo;
using Supply.Dashboards.Domain.AggregatesModel.Core;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.Types;

namespace Supply.Dashboards.Infrastructure.TypeConfigurations.AggregatesModel.Customers
{
    public sealed class CustomerTypeConfig : IEntityTypeConfiguration<Customer>
    {
        public void Configure(EntityTypeBuilder<Customer> builder)
        {
            builder.ToTable("customers");

            builder.HasKey(_ => _.Id);
            builder.HasAlternateKey(_ => _.InnerId);
            builder
                .Property(_ => _.Id)
                .ValueGeneratedOnAdd();

            builder
                .Property(_ => _.XMin)
                .HasColumnName("xmin")
                .HasColumnType("xid")
                .ValueGeneratedOnAddOrUpdate()
                .IsConcurrencyToken();

            builder
                .HasOne<Context>()
                .WithMany()
                .HasForeignKey("ContextId")
                .IsRequired();
            builder.HasQueryFilter(_ => UserInfo.Context == null
                ? EF.Property<int>(_, "ContextId") != 0
                : EF.Property<int>(_, "ContextId") == UserInfo.Context.Id);

            builder
                .Property(_ => _.Status)
                .HasConversion(
                    type => type.Id,
                    key => Enumeration.FromValue<StatusType>(key)!);

            builder
                .OwnsOne(_ => _.Payload)
                .Property(payload => payload.Type)
                .HasConversion(
                    type => type.Id,
                    key => Enumeration.FromValue<CustomerType>(key)!);

            builder.Ignore(_ => _.DomainEvents);
        }
    }
}
