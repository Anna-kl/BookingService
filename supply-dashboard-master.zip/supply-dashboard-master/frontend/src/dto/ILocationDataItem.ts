import { IDirectoryDataItem } from "./IDirectoryDataItem";
import { LocationTypeEnum } from "@/dto/InputData";

export interface ILocationDataItem extends IDirectoryDataItem {
    longitude?: number;
    latitude?: number;
    diameter?: number;
    type: LocationTypeEnum;
}