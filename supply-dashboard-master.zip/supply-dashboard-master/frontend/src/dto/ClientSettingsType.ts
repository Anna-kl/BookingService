export interface IClientSettingsType {
    authenticationHost: string;
}
