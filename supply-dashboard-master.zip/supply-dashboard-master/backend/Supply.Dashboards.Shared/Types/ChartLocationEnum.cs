﻿namespace Supply.Dashboards.Shared.Types
{
    public enum ChartLocationEnum
    {
        All = 0,
        Division = 1,
        Direction = 2,
        Node = 3
    }
}
