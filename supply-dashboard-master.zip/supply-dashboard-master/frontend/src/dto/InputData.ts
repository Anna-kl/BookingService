// common

export enum MtrItemTypeEnum {
    CargoHandlingFact = 1,
    CargoHandlingPlan = 2,
    CargoHandlingAdjustedPlan = 3,
    CargoHandlingDailyPlan = 4,
    CargoHandlingPerformed = 9114, // на бэке Performed поля удалены, но тут нужны для расчета

    FreightTurnoverFact = 5,
    FreightTurnoverPlan = 6,
    FreightTurnoverAdjustedPlan = 7,
    FreightTurnoverDailyPlan = 8,
    FreightTurnoverPerformed = 9118,

    ArrivalFact = 300,
    ArrivalPlan = 301,
    ArrivalAdjustedPlan = 302,
    ArrivalDailyPlan = 303,

    ExpenditureFact = 304,
    ExpenditurePlan = 305,
    ExpenditureAdjustedPlan = 306,
    ExpenditureDailyPlan = 307,

    SeasonalDeliveryFact = 9,
    SeasonalDeliveryPlan = 10,
    SeasonalDeliveryAdjustedPlan = 11,
    SeasonalDeliveryDailyPlan = 12,
    SeasonalDeliveryPerformed = 9112,

    AccountingMtrTotalSupplies = 15,
    AccountingMtrProcessing = 23,
    AccountingMtrUncapitalize0_14 = 24,
    AccountingMtrUncapitalize15_30 = 25,
    AccountingMtrUncapitalize31_60 = 26,
    AccountingMtrUncapitalize61More = 27,

    OtifApplicationsPlan = 16,
    OtifApplicationsFactTotal = 17,
    OtifApplicationsFactOnTime = 18,

    HseDeath = 100,
    HseDisability = 101,
    HseMedicalCare = 102,
    HseNearMiss = 103,
    HseDangerWarning = 104,

    BidPlan = 200,
    BidForecast = 201,
    BidTotalFact = 202,
    BidScheduledFact = 203,
    BidUnplanned = 204,
    BidOTIF = 205,

    TransportPlan = 701,
    TransportFact = 702,
    GPMPlan = 703,
    GPMFact = 704,
    LaborResourcesPlan = 705,
    LaborResourcesFact = 706,

    FullnessBasesTotalSquare = 801,
    FullnessBasesLoaded = 802,
    FullnessBasesLoadedRubles = 803,
    FullnessBasesLoadedWeight = 804
}

export interface IMtrItem {
    rowVersion: number;
    startPeriod: string;
    customerId: string | null;
    locationId?: string;
    mtrTypeId?: string;
    type: string;
    value?: number | null;
}

export interface ILocation {
    id: string;
    rowVersion: number;
    type: LocationTypeEnum;
    parentIds?: string[];
    title?: string;
    description?: string;
    longitude?: number;
    latitude?: number;
    diameter?: number;
    childrenIds: string[];
    isObsolete?: boolean;
}

export enum LocationTypeEnum {
    Division = "Division",
    Direction = "Direction",
    Node = "Node"
}

export enum CustomerTypeEnum {
    Inner = "Inner",
    External = "External"
}


export interface ICustomer {
    id: string;
    rowVersion: number;
    title?: string;
    description?: string;
    type: CustomerTypeEnum;
    parentIds?: string[];
    childrenIds: string[];
    isObsolete?: boolean;
}

export interface IRelation {
    sourceId: string,
    destinationId: string,
    isObsolete?: boolean
}

// data

export interface IDataMtrItem extends IMtrItem {
    rowVersion: number;
    endPeriod: string;
    inputType: string;
}

export interface IDataMtrRequest {
    startPeriod: string;
    endPeriod: string;
    customerIds?: string[];
    locationIds?: string[];
    mtrTypeIds?: string[];
    types?: string[];
}


// Imports

export interface IImportMtrItem extends IMtrItem {
    duration: string;

}

export interface IImportMtr {
    items: IImportMtrItem[];
}


// mtr-types

export interface IMtrType {
    id: string;
    rowVersion: number;
    title?: string;
    description?: string;
    parentIds?: string[];
    childrenIds: string[];
    isObsolete?: boolean;
}
