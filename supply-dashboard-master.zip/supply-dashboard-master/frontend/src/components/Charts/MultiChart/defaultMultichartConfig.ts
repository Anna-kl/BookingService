import IMultiChartConfig from '@/dto/IMultiChartConfig';

function config(): Partial<IMultiChartConfig> {
    return {
        settings: {
            hoverMode: "allArgumentPoints",
            selectionMode: "allArgumentPoints"
        },
        type: "bar",
        title: {
            horizontalAlignment: "left",
            subtitle: {
                fontColor: "#42a2f6"
            }
        },
        tooltip: {
            enabled: true,
            formatPrecision: 3,
            formatType: "fixedPoint"
        },
        label: {
            visible: true,
            backgroundColor: "none",
            rotationAngle: -55,
            formatPrecision: 0,
            formatType: "fixedPoint",
            fontColor: "white"
        },
        legend: {
            horizontalAlignment: "center",
            verticalAlignment: "bottom"
        }
    };
}

export default config;
