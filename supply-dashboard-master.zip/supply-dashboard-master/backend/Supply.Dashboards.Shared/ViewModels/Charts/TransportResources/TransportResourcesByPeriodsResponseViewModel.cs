﻿using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Charts.TransportResources
{
    public sealed class TransportResourcesByPeriodsResponseViewModel
    {
        public List<TransportResourcesByPeriodsParamResponseViewModel>? Periods { get; set; }
    }
}
