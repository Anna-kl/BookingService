﻿using Supply.Dashboards.App.Types;
using Supply.Dashboards.Domain.AggregatesModel.Customers;

using System;

namespace Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Input
{
    public sealed class ImportDirectoriesCustomerInput
    {
        public ImportDirectoriesCustomerInput(
            Guid? id,
            uint rowVersion,
            AppCustomerType? type,
            string title,
            string? description,
            bool? isObsolete)
        {
            Id = id ?? Guid.Empty;
            XMin = rowVersion;
            Type = type ?? AppCustomerType.Default;
            Title = title;
            Description = description;
            IsObsolete = isObsolete;
        }

        public Guid Id { get; }
        public uint XMin { get; }
        public AppCustomerType Type { get; }
        public string Title { get; }
        public string? Description { get; }

        public bool? IsObsolete { get; }

        internal Customer ToCustomer()
        {
            return new Customer(
                Id,
                new CustomerPayload(
                    AppCustomerType.GetCustomerType(Type),
                    Title,
                    Description));
        }
    }
}
