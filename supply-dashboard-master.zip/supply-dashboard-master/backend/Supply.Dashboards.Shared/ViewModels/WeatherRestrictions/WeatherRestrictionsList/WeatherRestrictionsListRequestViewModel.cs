﻿using Common.Extensions;
using Supply.Dashboards.Shared.Types;

using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.WeatherRestrictions.WeatherRestrictionsList
{
    public sealed class WeatherRestrictionsListRequestViewModel
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public List<Guid>? LocationIds { get; set; }
        public List<Guid?>? CustomerIds { get; set; }

    }
}
