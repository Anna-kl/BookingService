﻿using Common.SeedWork;

namespace Supply.Dashboards.Domain.Types
{
    public sealed class InputType : Enumeration
    {
        public static InputType ManualInput = new(1, "ManualInput");
        public static InputType Xlsx = new(2, "Xlsx");
        public static InputType Json = new(3, "Json");

        public InputType(int id, string name) : base(id, name)
        {
        }
    }
}
