﻿using Common.SeedWork;
using MediatR;
using Newtonsoft.Json;
using Supply.Dashboards.Domain.Types;
using System;

namespace Supply.Dashboards.Domain.AggregatesModel
{
    public sealed class Event : IAggregateRoot, INotification
    {
        #region c'tors

        public Event(
            string creatorId,
            StatusType payloadStatus,
            object payload)
        {
            CreateAt = DateTime.UtcNow;
            CreatorId = creatorId;
            PayloadStatus = payloadStatus;
            Payload = JsonConvert.SerializeObject(
                payload,
                Formatting.Indented,
                new JsonSerializerSettings
                {
                    ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                });
        }

#pragma warning disable 8618
        // ReSharper disable once UnusedMember.Local
        private Event()
        {
        }
#pragma warning restore 8618

        #endregion

        #region props

        public DateTime CreateAt { get; init; }
        public string CreatorId { get; init; }

        public StatusType PayloadStatus { get; init; }
        public string Payload { get; init; }

        #endregion

        public override string ToString()
        {
            return Payload;
        }
    }
}
