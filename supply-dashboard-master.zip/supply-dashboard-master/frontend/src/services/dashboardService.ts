import config from "@/config";
import { IContextUserSettingsResponse } from "@/dto/ContextUserSettings";
import { IDashboard, IDashboardItem, IDashboardLayout } from "@/dto/Dashboards";
import { Guid } from "@/helpers/guid";
import { DashboardsState } from "@/store";
import { FetchService } from "./fetchService";

export class DashboardService {

    private _fetchService = new FetchService();

    public async loadDashboardsToStore(): Promise<void> {

        const result = await this._fetchService.post<IContextUserSettingsResponse>(
            "/api/context-user-settings/get", null
        );

        const apiData: IDashboard[] | undefined = result === null ? undefined : JSON.parse(result.dashboardsState);

        if (apiData) {
            DashboardsState.setDashboards(apiData);
            DashboardsState.setCurrentDashboardId(apiData![0].id);
        } else {
            DashboardsState.setDashboards(this.createDefaultDashboards());
            DashboardsState.setCurrentDashboardId(config.defaultDashboards[0].id);
        }
    }

    public async saveDashboardsState(): Promise<void> {

        const savedObj = DashboardsState.dashboards;

        const result = await this._fetchService.post<void>(
            "/api/context-user-settings/save",
            {
                dashboardsState: JSON.stringify(savedObj),
            }
        );

        return result;
    }

    private createDefaultDashboards() {
        const dashboards: IDashboard[] = [];
        let i: number = 0;

        config.defaultDashboards.forEach((defaultDashboard: IDashboard) => {
            const layouts: IDashboardLayout[] = [];

            const dashboard: IDashboard = {
                id: i,
                name: defaultDashboard.name,
                layouts: layouts
            }

            defaultDashboard.layouts.forEach((defaultLayout: IDashboardLayout) => {

                const layout: IDashboardLayout = {
                    breakpoint: defaultLayout.breakpoint,
                    numberOfCols: defaultLayout.numberOfCols,
                    margin: defaultLayout.margin,
                    breakpointWidth: defaultLayout.breakpointWidth,
                    useCssTransforms: defaultLayout.useCssTransforms,
                    compact: defaultLayout.compact,
                    colWidth: defaultLayout.colWidth,
                    maxColWidth: defaultLayout.maxColWidth,
                    minColWidth: defaultLayout.minColWidth,
                    rowHeight: defaultLayout.rowHeight,
                    maxRowHeight: defaultLayout.maxRowHeight,
                    minRowHeight: defaultLayout.minRowHeight,
                    items: []
                }

                config.defaultDashboardItems.forEach((defaultDashboardItem: IDashboardItem) => {
                    const module = config.allDashboardModules.find(s => s.id === defaultDashboardItem.moduleId);
                    if (module) {

                        const dashboardItem: IDashboardItem = {
                            id: Guid.newGuid(),
                            x: defaultDashboardItem.x,
                            y: defaultDashboardItem.y,
                            width: module.defaultWidth ?? defaultDashboardItem.width,
                            minWidth: module.defaultMinWidth ?? defaultDashboardItem.minHeight,
                            height: module.defaultHeight ?? defaultDashboardItem.height,
                            minHeight: module.defaultMinHeight ?? defaultDashboardItem.minHeight,
                            config: module.defaultConfig !== undefined ? JSON.parse(JSON.stringify(module.defaultConfig)) : undefined,
                            series: module.defaultSeries !== undefined ? JSON.parse(JSON.stringify(module.defaultSeries)) : [],
                            maxHeight: defaultDashboardItem.maxHeight,
                            maxWidth: defaultDashboardItem.maxWidth,
                            draggable: defaultDashboardItem.draggable,
                            resizable: defaultDashboardItem.resizable,
                            resizeEdges: defaultDashboardItem.resizeEdges,
                            resizeHandleSize: defaultDashboardItem.resizeHandleSize,
                            draggableZIndex: defaultDashboardItem.draggableZIndex,
                            resizableZIndex: defaultDashboardItem.resizableZIndex,
                            moveHold: defaultDashboardItem.moveHold,
                            resizeHold: defaultDashboardItem.resizeHold,
                            dragAllowFrom: defaultDashboardItem.dragAllowFrom,
                            dragIgnoreFrom: defaultDashboardItem.dragIgnoreFrom,
                            locked: defaultDashboardItem.locked,
                            moduleId: defaultDashboardItem.moduleId,

                        };

                        layout.items.push(dashboardItem);
                    } else {
                        console.error(`Модуль с Id: ${defaultDashboardItem.moduleId} не обнаружен!`);
                    }
                });
                layouts.push(layout);
            });

            dashboards.push(dashboard);

            i++;
        });

        return dashboards;
    }

}