﻿using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Supply.Dashboards.Domain.AggregatesModel.Core;
using Supply.Dashboards.Domain.Types;
using Supply.Dashboards.Infrastructure.Data;
using System;
using System.Linq;

namespace Supply.Dashboards.Infrastructure.Extensions
{
    public static class SeedDataExtensions
    {
        public static IApplicationBuilder UseSeedDataExtensions(
            this IApplicationBuilder app)
        {
            using var serviceScope = app.ApplicationServices
                .GetService<IServiceScopeFactory>()
                ?.CreateScope();

            if (serviceScope == null)
                throw new ApplicationException(nameof(serviceScope));

            using var context = serviceScope
                .ServiceProvider
                .GetRequiredService<DashboardsContext>();

            if (!context.Contexts.Any())
            {
                context.Contexts.Add(new Context(
                    Guid.Parse("91c8087f-4525-458c-a5b6-075f90aed7de"),
                    "First context"));

                context.SaveChanges();
            }

            if (context.Customers.Any())
            {
                var removedCustomers = context
                    .Customers
                    .Include(_ => _.SourceEdges)
                    .Include(_ => _.DestinationEdges)
                    .Where(_ => _.Status == StatusType.Archived)
                    .ToList();

                var customerSourceEdges = removedCustomers
                    .Where(_ => _ != null && _.SourceEdges != null)
                    .SelectMany(_ => _.SourceEdges!)
                    .ToList();
                var customerDestinationEdges = removedCustomers
                    .Where(_ => _ != null && _.DestinationEdges != null)
                    .SelectMany(_ => _.DestinationEdges!)
                    .ToList();

                if (customerSourceEdges.Any())
                    context
                        .CustomersEdges
                        .RemoveRange(customerSourceEdges);

                if (customerDestinationEdges.Any())
                    context
                        .CustomersEdges
                        .RemoveRange(customerDestinationEdges);

                context.SaveChanges();
            }

            if (context.Locations.Any())
            {
                var removedLocations = context
                    .Locations
                    .Include(_ => _.SourceEdges)
                    .Include(_ => _.DestinationEdges)
                    .Where(_ => _.Status == StatusType.Archived)
                    .ToList();

                var locationSourceEdges = removedLocations
                    .Where(_ => _ != null && _.SourceEdges != null)
                    .SelectMany(_ => _.SourceEdges!)
                    .ToList();
                var locationDestinationEdges = removedLocations
                    .Where(_ => _ != null && _.DestinationEdges != null)
                    .SelectMany(_ => _.DestinationEdges!)
                    .ToList();

                if (locationSourceEdges.Any())
                    context
                        .LocationEdges
                        .RemoveRange(locationSourceEdges);

                if (locationDestinationEdges.Any())
                    context
                        .LocationEdges
                        .RemoveRange(locationDestinationEdges);

                context.SaveChanges();
            }

            if (context.MtrTypes.Any())
            {
                var removedMtrTypes = context
                    .MtrTypes
                    .Include(_ => _.SourceEdges)
                    .Include(_ => _.DestinationEdges)
                    .Where(_ => _.Status == StatusType.Archived)
                    .ToList();

                var mtrTypeSourceEdges = removedMtrTypes
                    .Where(_ => _ != null && _.SourceEdges != null)
                    .SelectMany(_ => _.SourceEdges!)
                    .ToList();
                var mtrTypeDestinationEdges = removedMtrTypes
                    .Where(_ => _ != null && _.DestinationEdges != null)
                    .SelectMany(_ => _.DestinationEdges!)
                    .ToList();

                if (mtrTypeSourceEdges.Any())
                    context
                        .MtrTypesEdges
                        .RemoveRange(mtrTypeSourceEdges);

                if (mtrTypeDestinationEdges.Any())
                    context
                        .MtrTypesEdges
                        .RemoveRange(mtrTypeDestinationEdges);

                context.SaveChanges();
            }

            return app;
        }
    }
}
