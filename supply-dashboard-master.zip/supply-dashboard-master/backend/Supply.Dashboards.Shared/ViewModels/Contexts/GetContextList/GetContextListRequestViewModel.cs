﻿using Supply.Dashboards.Shared.Types;
using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Contexts.GetContextList
{
    public sealed class GetContextListRequestViewModel
    {
        public List<StatusEnum>? Statuses { get; set; }
        public List<int>? Ids { get; set; }
    }
}
