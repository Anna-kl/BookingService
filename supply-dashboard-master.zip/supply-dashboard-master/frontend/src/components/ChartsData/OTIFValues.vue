<template>
  <div class="module-inner-container">
    <DxToolbar>
      <DxItem
        widget="dxButton"
        location="after"
        :options="prevButtonOptions"
        v-if="!isDayChart"
      />
      <DxItem location="after" :text="periodText()" v-if="!isDayChart" />
      <DxItem
        widget="dxButton"
        location="after"
        :options="nextButtonOptions"
        v-if="!isDayChart"
      />
      <DxItem
        widget="dxDateBox"
        location="after"
        :options="chartDateOptions"
        v-if="isDayChart"
      />
    </DxToolbar>
    <DxPieChart
      class="chart-module"
      :data-source="dataSource"
      type="doughnut"
      :palette="['#42A2F8', '#E8574E']"
    >
      <DxTitle text="OTIF (Выполнение заявок)" horizontalAlignment="left" />
      <DxSeries argument-field="value" value-field="percent">
        <DxLabel :visible="false" />
      </DxSeries>
      <DxLegend
        :margin="0"
        horizontal-alignment="right"
        vertical-alignment="top"
        :customize-items="customizeItems"
        marker-template="none"
      >
        <DxFont size="3em" />
      </DxLegend>
    </DxPieChart>
  </div>
</template>

<script lang='ts'>
import Chart from "./chart";
import { Component, Prop } from "vue-property-decorator";
import DxPieChart, {
  DxSeries,
  DxLegend,
  DxLabel,
  DxTitle,
  DxFont,
} from "devextreme-vue/pie-chart";
import { ChartDataService } from "@/services/chartDataService";
import config from "@/config";
import {
  addMonth,
  getMonthEnd,
  getMonthStart,
  getYearEnd,
  getYearStart,
  roundDate,
  yesterdayDate,
} from "@/helpers";
import { ChartPeriodEnum, IModuleConfig } from "@/dto/Dashboards";
import {
  IOTIFChartData,
  IOTIFDataRequest,
  IOTIFDataResponse,
} from "@/dto/OTIFData";
import { MtrItemTypeEnum } from "@/dto/InputData";
import DxToolbar, { DxItem } from "devextreme-vue/toolbar";

@Component({
  components: {
    DxPieChart,
    DxLegend,
    DxSeries,
    DxLabel,
    DxTitle,
    DxFont,
    DxToolbar,
    DxItem,
  },
})
export default class OTIFValues extends Chart {
  @Prop({ type: Object, required: false }) public config!: IModuleConfig;

  private url = config.remoteHost + "/api/dashboards/otif-chart";
  private curDate: Date = yesterdayDate();

  private get isDayChart() {
    return this.config?.period === ChartPeriodEnum.Day;
  }

  private dataSource: IOTIFChartData[] = [];

  private customizeItems(data: any) {
    if (data.length > 0) {
      data.forEach((item: any) => {
        const dataItem = item?.points[0].data;
        item.text =
          dataItem.value === "OTIF"
            ? `<span style="color:${
                item.marker.fill
              };">${(dataItem.percent as number).toFixed(2)}%</span> `
            : "";
      });
    }
  }

  public update() {
    this.getData(this.curDate);
  }

  private _chartDataService!: ChartDataService;

  private created() {
    this._chartDataService = new ChartDataService();
  }

  private mounted(): void {
    this.getData(this.curDate);
  }

  private async getData(curDate: Date) {
    let startPeriod: string;
    let endPeriod: string;

    switch (this.config?.period) {
      case ChartPeriodEnum.Year:
        startPeriod = getYearStart(this.curDate);
        endPeriod = getYearEnd(this.curDate);
        break;
      case ChartPeriodEnum.Day:
        startPeriod = getMonthStart(this.curDate);
        endPeriod = this.curDate.toISOString();
        break;
      case ChartPeriodEnum.Month:
      default:
        startPeriod = getMonthStart(this.curDate);
        endPeriod = getMonthEnd(this.curDate);
        break;
    }

    const locationIds =
      this.config?.locationsIds !== undefined
        ? this.config?.locationsIds
            ?.filter((f) => f.selected)
            .map<string>((s) => s.dbId)
        : [];

    const request: IOTIFDataRequest = {
      startPeriod: startPeriod,
      endPeriod: endPeriod,
      locationsIds: locationIds || [],
      customersIds: this.config?.customersIds || [],
      mtrTypesIds: this.config?.mtrTypesIds || [],
    };

    const data = await this._chartDataService
      .getOTIFData(this.url, request)
      .then((data) => {
        const response = data as IOTIFDataResponse;
        if (response) {
          this.dataSource = [
            { value: "OTIF", percent: response.otif },
            { value: "NotOTIF", percent: response.notOtif },
          ];
        }
      });
  }
  private prevButtonOptions = {
    icon: "arrowleft",
    hint: "Предыдущий период",
    onClick: () => this.prevPeriod(),
  };

  private nextButtonOptions = {
    icon: "arrowright",
    hint: "Следующий период",
    onClick: () => this.nextPeriod(),
  };
  private prevPeriod() {
    switch (this.config?.period) {
      case ChartPeriodEnum.Year:
        this.curDate.setFullYear(this.curDate.getFullYear() - 1);
        break;
      case ChartPeriodEnum.Month:
      default:
        this.curDate = addMonth(this.curDate, -1);
        break;
    }
    this.getData(this.curDate);
  }

  private nextPeriod() {
    switch (this.config?.period) {
      case ChartPeriodEnum.Year:
        this.curDate.setFullYear(this.curDate.getFullYear() + 1);
        break;
      case ChartPeriodEnum.Month:
      default:
        this.curDate = addMonth(this.curDate, 1);
        break;
    }
    this.getData(this.curDate);
  }

  private periodText() {
    let result: string;
    switch (this.config?.period) {
      case ChartPeriodEnum.Month:
        result = `${this.curDate.toLocaleString("ru", {
          month: "long",
        })} ${this.curDate.getFullYear()}`;
        break;
      case ChartPeriodEnum.Year:
      default:
        result = this.curDate.getFullYear().toString();
        break;
    }
    return result;
  }

  private chartDateOptions = {
    hint: "Выбор даты данных",
    pickerType: "rollers",
    displayFormat: "dd.MM.yyyy",
    value: this.curDate,
    onValueChanged: (args: any) => {
      const curDate = roundDate(args.value);
      this.getData(curDate);
    },
  };
}
</script>
<style lang="scss">
.label {
  font-size: 0.5em;
}
</style>

<style scoped>
.dx-toolbar {
  background: none;
}
</style>