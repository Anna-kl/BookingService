<template>
  <div>
    <div v-show="currentWorkboard === 'Dashboards'">
      <FilterTree v-show="currentWorkboard === 'Dashboards'" pageType="graph" />
      <SeriesFilter />
      <DurationPicker />
      <GraphLocationsGroupPicker />
    </div>
    <div v-show="currentWorkboard === 'InputData'">
      <FilterTree pageType="inputData" />
      <TimeStampList />
    </div>
  </div>
</template>

<script lang='ts'>
import Vue from "vue";
import { Component, Watch, Prop } from "vue-property-decorator";

import FilterTree from "@/components/controls/filterTree/FilterTree.vue";
import SeriesFilter from "@/components/controls/seriesFilter/SeriesFilter.vue";
import DurationPicker from "@/components/controls/durationPicker/DurationPicker.vue";
import GraphLocationsGroupPicker from "@/components/controls/graphLocationsGroupPicker/GraphLocationsGroupPicker.vue";
import TimeStampList from "@/components/InputData/TimeStampList.vue";
import DxButton from "devextreme-vue/button";
import DxSelectBox from "devextreme-vue/select-box";
import { DxDataGrid, DxColumn, DxEditing } from "devextreme-vue/data-grid";
import config from "@/config";
import DataSource from "devextreme/data/data_source";

@Component({
  components: {
    FilterTree,
    SeriesFilter,
    DurationPicker,
    TimeStampList,
    GraphLocationsGroupPicker,
    DxDataGrid,
    DxColumn,
    DxEditing,
    DxButton,
    DxSelectBox,
  },
})
export default class PropertyPanel extends Vue {
  @Prop({ type: String, required: true }) public currentWorkboard!: string;
}
</script>

<style lang="scss" scoped>
div {
  text-align: left;
}
</style>