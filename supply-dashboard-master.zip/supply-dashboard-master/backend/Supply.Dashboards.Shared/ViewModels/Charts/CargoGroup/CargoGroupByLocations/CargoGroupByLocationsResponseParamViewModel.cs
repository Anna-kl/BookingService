﻿using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Charts.CargoGroupByLocations
{
    public sealed class CargoGroupByLocationsResponseParamViewModel
    {
        public Guid LocationId { get; set; }
        public string? LocationTitle { get; set; }

        public List<CargoGroupByLocationsResponseUnitViewModel>? Units { get; set; }

        //public CargoGroupByLocationsResponseUnitViewModel? FactUnit { get; set; }
        //public CargoGroupByLocationsResponseUnitViewModel? PlanUnit { get; set; }
        //public CargoGroupByLocationsResponseUnitViewModel? AdjustedPlanUnit { get; set; }
        //public CargoGroupByLocationsResponseUnitViewModel? DailyPlanUnit { get; set; }
    }
}
