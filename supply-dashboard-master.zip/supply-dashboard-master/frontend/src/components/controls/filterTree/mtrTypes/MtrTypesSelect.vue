<template>
  <div>
    <MtrTypeEdit
      ref="mtrTypeEditRef"
      :reloadTree="reloadMtrTypeTree"
      :loadDataItemFromApi="loadMtrTypeFromApi"
      :loadDataItemsFromApi="loadMtrTypesFromApi"
    />
    <DirectoryTree
      ref="mtrTypesDirectoryTreeRef"
      treeRef="mtrTypesTreeRef"
      :loadDataItemFromApi="loadMtrTypeFromApi"
      :loadDataItemsFromApi="loadMtrTypesFromApi"
      :createRootItem="createMtrTypesTreeRoot"
      :deleteDataItem="deleteMtrType"
      :addDataItem="addMtrType"
      :editDataItem="editMtrType"
      :setSelectedDataItems="setSelectedMtrTypes"
      :pageType="pageType"
    />
  </div>
</template>

<script lang='ts'>
import Vue from "vue";
import { DxCheckBox } from "devextreme-vue/check-box";
import { Component, Prop, Watch } from "vue-property-decorator";
import DxButton from "devextreme-vue/button";
import { InputDataState } from "@/store";
import { InputDataService } from "@/services/inputDataService";
import MtrTypeEdit from "./MtrTypeEdit.vue";
import { Guid } from "@/helpers/guid";
import { confirm } from "devextreme/ui/dialog";
import notify from "devextreme/ui/notify";
import DirectoryTree from "../DirectoryTree.vue";
import {
  IDirectoryDataItem,
  IDirectoryTreeDataItem,
  IMtrTypeDataItem,
  IMtrType,
  IRelation,
} from "../types";

@Component({
  components: {
    DxCheckBox,
    MtrTypeEdit,
    DxButton,
    DirectoryTree,
  },
})
export default class MtrTypesForm extends Vue {
  @Prop({ type: String, required: true }) public pageType!: string;

  private currentVisibleCheck: string = "";
  private mtrTypeTreeData: IMtrTypeDataItem[] = [];
  private _inputDataService!: InputDataService;
  private contextMenuClickItem!: any;
  private showTreeEdit: boolean = false;
  private customLoadTree: boolean = false;
  private currentParentIdForLoad: string = "";
  private focusedRowKey: string = "";
  private menuItems!: any[];
  private rootTreeListId = Guid.newGuid();
  private idRelations: any[] = [];

  private created() {
    this._inputDataService = new InputDataService();
  }

  private addMtrType(parentDbId: string) {
    this.showTreeEdit = true;
    const newMtrType = {
      id: Guid.newGuid(),
      rowVersion: 0,
      hasItems: false,
      parentIds: [parentDbId],
      title: "",
      description: "",
      childrenIds: [],
    };

    this.mtrTypeEdit.add(newMtrType);
  }

  private get mtrTypeEdit() {
    return this.$refs["mtrTypeEditRef"] as MtrTypeEdit;
  }

  private get mtrTypesTree() {
    return this.$refs["mtrTypesDirectoryTreeRef"] as DirectoryTree;
  }

  private createMtrTypesTreeRoot(
    rootId: string,
    childrenIds: string[]
  ): IDirectoryTreeDataItem {
    return {
      id: rootId,
      rowVersion: 0,
      title: "Типы МТР",
      description: "Корневой элемент",
      hasItems: childrenIds.length > 0 ? true : false,
      parentId: "",
    };
  }

  private async editMtrType(dbId: string) {
    const mtrType = await this._inputDataService.getMtrTypeForId(dbId);

    if (mtrType === null) {
      return;
    }

    this.mtrTypeEdit.edit({
      id: mtrType.id,
      parentIds: mtrType.parentIds === undefined ? [] : mtrType.parentIds!,
      rowVersion: mtrType.rowVersion,
      title: mtrType.title === undefined ? "" : mtrType.title,
      description: mtrType.description === undefined ? "" : mtrType.description,
      childrenIds: mtrType.childrenIds,
    } as IMtrTypeDataItem);
  }

  private async deleteMtrType(dbId: string) {
    const mtrType = await this._inputDataService.getMtrTypeForId(dbId);

    if (mtrType === null) {
      return;
    }

    const relations: IRelation[] = [];

    mtrType!.childrenIds.forEach((childrenId) => {
      relations.push({
        sourceId: mtrType!.id,
        destinationId: childrenId,
        isObsolete: true,
      });
    });

    mtrType!.parentIds!.forEach((parentDbId) => {
      relations.push({
        sourceId: parentDbId,
        destinationId: mtrType.id,
        isObsolete: true,
      });
    });

    this._inputDataService
      .saveMtrType(
        {
          id: mtrType.id,
          rowVersion: mtrType.rowVersion,
          isObsolete: true,
          title: mtrType.title,
          childrenIds: mtrType.childrenIds,
        },
        relations
      )
      .then(() => {
        this.reloadMtrTypeTree();
      });
  }
  private async loadMtrTypeFromApi(dbId: string): Promise<IDirectoryDataItem> {
    const mtrType = await this._inputDataService.getMtrTypeForId(dbId);
    return {
      id: mtrType.id,
      rowVersion: mtrType.rowVersion,
      parentIds: mtrType.parentIds === undefined ? [] : mtrType.parentIds!,
      title: mtrType.title === undefined ? "" : mtrType.title,
      description: mtrType.description,
      childrenIds: mtrType.childrenIds,
    };
  }

  private async loadMtrTypesFromApi(
    parentDbIds: any[],
    types: any[]
  ): Promise<IDirectoryDataItem[]> {
    const mtrTypes: IMtrType[] = await this._inputDataService.getActiveMtrTypesForParentIds(
      parentDbIds,
      types
    );

    if (mtrTypes !== undefined && mtrTypes !== null) {
      return mtrTypes.map((s) => {
        return {
          id: s.id,
          rowVersion: s.rowVersion,
          parentIds: s.parentIds === undefined ? [] : s.parentIds!,
          title: s.title === undefined ? "" : s.title,
          childrenIds: s.childrenIds,
          description: s.description,
        };
      });
    } else {
      return [];
    }
  }

  private async setSelectedMtrTypes(ids: string[]) {
    //
  }

  public reloadMtrTypeTree(): any {
    this.mtrTypesTree.reloadTree();
  }
}
</script>

<style scoped>
.mtrType-item-container {
  overflow: hidden;
  width: 100%;
  height: 26px;
}

.box {
  white-space: inherit;
}

.box div {
  width: 34px;
  float: left;
}

.box div.mtrType-title {
  width: 300px;
  float: left;
  padding-left: 34px;
}

.action-buttons {
  position: absolute;
  left: 320px;
  width: 110px;
  margin-top: -5px;
}

.action-buttons div {
  float: left;
}
</style>