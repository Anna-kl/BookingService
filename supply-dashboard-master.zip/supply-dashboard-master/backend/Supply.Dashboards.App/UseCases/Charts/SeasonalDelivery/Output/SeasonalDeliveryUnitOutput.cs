﻿using Supply.Dashboards.App.UseCases.Charts.SeasonalDelivery.Types;

namespace Supply.Dashboards.App.UseCases.Charts.SeasonalDelivery.Output
{
    public sealed class SeasonalDeliveryUnitOutput
    {
        public SeasonalDeliveryUnitOutput(
            SeasonalDeliveryType type,
            double value)
        {
            Type = type;
            Value = value;
        }

        public SeasonalDeliveryType Type { get; }
        public double Value { get; }
    }


}
