﻿using FluentValidation;

namespace Supply.Dashboards.App.UseCases.Charts.SeasonalDelivery.Input
{
    public sealed class SeasonalDeliveryValidator
        : AbstractValidator<SeasonalDeliveryQuery>
    {
        public SeasonalDeliveryValidator()
        {
            ValidateDateTime();
            ValidateCustomersIds();
            ValidateLocationsIds();
            ValidateMtrTypesIds();
        }

        private void ValidateDateTime() =>
            RuleFor(_ => _.DateTime)
                .NotEmpty();

        private void ValidateCustomersIds() =>
            RuleForEach(_ => _.CustomersIds);

        private void ValidateLocationsIds() =>
            RuleForEach(_ => _.LocationsIds);

        private void ValidateMtrTypesIds() =>
            RuleForEach(_ => _.MtrTypesIds);
    }
}
