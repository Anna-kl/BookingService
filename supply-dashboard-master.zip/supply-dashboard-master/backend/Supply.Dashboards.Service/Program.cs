using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;

using Serilog;
using Serilog.Sinks.SystemConsole.Themes;

using System;
using System.IO;

namespace Supply.Dashboards.Service
{
    public class Program
    {
        public static void Main(string[] args)
        {
            if (!Directory.Exists("Logs"))
                try
                {
                    Directory.CreateDirectory("Logs");
                }
                catch (Exception)
                {
                    // ignored
                }

            CreateHostBuilder(args)
                .Build()
                .Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host
                .CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder
                        .UseUrls("https://0.0.0.0:44321")
                        .UseSerilog((context, configuration) =>
                            configuration
                                .ReadFrom.Configuration(context.Configuration)
                                .MinimumLevel.Debug()
                                .Enrich.FromLogContext()
                                .WriteTo.Debug()
                                .WriteTo.Console(theme: AnsiConsoleTheme.Code)
                                .WriteTo.File("Logs/log.txt",
                                    rollingInterval: RollingInterval.Day,
                                    rollOnFileSizeLimit: true))
                        .UseIISIntegration()
                        .UseStartup<Startup>();


                });
    }
}
