﻿using Supply.Dashboards.Shared.Types;

using System;

namespace Supply.Dashboards.Shared.ViewModels.Data.DataMtr
{
    public sealed class DataMtrResponseViewModel
    {
        public uint RowVersion { get; set; }
        public DateTime StartPeriod { get; set; }
        public TimeSpan EndPeriod { get; set; }
        public Guid? CustomerId { get; set; }
        public Guid? LocationId { get; set; }
        public Guid? MtrTypeId { get; set; }
        public ValueRecordEnum Type { get; set; }
        public double? Value { get; set; }
        public InputTypeEnum InputType { get; set; }
    }
}
