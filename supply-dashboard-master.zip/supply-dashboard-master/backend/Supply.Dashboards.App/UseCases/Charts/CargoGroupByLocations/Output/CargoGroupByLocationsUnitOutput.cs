﻿using Supply.Dashboards.App.UseCases.Charts.CargoGroupByLocations.Types;

namespace Supply.Dashboards.App.UseCases.Charts.CargoGroupByLocations.Output
{
    public sealed class CargoGroupByLocationsUnitOutput
    {

        public CargoGroupByLocationsUnitOutput(
            CargoGroupType type,
            double value)
        {
            Type = type;
            Value = value;
        }

        public CargoGroupType Type { get; }
        public double Value { get; }

    }
}
