﻿using Common.SeedWork;

using Supply.Dashboards.Domain.AggregatesModel.Bids;
using Supply.Dashboards.Domain.AggregatesModel.Core;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.HseIncidents;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;
using Supply.Dashboards.Domain.AggregatesModel.ValueRecords;
using Supply.Dashboards.Domain.Types;

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.Imports.ImportMtr
{
    public interface IImportMtr : IRepository<ValueRecord>
    {
        #region ValueRecord

        Task<IEnumerable<ValueRecord>> ValueRecordsGet(
            List<Customer> customers,
            List<Location> locations,
            List<MtrType> mtrTypes,
            List<ValueRecordType> valueRecordTypes,
            List<(DateTime startPeriod, DateTime endPeriod)> periodList,
            CancellationToken cancellationToken);

        Task<IEnumerable<ValueRecord>> ValueRecordsAdd(
            List<ValueRecord> records,
            CancellationToken cancellationToken);

        void ValueRecordsRemove(ValueRecord record);

        #endregion

        #region HseIncident

        Task<IEnumerable<HseIncident>> HseIncidentGet(
            List<Customer> customers,
            List<Location> locations,
            List<HseIncidentType> incidentTypes,
            List<DateTime> periodList,
            CancellationToken cancellationToken);

        Task<IEnumerable<HseIncident>> HseIncidentsAdd(
            List<HseIncident> hseIncidents,
            CancellationToken cancellationToken);

        void HseIncidentsRemove(HseIncident hseIncident);
        void HseIncidentsRemove(List<HseIncident> hseIncidents);

        #endregion

        #region Bid

        Task<IEnumerable<Bid>> BidsGet(
            List<Customer> customers,
            List<Location> locations,
            List<BidType> bidTypes,
            List<DateTime> periodList,
            CancellationToken cancellationToken);

        Task<IEnumerable<Bid>> BidsAdd(
            List<Bid> bids,
            CancellationToken cancellationToken);

        void BidsRemove(Bid bid);
        void BidsRemove(List<Bid> bids);

        #endregion

        Task<User?> GetUserByInnerId(Guid innerId,
            CancellationToken cancellationToken);

        Task<IEnumerable<Customer>> GetCustomersByInnerIds(
            List<Guid> innerIds,
            CancellationToken cancellationToken);

        Task<IEnumerable<Location>> GetLocationsByInnerIds(
            List<Guid> ids,
            CancellationToken cancellationToken);

        Task<IEnumerable<MtrType>> GetMtrTypesByInnerIds(
            List<Guid> innerIds,
            CancellationToken cancellationToken);
    }
}
