﻿using Microsoft.Extensions.Logging;
using Supply.Dashboards.App.InnerEventHandlers;
using Supply.Dashboards.Domain.AggregatesModel;
using Supply.Dashboards.Infrastructure.Data;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.Infrastructure.UseCasesRepositories
{
    public sealed class DomainEventRepository : IDomainEventHandler
    {
        private readonly ILogger<DomainEventRepository> _logger;
        private readonly DashboardsContext _dashboardsContext;

        public DomainEventRepository(
            ILogger<DomainEventRepository> logger,
            DashboardsContext dashboardsContext)
        {
            _logger = logger;
            _dashboardsContext = dashboardsContext;
        }

        public async Task AddEvent(Event @event, CancellationToken cancellationToken)
        {
            await _dashboardsContext.AddAsync(@event, cancellationToken);
        }
    }
}
