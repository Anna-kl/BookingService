﻿using Common.SeedWork;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Supply.Dashboards.Domain.AggregatesModel.Core;
using Supply.Dashboards.Domain.Types;

namespace Supply.Dashboards.Infrastructure.TypeConfigurations.AggregatesModel.Core
{
    public sealed class ContextTypeConfig : IEntityTypeConfiguration<Context>
    {
        public void Configure(EntityTypeBuilder<Context> builder)
        {
            builder.ToTable("contexts");

            builder.HasKey(_ => _.Id);
            builder.HasAlternateKey(_ => _.InnerId);
            builder
                .Property(_ => _.Id)
                .ValueGeneratedOnAdd();

            builder
                .Property(_ => _.XMin)
                .HasColumnName("xmin")
                .HasColumnType("xid")
                .ValueGeneratedOnAddOrUpdate()
                .IsConcurrencyToken();

            builder
                .Property(_ => _.Status)
                .HasConversion(
                    type => type.Id,
                    key => Enumeration.FromValue<StatusType>(key)!);

            builder.OwnsMany(
                _ => _.AliasIds,
                navigationBuilder =>
                {
                    navigationBuilder
                        .WithOwner()
                        .HasForeignKey("OwnerId");

                    navigationBuilder.Property<int>("Id");
                    navigationBuilder.HasKey("Id");

                    navigationBuilder.Ignore(_ => _.Context);
                });

            builder.Ignore(_ => _.DomainEvents);
        }
    }
}
