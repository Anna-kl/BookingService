﻿using System;

namespace Supply.Dashboards.Domain.AggregatesModel.MtrTypes
{
    public sealed class MtrTypeEdge
    {
        public MtrTypeEdge(
            MtrType source,
            MtrType destination)
        {
            SourceId = source.Id;
            SourceInnerId = source.InnerId;
            Source = source;

            DestinationId = destination.Id;
            DestinationInnerId = destination.InnerId;
            Destination = destination;
        }


#pragma warning disable 8618
        // ReSharper disable once UnusedMember.Local
        private MtrTypeEdge()
        {
        }
#pragma warning restore 8618

        public int SourceId { get; init; }
        public Guid SourceInnerId { get; init; }
        public MtrType Source { get; init; }

        public int DestinationId { get; init; }
        public Guid DestinationInnerId { get; init; }
        public MtrType Destination { get; init; }
    }
}
