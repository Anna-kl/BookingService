﻿using FluentValidation.Results;
using MediatR;
using Microsoft.Extensions.Logging;
using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.Charts.ArrivalByLocations.Input;
using Supply.Dashboards.App.UseCases.Charts.ArrivalByLocations.Output;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;
using Supply.Dashboards.Domain.AggregatesModel.ValueRecords;
using Supply.Dashboards.Domain.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Common.Extensions;
using Supply.Dashboards.App.UseCases.ValueRecords;
using Supply.Dashboards.App.UseCases.Charts.ArrivalByLocations.Types;
using Supply.Dashboards.App.UseCases.Locations.GetLocationList;

namespace Supply.Dashboards.App.UseCases.Charts.ArrivalByLocations
{
    public sealed class ArrivalByLocationsUseCase
        : IRequestHandler<ArrivalByLocationsQuery, (ValidationResult validationResult, ArrivalByLocationsOutput? output)>
    {
        private readonly ILogger<ArrivalByLocationsUseCase> _logger;
        private readonly IMediator _mediator;
        private readonly IValueRecords _valueRecords;
        private readonly IGetLocationList _locationsRepo;

        private List<MtrType> _mtrTypes;
        private ValidationResult _validationResult;
        private readonly List<StatusType> _selectStatus;

        public ArrivalByLocationsUseCase(
            ILogger<ArrivalByLocationsUseCase> logger,
            IMediator mediator,
            IValueRecords valueRecords,
            IGetLocationList locationsRepo)
        {
            _logger = logger;
            _mediator = mediator;
            _valueRecords = valueRecords;
            _locationsRepo = locationsRepo;

            _mtrTypes = new List<MtrType>();
            _validationResult = new ValidationResult();
            _selectStatus = new List<StatusType> { StatusType.Active };
        }

        public async Task<(ValidationResult validationResult, ArrivalByLocationsOutput? output)> Handle(
            ArrivalByLocationsQuery request,
            CancellationToken cancellationToken)
        {
            _validationResult = request.ValidationResult;

            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            List<ValueRecordType> valueRecordTypes = new();

            var factDataType = ValueRecordType.ArrivalFact;
            var dailyPlanDataType = ValueRecordType.ArrivalDailyPlan;
            var planDataType = ValueRecordType.ArrivalPlan;
            var ajustedPlanDataType = ValueRecordType.ArrivalAdjustedPlan;

            valueRecordTypes.AddRange(
                new List<ValueRecordType>
                {
                    ValueRecordType.ArrivalFact,
                    ValueRecordType.ArrivalPlan,
                    ValueRecordType.ArrivalAdjustedPlan,
                    ValueRecordType.ArrivalDailyPlan
                });

            var records = (await _valueRecords.GetRecordsWithDateFilter(
                valueRecordTypes,
                request.StartPeriod,
                request.EndPeriod,
                null,
                request.ParentLocationId,
                request.LocationsIds,
                request.CustomersIds,
                request.MtrTypesIds,
                _selectStatus,
                true,
                true,
                cancellationToken))
                .DistinctBy(_ => _.Payload)
                .ToList();

            var recordsByLocations = records.GroupBy(_ => _.Payload.Location);

            var resultItems = new List<ArrivalByLocationsParamOutput>();

            var divisionsWithAllChildrenLocations = _locationsRepo.GetActiveDivisionsWithChildrenLocations();

            foreach (var divisionWithLocations in divisionsWithAllChildrenLocations)
            {
                // записи сгруппированные по локациям дивизиона
                var locationsWithRecords = recordsByLocations.Where(locationWithRecords =>
                    divisionWithLocations.Value.Select(_ => _.InnerId).Contains(locationWithRecords.Key!.InnerId)
                    || divisionWithLocations.Key.InnerId == locationWithRecords.Key!.InnerId
                    );

                // если запрос с группировкой(суммой всех локаций) дивизиона
                if (request.LocationType == LocationType.Division)
                {

                    var (factData, dailyPlanData, planData, ajustedPlanData) = createUnitItems(
                            request.EndPeriod.AddDays(-1),
                            locationsWithRecords.SelectMany(_ => _).ToList(),
                            factDataType,
                            dailyPlanDataType,
                            planDataType,
                            ajustedPlanDataType
                            );

                    if (!(factData == 0 && dailyPlanData == 0 && planData == 0 && ajustedPlanData == 0))
                    {
                        resultItems.Add(new ArrivalByLocationsParamOutput(
                                                    divisionWithLocations.Key.InnerId,
                                                    divisionWithLocations.Key.Payload.Title,
                                                    new List<ArrivalByLocationsUnitOutput>()
                                                    {
                                                             new ArrivalByLocationsUnitOutput(
                                                             ArrivalType.GetArrivalType(factDataType),
                                                             factData),
                                                             new ArrivalByLocationsUnitOutput(
                                                             ArrivalType.GetArrivalType(dailyPlanDataType),
                                                             dailyPlanData),
                                                             new ArrivalByLocationsUnitOutput(
                                                             ArrivalType.GetArrivalType(planDataType),
                                                             planData),
                                                             new ArrivalByLocationsUnitOutput(
                                                             ArrivalType.GetArrivalType(ajustedPlanDataType),
                                                             ajustedPlanData)
                                                    }
                                                ));
                    }
                }
                else
                {
                    foreach (var locationWithRecords in locationsWithRecords)
                    {
                        var (factData, dailyPlanData, planData, ajustedPlanData) = createUnitItems(
                            request.EndPeriod.AddDays(-1),
                            locationWithRecords.Select(_ => _).ToList(),
                            factDataType,
                            dailyPlanDataType,
                            planDataType,
                            ajustedPlanDataType
                            );

                        if (!(factData == 0 && dailyPlanData == 0 && planData == 0 && ajustedPlanData == 0))
                        {
                            resultItems.Add(new ArrivalByLocationsParamOutput(
                                                        locationWithRecords.Key!.InnerId,
                                                        locationWithRecords.Key!.Payload.Title,
                                                        new List<ArrivalByLocationsUnitOutput>()
                                                        {
                                                             new ArrivalByLocationsUnitOutput(
                                                             ArrivalType.GetArrivalType(factDataType),
                                                             factData),
                                                             new ArrivalByLocationsUnitOutput(
                                                             ArrivalType.GetArrivalType(dailyPlanDataType),
                                                             dailyPlanData),
                                                             new ArrivalByLocationsUnitOutput(
                                                             ArrivalType.GetArrivalType(planDataType),
                                                             planData),
                                                             new ArrivalByLocationsUnitOutput(
                                                             ArrivalType.GetArrivalType(ajustedPlanDataType),
                                                             ajustedPlanData)
                                                        }
                                                    ));
                        }

                    }
                }

            }

            return (_validationResult, new ArrivalByLocationsOutput(resultItems));
        }

        private (double factData, double dailyPlanData, double planData, double ajustedPlanData) createUnitItems(
            DateTime selectedPeriod,
            List<ValueRecord> dataRecords,
            ValueRecordType factDataType,
            ValueRecordType dailyPlanDataType,
            ValueRecordType planDataType,
            ValueRecordType ajustedPlanDataType)
        {
            var finedData = dataRecords.Select(_ =>
                new
                {
                    type = _.Payload.Type,
                    startDate = _.Payload.StartPeriod,
                    endDate = _.Payload.EndPeriod,
                    value = _.Payload.Value
                }).ToList();

            // вычисляем для каждого типа
            var factData = finedData.Where(_ => _.type == factDataType).Sum(_ => _.value);

            var dailyPlanData = finedData.Where(_ => _.type == dailyPlanDataType).Sum(_ => _.value);

            var planDataMonth = finedData.Where(_ => _.type == planDataType).Sum(_ => _.value);
            var planData = planDataMonth / DateTime.DaysInMonth(selectedPeriod.Year, selectedPeriod.Month) * selectedPeriod.Day;

            var ajustedPlanDataList = finedData.Where(_ => _.endDate <= selectedPeriod.AddDays(1) && _.type == ajustedPlanDataType).ToList();
            var ajustedPlanDataMonth = ajustedPlanDataList.Sum(_ => _.value);
            var ajustedPlanData = ajustedPlanDataMonth / DateTime.DaysInMonth(selectedPeriod.Year, selectedPeriod.Month) * selectedPeriod.Day;

            // если значения отсутствуют, то берем из плана
            if (ajustedPlanDataList.Count == 0)
            {
                ajustedPlanData = planData;
            }

            return (factData, dailyPlanData, planData, ajustedPlanData);
        }
    }
}
