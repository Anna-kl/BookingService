import { Duration } from 'luxon';

export class TimeSpan {

    public static fromDto(strValue: string): TimeSpan {
        const matchResult = /(?:(\d+)\.)?(\d{1,2}):(\d{1,2}):(\d{1,2})/.exec(strValue);
        if (!matchResult || matchResult.length !== 5) {
            throw new Error(`Invalid TimeSpan value '${strValue}'`);
        } else {
            let days;
            if (matchResult[1]) {
                days = parseInt(matchResult[1], 10);
            } else {
                days = undefined;
            }

            const hours = parseInt(matchResult[2], 10);
            const minutes = parseInt(matchResult[3], 10);
            const seconds = parseInt(matchResult[4], 10);

            if (hours < 0 || 23 < hours
                || minutes < 0 || 59 < minutes
                || seconds < 0 || 59 < seconds) {
                throw new Error();
            }

            const duration = Duration.fromObject({
                days,
                hours,
                minutes,
                seconds,
            });

            const result = new TimeSpan(duration);

            return result;
        }
    }

    private readonly _duration: Duration;

    constructor(duration: Duration) {
        this._duration = duration;
    }

    public get duration(): Duration {
        return this._duration;
    }

    public toDto(): string {
        const result = this._duration.toFormat('dd.hh:mm:ss');
        return result;
    }

}
