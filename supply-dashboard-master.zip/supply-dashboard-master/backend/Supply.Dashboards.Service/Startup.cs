using FluentValidation.AspNetCore;

using MediatR;

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.ApplicationModels;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Logging;

using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

using Serilog;
using Serilog.AspNetCore;

using Supply.Dashboards.App.Extensions;
using Supply.Dashboards.App.UserInfo;
using Supply.Dashboards.Infrastructure.Extensions;
using Supply.Dashboards.Service.Authentication;
using Supply.Dashboards.Service.Cors;
using Supply.Dashboards.Service.Middleware;
using Supply.Dashboards.Service.Swagger;

using System;
using System.IO;
using System.Reflection;
using System.Security.Principal;

namespace Supply.Dashboards.Service
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<RequestLoggingOptions>(options =>
            {
                options.EnrichDiagnosticContext = (diagnosticContext, httpContext) =>
                    diagnosticContext.Set(
                        "RemoteIpAddress",
                        httpContext.Connection.RemoteIpAddress?.MapToIPv4());
            });

            services.AddMediatR(
                typeof(StartupAppExtensions).Assembly,
                typeof(StartupInfraExtensions).Assembly,
                typeof(Startup).Assembly);

            services
                .AddStartupAppExtensions()
                .AddStartupInfraExtensions(Configuration);

            services
                .AddCorsExtension(Configuration)
                .AddAuthenticationExtension(Configuration);

            services
                .AddControllers(options =>
                {
                    options.Conventions.Add(new RouteTokenTransformerConvention(new SlugifyParameterTransformer()));
                })
                .AddNewtonsoftJson(options =>
                {
                    options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
                })
                .AddFluentValidation()
                .AddNewtonsoftJson(options =>
                    options.SerializerSettings.Converters.Add(new StringEnumConverter()));

            var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.XML";
            var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);

            services.AddSwaggerGenNewtonsoftSupport();
            services.AddSwagger(Configuration, xmlPath);

            services
                .AddHttpContextAccessor()
                .AddScoped<IPrincipal>(provider =>
                    provider.GetService<IHttpContextAccessor>()?.HttpContext?.User
                    ?? throw new ApplicationException(nameof(provider)));
            services.AddScoped<AuthInfo>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                IdentityModelEventSource.ShowPII = true;
            }

            if (env.IsEnvironment("test"))
                app.UseDeveloperExceptionPage();

            if (!env.IsEnvironment("dev"))
                app.UseHttpsRedirection();

            app
                .UseDefaultFiles()
                .UseStaticFiles()
                .UseSerilogRequestLogging();

            app.UseStartupInfraExtensions();

            app.UseCorsExtension();
            app.UseRouting();

            app
                .UseAuthentication()
                .UseAuthorization();

            //app.UseMiddleware<ServerErrorMiddleware>();
            app.UseMiddleware<RequestMiddleware>();

            app.UseSwagger(Configuration);

            app.UseEndpoints(endpoints =>
                endpoints
                    .MapControllers()
                    .RequireAuthorization());
        }
    }
}
