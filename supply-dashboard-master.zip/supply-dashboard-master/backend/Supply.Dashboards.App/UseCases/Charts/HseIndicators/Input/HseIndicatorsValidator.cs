﻿using FluentValidation;

namespace Supply.Dashboards.App.UseCases.Charts.HseIndicators.Input
{
    public sealed class HseIndicatorsValidator
        : AbstractValidator<HseIndicatorsQuery>
    {
        public HseIndicatorsValidator()
        {
            ValidateType();
            ValidateStartPeriod();
            ValidateEndPeriod();
            ValidateLastIncidentTypes();
            ValidateCustomersIds();
            ValidateLocationsIds();
        }

        private void ValidateType() =>
            RuleForEach(_ => _.LastIncidentTypes)
                .NotEmpty()
                .Must(_ => _.Id != 0); // TODO add description

        private void ValidateStartPeriod() =>
            RuleFor(_ => _.StartPeriod)
                .NotEmpty();

        private void ValidateEndPeriod() =>
            RuleFor(_ => _.EndPeriod)
                .NotEmpty();

        private void ValidateLastIncidentTypes() =>
            RuleForEach(_ => _.LastIncidentTypes);

        private void ValidateCustomersIds() =>
            RuleForEach(_ => _.CustomersIds);

        private void ValidateLocationsIds() =>
            RuleForEach(_ => _.LocationsIds);
    }
}
