﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Common.Extensions
{
    public static class GraphExtensions
    {
        public static List<TVertex> DepthFirstSearch<TVertex, TEdge>(
            this TVertex root,
            Func<TEdge, TVertex> vertex,
            Func<TVertex, IEnumerable<TEdge>?> edges,
            Action<TVertex> action)
        {
            var marked = new List<TVertex>();
            var stack = new Stack<TVertex>();

            if (root == null)
                return new List<TVertex>();

            stack.Push(root);

            while (stack.Count != 0)
            {
                var currentVertex = stack.Pop();

                if (marked.Contains(currentVertex))
                    continue;

                // visit
                action(currentVertex);
                // end visit

                marked.Add(currentVertex);

                if (edges(currentVertex) == null)
                    continue;

                foreach (var edge in edges(currentVertex)!)
                {
                    if (!marked.Contains(vertex(edge)))
                        stack.Push(vertex(edge));
                }
            }

            return marked;
        }
    }
}
