﻿using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Charts.OtifChart
{
    public sealed class OtifChartRequestViewModel
    {
        public DateTime StartPeriod { get; set; }
        public DateTime? EndPeriod { get; set; }

        public List<Guid>? LocationsIds { get; set; }
        public List<Guid>? CustomersIds { get; set; }
    }
}
