import Vue from "vue";

export default class Chart extends Vue {
    public update() {
    }
}