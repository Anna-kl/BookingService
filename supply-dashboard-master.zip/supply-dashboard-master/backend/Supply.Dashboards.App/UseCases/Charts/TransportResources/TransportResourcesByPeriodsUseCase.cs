﻿using FluentValidation.Results;

using MediatR;

using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.Charts.TransportResources.Input;
using Supply.Dashboards.App.UseCases.Charts.TransportResources.Output;
using Supply.Dashboards.App.UseCases.Charts.TransportResources.Types;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.AggregatesModel.ValueRecords;
using Supply.Dashboards.Domain.Types;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Common.Extensions;
using Supply.Dashboards.App.UseCases.Charts.TransportResources;

namespace Supply.Dashboards.App.UseCases.Charts.TransportResourcesByPeriods
{
    public sealed class TransportResourcesByPeriodsUseCase
        : IRequestHandler<TransportResourcesByPeriodsQuery, (ValidationResult validationResult, TransportResourcesByPeriodsOutput? output)>
    {
        private readonly ILogger<TransportResourcesByPeriodsUseCase> _logger;
        private readonly IMediator _mediator;
        private readonly ITransportResources _transportResources;

        private List<Customer> _customers;
        private List<Location> _locations;
        private ValidationResult _validationResult;
        private readonly List<StatusType> _selectStatus;

        public TransportResourcesByPeriodsUseCase(
            ILogger<TransportResourcesByPeriodsUseCase> logger,
            IMediator mediator,
            ITransportResources transportResources)
        {
            _logger = logger;
            _mediator = mediator;
            _transportResources = transportResources;

            _customers = new List<Customer>();
            _locations = new List<Location>();
            _validationResult = new ValidationResult();
            _selectStatus = new List<StatusType> { StatusType.Active };
        }

        public async Task<(ValidationResult validationResult, TransportResourcesByPeriodsOutput? output)> Handle(
            TransportResourcesByPeriodsQuery request,
            CancellationToken cancellationToken)
        {
            _validationResult = request.ValidationResult;

            // If there are validation errors, abort the method and return errors.
            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            await Customers(request, cancellationToken);
            await Locations(request, cancellationToken);

            // If there are validation errors, abort the method and return errors.
            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            var records = new List<ValueRecord>();

            var (subset, superset, crossing) = await _transportResources.GetRecords(
                new List<ValueRecordType>
                {
                    ValueRecordType.TransportPlan,
                    ValueRecordType.TransportFact,
                    ValueRecordType.GPMPlan,
                    ValueRecordType.GPMFact,
                    ValueRecordType.LaborResourcesPlan,
                    ValueRecordType.LaborResourcesFact
                },
                request.StartPeriod,
                request.EndPeriod,
                _locations,
                _customers,
                cancellationToken);

            records.AddRange(subset);
            records.AddRange(superset);
            records.AddRange(crossing);

            records = records
                .GroupBy(_ => (
                    _.Payload.Type,
                    _.Payload.EndPeriod.Month,
                    _.Payload.EndPeriod.Year,
                    _.Payload.Customer,
                    _.Payload.Location))
                .Select(_ => (
                    key: (
                        _.Key.Type,
                        DateTime.Parse($"{_.Key.Month}-{_.Key.Year}"),
                        _.Key.Customer,
                        _.Key.Location),
                    value: _.OrderByDescending(record => record.Payload.EndPeriod).FirstOrDefault()))
                .Select(_ => _.value)
                .Where(_ => _ != null)
                .ToList()!;

            var valueRecordPerDays =
                ToSequences(
                    records,
                    request.StartPeriod,
                    request.EndPeriod ?? DateTime.UtcNow);

            #region day || week

            if (request.PeriodType == AppPeriodsType.Day ||
                request.PeriodType == AppPeriodsType.Week)
            {
                var dictionary = new Dictionary<DateTime, List<ValueRecordPerDay>>();

                if (request.PeriodType == AppPeriodsType.Day)
                    dictionary = valueRecordPerDays
                        .GroupBy(_ => _.DateTime.Date)
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                if (request.PeriodType == AppPeriodsType.Week)
                    dictionary = valueRecordPerDays
                        .GroupBy(_ => _.DateTime.Date.AddDays(-((int)_.DateTime.Date.DayOfWeek - 1)))
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                return (
                    _validationResult,
                    new TransportResourcesByPeriodsOutput(
                        dictionary
                            .SelectMany(_ =>
                                _.Value
                                    .Select(day => new TransportResourcesByPeriodsParamOutput(
                                        _.Key,
                                        _.Value
                                            .GroupBy(perDay => perDay.Type)
                                            .Select(perDay => new TransportResourcesUnitOutput(
                                                TransportResourcesType.GetTransportResourcesType(perDay.Key),
                                                perDay.Sum(r => r.Value ?? 0)))
                                            .ToList())))
                            .ToList()));
            }

            #endregion

            #region month || year

            if (request.PeriodType == AppPeriodsType.Month ||
                request.PeriodType == AppPeriodsType.Quarter ||
                request.PeriodType == AppPeriodsType.HalfYear ||
                request.PeriodType == AppPeriodsType.Year)
            {
                var dictionary = new Dictionary<(int month, int year), List<ValueRecordPerDay>>();

                if (request.PeriodType == AppPeriodsType.Month)
                    dictionary = valueRecordPerDays
                        .GroupBy(_ => (_.DateTime.Month, _.DateTime.Year))
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                if (request.PeriodType == AppPeriodsType.Quarter)
                    dictionary = valueRecordPerDays
                        .GroupBy(_ => (Month: (_.DateTime.Month - 1) / 3, _.DateTime.Year))
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                if (request.PeriodType == AppPeriodsType.HalfYear)
                    dictionary = valueRecordPerDays
                        .GroupBy(_ => (Month: (_.DateTime.Month - 1) / 6, _.DateTime.Year))
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                if (request.PeriodType == AppPeriodsType.Year)
                    dictionary = valueRecordPerDays
                        .GroupBy(_ => (1, _.DateTime.Year))
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                return (
                    _validationResult,
                    new TransportResourcesByPeriodsOutput(
                        dictionary
                            .SelectMany(_ =>
                                _.Value
                                    .GroupBy(day => _)
                                    .Select(day => new TransportResourcesByPeriodsParamOutput(
                                        DateTime.Parse($"{_.Key.month}-{_.Key.year}"),
                                        _.Value
                                            .GroupBy(perDay => perDay.Type)
                                            .Select(perDay => new TransportResourcesUnitOutput(
                                                TransportResourcesType.GetTransportResourcesType(perDay.Key),
                                                perDay.Sum(r => r.Value ?? 0)))
                                            .ToList())))
                            .ToList()));
            }

            #endregion

            return (_validationResult, null);
        }

        private async Task Customers(
            TransportResourcesByPeriodsQuery query,
            CancellationToken cancellationToken)
        {
            var existingIdsFromFilter = (await _transportResources.GetCustomersExistingIds(
                _selectStatus,
                query.CustomersIds.ToList(),
                cancellationToken)).ToList();
            var nonExistentIdsFromFilter = query
                .CustomersIds
                .Except(existingIdsFromFilter)
                .ToList();

            if (nonExistentIdsFromFilter.Any())
            {
                foreach (var id in nonExistentIdsFromFilter)
                    _validationResult.Errors.Add(new ValidationFailure(
                        "CustomerId",
                        $"{nameof(Customer)} with id \"{id}\" is not exist."));

                return;
            }

            var allCustomers = (await _transportResources.GetCustomers(
                _selectStatus,
                cancellationToken))
                .Where(_ => _.SourceEdges == null || !_.SourceEdges.Any())
                .SelectMany(_ => _.DepthFirstSearch(
                    edge => edge.Destination,
                    customer => customer.DestinationEdges,
                    _ => { }))
                .ToList();
            var allCustomersIds = allCustomers
                .Select(_ => _.InnerId)
                .ToList();
            var allCustomersEdges = (await _transportResources.GetCustomersEdges(
                allCustomersIds,
                cancellationToken)).ToList();

            foreach (var customer in allCustomers)
            {
                var sourceIds = allCustomersEdges
                    .Where(_ => _.DestinationId == customer.Id)
                    .Select(_ => _.SourceId);
                var sourcesVertex = allCustomers.Where(_ => sourceIds.Contains(_.Id));
                customer.AddSourceEdges(sourcesVertex.Select(_ => new CustomerEdge(_, customer)));

                var destinationIds = allCustomersEdges
                    .Where(_ => _.SourceId == customer.Id)
                    .Select(_ => _.DestinationId);
                var destinationVertex = allCustomers.Where(_ => destinationIds.Contains(_.Id));
                customer.AddDestinationEdges(destinationVertex.Select(_ => new CustomerEdge(customer, _)));
            }

            if (!query.CustomersIds.Any())
            {
                _customers = allCustomers;
                return;
            }

            var customersFromFilter = new List<Customer>();

            foreach (var customer in allCustomers)
            {
                customer.DepthFirstSearch(
                    _ => _.Destination,
                    _ => _.DestinationEdges!,
                    _ =>
                    {
                        if (existingIdsFromFilter.Contains(_.InnerId))
                            customersFromFilter.Add(_);
                    });
            }

            var customers = new List<Customer>();

            foreach (var customer in customersFromFilter)
            {
                customers.AddRange(customer.DepthFirstSearch(
                    _ => _.Destination,
                    _ => _.DestinationEdges!,
                    _ => { }));
            }

            if (!customers.Any())
                customers = allCustomers;

            _customers = customers
                .Distinct()
                .ToList();
        }

        private async Task Locations(
            TransportResourcesByPeriodsQuery query,
           CancellationToken cancellationToken)
        {
            var existingIdsFromFilter = (await _transportResources.GetLocationsExistingIds(
                _selectStatus,
                query.LocationsIds.ToList(),
                cancellationToken)).ToList();
            var nonExistentIdsFromFilter = query
                .LocationsIds
                .Except(existingIdsFromFilter)
                .ToList();

            if (nonExistentIdsFromFilter.Any())
            {
                foreach (var id in nonExistentIdsFromFilter)
                    _validationResult.Errors.Add(new ValidationFailure(
                        "LocationId",
                        $"{nameof(Location)} with id \"{id}\" is not exist."));

                return;
            }

            var allLocations = (await _transportResources.GetLocations(
                _selectStatus,
                cancellationToken))
                .Where(_ => _.SourceEdges == null || !_.SourceEdges.Any())
                .SelectMany(_ => _.DepthFirstSearch(
                    edge => edge.Destination,
                    location => location.DestinationEdges,
                    _ => { }))
                .ToList();
            var allLocationsIds = allLocations
                .Select(_ => _.InnerId)
                .ToList();
            var allLocationsEdges = (await _transportResources.GetLocationsEdges(
                allLocationsIds,
                cancellationToken)).ToList();

            foreach (var location in allLocations)
            {
                var sourceIds = allLocationsEdges
                    .Where(_ => _.DestinationId == location.Id)
                    .Select(_ => _.SourceId);
                var sourcesVertex = allLocations.Where(_ => sourceIds.Contains(_.Id));
                location.AddSourceEdges(sourcesVertex.Select(_ => new LocationEdge(_, location)));

                var destinationIds = allLocationsEdges
                    .Where(_ => _.SourceId == location.Id)
                    .Select(_ => _.DestinationId);
                var destinationVertex = allLocations.Where(_ => destinationIds.Contains(_.Id));
                location.AddDestinationEdges(destinationVertex.Select(_ => new LocationEdge(location, _)));
            }

            if (!query.LocationsIds.Any())
            {
                _locations = allLocations;
                return;
            }

            var locationsFromFilter = new List<Location>();

            foreach (var location in allLocations)
            {
                location.DepthFirstSearch(
                    _ => _.Destination,
                    _ => _.DestinationEdges!,
                    _ =>
                    {
                        if (existingIdsFromFilter.Contains(_.InnerId))
                            locationsFromFilter.Add(_);
                    });
            }

            var locations = new List<Location>();

            foreach (var location in locationsFromFilter)
            {
                locations.AddRange(location.DepthFirstSearch(
                    _ => _.Destination,
                    _ => _.DestinationEdges!,
                    _ => { }));
            }

            if (!locations.Any())
                locations = allLocations;

            _locations = locations
                .Distinct()
                .ToList();
        }

        private static List<ValueRecordPerDay> ToSequences(
            List<ValueRecord> records,
            DateTime startPeriod,
            DateTime endPeriod)
        {
            var valuePeriods = new List<ValueRecordPerDay>();

            records.ForEach(record =>
            {
                valuePeriods.AddRange(ToDailySequences(record, 0));
            });

            return valuePeriods
                .Where(_ => _.DateTime >= startPeriod && _.DateTime <= endPeriod)
                .ToList();
        }

        private static IEnumerable<ValueRecordPerDay> ToDailySequences(
            ValueRecord record,
            int priority)
        {
            var valuePeriods = new List<ValueRecordPerDay>();
            var date = record.Payload.StartPeriod;
            var dayCount = (record.Payload.EndPeriod - record.Payload.StartPeriod).Days;

            for (var i = 0; i < dayCount; i++)
            {
                var valueRecordPerDay = new ValueRecordPerDay(
                    date.AddDays(i),
                    record,
                    priority);

                if (dayCount != 0)
                    valueRecordPerDay.UpdateValue(record.Payload.Value / dayCount);

                valuePeriods.Add(valueRecordPerDay);
            }

            return valuePeriods;
        }
    }
}
