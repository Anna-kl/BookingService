﻿namespace Supply.Dashboards.Shared.ViewModels.Charts.AccountingMtrByPeriods
{
    public enum AccountingMtrByPeriodsEnum
    {
        AccountingMtrTotalSupplies = 1,
        AccountingMtrProcessing = 2,
        AccountingMtrUncapitalize0_14 = 3,
        AccountingMtrUncapitalize15_30 = 4,
        AccountingMtrUncapitalize31_60 = 5,
        AccountingMtrUncapitalize61More = 6,
    }
}
