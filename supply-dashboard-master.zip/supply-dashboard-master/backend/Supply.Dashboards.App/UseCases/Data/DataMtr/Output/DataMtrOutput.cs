﻿
using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.Data.DataMtr.Output
{
    public sealed class DataMtrOutput
    {
        private readonly List<DataMtrItemOutput> _item;

        internal DataMtrOutput(List<DataMtrItemOutput>? items)
        {
            _item = items
                    ?? new List<DataMtrItemOutput>();
        }

        public IEnumerable<DataMtrItemOutput> Items =>
            _item.AsReadOnly();
    }
}
