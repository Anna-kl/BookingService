﻿using Common.SeedWork;

using Microsoft.EntityFrameworkCore;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.Infrastructure.Extensions
{
    public static class SyncExtensions
    {
        public static async Task Sync<TType>(
            this DbContext context,
            List<TType> add,
            List<TType> update,
            CancellationToken cancellationToken)
            where TType : Entity
        {
            var queryable = Set<TType>(context, typeof(TType));

            if (queryable == null)
                return;

            var exist = new List<TType>();
            exist.AddRange(add);
            exist.AddRange(update);

            var remove = queryable
                .Where(_ => !exist.Select(type => type.InnerId).Contains(_.InnerId))
                .ToListAsync(cancellationToken);

            await context.AddRangeAsync(add, cancellationToken);
            context.UpdateRange(update);
            context.RemoveRange(remove);
        }

        private static IQueryable<TEntity>? Set<TEntity>(this DbContext context, Type type)
        {
            var method = typeof(DbContext).GetMethod(
                nameof(DbContext.Set),
                BindingFlags.Public | BindingFlags.Instance);

            if (method == null)
                return null;

            method = method.MakeGenericMethod(type);

            return method.Invoke(context, null) as IQueryable<TEntity>;
        }
    }
}
