﻿using FluentValidation.Results;

using MediatR;

using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Input;
using Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Output;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;
using Supply.Dashboards.Domain.Types;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.Imports.ImportDirectories
{
    public sealed class ImportDirectoriesUseCase
        : IRequestHandler<ImportDirectoriesCommand, (ValidationResult validationResult, ImportDirectoriesOutput? output)>
    {
        private readonly ILogger<ImportDirectoriesUseCase> _logger;
        private readonly IImportDirectories _importDirectories;

        private List<Customer> _existCustomers;
        private readonly List<Customer> _newCustomers;
        private readonly List<Customer> _updateCustomers;
        private readonly List<Customer> _removeCustomers;

        private readonly List<CustomerEdge> _newCustomersEdges;
        private readonly List<CustomerEdge> _removeCustomersEdges;

        private List<Location> _existLocations;
        private readonly List<Location> _newLocations;
        private readonly List<Location> _updateLocations;
        private readonly List<Location> _removeLocations;

        private readonly List<LocationEdge> _newLocationsEdges;
        private readonly List<LocationEdge> _removeLocationsEdges;

        private List<MtrType> _existMtrTypes;
        private readonly List<MtrType> _newMtrTypes;
        private readonly List<MtrType> _updateMtrTypes;
        private readonly List<MtrType> _removeMtrTypes;

        private readonly List<MtrTypeEdge> _newMtrTypesEdges;
        private readonly List<MtrTypeEdge> _removeMtrTypesEdges;

        private ValidationResult _validationResult;

        public ImportDirectoriesUseCase(
            ILogger<ImportDirectoriesUseCase> logger,
            IImportDirectories importDirectories)
        {
            _logger = logger;
            _importDirectories = importDirectories;

            _existCustomers = new List<Customer>();
            _newCustomers = new List<Customer>();
            _updateCustomers = new List<Customer>();
            _removeCustomers = new List<Customer>();

            _newCustomersEdges = new List<CustomerEdge>();
            _removeCustomersEdges = new List<CustomerEdge>();

            _existLocations = new List<Location>();
            _newLocations = new List<Location>();
            _updateLocations = new List<Location>();
            _removeLocations = new List<Location>();

            _newLocationsEdges = new List<LocationEdge>();
            _removeLocationsEdges = new List<LocationEdge>();

            _existMtrTypes = new List<MtrType>();
            _newMtrTypes = new List<MtrType>();
            _updateMtrTypes = new List<MtrType>();
            _removeMtrTypes = new List<MtrType>();

            _newMtrTypesEdges = new List<MtrTypeEdge>();
            _removeMtrTypesEdges = new List<MtrTypeEdge>();

            _validationResult = new ValidationResult();
        }

        public async Task<(ValidationResult validationResult, ImportDirectoriesOutput? output)> Handle(
            ImportDirectoriesCommand request,
            CancellationToken cancellationToken)
        {
            _validationResult = request.ValidationResult;

            if (!_validationResult.IsValid) return (_validationResult, null);

            await CheckCustomers(request, cancellationToken);
            await CheckLocations(request, cancellationToken);
            await CheckMtrTypes(request, cancellationToken);

            if (!_validationResult.IsValid) return (_validationResult, null);

            await CustomersProcessing(request, cancellationToken);
            await LocationsProcessing(request, cancellationToken);
            await MtrTypesProcessing(request, cancellationToken);

            if (!_validationResult.IsValid) return (_validationResult, null);

            await _importDirectories.UnitOfWork.SaveEntitiesAsync(cancellationToken);

            return (_validationResult, new ImportDirectoriesOutput(
                _newCustomers,
                _updateCustomers,
                _removeCustomers,
                _newCustomersEdges,
                _removeCustomersEdges,
                _newLocations,
                _updateLocations,
                _removeLocations,
                _newLocationsEdges,
                _removeLocationsEdges,
                _newMtrTypes,
                _updateMtrTypes,
                _removeMtrTypes,
                _newMtrTypesEdges,
                _removeMtrTypesEdges));
        }

        #region customers

        private async Task CheckCustomers(
            ImportDirectoriesCommand command,
            CancellationToken cancellationToken)
        {
            var groupByCustomers = command.Customers.GroupBy(_ => _.Id);

            foreach (var customer in groupByCustomers)
            {
                if (customer.Count() > 1)
                {
                    command.ValidationResult.Errors.Add(new ValidationFailure(
                        "Items",
                        $"Customer by id: {customer.Key} duplicated."));
                }
            }

            var groupByEdges = command.CustomersEdges.GroupBy(_ => new { _.SourceId, _.DestinationId });

            foreach (var edge in groupByEdges)
            {
                if (edge.Count() > 1)
                {
                    command.ValidationResult.Errors.Add(new ValidationFailure(
                        "Items",
                        $"CustomerEdge by id: {edge.Key} duplicated."));
                }
            }

            var inputIds = command
                .Locations
                .Select(_ => _.Id)
                .Distinct()
                .ToList();

            var customers = await _importDirectories.GetCustomersByInnerIds(
                new List<StatusType>(),
                inputIds,
                cancellationToken);

            _existCustomers = customers.ToList();
        }

        private async Task CustomersProcessing(
            ImportDirectoriesCommand command,
            CancellationToken cancellationToken)
        {
            var allCustomersIdsByInput = new List<Guid>();
            allCustomersIdsByInput.AddRange(command.Customers.Select(_ => _.Id));
            allCustomersIdsByInput.AddRange(command.CustomersEdges.Select(_ => _.SourceId));
            allCustomersIdsByInput.AddRange(command.CustomersEdges.Select(_ => _.DestinationId));
            allCustomersIdsByInput = allCustomersIdsByInput.Distinct().ToList();

            _existCustomers = (await _importDirectories.GetCustomersByInnerIds(
                new List<StatusType>(),
                allCustomersIdsByInput,
                cancellationToken)).ToList();

            // update or soft delete
            foreach (var existCustomer in _existCustomers.Where(_ => command.Customers.Select(input => input.Id).Contains(_.InnerId)))
            {
                var inputCustomer = command
                    .Customers
                    .SingleOrDefault(item => item.Id == existCustomer.InnerId);

                if (inputCustomer == null)
                    continue;

                var customer = inputCustomer.ToCustomer();

                if (existCustomer.InnerId != inputCustomer.Id)
                    continue;

                if (inputCustomer.IsObsolete == true && existCustomer.Status == StatusType.Archived)
                    continue;

                if (inputCustomer.IsObsolete == true && existCustomer.Status != StatusType.Archived)
                {
                    existCustomer.ChangeStatus(StatusType.Archived);
                    _removeCustomers.Add(existCustomer);

                    if (existCustomer.SourceEdges != null && existCustomer.SourceEdges.Any())
                    {
                        _removeCustomersEdges.AddRange(existCustomer.SourceEdges);
                        await _importDirectories.RemoveCustomerEdges(
                            existCustomer.SourceEdges.ToList(),
                            cancellationToken);
                    }

                    if (existCustomer.DestinationEdges != null && existCustomer.DestinationEdges.Any())
                    {
                        _removeCustomersEdges.AddRange(existCustomer.DestinationEdges);
                        await _importDirectories.RemoveCustomerEdges(
                            existCustomer.DestinationEdges.ToList(),
                            cancellationToken);
                    }
                }

                if (inputCustomer.IsObsolete != true && existCustomer.Status == StatusType.Archived)
                {
                    existCustomer.ChangeStatus(StatusType.Active);

                    if (!_removeCustomers.Contains(existCustomer))
                        _updateCustomers.Add(customer);
                }

                // do not update if there are no changes 
                if (!Equals(existCustomer.Payload, customer.Payload))
                {
                    existCustomer.Update(customer.Payload);
                    if (!_removeCustomers.Contains(customer) && !_updateCustomers.Contains(customer))
                        _updateCustomers.Add(customer);
                }
            }

            _newCustomers.AddRange(command
                .Customers
                .Where(_ => !_existCustomers.Select(customer => customer.InnerId).Contains(_.Id))
                .Where(_ => _.IsObsolete != true)
                .Select(_ => _.ToCustomer())
                .ToList());

            var newOrExistCustomers = new List<Customer>();
            newOrExistCustomers.AddRange(_newCustomers);
            newOrExistCustomers.AddRange(_existCustomers);

            var existCustomersEdges = newOrExistCustomers
                .Where(_ => _.SourceEdges != null)
                .SelectMany(_ => _.SourceEdges!)
                .ToList();

            foreach (var inputCustomersEdge in command.CustomersEdges)
            {
                var sourceCustomer = newOrExistCustomers
                    .Where(_ => !_removeCustomers.Contains(_))
                    .SingleOrDefault(_ => _.InnerId == inputCustomersEdge.SourceId);

                var destinationCustomer = newOrExistCustomers
                    .Where(_ => !_removeCustomers.Contains(_))
                    .SingleOrDefault(_ => _.InnerId == inputCustomersEdge.DestinationId);

                if (sourceCustomer == null || destinationCustomer == null)
                    continue;

                var newEdge = new CustomerEdge(sourceCustomer, destinationCustomer);

                if (inputCustomersEdge.IsObsolete == null || inputCustomersEdge.IsObsolete != true)
                {
                    if (existCustomersEdges.Any(_ => _.SourceInnerId == newEdge.SourceInnerId && _.DestinationInnerId == newEdge.DestinationInnerId))
                        continue;

                    await _importDirectories.AddCustomerEdge(newEdge, cancellationToken);
                    _newCustomersEdges.Add(newEdge);
                }

                if (inputCustomersEdge.IsObsolete == true)
                {
                    if (!existCustomersEdges.Any(_ => _.SourceInnerId == newEdge.SourceInnerId && _.DestinationInnerId == newEdge.DestinationInnerId))
                        continue;

                    var edge = existCustomersEdges.Single(_ =>
                        _.SourceInnerId == inputCustomersEdge.SourceId &&
                        _.DestinationInnerId == inputCustomersEdge.DestinationId);

                    await _importDirectories.RemoveCustomerEdges(
                        new List<CustomerEdge> { edge },
                        cancellationToken);
                    _removeCustomersEdges.Add(edge);
                }
            }

            if (_newCustomers.Any())
                await _importDirectories.AddCustomers(_newCustomers, cancellationToken);
        }

        #endregion

        #region locations

        private async Task CheckLocations(
            ImportDirectoriesCommand command,
            CancellationToken cancellationToken)
        {
            var groupByLocations = command.Locations.GroupBy(_ => _.Id);

            foreach (var location in groupByLocations)
            {
                if (location.Count() > 1)
                {
                    command.ValidationResult.Errors.Add(new ValidationFailure(
                        "Items",
                        $"Location by id: {location.Key} duplicated."));
                }
            }

            var groupByEdges = command.LocationsEdges.GroupBy(_ => new { _.SourceId, _.DestinationId });

            foreach (var edge in groupByEdges)
            {
                if (edge.Count() > 1)
                {
                    command.ValidationResult.Errors.Add(new ValidationFailure(
                        "Items",
                        $"LocationsEdge by id: {edge.Key} duplicated."));
                }
            }

            var inputLocationsIds = command
                .Locations
                .Select(_ => _.Id)
                .Distinct()
                .ToList();

            var locations = await _importDirectories.GetLocationsByInnerIds(
                new List<StatusType>(),
                inputLocationsIds,
                cancellationToken);

            _existLocations = locations.ToList();
        }

        private async Task LocationsProcessing(
            ImportDirectoriesCommand command,
            CancellationToken cancellationToken)
        {
            var allLocationsIdsByInput = new List<Guid>();
            allLocationsIdsByInput.AddRange(command.Locations.Select(_ => _.Id));
            allLocationsIdsByInput.AddRange(command.LocationsEdges.Select(_ => _.SourceId));
            allLocationsIdsByInput.AddRange(command.LocationsEdges.Select(_ => _.DestinationId));
            allLocationsIdsByInput = allLocationsIdsByInput.Distinct().ToList();

            _existLocations = (await _importDirectories.GetLocationsByInnerIds(
                new List<StatusType>(),
                allLocationsIdsByInput,
                cancellationToken)).ToList();

            // update or soft delete
            foreach (var existLocation in _existLocations.Where(_ => command.Locations.Select(input => input.Id).Contains(_.InnerId)))
            {
                var inputLocation = command
                    .Locations
                    .SingleOrDefault(item => item.Id == existLocation.InnerId);

                if (inputLocation == null)
                    continue;

                var location = inputLocation.ToLocation();

                if (existLocation.InnerId != inputLocation.Id)
                    continue;

                if (inputLocation.IsObsolete == true && existLocation.Status == StatusType.Archived)
                    continue;

                if (inputLocation.IsObsolete == true && existLocation.Status != StatusType.Archived)
                {
                    existLocation.ChangeStatus(StatusType.Archived);
                    _removeLocations.Add(existLocation);

                    if (existLocation.SourceEdges != null && existLocation.SourceEdges.Any())
                    {
                        _removeLocationsEdges.AddRange(existLocation.SourceEdges);
                        await _importDirectories.RemoveLocationEdges(
                            existLocation.SourceEdges.ToList(),
                            cancellationToken);
                    }

                    if (existLocation.DestinationEdges != null && existLocation.DestinationEdges.Any())
                    {
                        _removeLocationsEdges.AddRange(existLocation.DestinationEdges);
                        await _importDirectories.RemoveLocationEdges(
                            existLocation.DestinationEdges.ToList(),
                            cancellationToken);
                    }
                }

                if (inputLocation.IsObsolete != true && existLocation.Status == StatusType.Archived)
                {
                    existLocation.ChangeStatus(StatusType.Active);

                    if (!_removeLocations.Contains(existLocation))
                        _updateLocations.Add(existLocation);
                }

                // do not update if there are no changes 
                if (!Equals(existLocation.Payload, location.Payload))
                {
                    existLocation.Update(location.Payload);
                    if (!_removeLocations.Contains(location) && !_updateLocations.Contains(location))
                        _updateLocations.Add(existLocation);
                }
            }

            _newLocations.AddRange(command
                .Locations
                .Where(_ => !_existLocations.Select(location => location.InnerId).Contains(_.Id))
                .Where(_ => _.IsObsolete != true)
                .Select(_ => _.ToLocation())
                .ToList());

            var newOrExistLocations = new List<Location>();
            newOrExistLocations.AddRange(_newLocations);
            newOrExistLocations.AddRange(_existLocations);

            var existLocationsEdges = newOrExistLocations
                .Where(_ => _.SourceEdges != null)
                .SelectMany(_ => _.SourceEdges!)
                .ToList();

            foreach (var inputLocationsEdge in command.LocationsEdges)
            {
                var sourceLocation = newOrExistLocations
                    .Where(_ => !_removeLocations.Contains(_))
                    .SingleOrDefault(_ => _.InnerId == inputLocationsEdge.SourceId);

                var destinationLocation = newOrExistLocations
                    .Where(_ => !_removeLocations.Contains(_))
                    .SingleOrDefault(_ => _.InnerId == inputLocationsEdge.DestinationId);

                if (sourceLocation == null || destinationLocation == null)
                    continue;

                var newEdge = new LocationEdge(sourceLocation, destinationLocation);

                if (inputLocationsEdge.IsObsolete == null || inputLocationsEdge.IsObsolete != true)
                {
                    if (existLocationsEdges.Any(_ => _.SourceInnerId == newEdge.SourceInnerId && _.DestinationInnerId == newEdge.DestinationInnerId))
                        continue;

                    await _importDirectories.AddLocationEdge(newEdge, cancellationToken);
                    _newLocationsEdges.Add(newEdge);
                }

                if (inputLocationsEdge.IsObsolete == true)
                {
                    if (!existLocationsEdges.Any(_ => _.SourceInnerId == newEdge.SourceInnerId && _.DestinationInnerId == newEdge.DestinationInnerId))
                        continue;

                    var edge = existLocationsEdges.Single(_ =>
                        _.SourceInnerId == inputLocationsEdge.SourceId &&
                        _.DestinationInnerId == inputLocationsEdge.DestinationId);

                    await _importDirectories.RemoveLocationEdges(
                        new List<LocationEdge> { edge },
                        cancellationToken);
                    _removeLocationsEdges.Add(edge);
                }
            }

            if (_newLocations.Any())
                await _importDirectories.AddLocations(_newLocations, cancellationToken);
        }

        #endregion

        #region mtr types

        private async Task CheckMtrTypes(
            ImportDirectoriesCommand command,
            CancellationToken cancellationToken)
        {
            var groupByMtrTypes = command.MtrTypes.GroupBy(_ => _.Id);

            foreach (var mtrType in groupByMtrTypes)
            {
                if (mtrType.Count() > 1)
                {
                    command.ValidationResult.Errors.Add(new ValidationFailure(
                        "Items",
                        $"mtrType by id: {mtrType.Key} duplicated."));
                }
            }

            var groupByEdges = command.MtrTypesEdges.GroupBy(_ => new { _.SourceId, _.DestinationId });

            foreach (var edge in groupByEdges)
            {
                if (edge.Count() > 1)
                {
                    command.ValidationResult.Errors.Add(new ValidationFailure(
                        "Items",
                        $"MtrTypesEdge by id: {edge.Key} duplicated."));
                }
            }

            var inputMtrTypesIds = command
                .MtrTypes
                .Select(_ => _.Id)
                .Distinct()
                .ToList();

            var mtrTypes = await _importDirectories.GetMtrTypesByInnerIds(
                new List<StatusType>(),
                inputMtrTypesIds,
                cancellationToken);

            _existMtrTypes = mtrTypes.ToList();
        }

        private async Task MtrTypesProcessing(
            ImportDirectoriesCommand command,
            CancellationToken cancellationToken)
        {
            var allMtrTypesIdsByInput = new List<Guid>();
            allMtrTypesIdsByInput.AddRange(command.MtrTypes.Select(_ => _.Id));
            allMtrTypesIdsByInput.AddRange(command.MtrTypesEdges.Select(_ => _.SourceId));
            allMtrTypesIdsByInput.AddRange(command.MtrTypesEdges.Select(_ => _.DestinationId));
            allMtrTypesIdsByInput = allMtrTypesIdsByInput.Distinct().ToList();

            _existMtrTypes = (await _importDirectories.GetMtrTypesByInnerIds(
                new List<StatusType>(),
                allMtrTypesIdsByInput,
                cancellationToken)).ToList();

            // update or soft delete
            foreach (var existMtrType in _existMtrTypes.Where(_ => command.MtrTypes.Select(input => input.Id).Contains(_.InnerId)))
            {
                var inputMtrType = command
                    .MtrTypes
                    .SingleOrDefault(item => item.Id == existMtrType.InnerId);

                if (inputMtrType == null)
                    continue;

                var mtrType = inputMtrType.ToMtrType();

                if (existMtrType.InnerId != inputMtrType.Id)
                    continue;

                if (inputMtrType.IsObsolete == true && existMtrType.Status == StatusType.Archived)
                    continue;

                if (inputMtrType.IsObsolete == true && existMtrType.Status != StatusType.Archived)
                {
                    existMtrType.ChangeStatus(StatusType.Archived);
                    _removeMtrTypes.Add(existMtrType);

                    if (existMtrType.SourceEdges != null && existMtrType.SourceEdges.Any())
                    {
                        _removeMtrTypesEdges.AddRange(existMtrType.SourceEdges);
                        await _importDirectories.RemoveMtrTypeEdges(
                            existMtrType.SourceEdges.ToList(),
                            cancellationToken);
                    }

                    if (existMtrType.DestinationEdges != null && existMtrType.DestinationEdges.Any())
                    {
                        _removeMtrTypesEdges.AddRange(existMtrType.DestinationEdges);
                        await _importDirectories.RemoveMtrTypeEdges(
                            existMtrType.DestinationEdges.ToList(),
                            cancellationToken);
                    }
                }

                if (inputMtrType.IsObsolete != true && existMtrType.Status == StatusType.Archived)
                {
                    existMtrType.ChangeStatus(StatusType.Active);

                    if (!_removeMtrTypes.Contains(existMtrType))
                        _updateMtrTypes.Add(mtrType);
                }

                // do not update if there are no changes 
                if (!Equals(existMtrType.Payload, mtrType.Payload))
                {
                    existMtrType.Update(mtrType.Payload);
                    if (!_removeMtrTypes.Contains(mtrType) && !_updateMtrTypes.Contains(mtrType))
                        _updateMtrTypes.Add(mtrType);
                }
            }

            _newMtrTypes.AddRange(command
                .MtrTypes
                .Where(_ => !_existMtrTypes.Select(mtrType => mtrType.InnerId).Contains(_.Id))
                .Where(_ => _.IsObsolete != true)
                .Select(_ => _.ToMtrType())
                .ToList());

            var newOrExistMtrTypes = new List<MtrType>();
            newOrExistMtrTypes.AddRange(_newMtrTypes);
            newOrExistMtrTypes.AddRange(_existMtrTypes);

            var existMtrTypesEdges = newOrExistMtrTypes
                .Where(_ => _.SourceEdges != null)
                .SelectMany(_ => _.SourceEdges!)
                .ToList();

            foreach (var inputMtrTypesEdge in command.MtrTypesEdges)
            {
                var sourceMtrType = newOrExistMtrTypes
                    .Where(_ => !_removeMtrTypes.Contains(_))
                    .SingleOrDefault(_ => _.InnerId == inputMtrTypesEdge.SourceId);

                var destinationMtrType = newOrExistMtrTypes
                    .Where(_ => !_removeMtrTypes.Contains(_))
                    .SingleOrDefault(_ => _.InnerId == inputMtrTypesEdge.DestinationId);

                if (sourceMtrType == null || destinationMtrType == null)
                    continue;

                var newEdge = new MtrTypeEdge(sourceMtrType, destinationMtrType);

                if (inputMtrTypesEdge.IsObsolete == null || inputMtrTypesEdge.IsObsolete != true)
                {
                    if (existMtrTypesEdges.Any(_ => _.SourceInnerId == newEdge.SourceInnerId && _.DestinationInnerId == newEdge.DestinationInnerId))
                        continue;

                    await _importDirectories.AddMtrTypeEdge(newEdge, cancellationToken);
                    _newMtrTypesEdges.Add(newEdge);
                }

                if (inputMtrTypesEdge.IsObsolete == true)
                {
                    if (!existMtrTypesEdges.Any(_ => _.SourceInnerId == newEdge.SourceInnerId && _.DestinationInnerId == newEdge.DestinationInnerId))
                        continue;

                    var edge = existMtrTypesEdges.Single(_ =>
                        _.SourceInnerId == inputMtrTypesEdge.SourceId &&
                        _.DestinationInnerId == inputMtrTypesEdge.DestinationId);

                    await _importDirectories.RemoveMtrTypeEdges(
                        new List<MtrTypeEdge> { edge },
                        cancellationToken);
                    _removeMtrTypesEdges.Add(edge);
                }
            }

            if (_newMtrTypes.Any())
                await _importDirectories.AddMtrTypes(_newMtrTypes, cancellationToken);
        }

        #endregion
    }
}
