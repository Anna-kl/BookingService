﻿namespace Supply.Dashboards.Service.Cors
{
    public sealed class CorsConfiguration
    {
        public string[]? AllowedOrigins { get; set; }
    }
}
