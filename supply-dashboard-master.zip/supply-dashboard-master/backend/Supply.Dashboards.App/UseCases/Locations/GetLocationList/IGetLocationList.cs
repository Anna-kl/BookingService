﻿using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.Types;

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.Locations.GetLocationList
{
    public interface IGetLocationList
    {
        Task<IEnumerable<Location>> Get(
            List<StatusType> statuses,
            List<Location>? destinationList,
            List<Guid>? ids,
            List<LocationType>? types,
            bool includeRoot,
            CancellationToken cancellationToken);

        Task<IEnumerable<Location>> GetByIds(
            List<StatusType> statuses,
            List<Guid> ids,
            CancellationToken cancellationToken);

        /// <summary>
        /// Ид дивизионов с дочерними ид локаций всех уровней вложенности 
        /// </summary>
        /// <returns></returns>
        Dictionary<Location, List<Location>> GetActiveDivisionsWithChildrenLocations();
    }
}
