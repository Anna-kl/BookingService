﻿using Common.SeedWork;

using Supply.Dashboards.App.Exceptions;
using Supply.Dashboards.Domain.Types;

namespace Supply.Dashboards.App.UseCases.Charts.SeasonalDelivery.Types
{
    public sealed class SeasonalDeliveryType : Enumeration
    {

        public static SeasonalDeliveryType SeasonalDeliveryAdjustedPlan = new(11, "SeasonalDeliveryAdjustedPlan");
        public static SeasonalDeliveryType SeasonalDeliveryDailyPlan = new(21, "SeasonalDeliveryDailyPlan");
        public static SeasonalDeliveryType SeasonalDeliveryFact = new(9, "SeasonalDeliveryFact");
        public static SeasonalDeliveryType SeasonalDeliveryPlan = new(10, "SeasonalDeliveryPlan");

        public SeasonalDeliveryType(int id, string name) : base(id, name)
        {
        }

        internal static SeasonalDeliveryType GetSeasonalDeliveryType(ValueRecordType type)
        {
            var name = type.Name switch
            {
                nameof(ValueRecordType.SeasonalDeliveryAdjustedPlan) => SeasonalDeliveryAdjustedPlan.Name,
                nameof(ValueRecordType.SeasonalDeliveryDailyPlan) => SeasonalDeliveryDailyPlan.Name,
                nameof(ValueRecordType.SeasonalDeliveryFact) => SeasonalDeliveryFact.Name,
                nameof(ValueRecordType.SeasonalDeliveryPlan) => SeasonalDeliveryPlan.Name,

                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<SeasonalDeliveryType>(name)!;
        }
    }
}
