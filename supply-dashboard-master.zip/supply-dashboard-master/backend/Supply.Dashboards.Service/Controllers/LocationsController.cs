﻿using Common.SeedWork;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.Locations.GetLocationList.Input;
using Supply.Dashboards.Shared.Types;
using Supply.Dashboards.Shared.ViewModels.Locations.LocationList;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.Service.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public sealed class LocationsController : ControllerBase
    {
        private readonly ILogger<LocationsController> _logger;
        private readonly IMediator _mediator;

        public LocationsController(
            ILogger<LocationsController> logger,
            IMediator mediator)
        {
            _logger = logger;
            _mediator = mediator;
        }

        /// <summary>
        /// Get a list of locations with optional filtering
        /// Actual data has the status "actual".
        /// If you do not pass the status, all data types will be returned, including deleted ones.
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [HttpPost("list")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        public async Task<ActionResult<List<LocationListResponseViewModel>>> GetList(
            [FromBody] LocationListRequestViewModel request,
            CancellationToken cancellationToken)
        {
            var query = new GetLocationListQuery(
                request.Statuses?.Select(_ => Enumeration.IsDefined<AppStatusType>(_.ToString())
                    ? Enumeration.FromDisplayName<AppStatusType>(_.ToString())!
                    : AppStatusType.Active),
                request.ParentIds,
                request.Ids,
                request.Types?.Select(_ => Enumeration.IsDefined<AppLocationType>(_.ToString())
                    ? Enumeration.FromDisplayName<AppLocationType>(_.ToString())!
                    : AppLocationType.Default).ToList());

            if (!query.ValidationResult.IsValid)
                return BadRequest(
                    query
                        .ValidationResult
                        .Errors
                        .Select(failure => new
                        {
                            failure.ErrorCode,
                            failure.ErrorMessage
                        }));

            var (validationResult, output) = await _mediator.Send(
                query,
                cancellationToken);

            if (!validationResult.IsValid)
                return BadRequest(
                    query
                        .ValidationResult
                        .Errors
                        .Select(failure => new
                        {
                            failure.ErrorCode,
                            failure.ErrorMessage
                        }));

            if (output == null || !output.Items.Any())
                return NoContent();

            var viewModels = output.Items.Select(_ => new LocationListResponseViewModel
            {
                Id = _.Id,
                RowVersion = _.RowVersion,
                ParentIds = _.SourceIds,
                ChildrenIds = _.DestinationIds,
                Type = (LocationTypeEnum)Enum.Parse(typeof(LocationTypeEnum), _.Type.ToString()),
                Title = _.Title,
                Description = _.Description,
                Longitude = _.Longitude,
                Latitude = _.Latitude,
                Diameter = _.Diameter
            }).ToList();

            return viewModels;
        }
    }
}
