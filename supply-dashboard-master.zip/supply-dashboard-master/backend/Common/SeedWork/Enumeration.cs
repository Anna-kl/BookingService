﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace Common.SeedWork
{
    public abstract class Enumeration : IComparable
    {
        protected Enumeration(int id, string name)
        {
            Id = id;
            Name = name;
        }

        public int Id { get; }
        public string Name { get; }

        public int CompareTo(object? other) =>
            other == null
                ? 0
                : Id.CompareTo(((Enumeration)other).Id);

        public static IEnumerable<T> GetAll<T>()
            where T : Enumeration
        {
            var fields = typeof(T).GetFields(
                BindingFlags.Public
                | BindingFlags.Static
                | BindingFlags.DeclaredOnly
            );

            return fields
                .Select(f => f.GetValue(null))
                .Cast<T>();
        }

        public static T? FromValue<T>(
            int value)
            where T : Enumeration
        {
            return GetAll<T>().SingleOrDefault(item => item.Id == value);
        }

        public static bool IsDefined<T>(int value)
            where T : Enumeration
        {
            return FromValue<T>(value) != null!;
        }

        public static T? FromDisplayName<T>(string displayName)
            where T : Enumeration
        {
            return GetAll<T>()
                .SingleOrDefault(item => string.Equals(
                    item.Name,
                    displayName,
                    StringComparison.CurrentCultureIgnoreCase));
        }

        public static bool IsDefined<T>(
            string displayName)
            where T : Enumeration
        {
            return FromDisplayName<T>(displayName) != null!;
        }

        public static int AbsoluteDifference(Enumeration firstValue, Enumeration secondValue)
        {
            return Math.Abs(firstValue.Id - secondValue.Id);
        }

        public override bool Equals(object? obj)
        {
            if (!(obj is Enumeration otherValue))
                return false;

            var typeMatches = GetType() == obj.GetType();
            var valueMatches = Id.Equals(otherValue.Id);

            return typeMatches && valueMatches;
        }

        protected bool Equals(Enumeration? other)
        {
            return string.Equals(Name, other?.Name) && Id == other?.Id;
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return ((Name != null ? Name.GetHashCode() : 0) * 397) ^ Id;
            }
        }

        public override string ToString()
        {
            return Name;
        }

        #region operators

        public static bool operator ==(Enumeration? left, Enumeration? right)
        {
            return ReferenceEquals(left, null)
                ? ReferenceEquals(right, null)
                : left.Equals(right);
        }

        public static bool operator !=(Enumeration? left, Enumeration? right)
        {
            return !(left == right);
        }

        public static bool operator <(Enumeration? left, Enumeration? right)
        {
            return ReferenceEquals(left, null)
                ? !ReferenceEquals(right, null)
                : left.CompareTo(right) < 0;
        }

        public static bool operator <=(Enumeration? left, Enumeration? right)
        {
            return ReferenceEquals(left, null)
                   || left.CompareTo(right) <= 0;
        }

        public static bool operator >(Enumeration? left, Enumeration? right)
        {
            return !ReferenceEquals(left, null)
                   && left.CompareTo(right) > 0;
        }

        public static bool operator >=(Enumeration? left, Enumeration? right)
        {
            return ReferenceEquals(left, null)
                ? ReferenceEquals(right, null)
                : left.CompareTo(right) >= 0;
        }

        #endregion
    }
}
