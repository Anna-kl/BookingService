﻿using Common.SeedWork;

using FluentValidation.Results;

using MediatR;

using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.Charts.TransportResources.Output;

using System;
using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.Charts.TransportResources.Input
{
    public sealed class TransportResourcesByPeriodsQuery
        : IRequest<(ValidationResult validationResult, TransportResourcesByPeriodsOutput? output)>
    {
        private readonly List<Guid> _locationsIds;
        private readonly List<Guid> _customersIds;

        public TransportResourcesByPeriodsQuery(
            string periodType,
            DateTime startPeriod,
            DateTime? endPeriod,
            List<Guid>? locationsIds,
            List<Guid>? customersIds)
        {
            PeriodType = Enumeration.IsDefined<AppPeriodsType>(periodType)
                ? Enumeration.FromDisplayName<AppPeriodsType>(periodType)!
                : AppPeriodsType.Default;
            StartPeriod = startPeriod;
            EndPeriod = endPeriod;

            _locationsIds = locationsIds ?? new List<Guid>();
            _customersIds = customersIds ?? new List<Guid>();

            ValidationResult = new TransportResourcesByPeriodsValidator()
                .Validate(this);
        }

        public AppPeriodsType PeriodType { get; }
        public DateTime StartPeriod { get; }
        public DateTime? EndPeriod { get; }

        public IEnumerable<Guid> LocationsIds =>
            _locationsIds.AsReadOnly();

        public IEnumerable<Guid> CustomersIds =>
            _customersIds.AsReadOnly();

        public ValidationResult ValidationResult { get; }
    }
}
