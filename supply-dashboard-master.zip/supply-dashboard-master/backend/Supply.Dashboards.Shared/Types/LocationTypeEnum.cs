﻿namespace Supply.Dashboards.Shared.Types
{
    public enum LocationTypeEnum
    {
        Division = 1,
        Direction = 2,
        Node = 3
    }
}
