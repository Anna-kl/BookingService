﻿using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Charts.AccountingMtrByPeriods
{
    public sealed class AccountingMtrByPeriodsResponseViewModel
    {
        public List<AccountingMtrByPeriodsResponseParamViewModel>? Periods { get; set; }
    }
}
