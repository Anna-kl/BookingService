export interface ITreeEditItem {
    id: string;
    rowVersion: number;
    parentId: string;
    title: string;
    description?: string;
    hasItems: boolean;
}

export interface ITreeListItemRelation {
    id: string;
    dbId: string;
    parentId: string;
    parentDbId: string;
    title: string;
}

export interface ITreeListSelectedItem extends ITreeListItemRelation {
    selected: boolean;
}

export interface IDirectoryTreeDataItem {
    id: string;
    rowVersion: number,
    parentId: string;
    title: string;
    hasItems: boolean;
    description?: string;
}

export interface IDirectoryDataItem {
    id: string;
    rowVersion: number;
    parentIds: any[];
    title: string;
    // type?: string;
    childrenIds: string[];
    description?: string;
}

export interface ILocationDataItem extends IDirectoryDataItem {
    longitude?: number;
    latitude?: number;
    diameter?: number;
    type: LocationTypeEnum;
}

export enum LocationTypeEnum {
    Division = "Division",
    Direction = "Direction",
    Node = "Node"
}

export interface ICustomerDataItem extends IDirectoryDataItem {
    type: CustomerTypeEnum;
}

export enum CustomerTypeEnum {
    Inner = "Inner",
    External = "External"
}

export interface IMtrTypeDataItem extends IDirectoryDataItem {

}

export interface ISelectedCustomer {
    id: string | null;
    title: string;
}

export interface ISelectedLocation {
    id: string;
    type: LocationTypeEnum;
    title: string;
}

export interface ICustomer {
    id: string;
    rowVersion: number;
    title?: string;
    description?: string;
    type: CustomerTypeEnum;
    parentIds?: string[];
    childrenIds: string[];
    isObsolete?: boolean;
}

export interface ILocation {
    id: string;
    rowVersion: number;
    type: LocationTypeEnum;
    parentIds?: string[];
    title?: string;
    description?: string;
    longitude?: number;
    latitude?: number;
    diameter?: number;
    childrenIds: string[];
    isObsolete?: boolean;
}

export interface IMtrType {
    id: string;
    rowVersion: number;
    title?: string;
    description?: string;
    parentIds?: string[];
    childrenIds: string[];
    isObsolete?: boolean;
}

export interface IRelation {
    sourceId: string,
    destinationId: string,
    isObsolete?: boolean
}