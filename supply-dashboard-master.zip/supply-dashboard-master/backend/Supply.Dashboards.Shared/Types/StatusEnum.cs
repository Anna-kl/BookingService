﻿namespace Supply.Dashboards.Shared.Types
{
    public enum StatusEnum
    {
        Active = 1,
        Disable = 2,
        Archived = 3
    }
}
