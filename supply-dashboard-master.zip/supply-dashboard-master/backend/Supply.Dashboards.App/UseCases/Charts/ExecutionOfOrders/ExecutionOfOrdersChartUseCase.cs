﻿using Common.Extensions;
using FluentValidation.Results;
using MediatR;
using Microsoft.Extensions.Logging;
using Supply.Dashboards.App.UseCases.Charts.ExecutionOfOrders.Input;
using Supply.Dashboards.App.UseCases.Charts.ExecutionOfOrders.Output;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.Types;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.Charts.ExecutionOfOrders
{
    public sealed class ExecutionOfOrdersChartUseCase
        : IRequestHandler<ExecutionOfOrdersChartQuery, (ValidationResult validationResult, ExecutionOfOrdersChartOutput? output)>
    {
        private readonly ILogger<ExecutionOfOrdersChartUseCase> _logger;
        private readonly IMediator _mediator;
        private readonly IExecutionOfOrdersChart _executionOfOrdersChart;

        private List<Customer> _customers;
        private List<Location> _locations;
        private ValidationResult _validationResult;
        private readonly List<StatusType> _selectStatus;

        public ExecutionOfOrdersChartUseCase(
            ILogger<ExecutionOfOrdersChartUseCase> logger,
            IMediator mediator,
            IExecutionOfOrdersChart executionOfOrdersChart)
        {
            _logger = logger;
            _mediator = mediator;
            _executionOfOrdersChart = executionOfOrdersChart;

            _customers = new List<Customer>();
            _locations = new List<Location>();
            _validationResult = new ValidationResult();
            _selectStatus = new List<StatusType> { StatusType.Active };
        }

        public async Task<(ValidationResult validationResult, ExecutionOfOrdersChartOutput? output)> Handle(
            ExecutionOfOrdersChartQuery request,
            CancellationToken cancellationToken)
        {
            _validationResult = request.ValidationResult;

            // If there are validation errors, abort the method and return errors.
            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            await Customers(request, cancellationToken);
            await Locations(request, cancellationToken);

            // If there are validation errors, abort the method and return errors.
            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            var records = (await _executionOfOrdersChart.GetRecords(
                    request.StartPeriod,
                    request.EndPeriod,
                    _locations,
                    _customers,
                    cancellationToken));

            return (_validationResult, new ExecutionOfOrdersChartOutput(records));
        }

        private async Task Customers(
            ExecutionOfOrdersChartQuery query,
            CancellationToken cancellationToken)
        {
            var existingIdsFromFilter = (await _executionOfOrdersChart.GetCustomersExistingIds(
                _selectStatus,
                query.CustomersIds.ToList(),
                cancellationToken)).ToList();
            var nonExistentIdsFromFilter = query
                .CustomersIds
                .Except(existingIdsFromFilter)
                .ToList();

            if (nonExistentIdsFromFilter.Any())
            {
                foreach (var id in nonExistentIdsFromFilter)
                    _validationResult.Errors.Add(new ValidationFailure(
                        "CustomerId",
                        $"{nameof(Customer)} with id \"{id}\" is not exist."));

                return;
            }

            var allCustomers = (await _executionOfOrdersChart.GetCustomers(
                _selectStatus,
                cancellationToken))
                .Where(_ => _.SourceEdges == null || !_.SourceEdges.Any())
                .SelectMany(_ => _.DepthFirstSearch(
                    edge => edge.Destination,
                    customer => customer.DestinationEdges,
                    _ => { }))
                .ToList();
            var allCustomersIds = allCustomers
                .Select(_ => _.InnerId)
                .ToList();
            var allCustomersEdges = (await _executionOfOrdersChart.GetCustomersEdges(
                allCustomersIds,
                cancellationToken)).ToList();

            foreach (var customer in allCustomers)
            {
                var sourceIds = allCustomersEdges
                    .Where(_ => _.DestinationId == customer.Id)
                    .Select(_ => _.SourceId);
                var sourcesVertex = allCustomers.Where(_ => sourceIds.Contains(_.Id));
                customer.AddSourceEdges(sourcesVertex.Select(_ => new CustomerEdge(_, customer)));

                var destinationIds = allCustomersEdges
                    .Where(_ => _.SourceId == customer.Id)
                    .Select(_ => _.DestinationId);
                var destinationVertex = allCustomers.Where(_ => destinationIds.Contains(_.Id));
                customer.AddDestinationEdges(destinationVertex.Select(_ => new CustomerEdge(customer, _)));
            }

            if (!query.CustomersIds.Any())
            {
                _customers = allCustomers;
                return;
            }

            var customersFromFilter = new List<Customer>();

            foreach (var customer in allCustomers)
            {
                customer.DepthFirstSearch(
                    _ => _.Destination,
                    _ => _.DestinationEdges!,
                    _ =>
                    {
                        if (existingIdsFromFilter.Contains(_.InnerId))
                            customersFromFilter.Add(_);
                    });
            }

            var customers = new List<Customer>();

            foreach (var customer in customersFromFilter)
            {
                customers.AddRange(customer.DepthFirstSearch(
                    _ => _.Destination,
                    _ => _.DestinationEdges!,
                    _ => { }));
            }

            if (!customers.Any())
                customers = allCustomers;

            _customers = customers
                .Distinct()
                .ToList();
        }

        private async Task Locations(
           ExecutionOfOrdersChartQuery query,
           CancellationToken cancellationToken)
        {
            var existingIdsFromFilter = (await _executionOfOrdersChart.GetLocationsExistingIds(
                _selectStatus,
                query.LocationsIds.ToList(),
                cancellationToken)).ToList();
            var nonExistentIdsFromFilter = query
                .LocationsIds
                .Except(existingIdsFromFilter)
                .ToList();

            if (nonExistentIdsFromFilter.Any())
            {
                foreach (var id in nonExistentIdsFromFilter)
                    _validationResult.Errors.Add(new ValidationFailure(
                        "LocationId",
                        $"{nameof(Location)} with id \"{id}\" is not exist."));

                return;
            }

            var allLocations = (await _executionOfOrdersChart.GetLocations(
                _selectStatus,
                cancellationToken))
                .Where(_ => _.SourceEdges == null || !_.SourceEdges.Any())
                .SelectMany(_ => _.DepthFirstSearch(
                    edge => edge.Destination,
                    location => location.DestinationEdges,
                    _ => { }))
                .ToList();
            var allLocationsIds = allLocations
                .Select(_ => _.InnerId)
                .ToList();
            var allLocationsEdges = (await _executionOfOrdersChart.GetLocationsEdges(
                allLocationsIds,
                cancellationToken)).ToList();

            foreach (var location in allLocations)
            {
                var sourceIds = allLocationsEdges
                    .Where(_ => _.DestinationId == location.Id)
                    .Select(_ => _.SourceId);
                var sourcesVertex = allLocations.Where(_ => sourceIds.Contains(_.Id));
                location.AddSourceEdges(sourcesVertex.Select(_ => new LocationEdge(_, location)));

                var destinationIds = allLocationsEdges
                    .Where(_ => _.SourceId == location.Id)
                    .Select(_ => _.DestinationId);
                var destinationVertex = allLocations.Where(_ => destinationIds.Contains(_.Id));
                location.AddDestinationEdges(destinationVertex.Select(_ => new LocationEdge(location, _)));
            }

            if (!query.LocationsIds.Any())
            {
                _locations = allLocations;
                return;
            }

            var locationsFromFilter = new List<Location>();

            foreach (var location in allLocations)
            {
                location.DepthFirstSearch(
                    _ => _.Destination,
                    _ => _.DestinationEdges!,
                    _ =>
                    {
                        if (existingIdsFromFilter.Contains(_.InnerId))
                            locationsFromFilter.Add(_);
                    });
            }

            var locations = new List<Location>();

            foreach (var location in locationsFromFilter)
            {
                locations.AddRange(location.DepthFirstSearch(
                    _ => _.Destination,
                    _ => _.DestinationEdges!,
                    _ => { }));
            }

            if (!locations.Any())
                locations = allLocations;

            _locations = locations
                .Distinct()
                .ToList();
        }
    }
}
