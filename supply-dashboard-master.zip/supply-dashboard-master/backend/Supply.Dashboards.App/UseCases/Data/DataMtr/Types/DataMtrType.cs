﻿using Common.SeedWork;

using Supply.Dashboards.App.Exceptions;
using Supply.Dashboards.Domain.Types;

namespace Supply.Dashboards.App.UseCases.Data.DataMtr.Types
{
    public sealed class DataMtrType : Enumeration
    {
#pragma warning disable CA2211 // Non-constant fields should not be visible
        public static DataMtrType Default = new(0, "Default");

        public static DataMtrType CargoHandlingFact = new(100, "CargoHandlingFact");
        public static DataMtrType CargoHandlingPlan = new(101, "CargoHandlingPlan");
        public static DataMtrType CargoHandlingAdjustedPlan = new(102, "CargoHandlingAdjustedPlan");
        public static DataMtrType CargoHandlingDailyPlan = new(103, "CargoHandlingDailyPlan");

        public static DataMtrType FreightTurnoverFact = new(200, "FreightTurnoverFact");
        public static DataMtrType FreightTurnoverPlan = new(201, "FreightTurnoverPlan");
        public static DataMtrType FreightTurnoverAdjustedPlan = new(202, "FreightTurnoverAdjustedPlan");
        public static DataMtrType FreightTurnoverDailyPlan = new(203, "FreightTurnoverDailyPlan");

        public static DataMtrType ArrivalFact = new(204, "ArrivalFact");
        public static DataMtrType ArrivalPlan = new(205, "ArrivalPlan");
        public static DataMtrType ArrivalAdjustedPlan = new(206, "ArrivalAdjustedPlan");
        public static DataMtrType ArrivalDailyPlan = new(207, "ArrivalDailyPlan");

        public static DataMtrType ExpenditureFact = new(208, "ExpenditureFact");
        public static DataMtrType ExpenditurePlan = new(209, "ExpenditurePlan");
        public static DataMtrType ExpenditureAdjustedPlan = new(210, "ExpenditureAdjustedPlan");
        public static DataMtrType ExpenditureDailyPlan = new(211, "ExpenditureDailyPlan");

        public static DataMtrType SeasonalDeliveryFact = new(300, "SeasonalDeliveryFact");
        public static DataMtrType SeasonalDeliveryPlan = new(301, "SeasonalDeliveryPlan");
        public static DataMtrType SeasonalDeliveryAdjustedPlan = new(302, "SeasonalDeliveryAdjustedPlan");
        public static DataMtrType SeasonalDeliveryDailyPlan = new(303, "SeasonalDeliveryDailyPlan");

        public static DataMtrType AccountingMtrTotalSupplies = new(400, "AccountingMtrTotalSupplies");
        public static DataMtrType AccountingMtrProcessing = new(401, "AccountingMtrProcessing");
        public static DataMtrType AccountingMtrUncapitalize0_14 = new(402, "AccountingMtrUncapitalize0_14");
        public static DataMtrType AccountingMtrUncapitalize15_30 = new(403, "AccountingMtrUncapitalize15_30");
        public static DataMtrType AccountingMtrUncapitalize31_60 = new(404, "AccountingMtrUncapitalize31_60");
        public static DataMtrType AccountingMtrUncapitalize61More = new(405, "AccountingMtrUncapitalize61More");

        public static DataMtrType BidPlan = new(500, "BidPlan");
        public static DataMtrType BidForecast = new(501, "BidForecast");
        public static DataMtrType BidTotalFact = new(502, "BidTotalFact");
        public static DataMtrType BidScheduledFact = new(503, "BidScheduledFact");
        public static DataMtrType BidUnplanned = new(504, "BidUnplanned");

        public static DataMtrType HseDeath = new(600, "HseDeath");
        public static DataMtrType HseDisability = new(601, "HseDisability");
        public static DataMtrType HseMedicalCare = new(602, "HseMedicalCare");
        public static DataMtrType HseNearMiss = new(603, "HseNearMiss");
        public static DataMtrType HseDangerWarning = new(604, "HseDangerWarning");

        public static DataMtrType TransportPlan = new(701, "TransportPlan");
        public static DataMtrType TransportFact = new(702, "TransportFact");
        public static DataMtrType GPMPlan = new(703, "GPMPlan");
        public static DataMtrType GPMFact = new(704, "GPMFact");
        public static DataMtrType LaborResourcesPlan = new(705, "LaborResourcesPlan");
        public static DataMtrType LaborResourcesFact = new(706, "LaborResourcesFact");

        public static DataMtrType FullnessBasesTotalSquare = new(801, "FullnessBasesTotalSquare");
        public static DataMtrType FullnessBasesLoaded = new(802, "FullnessBasesLoaded");
        public static DataMtrType FullnessBasesLoadedRubles = new(803, "FullnessBasesLoadedRubles");
        public static DataMtrType FullnessBasesLoadedWeight = new(804, "FullnessBasesLoadedWeight");
#pragma warning restore CA2211 // Non-constant fields should not be visible

        public DataMtrType(int id, string name) : base(id, name)
        {
        }

        #region ValueRecords

        internal static bool IsValueRecordType(DataMtrType type)
        {
            return type.Name switch
            {
                nameof(Default) => false,

                nameof(CargoHandlingFact) => true,
                nameof(CargoHandlingPlan) => true,
                nameof(CargoHandlingAdjustedPlan) => true,
                nameof(CargoHandlingDailyPlan) => true,

                nameof(FreightTurnoverFact) => true,
                nameof(FreightTurnoverPlan) => true,
                nameof(FreightTurnoverAdjustedPlan) => true,
                nameof(FreightTurnoverDailyPlan) => true,

                nameof(ArrivalFact) => true,
                nameof(ArrivalPlan) => true,
                nameof(ArrivalAdjustedPlan) => true,
                nameof(ArrivalDailyPlan) => true,

                nameof(ExpenditureFact) => true,
                nameof(ExpenditurePlan) => true,
                nameof(ExpenditureAdjustedPlan) => true,
                nameof(ExpenditureDailyPlan) => true,

                nameof(SeasonalDeliveryFact) => true,
                nameof(SeasonalDeliveryPlan) => true,
                nameof(SeasonalDeliveryAdjustedPlan) => true,
                nameof(SeasonalDeliveryDailyPlan) => true,

                nameof(AccountingMtrTotalSupplies) => true,
                nameof(AccountingMtrProcessing) => true,
                nameof(AccountingMtrUncapitalize0_14) => true,
                nameof(AccountingMtrUncapitalize15_30) => true,
                nameof(AccountingMtrUncapitalize31_60) => true,
                nameof(AccountingMtrUncapitalize61More) => true,

                nameof(TransportPlan) => true,
                nameof(TransportFact) => true,
                nameof(GPMPlan) => true,
                nameof(GPMFact) => true,
                nameof(LaborResourcesPlan) => true,
                nameof(LaborResourcesFact) => true,

                nameof(FullnessBasesTotalSquare) => true,
                nameof(FullnessBasesLoaded) => true,
                nameof(FullnessBasesLoadedRubles) => true,
                nameof(FullnessBasesLoadedWeight) => true,

                _ => false
            };
        }

        internal static ValueRecordType GetValueRecordType(DataMtrType type)
        {
            var name = type.Name switch
            {
                nameof(Default) => throw new AppException(nameof(Default)),

                nameof(CargoHandlingFact) => ValueRecordType.CargoHandlingFact.Name,
                nameof(CargoHandlingPlan) => ValueRecordType.CargoHandlingPlan.Name,
                nameof(CargoHandlingAdjustedPlan) => ValueRecordType.CargoHandlingAdjustedPlan.Name,
                nameof(CargoHandlingDailyPlan) => ValueRecordType.CargoHandlingDailyPlan.Name,

                nameof(FreightTurnoverFact) => ValueRecordType.FreightTurnoverFact.Name,
                nameof(FreightTurnoverPlan) => ValueRecordType.FreightTurnoverPlan.Name,
                nameof(FreightTurnoverAdjustedPlan) => ValueRecordType.FreightTurnoverAdjustedPlan.Name,
                nameof(FreightTurnoverDailyPlan) => ValueRecordType.FreightTurnoverDailyPlan.Name,

                nameof(ArrivalFact) => ValueRecordType.ArrivalFact.Name,
                nameof(ArrivalPlan) => ValueRecordType.ArrivalPlan.Name,
                nameof(ArrivalAdjustedPlan) => ValueRecordType.ArrivalAdjustedPlan.Name,
                nameof(ArrivalDailyPlan) => ValueRecordType.ArrivalDailyPlan.Name,

                nameof(ExpenditureFact) => ValueRecordType.ExpenditureFact.Name,
                nameof(ExpenditurePlan) => ValueRecordType.ExpenditurePlan.Name,
                nameof(ExpenditureAdjustedPlan) => ValueRecordType.ExpenditureAdjustedPlan.Name,
                nameof(ExpenditureDailyPlan) => ValueRecordType.ExpenditureDailyPlan.Name,

                nameof(SeasonalDeliveryFact) => ValueRecordType.SeasonalDeliveryFact.Name,
                nameof(SeasonalDeliveryPlan) => ValueRecordType.SeasonalDeliveryPlan.Name,
                nameof(SeasonalDeliveryAdjustedPlan) => ValueRecordType.SeasonalDeliveryAdjustedPlan.Name,
                nameof(SeasonalDeliveryDailyPlan) => ValueRecordType.SeasonalDeliveryDailyPlan.Name,

                nameof(AccountingMtrTotalSupplies) => ValueRecordType.AccountingMtrTotalSupplies.Name,
                nameof(AccountingMtrProcessing) => ValueRecordType.AccountingMtrProcessing.Name,
                nameof(AccountingMtrUncapitalize0_14) => ValueRecordType.AccountingMtrUncapitalize0_14.Name,
                nameof(AccountingMtrUncapitalize15_30) => ValueRecordType.AccountingMtrUncapitalize15_30.Name,
                nameof(AccountingMtrUncapitalize31_60) => ValueRecordType.AccountingMtrUncapitalize31_60.Name,
                nameof(AccountingMtrUncapitalize61More) => ValueRecordType.AccountingMtrUncapitalize61More.Name,

                nameof(TransportPlan) => ValueRecordType.TransportPlan.Name,
                nameof(TransportFact) => ValueRecordType.TransportFact.Name,
                nameof(GPMPlan) => ValueRecordType.GPMPlan.Name,
                nameof(GPMFact) => ValueRecordType.GPMFact.Name,
                nameof(LaborResourcesPlan) => ValueRecordType.LaborResourcesPlan.Name,
                nameof(LaborResourcesFact) => ValueRecordType.LaborResourcesFact.Name,

                nameof(FullnessBasesTotalSquare) => ValueRecordType.FullnessBasesTotalSquare.Name,
                nameof(FullnessBasesLoaded) => ValueRecordType.FullnessBasesLoaded.Name,
                nameof(FullnessBasesLoadedRubles) => ValueRecordType.FullnessBasesLoadedRubles.Name,
                nameof(FullnessBasesLoadedWeight) => ValueRecordType.FullnessBasesLoadedWeight.Name,

                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<ValueRecordType>(name)!;
        }

        internal static DataMtrType GetDataMtrType(ValueRecordType type)
        {
            var name = type.Name switch
            {
                nameof(ValueRecordType.CargoHandlingFact) => CargoHandlingFact.Name,
                nameof(ValueRecordType.CargoHandlingPlan) => CargoHandlingPlan.Name,
                nameof(ValueRecordType.CargoHandlingAdjustedPlan) => CargoHandlingAdjustedPlan.Name,
                nameof(ValueRecordType.CargoHandlingDailyPlan) => CargoHandlingDailyPlan.Name,

                nameof(ValueRecordType.FreightTurnoverFact) => FreightTurnoverFact.Name,
                nameof(ValueRecordType.FreightTurnoverPlan) => FreightTurnoverPlan.Name,
                nameof(ValueRecordType.FreightTurnoverAdjustedPlan) => FreightTurnoverAdjustedPlan.Name,
                nameof(ValueRecordType.FreightTurnoverDailyPlan) => FreightTurnoverDailyPlan.Name,

                nameof(ValueRecordType.ArrivalFact) => ArrivalFact.Name,
                nameof(ValueRecordType.ArrivalPlan) => ArrivalPlan.Name,
                nameof(ValueRecordType.ArrivalAdjustedPlan) => ArrivalAdjustedPlan.Name,
                nameof(ValueRecordType.ArrivalDailyPlan) => ArrivalDailyPlan.Name,

                nameof(ValueRecordType.ExpenditureFact) => ExpenditureFact.Name,
                nameof(ValueRecordType.ExpenditurePlan) => ExpenditurePlan.Name,
                nameof(ValueRecordType.ExpenditureAdjustedPlan) => ExpenditureAdjustedPlan.Name,
                nameof(ValueRecordType.ExpenditureDailyPlan) => ExpenditureDailyPlan.Name,

                nameof(ValueRecordType.SeasonalDeliveryFact) => SeasonalDeliveryFact.Name,
                nameof(ValueRecordType.SeasonalDeliveryPlan) => SeasonalDeliveryPlan.Name,
                nameof(ValueRecordType.SeasonalDeliveryAdjustedPlan) => SeasonalDeliveryAdjustedPlan.Name,
                nameof(ValueRecordType.SeasonalDeliveryDailyPlan) => SeasonalDeliveryDailyPlan.Name,

                nameof(ValueRecordType.AccountingMtrTotalSupplies) => AccountingMtrTotalSupplies.Name,
                nameof(ValueRecordType.AccountingMtrProcessing) => AccountingMtrProcessing.Name,
                nameof(ValueRecordType.AccountingMtrUncapitalize0_14) => AccountingMtrUncapitalize0_14.Name,
                nameof(ValueRecordType.AccountingMtrUncapitalize15_30) => AccountingMtrUncapitalize15_30.Name,
                nameof(ValueRecordType.AccountingMtrUncapitalize31_60) => AccountingMtrUncapitalize31_60.Name,
                nameof(ValueRecordType.AccountingMtrUncapitalize61More) => AccountingMtrUncapitalize61More.Name,

                nameof(ValueRecordType.TransportPlan) => TransportPlan.Name,
                nameof(ValueRecordType.TransportFact) => TransportFact.Name,
                nameof(ValueRecordType.GPMPlan) => GPMPlan.Name,
                nameof(ValueRecordType.GPMFact) => GPMFact.Name,
                nameof(ValueRecordType.LaborResourcesPlan) => LaborResourcesPlan.Name,
                nameof(ValueRecordType.LaborResourcesFact) => LaborResourcesFact.Name,

                nameof(ValueRecordType.FullnessBasesTotalSquare) => FullnessBasesTotalSquare.Name,
                nameof(ValueRecordType.FullnessBasesLoaded) => FullnessBasesLoaded.Name,
                nameof(ValueRecordType.FullnessBasesLoadedRubles) => FullnessBasesLoadedRubles.Name,
                nameof(ValueRecordType.FullnessBasesLoadedWeight) => FullnessBasesLoadedWeight.Name,

                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<DataMtrType>(name)!;
        }

        #endregion

        #region HseIncidents

        internal static bool IsHseIncidentType(DataMtrType type) =>
            type.Name switch
            {
                nameof(Default) => false,
                nameof(HseDeath) => true,
                nameof(HseDisability) => true,
                nameof(HseMedicalCare) => true,
                nameof(HseNearMiss) => true,
                nameof(HseDangerWarning) => true,
                _ => false
            };

        internal static HseIncidentType GetHseIncidentType(DataMtrType type)
        {
            var name = type.Name switch
            {
                nameof(Default) => throw new AppException(nameof(Default)),
                nameof(HseDeath) => HseIncidentType.Death.Name,
                nameof(HseDisability) => HseIncidentType.Disability.Name,
                nameof(HseMedicalCare) => HseIncidentType.MedicalCare.Name,
                nameof(HseNearMiss) => HseIncidentType.NearMiss.Name,
                nameof(HseDangerWarning) => HseIncidentType.DangerWarning.Name,
                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<HseIncidentType>(name)!;
        }

        internal static DataMtrType GetDataMtrType(HseIncidentType type)
        {
            var name = type.Name switch
            {
                nameof(HseIncidentType.Death) => HseDeath.Name,
                nameof(HseIncidentType.Disability) => HseDisability.Name,
                nameof(HseIncidentType.MedicalCare) => HseMedicalCare.Name,
                nameof(HseIncidentType.NearMiss) => HseNearMiss.Name,
                nameof(HseIncidentType.DangerWarning) => HseDangerWarning.Name,
                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<DataMtrType>(name)!;
        }

        #endregion

        #region Bids

        internal static bool IsBidType(DataMtrType type) =>
            type.Name switch
            {
                nameof(Default) => false,
                nameof(BidPlan) => true,
                nameof(BidForecast) => true,
                nameof(BidTotalFact) => true,
                nameof(BidScheduledFact) => true,
                nameof(BidUnplanned) => true,
                _ => false
            };

        internal static BidType GetBidType(DataMtrType type)
        {
            var name = type.Name switch
            {
                nameof(Default) => throw new AppException(nameof(Default)),
                nameof(BidPlan) => BidType.Plan.Name,
                nameof(BidForecast) => BidType.Forecast.Name,
                nameof(BidTotalFact) => BidType.TotalFact.Name,
                nameof(BidScheduledFact) => BidType.ScheduledFact.Name,
                nameof(BidUnplanned) => BidType.Unplanned.Name,
                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<BidType>(name)!;
        }

        internal static DataMtrType GetDataMtrType(BidType type)
        {
            var name = type.Name switch
            {
                nameof(BidType.Plan) => BidPlan.Name,
                nameof(BidType.Forecast) => BidForecast.Name,
                nameof(BidType.TotalFact) => BidTotalFact.Name,
                nameof(BidType.ScheduledFact) => BidScheduledFact.Name,
                nameof(BidType.Unplanned) => BidUnplanned.Name,
                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<DataMtrType>(name)!;
        }

        #endregion
    }
}
