﻿using FluentValidation.Results;

using MediatR;

using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.Charts.CargoGroupByPeriods.Output;

using System;
using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.Charts.CargoGroupByPeriods.Input
{
    public sealed class CargoGroupByPeriodsQuery
        : IRequest<(ValidationResult validationResult, CargoGroupByPeriodsOutput? output)>
    {
        private readonly List<Guid> _locationsIds;
        private readonly List<Guid> _customersIds;
        private readonly List<Guid> _mtrTypesIds;

        public CargoGroupByPeriodsQuery(
            AppPeriodsType? periodType,
            AppDataType? dataType,
            DateTime startPeriod,
            DateTime? endPeriod,
            List<Guid>? locationsIds,
            List<Guid>? customersIds,
            List<Guid>? mtrTypesIds)
        {
            PeriodType = periodType ?? AppPeriodsType.Default;
            DataType = dataType ?? AppDataType.Default;
            StartPeriod = startPeriod;
            EndPeriod = endPeriod;

            _locationsIds = locationsIds ?? new List<Guid>();
            _customersIds = customersIds ?? new List<Guid>();
            _mtrTypesIds = mtrTypesIds ?? new List<Guid>();

            ValidationResult = new CargoGroupByPeriodsValidator()
                .Validate(this);
        }

        public AppPeriodsType PeriodType { get; }
        public AppDataType DataType { get; }
        public DateTime StartPeriod { get; }
        public DateTime? EndPeriod { get; }

        public IEnumerable<Guid> LocationsIds =>
            _locationsIds.AsReadOnly();

        public IEnumerable<Guid> CustomersIds =>
            _customersIds.AsReadOnly();

        public IEnumerable<Guid> MtrTypesIds =>
            _mtrTypesIds.AsReadOnly();

        public ValidationResult ValidationResult { get; }
    }
}
