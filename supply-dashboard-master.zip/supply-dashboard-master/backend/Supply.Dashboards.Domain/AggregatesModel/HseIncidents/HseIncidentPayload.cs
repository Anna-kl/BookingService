﻿using Common.SeedWork;

using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.Exceptions;
using Supply.Dashboards.Domain.Types;

using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Domain.AggregatesModel.HseIncidents
{
    public sealed class HseIncidentPayload : ValueObject
    {
        public HseIncidentPayload(
            DateTime dateTime,
            HseIncidentType type,
            Customer? customer,
            Location? location,
            string text,
            InputType inputType)
        {
            DateTime = dateTime == default
                ? throw new DomainException($"{nameof(dateTime)} can't be a default value")
                : dateTime;
            Type = type
                   ?? throw new DomainException($"{nameof(type)} can't be null.");
            Customer = customer;
            Location = location;
            Text = string.IsNullOrWhiteSpace(text) // TODO
                ? text // throw new DomainException($"{nameof(text)} can't be null.")
                : text;
            InputType = inputType;
        }

#pragma warning disable 8618
        // ReSharper disable once UnusedMember.Local
        private HseIncidentPayload()
        {
        }
#pragma warning restore 8618

        public DateTime DateTime { get; init; }

        public HseIncidentType Type { get; init; }

        public Customer? Customer { get; init; }
        public Location? Location { get; init; }

        public string Text { get; init; }

        public InputType InputType { get; init; }

        protected override IEnumerable<object> GetAtomicValues()
        {
            yield return DateTime;
            yield return Type;
            yield return Customer!;
            yield return Location!;
            yield return Text;
            yield return InputType;
        }
    }
}
