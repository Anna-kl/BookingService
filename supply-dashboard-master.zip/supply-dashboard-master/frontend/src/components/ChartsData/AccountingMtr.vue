<template>
  <div class="module-inner-container">
    <DxToolbar>
      <DxItem widget="dxButton" location="after" :options="prevButtonOptions" />
      <DxItem location="after" :text="periodText()" />
      <DxItem widget="dxButton" location="after" :options="nextButtonOptions" />
    </DxToolbar>

    <DxChart :data-source="chartData" class="chart-module">
      <DxCommonSeriesSettings
        argument-field="period"
        hover-mode="allArgumentPoints"
        selection-mode="allArgumentPoints"
        type="stackedbar"
      >
      </DxCommonSeriesSettings>
      <DxSeries
        v-for="seriesItem in series.filter((s) => s.value)"
        :key="seriesItem.id"
        :value-field="seriesItem.id"
        :name="seriesItem.name"
        :color="seriesItem.color"
        :stack="seriesItem.stack"
      />
      <DxTitle :text="title" horizontalAlignment="left">
        <DxSubtitle text="млн. руб.">
          <DxFont color="#42a2f6" />
        </DxSubtitle>
      </DxTitle>
      <DxLegend vertical-alignment="bottom" horizontal-alignment="center" />
      <DxTooltip :enabled="true" :customize-tooltip="customizeTooltip">
        <DxFormat :precision="3" type="fixedPoint" />
      </DxTooltip>
    </DxChart>
  </div>
</template>

<script lang='ts'>
import {
  DxChart,
  DxSeries,
  DxCommonSeriesSettings,
  DxLabel,
  DxFormat,
  DxLegend,
  DxTooltip,
  DxTitle,
  DxSubtitle,
  DxFont,
} from "devextreme-vue/chart";
import { Component, Prop } from "vue-property-decorator";
import config from "@/config";
import notify from "devextreme/ui/notify";
import {
  IAccountingMtrChartData,
  IAccountingMtrPeriodResponse,
  IAccountingMtrRequest,
  IAccountingMtrResponse,
} from "@/dto/AccountingMtrData";
import {
  getShortMonth,
  addMonth,
  getYearStart,
  getYearEnd,
  getDuration,
  roundDate,
  getMonthStart,
  getMonthEnd,
  addDurationToDate,
} from "@/helpers";
import { ChartDataService } from "@/services/chartDataService";
import DxToolbar, { DxItem } from "devextreme-vue/toolbar";
import {
  ChartPeriodEnum,
  IModuleConfig,
  IModuleSeries,
} from "@/dto/Dashboards";
import Chart from "@/components/ChartsData/chart";
import { SettingsState } from "@/store";
import { MtrItemTypeEnum } from "@/dto/InputData";

@Component({
  components: {
    DxChart,
    DxSeries,
    DxCommonSeriesSettings,
    DxLabel,
    DxFormat,
    DxLegend,
    DxTooltip,
    DxTitle,
    DxSubtitle,
    DxFont,
    DxToolbar,
    DxItem,
  },
})
export default class AccountingMtr extends Chart {
  @Prop({ type: Object, required: false }) public config!: IModuleConfig;
  @Prop({ type: Array, required: false }) public series!: IModuleSeries[];

  private title: string = "Учет МТР";
  private chartData: IAccountingMtrChartData[] = [];
  private curDate: Date = roundDate(new Date());
  private period?: ChartPeriodEnum = this.config.period;

  private url = config.remoteHost + "/api/dashboards/accounting-mtr-by-periods";
  private _chartDataService!: ChartDataService;

  public update() {
    this.getData();
  }

  private prevButtonOptions = {
    icon: "arrowleft",
    hint: "Предыдущий период",
    onClick: () => this.prevPeriod(),
  };

  private nextButtonOptions = {
    icon: "arrowright",
    hint: "Следующий период",
    onClick: () => this.nextPeriod(),
  };

  private prevPeriod() {
    switch (this.config?.period) {
      case ChartPeriodEnum.Year:
        this.curDate.setFullYear(this.curDate.getFullYear() - 1);
        break;
      case ChartPeriodEnum.Month:
      default:
        this.curDate = addMonth(this.curDate, -1);
        break;
    }

    this.getData();
  }

  private nextPeriod() {
    switch (this.config?.period) {
      case ChartPeriodEnum.Year:
        this.curDate.setFullYear(this.curDate.getFullYear() + 1);
        break;
      case ChartPeriodEnum.Month:
      default:
        this.curDate = addMonth(this.curDate, 1);
        break;
    }
    this.getData();
  }

  private created() {
    this._chartDataService = new ChartDataService();
  }

  private mounted(): void {
    this.getData();
  }

  private async getData() {
    this.chartData = [];

    let startPeriod: string;
    let endPeriod: string;

    switch (this.config?.period) {
      case ChartPeriodEnum.Year:
        startPeriod = getYearStart(this.curDate);
        endPeriod = getYearEnd(this.curDate);
        break;
      case ChartPeriodEnum.Day:
        startPeriod = getMonthStart(this.curDate);
        endPeriod = this.curDate.toISOString();
        break;
      case ChartPeriodEnum.Month:
      default:
        startPeriod = getMonthStart(this.curDate);
        endPeriod = getMonthEnd(this.curDate);
        break;
    }

    const duration = getDuration(startPeriod, endPeriod);
    const requestPeriod = config.durationPickerValues.find(
      (value) => value.chartPeriod === this.config.period
    )!.groupBy;

    const request: IAccountingMtrRequest = {
      period: requestPeriod,
      startPeriod: startPeriod,
      duration: duration,
      locationsIds: this.config?.locationsIds?.map<string>((s) => s.dbId) || [],
      customersIds: this.config?.customersIds || [],
      mtrTypesIds: this.config?.mtrTypesIds || [],
    };

    const data = await this._chartDataService
      .getAccountingMtrPeriod(this.url, request)
      .then((data) => {
        const response = data as IAccountingMtrPeriodResponse[];
        if (response) {
          this.chartData = [];

          switch (this.config.period) {
            case ChartPeriodEnum.Month:
              for (let i = 0; i < Number(duration); i++) {
                const xValue = addDurationToDate(startPeriod, i);

                const obj: IAccountingMtrChartData = {
                  period: xValue.getDate().toString(),
                };

                const periodData = response.filter(
                  (x) =>
                    new Date(x.period).toDateString() == xValue.toDateString()
                )[0];

                if (periodData !== undefined) {
                  this.createChartData(obj, periodData);

                  this.chartData.push(obj);
                }
              }
              break;
            case ChartPeriodEnum.Year:
            default:
              for (let i = 0; i < 12; i++) {
                const obj: IAccountingMtrChartData = {
                  period: getShortMonth(i),
                };

                const periodData: IAccountingMtrPeriodResponse = response.filter(
                  (x) => {
                    const date = new Date(x.period);
                    return (
                      date.getMonth() == i &&
                      date.getFullYear() == this.curDate.getFullYear()
                    );
                  }
                )[0];

                if (periodData !== undefined) {
                  this.createChartData(obj, periodData);

                  this.chartData.push(obj);
                }
              }
              break;
          }
        }
      })
      .catch((error: any) => {
        notify(error, "error", 2000);
        throw new Error(error);
      });
  }

  private createChartData(
    obj: IAccountingMtrChartData,
    periodData: IAccountingMtrPeriodResponse
  ) {
    obj.totalSupplies =
      periodData.units.find(
        (s) =>
          s.type === MtrItemTypeEnum[MtrItemTypeEnum.AccountingMtrTotalSupplies]
      )?.tons ?? 0;
    obj.processing =
      periodData.units.find(
        (s) =>
          s.type === MtrItemTypeEnum[MtrItemTypeEnum.AccountingMtrProcessing]
      )?.tons ?? 0;
    obj.uncapitalize0_14 =
      periodData.units.find(
        (s) =>
          s.type ===
          MtrItemTypeEnum[MtrItemTypeEnum.AccountingMtrUncapitalize0_14]
      )?.tons ?? 0;
    obj.uncapitalize15_30 =
      periodData.units.find(
        (s) =>
          s.type ===
          MtrItemTypeEnum[MtrItemTypeEnum.AccountingMtrUncapitalize15_30]
      )?.tons ?? 0;
    obj.uncapitalize31_60 =
      periodData.units.find(
        (s) =>
          s.type ===
          MtrItemTypeEnum[MtrItemTypeEnum.AccountingMtrUncapitalize31_60]
      )?.tons ?? 0;
    obj.uncapitalize61More =
      periodData.units.find(
        (s) =>
          s.type ===
          MtrItemTypeEnum[MtrItemTypeEnum.AccountingMtrUncapitalize61More]
      )?.tons ?? 0;
  }

  private onPointClick({ target }: any) {
    target.select();
  }

  private periodText() {
    let result: string;
    switch (this.config?.period) {
      case ChartPeriodEnum.Month:
        result = `${this.curDate.toLocaleString("ru", {
          month: "long",
        })} ${this.curDate.getFullYear()}`;
        break;
      case ChartPeriodEnum.Year:
      default:
        result = this.curDate.getFullYear().toString();
        break;
    }

    return result;
  }

  private customizeTooltip(pointInfo: any) {
    return {
      text: `${pointInfo.argument}(${pointInfo.seriesName}): ${pointInfo.valueText}`,
    };
  }
}
</script>
<style scoped>
.dx-toolbar {
  background: none;
}
</style>