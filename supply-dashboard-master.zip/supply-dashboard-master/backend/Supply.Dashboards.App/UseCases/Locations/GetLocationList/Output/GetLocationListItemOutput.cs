﻿using Supply.Dashboards.App.Types;
using Supply.Dashboards.Domain.Types;

using System;
using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.Locations.GetLocationList.Output
{
    public sealed class GetLocationListItemOutput
    {
        public GetLocationListItemOutput(
            Guid id,
            uint xMin,
            List<Guid> sourceIds,
            List<Guid> destinationIds,
            StatusType status,
            AppLocationType type,
            string title,
            string? description,
            double? longitude,
            double? latitude,
            double? diameter)
        {
            Id = id;
            RowVersion = xMin;
            SourceIds = sourceIds;
            DestinationIds = destinationIds;
            Status = status;
            Type = type;
            Title = title;
            Description = description;
            Longitude = longitude;
            Latitude = latitude;
            Diameter = diameter;
        }

        public Guid Id { get; }
        public uint RowVersion { get; }

        public List<Guid> SourceIds { get; }
        public List<Guid> DestinationIds { get; }

        public StatusType Status { get; }
        public AppLocationType Type { get; }

        public string Title { get; }
        public string? Description { get; }

        public double? Longitude { get; }
        public double? Latitude { get; }
        public double? Diameter { get; }
    }
}
