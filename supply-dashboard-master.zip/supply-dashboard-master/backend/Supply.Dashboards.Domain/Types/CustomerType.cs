﻿using Common.SeedWork;

namespace Supply.Dashboards.Domain.Types
{
    public sealed class CustomerType : Enumeration
    {
        public static CustomerType Inner = new(1, "Inner");
        public static CustomerType External = new(2, "External");

        public CustomerType(int id, string name) : base(id, name)
        {
        }
    }
}
