﻿using FluentValidation;

namespace Supply.Dashboards.App.UseCases.Locations.GetLocationList.Input
{
    public sealed class GetLocationListValidator
        : AbstractValidator<GetLocationListQuery>
    {
        public GetLocationListValidator()
        {
            ValidateStatuses();
            ValidateParentIds();
            ValidateIds();
            ValidateTypes();
        }

        private void ValidateStatuses() =>
            RuleForEach(_ => _.Statuses)
                .Must(_ => _.Id != 0); // TODO add description

        private void ValidateParentIds() =>
            RuleForEach(_ => _.SourceIds);

        private void ValidateIds() =>
            RuleForEach(_ => _.Ids)
                .Must(_ => _ != default);

        private void ValidateTypes() =>
            RuleForEach(_ => _.Types)
                .Must(_ => _.Id != 0); // TODO add description
    }
}
