﻿using Supply.Dashboards.Domain.AggregatesModel.Core;
using Supply.Dashboards.Domain.Types;

using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.Contexts.GetContextList
{
    public interface IGetContextList
    {
        Task<IEnumerable<Context>> Get(
            List<StatusType> statuses,
            List<int>? ids,
            CancellationToken cancellationToken);
    }
}
