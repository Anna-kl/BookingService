<template>
  <div v-if="currentGroup">
    <h4>Данные направлений по умолчанию</h4>
    <DxRadioGroup
      :items="groupValues"
      :value="currentGroup"
      @value-changed="valueChange"
    />
  </div>
</template>

<script lang='ts'>
import Vue from "vue";
import { Component, Watch, Prop } from "vue-property-decorator";
import config from "@/config";
import { EventBus } from "@/event-bus";
import { SettingsState } from "@/store";
import { GraphLocationGroupData, IModuleSeries } from "@/dto/Dashboards";
import DxRadioGroup from "devextreme-vue/radio-group";

@Component({
  components: {
    DxRadioGroup,
  },
})
export default class GraphLocationsGroupPicker extends Vue {
  private groupValues: GraphLocationGroupData[] =
    config.graphLocationGroupValues;
  public mounted() {}

  private get currentGroup() {
    const pickedDashboardItem = SettingsState.pickedDashboardItem;
    return this.groupValues.find(
      (d: GraphLocationGroupData) =>
        d.locationsGroup === pickedDashboardItem?.config?.defaultLocationsGroup
    );
  }

  private valueChange(e: any) {
    SettingsState.setSelectedLocationsGroup(e.value.locationsGroup);
  }
}
</script>
<style scoped>
.checkbox {
  text-align: left;
}
</style>