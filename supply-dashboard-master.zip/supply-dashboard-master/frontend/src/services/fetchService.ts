import AuthService from "./auth.service";
import config from '@/config';

enum FetchMethod {
    GET = 'GET',
    POST = 'POST',
    PUT = 'PUT',
    DELETE = 'DELETE',
}

export class FetchService {

    private _authService = new AuthService();

    public async fetch(
        url: string,
        object?: any,
        method?: FetchMethod,
    ): Promise<Response> {
        const headers = new Headers({
            'Content-Type': 'application/json',
            'Cache-Control': 'no-store, no-cache, must-revalidate, post-check=0, pre-check=0',
            'Pragma': 'no-cache',
        });
        await this._authService.init();

        const user = await this._authService.getUser();
        if (user) {
            headers.set('Authorization', `Bearer ${user.access_token}`);
        }

        if (url.indexOf(config.remoteHost || '') < 0) {
            url = this.buildAbsoluteUrl(url);
        }

        // todo работа с несколькими контекстами
        return fetch(url + "?context_Id=1", {
            body: object ? JSON.stringify(object) : undefined,
            headers,
            method,
        }).then((response) => {
            if (response.status === 401 || response.status === 403) {

                this._authService.login();
            }
            return response;
        });
    }

    public get<T>(url: string): Promise<T> {
        return this.getJsonFromApi<T>(url);
    }

    public post<T>(url: string, object: any): Promise<T> {
        return this.getJsonFromApi<T>(url, object, FetchMethod.POST);
    }

    public delete<T>(url: string, body?: any): Promise<T> {
        return this.getJsonFromApi<T>(url, body, FetchMethod.DELETE);
    }

    public put<T>(url: string, object: any): Promise<T> {
        return this.getJsonFromApi<T>(url, object, FetchMethod.PUT);
    }

    public buildAbsoluteUrl(url: string): string {
        return config.remoteHost + url;
    }

    private async getJsonFromApi<T>(url: string, object?: any, method?: FetchMethod): Promise<T> {

        const response = await this.fetch(url, object, method);
        const respObj: any = await (() => { return response.text().then((text) => text ? JSON.parse(text) : null) })();
        if (response.ok) {
            return respObj;
        } else {
            throw (new Error(`${respObj[0].errorCode}: (${respObj[0].errorMessage})`));
        }
    }

}