﻿using FluentValidation;

namespace Supply.Dashboards.App.UseCases.Charts.ExecutionOfOrders.Input
{
    public class ExecutionOfOrdersChartValidator
        : AbstractValidator<ExecutionOfOrdersChartQuery>
    {
        public ExecutionOfOrdersChartValidator()
        {
            ValidateStartPeriod();
            ValidateCustomersIds();
            ValidateLocationsIds();
        }

        private void ValidateStartPeriod() =>
            RuleFor(_ => _.StartPeriod)
                .NotEmpty();

        private void ValidateCustomersIds() =>
            RuleForEach(_ => _.CustomersIds);

        private void ValidateLocationsIds() =>
            RuleForEach(_ => _.LocationsIds);
    }
}
