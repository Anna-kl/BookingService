import { daysInMonth } from '@/helpers/utils';
import { InputDataService } from '@/services/inputDataService';
import { DateTime, Interval } from 'luxon';
import { TimeSpan } from '@/helpers/timeSpan';
import DataSource from 'devextreme/data/data_source';
import { Column, dxDataGridColumn, dxDataGridOptions } from "devextreme/ui/data_grid";
import { IDataMtrItem, IImportMtrItem, MtrItemTypeEnum } from '@/dto/InputData';
import { DateTypeEnum, ICustomerForGrid, ILocationForGrid, ITreeListMtrItemDataType, IMtrItemTransformed } from '../common/models';
import notify from "devextreme/ui/notify";

interface IMtrItemTypesGroup {
    mainType: string;
    types: MtrItemTypeEnum[];
}

// !!!! на данном этапе все, что связано с расчетом полный хардкод т.к. расчет переедет на бэк
export class CommonTableData {

    public tableConfig: dxDataGridOptions;
    private _inputDataService = new InputDataService();

    private date: Date;
    private locations: ILocationForGrid[];
    private timeSpans: string[];
    private customersForGrid: ICustomerForGrid[];
    private firstDayMonth: Date;
    private year: number;
    private month: number;
    private daysCount: number;
    private allMtrItemDataTypes: ITreeListMtrItemDataType[];
    private selectedMtrItemDataTypes: ITreeListMtrItemDataType[] = [];

    constructor(date: Date, locations: ILocationForGrid[], customers: ICustomerForGrid[], mtrItemDataTypes: ITreeListMtrItemDataType[], timeSpans: string[]) {

        this.customersForGrid = customers.map<ICustomerForGrid>((s) => {
            return { id: s.id, title: s.title }
        });

        this.date = date;
        this.locations = locations;
        this.timeSpans = timeSpans;

        this.firstDayMonth = new Date(date.getFullYear(), date.getMonth(), 1);
        this.year = this.firstDayMonth.getFullYear();
        this.month = this.firstDayMonth.getMonth() + 1;
        this.allMtrItemDataTypes = mtrItemDataTypes;
        this.daysCount = daysInMonth(this.month, this.year);

        this.createSelectedMtrItemDataTypeArrar(mtrItemDataTypes);

        this.tableConfig = this.createTableConfig();
    }

    private getGridDataSource() {
        return new DataSource({
            load: () => this.generateGridData(this.date, this.locations, this.customersForGrid, this.timeSpans),
            update: async (data: any, changes: any) => await this.update(data, changes),
        });
    }

    private createTableConfig(): dxDataGridOptions {
        const config: dxDataGridOptions = {
            columns: this.columns(),
            dataSource: this.getGridDataSource(),
            onCellPrepared: this.onCellPrepared,
            allowColumnResizing: true,
            showBorders: true,
            columnResizingMode: "widget",
            columnWidth: 90,
            selection: { mode: "none" },
            groupPanel: { visible: true },
            editing: {
                allowUpdating: true,
                selectTextOnEditStart: true,
                startEditAction: "click",
                mode: "cell"
            },
            loadPanel: { enabled: false },
            paging: { enabled: false },
            columnFixing: { enabled: true },
            export: { enabled: true },
            scrolling: {
                mode: 'virtual',
                useNative: false,
                scrollByThumb: true,
                scrollByContent: true,
                showScrollbar: 'always',
            },
        };

        return config;
    }

    private loadDataFromServer(
        date: Date,
        locations: ILocationForGrid[],
        customers: ICustomerForGrid[],
        loadedMtrItemTypes: string[]
    ) {
        const startDateYear = new Date(date.getFullYear(), 0, 1, 0, 0, 0);
        const endDateYear = new Date(date.getFullYear() + 1, 0, 1, 0, 0, 0);
        const periodYear = Interval.fromDateTimes(startDateYear, endDateYear);

        return this._inputDataService.getDataItems({
            startPeriod: DateTime.utc(date.getFullYear(), 1, 1, 0, 0, 0).toISO(),
            endPeriod: periodYear.length("day").toString(),
            customerIds: customers.map((s) => s.id as string),
            locationIds: locations.map((s) => s.id),
            types: loadedMtrItemTypes
        });
    }

    private async update(data: any, changes: any) {
        let newValue, typeProperty, dateProperty, rowVersion;

        for (const property in changes) {
            dateProperty = data[property];
            for (const subProperty in changes[property]) {
                typeProperty = dateProperty[subProperty];
                newValue = changes[property][subProperty].value;
                rowVersion = data[property][subProperty].rowVersion;
            }
        }

        let startPeriod: string = "";
        let endPeriod: string = "1";

        const year = data.year.value;
        const month = data.month.value ?? 1;

        // год
        if (dateProperty["dateType"] === DateTypeEnum.Year) {
            const startDateYear = new Date(year, 0, 1, 0, 0, 0);
            const endDateYear = new Date(year + 1, 0, 1, 0, 0, 0);
            const periodYear = Interval.fromDateTimes(startDateYear, endDateYear);

            startPeriod = DateTime.utc(year, 1, 1, 0, 0, 0).toISO();
            endPeriod = periodYear.length("day").toString();
        }

        // месяц
        if (dateProperty["dateType"] === DateTypeEnum.Month) {
            const startDateMonth = new Date(year, month - 1, 1, 0, 0, 0);
            const endDateMonth = new Date(year, month, 1, 0, 0, 0);
            const periodMonth = Interval.fromDateTimes(startDateMonth, endDateMonth);

            startPeriod = DateTime.utc(year, month, 1, 0, 0, 0).toISO();
            endPeriod = periodMonth.length("day").toString();
        }

        // неделя // отключено до понимания как с ней работать
        // if (typeProperty.dateType === DateTypeEnum.Week) {
        //     startPeriod = DateTime.utc(year, 1, 1, 0, 0, 0)
        //         .plus({ week: this.editedValue.date.value - 1 })
        //         .toISO();
        //     endPeriod = "7";
        // }

        // день
        if (dateProperty["dateType"] === DateTypeEnum.Day) {
            startPeriod = DateTime.utc(
                year,
                month,
                dateProperty.dateValue,
                0,
                0,
                0
            ).toISO();
            endPeriod = "1";
        }

        const parsedNewValue: number | null = newValue !== null ? Number.parseFloat(newValue.toString().replace(',', '.').replace(' ', '')) : null;

        const savedItem: IImportMtrItem = {
            rowVersion: rowVersion,
            startPeriod: startPeriod,
            duration: endPeriod,
            customerId: data.customer.id,
            locationId: data.location.id,
            type: typeProperty.mtrItemType,
            value: parsedNewValue,
        };
        typeProperty.value = parsedNewValue;
        await this._inputDataService
            .saveDataItem([savedItem])
            .then((data) => {
                notify("Данные успешно сохранены.", "success", 3000);

            })
            .catch((error) => {
                notify(`${error.message}`, "error", 3000);
            });

    }

    private setGroupText(element: any, cellInfo: any) {
        element.innerText = cellInfo.value;
    }

    private setDigitalCellText(element: any, cellInfo: any) {
        if (cellInfo.value !== undefined) {
            element.innerText = (cellInfo.value as number).toLocaleString("ru-RU", { maximumFractionDigits: 3, minimumFractionDigits: 3 }).replace(',', '.');
        }
    }

    private verticalTextTemplate(element: any, cellInfo: any) {
        element.innerHTML = `<div class="vert-text">${cellInfo.column.caption}</div>`;
    }

    private columns(): Column[] {
        const retData: Column[] = [
            {
                caption: "География",
                dataField: "location.title",
                groupIndex: 0,
                allowEditing: false,
                fixed: true,
                sortOrder: "asc",
                groupCellTemplate: this.setGroupText
            },
            {
                caption: "Заказчик",
                dataField: "customer.title",
                sortOrder: "asc",

                fixed: true,
                allowEditing: false,
                groupCellTemplate: this.setGroupText
            }];

        if (this.timeSpans.includes("year")) {
            retData.push({
                caption: "Год",
                alignment: 'center',
                columns: [
                    {
                        caption: this.date.getFullYear().toString(),
                        alignment: 'center',
                        columns: [
                            ...this.createDateItemColumns("year", DateTypeEnum.Year, "root")
                        ]
                    }
                ]
            });
        }

        if (this.timeSpans.includes("month")) {
            retData.push(
                {
                    caption: "Месяц",
                    alignment: 'center',
                    columns: [
                        {
                            caption: this.date.toLocaleString('default', { month: 'long' }),
                            alignment: 'center',
                            columns: [
                                ...this.createDateItemColumns("month", DateTypeEnum.Month, "root")
                            ]
                        }
                    ]
                });
        }

        if (this.timeSpans.includes("day")) {
            const daysCols: Column = {
                caption: "Дни",
                columns: this.createDaysColumns()
            }
            retData.push(daysCols);
        }

        return retData;
    }

    private createColumn(caption: string, dataField: string): dxDataGridColumn {

        return {
            caption: caption,
            dataField: dataField,
            headerCellTemplate: this.verticalTextTemplate,
            allowEditing: false,
            alignment: 'center',
            cellTemplate: this.setDigitalCellText
        };
    }

    private isEditable(mtrItemType: MtrItemTypeEnum, dateType: DateTypeEnum) {
        if ((mtrItemType === MtrItemTypeEnum.CargoHandlingPlan
            || mtrItemType === MtrItemTypeEnum.FreightTurnoverPlan
            || mtrItemType === MtrItemTypeEnum.SeasonalDeliveryPlan
            || mtrItemType === MtrItemTypeEnum.ArrivalPlan
            || mtrItemType === MtrItemTypeEnum.ExpenditurePlan)
            && dateType === DateTypeEnum.Month) {
            return true;
        }

        if ((mtrItemType === MtrItemTypeEnum.CargoHandlingAdjustedPlan
            || mtrItemType === MtrItemTypeEnum.FreightTurnoverAdjustedPlan
            || mtrItemType === MtrItemTypeEnum.SeasonalDeliveryAdjustedPlan
            || mtrItemType === MtrItemTypeEnum.ArrivalAdjustedPlan
            || mtrItemType === MtrItemTypeEnum.ExpenditureAdjustedPlan)
            && dateType === DateTypeEnum.Month) {
            return true;
        }

        if ((mtrItemType === MtrItemTypeEnum.CargoHandlingFact
            || mtrItemType === MtrItemTypeEnum.FreightTurnoverFact
            || mtrItemType === MtrItemTypeEnum.SeasonalDeliveryFact
            || mtrItemType === MtrItemTypeEnum.ArrivalFact
            || mtrItemType === MtrItemTypeEnum.ExpenditureFact)
            && dateType === DateTypeEnum.Day) {
            return true;
        }

        if ((mtrItemType === MtrItemTypeEnum.CargoHandlingDailyPlan
            || mtrItemType === MtrItemTypeEnum.FreightTurnoverDailyPlan
            || mtrItemType === MtrItemTypeEnum.SeasonalDeliveryDailyPlan
            || mtrItemType === MtrItemTypeEnum.ArrivalDailyPlan
            || mtrItemType === MtrItemTypeEnum.ExpenditureDailyPlan)
            && dateType === DateTypeEnum.Day) {
            return true;
        }

        if ((mtrItemType === MtrItemTypeEnum.HseDangerWarning
            || mtrItemType === MtrItemTypeEnum.HseDeath
            || mtrItemType === MtrItemTypeEnum.HseDisability
            || mtrItemType === MtrItemTypeEnum.HseMedicalCare
            || mtrItemType === MtrItemTypeEnum.HseNearMiss)
            && dateType === DateTypeEnum.Day) {
            return true;
        }

        if ((mtrItemType === MtrItemTypeEnum.AccountingMtrProcessing
            || mtrItemType === MtrItemTypeEnum.AccountingMtrTotalSupplies
            || mtrItemType === MtrItemTypeEnum.AccountingMtrUncapitalize0_14
            || mtrItemType === MtrItemTypeEnum.AccountingMtrUncapitalize15_30
            || mtrItemType === MtrItemTypeEnum.AccountingMtrUncapitalize31_60
            || mtrItemType === MtrItemTypeEnum.AccountingMtrUncapitalize61More)
            && dateType === DateTypeEnum.Day) {
            return true;
        }

        if ((mtrItemType === MtrItemTypeEnum.BidPlan
            || mtrItemType === MtrItemTypeEnum.BidForecast
            || mtrItemType === MtrItemTypeEnum.BidTotalFact
            || mtrItemType === MtrItemTypeEnum.BidScheduledFact
            || mtrItemType === MtrItemTypeEnum.BidUnplanned)
            && dateType === DateTypeEnum.Day) {
            return true;
        }

        if ((mtrItemType === MtrItemTypeEnum.TransportFact
            || mtrItemType === MtrItemTypeEnum.TransportPlan
            || mtrItemType === MtrItemTypeEnum.GPMFact
            || mtrItemType === MtrItemTypeEnum.GPMPlan
            || mtrItemType === MtrItemTypeEnum.LaborResourcesPlan
            || mtrItemType === MtrItemTypeEnum.LaborResourcesFact)
            && dateType === DateTypeEnum.Day) {
            return true;
        }

        if ((mtrItemType === MtrItemTypeEnum.FullnessBasesTotalSquare
            || mtrItemType === MtrItemTypeEnum.FullnessBasesLoaded
            || mtrItemType === MtrItemTypeEnum.FullnessBasesLoadedRubles
            || mtrItemType === MtrItemTypeEnum.FullnessBasesLoadedWeight)
            && dateType === DateTypeEnum.Day) {
            return true;
        }


        return false;
    }

    private createDateItemColumns(dateItem: string, dateType: DateTypeEnum, parentId: string): dxDataGridColumn[] {
        const result: dxDataGridColumn[] = [];

        const finedRootItems = this.selectedMtrItemDataTypes.filter(s => s.parentId === parentId);
        finedRootItems.forEach(finedRootItem => {
            if (finedRootItem.type !== undefined) {
                result.push(Object.assign(this.createColumn(finedRootItem.name, `${dateItem}.${MtrItemTypeEnum[finedRootItem.type]}.value`), { allowEditing: this.isEditable(finedRootItem.type, dateType) }));
            } else {
                result.push({
                    caption: finedRootItem.name,
                    alignment: 'center',
                    columns: [
                        ...this.createDateItemColumns(dateItem, dateType, finedRootItem.id)
                    ]
                });
            }
        })
        return result;
    }

    private createDaysColumns(): dxDataGridColumn[] {
        const result: dxDataGridColumn[] = [];
        for (let index = 1; index <= this.daysCount; index++) {
            result.push({
                caption: `${index}`,
                columns: [
                    ...this.createDateItemColumns(`day${index}`, DateTypeEnum.Day, "root")
                ]
            });
        }

        return result;
    }

    private transformApiData(apiDataNoFormated: IDataMtrItem[]) {
        const transformedData = apiDataNoFormated !== undefined && apiDataNoFormated !== null ? apiDataNoFormated.map<IMtrItemTransformed>((s) => {
            const startPeriod = DateTime.fromISO(s.startPeriod, { zone: "utc" });
            const endPeriodDuration = TimeSpan.fromDto(s.endPeriod).duration;
            const endPeriod = startPeriod.plus(endPeriodDuration);

            let dateType = DateTypeEnum.Day;

            if (endPeriodDuration.days > 31) {
                dateType = DateTypeEnum.Year;
            }

            if (endPeriodDuration.days >= 28 && endPeriodDuration.days < 32) {
                dateType = DateTypeEnum.Month;
            }

            if (endPeriodDuration.days > 1 && endPeriodDuration.days == 7) {
                dateType = DateTypeEnum.Week;
            }

            return {
                rowVersion: s.rowVersion,
                startPeriod: startPeriod,
                dateType: dateType,
                year: startPeriod.year,
                month: (dateType === DateTypeEnum.Month || dateType === DateTypeEnum.Day) ? startPeriod.month : undefined,
                week: dateType === DateTypeEnum.Week ? startPeriod.weekNumber : undefined,
                day: dateType === DateTypeEnum.Day ? startPeriod.day : undefined,
                customerId: s.customerId,
                locationId: s.locationId,
                mtrTypeId: s.mtrTypeId,
                type: s.type,
                value: s.value,
                inputType: s.inputType
            }
        }) : [];
        return transformedData;
    }

    private async generateGridData(dataDate: Date, locations: ILocationForGrid[], customers: ICustomerForGrid[], timeSpans: string[]) {

        const retData: any[] = [];
        const mtrItemTypeGroups: IMtrItemTypesGroup[] = [
            {
                mainType: "Arrival",
                types: [
                    MtrItemTypeEnum.ArrivalFact,
                    MtrItemTypeEnum.ArrivalPlan,
                    MtrItemTypeEnum.ArrivalAdjustedPlan,
                    MtrItemTypeEnum.ArrivalDailyPlan
                ]
            },
            {
                mainType: "Expenditure",
                types: [
                    MtrItemTypeEnum.ExpenditureFact,
                    MtrItemTypeEnum.ExpenditurePlan,
                    MtrItemTypeEnum.ExpenditureAdjustedPlan,
                    MtrItemTypeEnum.ExpenditureDailyPlan
                ]
            },
            {
                mainType: "CargoHandling",
                types: [
                    MtrItemTypeEnum.CargoHandlingFact,
                    MtrItemTypeEnum.CargoHandlingPlan,
                    MtrItemTypeEnum.CargoHandlingAdjustedPlan,
                    MtrItemTypeEnum.CargoHandlingDailyPlan,
                    MtrItemTypeEnum.CargoHandlingPerformed
                ]
            },
            {
                mainType: "FreightTurnover",
                types: [
                    MtrItemTypeEnum.FreightTurnoverFact,
                    MtrItemTypeEnum.FreightTurnoverPlan,
                    MtrItemTypeEnum.FreightTurnoverAdjustedPlan,
                    MtrItemTypeEnum.FreightTurnoverDailyPlan,
                    MtrItemTypeEnum.FreightTurnoverPerformed
                ]
            },
            {
                mainType: "SeasonalDelivery",
                types: [
                    MtrItemTypeEnum.SeasonalDeliveryFact,
                    MtrItemTypeEnum.SeasonalDeliveryPlan,
                    MtrItemTypeEnum.SeasonalDeliveryAdjustedPlan,
                    MtrItemTypeEnum.SeasonalDeliveryDailyPlan,
                    MtrItemTypeEnum.SeasonalDeliveryPerformed
                ]
            },
            {
                mainType: "AccountingMtr",
                types: [
                    MtrItemTypeEnum.AccountingMtrTotalSupplies,
                    MtrItemTypeEnum.AccountingMtrProcessing,
                    MtrItemTypeEnum.AccountingMtrUncapitalize0_14,
                    MtrItemTypeEnum.AccountingMtrUncapitalize15_30,
                    MtrItemTypeEnum.AccountingMtrUncapitalize31_60,
                    MtrItemTypeEnum.AccountingMtrUncapitalize61More
                ]
            },
            {
                mainType: "OtifApplications",
                types: [
                    MtrItemTypeEnum.OtifApplicationsPlan,
                    MtrItemTypeEnum.OtifApplicationsFactTotal,
                    MtrItemTypeEnum.OtifApplicationsFactOnTime
                ]
            },
            {
                mainType: "Hse",
                types: [
                    MtrItemTypeEnum.HseDeath,
                    MtrItemTypeEnum.HseDisability,
                    MtrItemTypeEnum.HseMedicalCare,
                    MtrItemTypeEnum.HseNearMiss,
                    MtrItemTypeEnum.HseDangerWarning
                ]
            },
            {
                mainType: "Bid",
                types: [
                    MtrItemTypeEnum.BidPlan,
                    MtrItemTypeEnum.BidForecast,
                    MtrItemTypeEnum.BidTotalFact,
                    MtrItemTypeEnum.BidScheduledFact,
                    MtrItemTypeEnum.BidUnplanned,
                    MtrItemTypeEnum.BidOTIF
                ]
            },
            {
                mainType: "Transport",
                types: [
                    MtrItemTypeEnum.TransportPlan,
                    MtrItemTypeEnum.TransportFact,
                ]
            },
            {
                mainType: "GPM",
                types: [
                    MtrItemTypeEnum.GPMPlan,
                    MtrItemTypeEnum.GPMFact,
                ]
            },
            {
                mainType: "LaborResources",
                types: [
                    MtrItemTypeEnum.LaborResourcesPlan,
                    MtrItemTypeEnum.LaborResourcesFact,
                ]
            },
            {
                mainType: "FullnessBases",
                types: [
                    MtrItemTypeEnum.FullnessBasesTotalSquare,
                    MtrItemTypeEnum.FullnessBasesLoaded,
                    MtrItemTypeEnum.FullnessBasesLoadedRubles,
                    MtrItemTypeEnum.FullnessBasesLoadedWeight
                ]
            }
        ];

        const mtrItemTypesAsTreeList = this.selectedMtrItemDataTypes.filter(s => s.type !== undefined);
        const mtrItemTypesForLoad: string[] = mtrItemTypesAsTreeList.filter(s => MtrItemTypeEnum[s.type!].includes("Performed") === false).map<string>(m => MtrItemTypeEnum[m.type!]);
        const mtrItemTypes: string[] = mtrItemTypesAsTreeList.map<string>(m => MtrItemTypeEnum[m.type!]);
        const apiDataNoFormated: IDataMtrItem[] = await this.loadDataFromServer(dataDate, locations, customers, mtrItemTypesForLoad);
        const calculatedTypes: string[] = [];

        mtrItemTypeGroups.forEach(group => {
            if (mtrItemTypesAsTreeList.find(g => group.types.indexOf(g.type!) >= 0)) {
                group.types.forEach(groupType => {
                    calculatedTypes.push(MtrItemTypeEnum[groupType]);
                });
            }
        });

        let apiData = this.transformApiData(apiDataNoFormated);

        let id = 1;
        if (apiData === undefined || apiData === null) {
            apiData = [];
        }

        locations.forEach((location) => {

            customers.forEach((customer) => {

                const tmpValue: any = {
                    id: id,
                    location: location,
                    customer: customer,
                    year: {
                        dateType: DateTypeEnum.Year,
                        value: this.year,
                    },
                    month: {
                        dateType: DateTypeEnum.Month,
                        value: this.month,
                    }
                };

                // установка значений из БД

                // для года
                calculatedTypes.forEach(mtrItemType => {
                    tmpValue.year[mtrItemType] = {
                        mtrItemType: mtrItemType, value: this.getValueFromApi(
                            apiData,
                            mtrItemType,
                            DateTypeEnum.Year,
                            customer.id,
                            location.id
                        )?.value
                    };
                });

                // для месяца

                calculatedTypes.forEach(mtrItemType => {
                    tmpValue.month[mtrItemType] = {
                        mtrItemType: mtrItemType, value: this.getValueFromApi(
                            apiData,
                            mtrItemType,
                            DateTypeEnum.Month,
                            customer.id,
                            location.id,
                            this.month
                        )?.value
                    };
                });

                // для дней

                for (let index = 1; index <= this.daysCount; index++) {
                    const dayProperty = `day${index}`;
                    tmpValue[dayProperty] = {
                        dateType: DateTypeEnum.Day,
                        dateValue: index
                    };

                    calculatedTypes.forEach(mtrItemType => {
                        const cellData = this.getValueFromApi(
                            apiData,
                            mtrItemType,
                            DateTypeEnum.Day,
                            customer.id,
                            location.id,
                            this.month,
                            index
                        )

                        tmpValue[dayProperty][mtrItemType] = {
                            mtrItemType: mtrItemType, 
                            value: cellData?.value, 
                            rowVersion: cellData?.rowVersion
                        };
                    });
                }

                // установка расчетных значений

                // для года
                this.calculateYearValue(apiData, tmpValue, location.id, calculatedTypes, customer.id);

                // для месяца
                this.calculateMonthValue(apiData, tmpValue, location.id, calculatedTypes, customer.id);

                // для дней

                const calcCargoHandling = calculatedTypes.indexOf("CargoHandlingPlan") >= 0;
                const calcFreightTurnover = calculatedTypes.indexOf("FreightTurnoverPlan") >= 0;
                const calcSeasonalDelivery = calculatedTypes.indexOf("SeasonalDeliveryPlan") >= 0;
                const calcBid = calculatedTypes.indexOf("BidPlan") >= 0;

                if (calcCargoHandling || calcFreightTurnover || calcSeasonalDelivery || calcBid) {
                    const cargoHandlingAdjustedPlan_day = calcCargoHandling ? this.getDayPlan(tmpValue.month.CargoHandlingAdjustedPlan) : undefined;
                    const cargoHandlingPlan_day = calcCargoHandling ? this.getDayPlan(tmpValue.month.CargoHandlingPlan) : undefined;
                    const freightTurnoverAdjustedPlan_day = calcFreightTurnover ? this.getDayPlan(tmpValue.month.FreightTurnoverAdjustedPlan) : undefined;
                    const freightTurnoverPlan_day = calcFreightTurnover ? this.getDayPlan(tmpValue.month.FreightTurnoverPlan) : undefined;
                    const seasonalDeliveryAdjustedPlan_day = calcSeasonalDelivery ? this.getDayPlan(tmpValue.month.SeasonalDeliveryAdjustedPlan) : undefined;
                    const seasonalDeliveryPlan_day = calcSeasonalDelivery ? this.getDayPlan(tmpValue.month.SeasonalDeliveryPlan) : undefined;

                    for (let indexCalc = 1; indexCalc <= this.daysCount; indexCalc++) {
                        const dayPropertyCalc = `day${indexCalc}`;
                        if (calcCargoHandling) {
                            tmpValue[dayPropertyCalc].CargoHandlingAdjustedPlan = cargoHandlingAdjustedPlan_day;
                            tmpValue[dayPropertyCalc].CargoHandlingPlan = cargoHandlingPlan_day;
                            const cargoHandlingAdjustedPlan: any = tmpValue[dayPropertyCalc]?.CargoHandlingAdjustedPlan?.value;
                            const cargoHandlingFact: any = tmpValue[dayPropertyCalc]?.CargoHandlingFact?.value;

                            if (cargoHandlingAdjustedPlan !== undefined && cargoHandlingAdjustedPlan !== 0 && cargoHandlingFact !== undefined) {
                                tmpValue[dayPropertyCalc].CargoHandlingPerformed = {
                                    mtrItemType: MtrItemTypeEnum.CargoHandlingPerformed, value: (cargoHandlingFact! / cargoHandlingAdjustedPlan!) * 100
                                };
                            }
                        }

                        if (calcFreightTurnover) {
                            tmpValue[dayPropertyCalc].FreightTurnoverAdjustedPlan = freightTurnoverAdjustedPlan_day;
                            tmpValue[dayPropertyCalc].FreightTurnoverPlan = freightTurnoverPlan_day;
                            const freightTurnoverAdjustedPlan: any = tmpValue[dayPropertyCalc]?.FreightTurnoverAdjustedPlan?.value;
                            const freightTurnoverFact: any = tmpValue[dayPropertyCalc]?.FreightTurnoverFact?.value;

                            if (freightTurnoverAdjustedPlan !== undefined && freightTurnoverAdjustedPlan !== 0 && freightTurnoverFact !== undefined) {
                                tmpValue[dayPropertyCalc].FreightTurnoverPerformed = {
                                    mtrItemType: MtrItemTypeEnum.CargoHandlingPerformed, value: (freightTurnoverFact! / freightTurnoverAdjustedPlan!) * 100
                                };
                            }
                        }

                        if (calcSeasonalDelivery) {
                            tmpValue[dayPropertyCalc].SeasonalDeliveryAdjustedPlan = seasonalDeliveryAdjustedPlan_day;
                            tmpValue[dayPropertyCalc].SeasonalDeliveryPlan = seasonalDeliveryPlan_day;
                            const seasonalDeliveryAdjustedPlan: any = tmpValue[dayPropertyCalc]?.SeasonalDeliveryAdjustedPlan?.value;
                            const seasonalDeliveryFact: any = tmpValue[dayPropertyCalc]?.SeasonalDeliveryFact?.value;

                            if (seasonalDeliveryAdjustedPlan !== undefined && seasonalDeliveryAdjustedPlan !== 0 && seasonalDeliveryFact !== undefined) {
                                tmpValue[dayPropertyCalc].SeasonalDeliveryPerformed = {
                                    mtrItemType: MtrItemTypeEnum.CargoHandlingPerformed, value: (seasonalDeliveryFact! / seasonalDeliveryAdjustedPlan!) * 100
                                };
                            }
                        }

                        if (calcBid) {
                            // Bid
                            // OT = ShedulledFact/Plan
                            // IF = TotalFact/Plan
                            // OTIF = OT * IF * 100%
                            if (tmpValue[dayPropertyCalc]?.BidPlan !== undefined
                                && tmpValue[dayPropertyCalc]?.BidPlan.value !== undefined
                                && tmpValue[dayPropertyCalc]?.BidScheduledFact.value !== undefined
                                && tmpValue[dayPropertyCalc]?.BidTotalFact.value !== undefined
                                && tmpValue[dayPropertyCalc]?.BidPlan.value !== 0) {
                                const otValue = tmpValue[dayPropertyCalc]?.BidScheduledFact.value / tmpValue[dayPropertyCalc]?.BidPlan.value;
                                const ifValue = tmpValue[dayPropertyCalc]?.BidTotalFact.value / tmpValue[dayPropertyCalc]?.BidPlan.value;
                                tmpValue[dayPropertyCalc].BidOTIF = {
                                    mtrItemType: MtrItemTypeEnum.BidOTIF, value: otValue * ifValue * 100
                                };
                            }
                        }

                    }
                }

                retData.push(tmpValue);
                id++;

            });

        });


        return retData;
    }

    private getValueFromApi(apiData: IMtrItemTransformed[], mtrItemType: string, dateType: DateTypeEnum, customerId: string | null, locationId: string, month?: number | undefined, day?: number | undefined) {
        const apiItem = apiData.find(s =>
            s.type === mtrItemType
            && s.dateType === dateType
            && s.year === this.year
            && s.month === month
            && s.day === day
            && s.customerId === customerId
            && s.locationId === locationId
        );
        return apiItem !== undefined ? {rowVersion: apiItem?.rowVersion, value: apiItem?.value} : undefined;
    }

    private getDayPlan(monthPlan: any): any {
        if (monthPlan.value !== undefined) {
            return {
                mtrItemType: monthPlan.mtrItemType,
                value: monthPlan.value / this.daysCount
            };
        } else {
            return {
                mtrItemType: monthPlan.mtrItemType,
                value: undefined
            };
        }

    }

    private calculateMonthValue(apiData: IMtrItemTransformed[], tmpValue: any, locationId: string, calculatedTypes: string[], customerId: string | null) {

        // alltypes sum type
        [
            MtrItemTypeEnum.ArrivalFact,
            MtrItemTypeEnum.ExpenditureFact,
            MtrItemTypeEnum.CargoHandlingFact,
            MtrItemTypeEnum.FreightTurnoverFact,
            MtrItemTypeEnum.SeasonalDeliveryFact,
            MtrItemTypeEnum.CargoHandlingDailyPlan,
            MtrItemTypeEnum.FreightTurnoverDailyPlan,
            MtrItemTypeEnum.SeasonalDeliveryDailyPlan,
            MtrItemTypeEnum.HseDangerWarning,
            MtrItemTypeEnum.HseDeath,
            MtrItemTypeEnum.HseDisability,
            MtrItemTypeEnum.HseMedicalCare,
            MtrItemTypeEnum.HseNearMiss,
            MtrItemTypeEnum.BidForecast,
            MtrItemTypeEnum.BidPlan,
            MtrItemTypeEnum.BidScheduledFact,
            MtrItemTypeEnum.BidTotalFact,
            MtrItemTypeEnum.BidUnplanned
        ].forEach(element => {
            if (calculatedTypes.indexOf(MtrItemTypeEnum[element]) >= 0) {
                this.calculateSumValuesInMonth(apiData, tmpValue, locationId, customerId, element);
            }
        });

        // Performed
        if (calculatedTypes.indexOf("CargoHandlingPerformed") >= 0) {
            const cargoHandlingAdjustedPlan: any = tmpValue.month?.CargoHandlingAdjustedPlan?.value;
            const cargoHandlingFact: any = tmpValue.month?.CargoHandlingFact?.value;

            if (cargoHandlingAdjustedPlan !== undefined && cargoHandlingAdjustedPlan !== 0 && cargoHandlingFact !== undefined) {
                tmpValue.month.CargoHandlingPerformed = { value: (cargoHandlingFact! / cargoHandlingAdjustedPlan!) * 100, mtrItemType: MtrItemTypeEnum.CargoHandlingPerformed };
            }
        }

        if (calculatedTypes.indexOf("FreightTurnoverPerformed") >= 0) {
            const freightTurnoverAdjustedPlan: any = tmpValue.month?.FreightTurnoverAdjustedPlan?.value;
            const freightTurnoverFact: any = tmpValue.month?.FreightTurnoverFact?.value;

            if (freightTurnoverAdjustedPlan !== undefined && freightTurnoverAdjustedPlan !== 0 && freightTurnoverFact !== undefined) {
                tmpValue.month.FreightTurnoverPerformed = { value: (freightTurnoverFact! / freightTurnoverAdjustedPlan!) * 100, mtrItemType: MtrItemTypeEnum.FreightTurnoverPerformed };
            }
        }

        if (calculatedTypes.indexOf("SeasonalDeliveryPerformed") >= 0) {
            const seasonalDeliveryAdjustedPlan: any = tmpValue.month?.SeasonalDeliveryAdjustedPlan?.value;
            const seasonalDeliveryFact: any = tmpValue.month?.SeasonalDeliveryFact?.value;

            if (seasonalDeliveryAdjustedPlan !== undefined && seasonalDeliveryAdjustedPlan !== 0 && seasonalDeliveryFact !== undefined) {
                tmpValue.month.SeasonalDeliveryPerformed = { value: (seasonalDeliveryFact! / seasonalDeliveryAdjustedPlan!) * 100, mtrItemType: MtrItemTypeEnum.SeasonalDeliveryPerformed };
            }
        }

        // last value
        [
            MtrItemTypeEnum.AccountingMtrProcessing,
            MtrItemTypeEnum.AccountingMtrTotalSupplies,
            MtrItemTypeEnum.AccountingMtrUncapitalize0_14,
            MtrItemTypeEnum.AccountingMtrUncapitalize15_30,
            MtrItemTypeEnum.AccountingMtrUncapitalize31_60,
            MtrItemTypeEnum.AccountingMtrUncapitalize61More,
            MtrItemTypeEnum.TransportPlan,
            MtrItemTypeEnum.TransportFact,
            MtrItemTypeEnum.GPMPlan,
            MtrItemTypeEnum.GPMFact,
            MtrItemTypeEnum.LaborResourcesPlan,
            MtrItemTypeEnum.LaborResourcesFact,
            MtrItemTypeEnum.FullnessBasesTotalSquare,
            MtrItemTypeEnum.FullnessBasesLoaded,
            MtrItemTypeEnum.FullnessBasesLoadedRubles,
            MtrItemTypeEnum.FullnessBasesLoadedWeight
        ].forEach(element => {
            if (calculatedTypes.indexOf(MtrItemTypeEnum[element]) >= 0) {
                this.calculateLastValueInMonth(apiData, tmpValue, locationId, customerId, element);
            }
        });

        //Bid
        if (calculatedTypes.indexOf("BidPlan") >= 0) {
            if (tmpValue.month.BidPlan !== undefined
                && tmpValue.month.BidPlan.value !== undefined
                && tmpValue.month.BidScheduledFact.value !== undefined
                && tmpValue.month.BidTotalFact.value !== undefined
                && tmpValue.month.BidPlan.value !== 0) {
                const otValue = tmpValue.month.BidScheduledFact.value / tmpValue.month.BidPlan.value;
                const ifValue = tmpValue.month.BidTotalFact.value / tmpValue.month.BidPlan.value;
                tmpValue.month.BidOTIF = {
                    mtrItemType: MtrItemTypeEnum.BidOTIF, value: otValue * ifValue * 100
                };
            }
        }

    }

    private calculateSumValuesInMonth(apiData: IMtrItemTransformed[], tmpValue: any, locationId: string, customerId: string | null, mtrItemType: MtrItemTypeEnum) {

        tmpValue.month[MtrItemTypeEnum[mtrItemType]] = {
            value: apiData.filter(s =>
                s.dateType === DateTypeEnum.Day
                && s.year === this.year
                && s.month === this.month
                && s.type === MtrItemTypeEnum[mtrItemType]
                && s.customerId === customerId
                && s.locationId === locationId
            ).map(v => v.value).reduce((a, b) => a! + b!, 0),
            mtrItemType: mtrItemType
        };
    }

    private calculateLastValueInMonth(apiData: IMtrItemTransformed[], tmpValue: any, locationId: string, customerId: string | null, mtrItemType: MtrItemTypeEnum) {
        const array = apiData.filter(s =>
            s.dateType === DateTypeEnum.Day
            && s.year === this.year
            && s.month === this.month
            && s.type === MtrItemTypeEnum[mtrItemType]
            && s.customerId === customerId
            && s.locationId === locationId
        );

        const array_byDays = array.filter(s => s.day !== undefined)
            .sort((a, b) => a.day! < b.day! ? 1 : -1);

        if (array_byDays.length > 0) {
            tmpValue.month[MtrItemTypeEnum[mtrItemType]] = {
                value: array_byDays[0].value,
                mtrItemType: mtrItemType
            };
        }
    }

    private calculateYearValue(apiData: IMtrItemTransformed[], tmpValue: any, locationId: string, calculatedTypes: string[], customerId: string | null) {

        // alltypes sum type
        //day sum
        [
            MtrItemTypeEnum.ArrivalFact,
            MtrItemTypeEnum.ExpenditureFact,
            MtrItemTypeEnum.CargoHandlingFact,
            MtrItemTypeEnum.FreightTurnoverFact,
            MtrItemTypeEnum.SeasonalDeliveryFact,
            MtrItemTypeEnum.CargoHandlingDailyPlan,
            MtrItemTypeEnum.FreightTurnoverDailyPlan,
            MtrItemTypeEnum.SeasonalDeliveryDailyPlan,
            MtrItemTypeEnum.HseDangerWarning,
            MtrItemTypeEnum.HseDeath,
            MtrItemTypeEnum.HseDisability,
            MtrItemTypeEnum.HseMedicalCare,
            MtrItemTypeEnum.HseNearMiss,
            MtrItemTypeEnum.BidForecast,
            MtrItemTypeEnum.BidScheduledFact,
            MtrItemTypeEnum.BidTotalFact,
            MtrItemTypeEnum.BidUnplanned,
            MtrItemTypeEnum.BidPlan
        ].forEach(element => {
            if (calculatedTypes.indexOf(MtrItemTypeEnum[element]) >= 0) {
                this.calculateSumValuesInYear(apiData, tmpValue, locationId, customerId, element, DateTypeEnum.Day);
            }
        });

        //month sum
        [
            MtrItemTypeEnum.ArrivalPlan,
            MtrItemTypeEnum.ExpenditurePlan,
            MtrItemTypeEnum.CargoHandlingPlan,
            MtrItemTypeEnum.FreightTurnoverPlan,
            MtrItemTypeEnum.SeasonalDeliveryPlan,
            MtrItemTypeEnum.ArrivalAdjustedPlan,
            MtrItemTypeEnum.ExpenditureAdjustedPlan,
            MtrItemTypeEnum.CargoHandlingAdjustedPlan,
            MtrItemTypeEnum.FreightTurnoverAdjustedPlan,
            MtrItemTypeEnum.SeasonalDeliveryAdjustedPlan,
        ].forEach(element => {
            if (calculatedTypes.indexOf(MtrItemTypeEnum[element]) >= 0) {
                this.calculateSumValuesInYear(apiData, tmpValue, locationId, customerId, element, DateTypeEnum.Month);
            }

        });

        // Performed

        if (calculatedTypes.indexOf("CargoHandlingPlan") >= 0) {
            const cargoHandlingAdjustedPlan: any = tmpValue.year?.CargoHandlingAdjustedPlan?.value;
            const cargoHandlingFact: any = tmpValue.year?.CargoHandlingFact?.value;

            if (cargoHandlingAdjustedPlan !== undefined && cargoHandlingAdjustedPlan !== 0 && cargoHandlingFact !== undefined) {
                tmpValue.year.CargoHandlingPerformed = { value: (cargoHandlingFact! / cargoHandlingAdjustedPlan!) * 100, mtrItemType: MtrItemTypeEnum.CargoHandlingPerformed };
            }
        }

        if (calculatedTypes.indexOf("FreightTurnoverPlan") >= 0) {
            const freightTurnoverAdjustedPlan: any = tmpValue.year?.FreightTurnoverAdjustedPlan?.value;
            const freightTurnoverFact: any = tmpValue.year?.FreightTurnoverFact?.value;

            if (freightTurnoverAdjustedPlan !== undefined && freightTurnoverAdjustedPlan !== 0 && freightTurnoverFact !== undefined) {
                tmpValue.year.FreightTurnoverPerformed = { value: (freightTurnoverFact! / freightTurnoverAdjustedPlan!) * 100, mtrItemType: MtrItemTypeEnum.FreightTurnoverPerformed };
            }
        }

        if (calculatedTypes.indexOf("SeasonalDeliveryPlan") >= 0) {
            const seasonalDeliveryAdjustedPlan: any = tmpValue.year?.SeasonalDeliveryAdjustedPlan?.value;
            const seasonalDeliveryFact: any = tmpValue.year?.SeasonalDeliveryFact?.value;

            if (seasonalDeliveryAdjustedPlan !== undefined && seasonalDeliveryAdjustedPlan !== 0 && seasonalDeliveryFact !== undefined) {
                tmpValue.year.SeasonalDeliveryPerformed = { value: (seasonalDeliveryFact! / seasonalDeliveryAdjustedPlan!) * 100, mtrItemType: MtrItemTypeEnum.SeasonalDeliveryPerformed };
            }
        }

        // last value
        [
            MtrItemTypeEnum.ArrivalPlan,
            MtrItemTypeEnum.ArrivalFact,
            MtrItemTypeEnum.ExpenditurePlan,
            MtrItemTypeEnum.ExpenditureFact,
            MtrItemTypeEnum.AccountingMtrProcessing,
            MtrItemTypeEnum.AccountingMtrTotalSupplies,
            MtrItemTypeEnum.AccountingMtrUncapitalize0_14,
            MtrItemTypeEnum.AccountingMtrUncapitalize15_30,
            MtrItemTypeEnum.AccountingMtrUncapitalize31_60,
            MtrItemTypeEnum.AccountingMtrUncapitalize61More,
            MtrItemTypeEnum.TransportPlan,
            MtrItemTypeEnum.TransportFact,
            MtrItemTypeEnum.GPMPlan,
            MtrItemTypeEnum.GPMFact,
            MtrItemTypeEnum.LaborResourcesPlan,
            MtrItemTypeEnum.LaborResourcesFact,
            MtrItemTypeEnum.FullnessBasesTotalSquare,
            MtrItemTypeEnum.FullnessBasesLoaded,
            MtrItemTypeEnum.FullnessBasesLoadedRubles,
            MtrItemTypeEnum.FullnessBasesLoadedWeight
        ].forEach(element => {
            if (calculatedTypes.indexOf(MtrItemTypeEnum[element]) >= 0) {
                this.calculateLastValueInYear(apiData, tmpValue, locationId, customerId, element);
            }

        });

        if (calculatedTypes.indexOf("BidPlan") >= 0) {
            if (tmpValue.year.BidPlan !== undefined
                && tmpValue.year.BidPlan.value !== undefined
                && tmpValue.year.BidScheduledFact.value !== undefined
                && tmpValue.year.BidTotalFact.value !== undefined
                && tmpValue.year.BidPlan.value !== 0) {
                const otValue = tmpValue.year.BidScheduledFact.value / tmpValue.year.BidPlan.value;
                const ifValue = tmpValue.year.BidTotalFact.value / tmpValue.year.BidPlan.value;
                tmpValue.year.BidOTIF = {
                    mtrItemType: MtrItemTypeEnum.BidOTIF, value: otValue * ifValue * 100
                };
            }
        }
    }

    private calculateSumValuesInYear(apiData: IMtrItemTransformed[], tmpValue: any, locationId: string, customerId: string | null, mtrItemType: MtrItemTypeEnum, dateType: DateTypeEnum) {

        tmpValue.year[MtrItemTypeEnum[mtrItemType]] = {
            value: apiData.filter(s =>
                s.dateType === dateType
                && s.year === this.year
                && s.type === MtrItemTypeEnum[mtrItemType]
                && s.customerId === customerId
                && s.locationId === locationId
            ).map(v => v.value).reduce((a, b) => a! + b!, 0),
            mtrItemType: mtrItemType
        };
    }

    private calculateLastValueInYear(apiData: IMtrItemTransformed[], tmpValue: any, locationId: string, customerId: string | null, mtrItemType: MtrItemTypeEnum) {
        const array = apiData.filter(s =>
            s.dateType === DateTypeEnum.Day
            && s.year === this.year
            && s.type === MtrItemTypeEnum[mtrItemType]
            && s.customerId === customerId
            && s.locationId === locationId
        );

        const array_byMonth = array.sort((a, b) => a.month! < b.month! ? 1 : -1);

        if (array_byMonth.length > 0) {
            const lastMoth = array_byMonth[0].month!;
            const array_byDays = array.filter(s => s.month === lastMoth && s.day !== undefined)
                .sort((a, b) => a.day! < b.day! ? 1 : -1);

            if (array_byDays.length > 0) {
                tmpValue.year[MtrItemTypeEnum[mtrItemType]] = {
                    value: array_byDays[0].value,
                    mtrItemType: mtrItemType
                };
            }
        }
    }

    private createSelectedMtrItemDataTypeArrar(mtrItemDataTypes: ITreeListMtrItemDataType[]) {
        const tmpValues = mtrItemDataTypes.filter(s => s.selected === true);
        // все выбранные элементы
        tmpValues.forEach(element => {
            // для каждого
            //добавляем сам элемент
            this.selectedMtrItemDataTypes.push(element);
            // добавляем всех родителей
            this.addAllParentValues(element.parentId);
            // если группа, то еще дочерних
            if (element.type === undefined) {

                this.addAllChildrenValues(element.id);
            }
        });
    }

    private addAllChildrenValues(id: string) {
        const childrenItems = this.allMtrItemDataTypes.filter(s => s.parentId === id);
        childrenItems.forEach(childrenItem => {
            if (this.selectedMtrItemDataTypes.includes(childrenItem) === false) {
                this.selectedMtrItemDataTypes.push(childrenItem);
            }

            if (childrenItem.type === undefined) {
                this.addAllChildrenValues(childrenItem!.id);
            }
        });

    }

    private addAllParentValues(parentMtrItemDataTypeId: string) {
        const parentItem = this.allMtrItemDataTypes.find(s => s.id === parentMtrItemDataTypeId);

        if (parentItem !== undefined && this.selectedMtrItemDataTypes.includes(parentItem) === false) {
            this.selectedMtrItemDataTypes.push(parentItem);

            if (parentItem?.parentId !== "root") {
                this.addAllParentValues(parentItem!.parentId);
            }
        }
    }

    private onCellPrepared(options: any) {
        if (options.rowType === "data") {
            if (options.column.allowEditing) {
                options.cellElement.style.color = "black";
                options.cellElement.style.backgroundColor = "#baccea";
            }
        }
    }
}