﻿using Common.Extensions;
using FluentValidation.Results;

using MediatR;
using Supply.Dashboards.App.UseCases.WeatherRestrictions.GetWeatherRestrictionsList.Output;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.WeatherRestrictions.GetWeatherRestrictionsList.Input
{
    public sealed class GetWeatherRestrictionsListQuery : IRequest<(ValidationResult validationResult, GetWeatherRestrictionsListOutput? output)>
    {

        public GetWeatherRestrictionsListQuery(
            DateTime startDate,
            DateTime endDate,
            IEnumerable<Guid?>? customerIds,
            IEnumerable<Guid>? locationIds,
            bool notNullAktirovka = false)
        {
            StartDate = startDate;
            EndDate = endDate;
            CustomerIds = customerIds;
            LocationIds = locationIds;
            NotNullAktirovka = notNullAktirovka;

            ValidationResult = new GetWeatherRestrictionsListValidator()
                .Validate(this);
        }

        public DateTime StartDate { get; }
        public DateTime EndDate { get; }
        public bool NotNullAktirovka { get; }
        public IEnumerable<Guid?>? CustomerIds { get; }
        public IEnumerable<Guid>? LocationIds { get; }

        public ValidationResult ValidationResult { get; }


    }
}
