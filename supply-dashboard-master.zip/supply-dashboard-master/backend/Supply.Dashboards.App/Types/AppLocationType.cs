﻿using Common.SeedWork;

using Supply.Dashboards.App.Exceptions;
using Supply.Dashboards.Domain.Types;

namespace Supply.Dashboards.App.Types
{
    public sealed class AppLocationType : Enumeration
    {
        public static AppLocationType Default = new(0, "Default");
        public static AppLocationType Division = new(1, "Division");
        public static AppLocationType Direction = new(2, "Direction");
        public static AppLocationType Node = new(3, "Node");

        public AppLocationType(int id, string name) : base(id, name)
        {
        }

        internal static LocationType GetLocationType(AppLocationType type)
        {
            var name = type.Name switch
            {
                nameof(Default) => throw new AppException(nameof(Default)),
                nameof(Division) => LocationType.Division.Name,
                nameof(Direction) => LocationType.Direction.Name,
                nameof(Node) => LocationType.Node.Name,
                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<LocationType>(name)!;
        }

        internal static AppLocationType GetAppLocationType(LocationType type)
        {
            var name = type.Name switch
            {
                nameof(LocationType.Division) => Division.Name,
                nameof(LocationType.Direction) => Direction.Name,
                nameof(LocationType.Node) => Node.Name,
                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<AppLocationType>(name)!;
        }
    }
}
