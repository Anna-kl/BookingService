﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Supply.Dashboards.Domain.AggregatesModel.Core;

namespace Supply.Dashboards.Infrastructure.TypeConfigurations.AggregatesModel.Core
{
    public sealed class ContextUserTypeConfig : IEntityTypeConfiguration<ContextUser>
    {
        public void Configure(EntityTypeBuilder<ContextUser> builder)
        {
            builder.ToTable("context_user");

            builder.HasKey(_ => new { _.ContextId, _.UserId });

            builder
                .HasOne(_ => _.Context)
                .WithMany(_ => _.ContextUsers)
                .HasForeignKey(_ => _.ContextId)
                .OnDelete(DeleteBehavior.NoAction);

            builder
                .HasOne(_ => _.User)
                .WithMany(_ => _.ContextUsers)
                .HasForeignKey(_ => _.UserId)
                .OnDelete(DeleteBehavior.NoAction);

            builder
                .HasIndex(_ => new { _.ContextInnerId, _.UserInnerId })
                .IsUnique();
        }
    }
}
