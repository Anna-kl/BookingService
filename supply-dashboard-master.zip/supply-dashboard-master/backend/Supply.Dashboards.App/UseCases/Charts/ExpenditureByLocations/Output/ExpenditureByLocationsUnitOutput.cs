﻿using Supply.Dashboards.App.UseCases.Charts.ExpenditureByLocations.Types;

namespace Supply.Dashboards.App.UseCases.Charts.ExpenditureByLocations.Output
{
    public sealed class ExpenditureByLocationsUnitOutput
    {
        public ExpenditureByLocationsUnitOutput(
            ExpenditureType type,
            double value)
        {
            Type = type;
            Value = value;
        }

        public ExpenditureType Type { get; }
        public double Value { get; }
    }
}
