﻿using Supply.Dashboards.App.UseCases.Charts.HseIndicators.Types;

using System;

namespace Supply.Dashboards.App.UseCases.Charts.HseIndicators.Output
{
    public sealed class HseIndicatorIncidentOutput
    {
        public HseIndicatorIncidentOutput(
            DateTime dateTime,
            HseIndicatorType type,
            string text)
        {
            DateTime = dateTime;
            Type = type;
            Text = text;
        }

        public DateTime DateTime { get; }
        public HseIndicatorType Type { get; }
        public string Text { get; }
    }
}
