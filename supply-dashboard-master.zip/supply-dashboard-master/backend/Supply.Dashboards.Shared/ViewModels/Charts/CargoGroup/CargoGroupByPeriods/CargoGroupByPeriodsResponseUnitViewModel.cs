﻿namespace Supply.Dashboards.Shared.ViewModels.Charts.CargoGroupByPeriods
{
    public sealed class CargoGroupByPeriodsResponseUnitViewModel
    {
        public double Tons { get; set; }
    }
}
