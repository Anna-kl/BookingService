﻿using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.Data.DataMtr.Types;

using System;

namespace Supply.Dashboards.App.UseCases.Data.DataMtr.Output
{
    public sealed class DataMtrItemOutput
    {
        internal DataMtrItemOutput(
            uint xMin,
            DateTime startPeriod,
            DateTime endPeriod,
            Guid? customerId,
            Guid? locationId,
            Guid? mtrTypeId,
            DataMtrType type,
            double value,
            AppInputType inputType)
        {
            RowVersion = xMin;
            StartPeriod = startPeriod;
            EndPeriod = endPeriod;
            CustomerId = customerId;
            LocationId = locationId;
            MtrTypeId = mtrTypeId;
            Type = type;
            Value = value;
            InputType = inputType;
        }

        public uint RowVersion { get; }
        public DateTime StartPeriod { get; }
        public DateTime EndPeriod { get; }
        public Guid? CustomerId { get; }
        public Guid? LocationId { get; }
        public Guid? MtrTypeId { get; }
        public DataMtrType Type { get; }
        public double Value { get; }
        public AppInputType InputType { get; }
    }
}
