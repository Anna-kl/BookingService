﻿using System;
using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.Charts.TransportResources.Output
{
    public sealed class TransportResourcesByPeriodsParamOutput
    {
        private readonly List<TransportResourcesUnitOutput> _units;

        internal TransportResourcesByPeriodsParamOutput(
            DateTime period,
            List<TransportResourcesUnitOutput>? units)
        {
            Period = period;
            _units = units ?? new List<TransportResourcesUnitOutput>();
        }

        public DateTime Period { get; }
        public IEnumerable<TransportResourcesUnitOutput>? Units =>
            _units.AsReadOnly();
    }
}
