﻿using Common.SeedWork;

using Supply.Dashboards.App.Exceptions;
using Supply.Dashboards.Domain.Types;

namespace Supply.Dashboards.App.UseCases.Charts.AccountingMtrByPeriods.Types
{
    public sealed class AccountingMtrByPeriodsType : Enumeration
    {
#pragma warning disable CA2211 // Non-constant fields should not be visible
        public static AccountingMtrByPeriodsType AccountingMtrTotalSupplies = new(400, "AccountingMtrTotalSupplies");
        public static AccountingMtrByPeriodsType AccountingMtrProcessing = new(401, "AccountingMtrProcessing");
        public static AccountingMtrByPeriodsType AccountingMtrUncapitalize0_14 = new(402, "AccountingMtrUncapitalize0_14");
        public static AccountingMtrByPeriodsType AccountingMtrUncapitalize15_30 = new(403, "AccountingMtrUncapitalize15_30");
        public static AccountingMtrByPeriodsType AccountingMtrUncapitalize31_60 = new(404, "AccountingMtrUncapitalize31_60");
        public static AccountingMtrByPeriodsType AccountingMtrUncapitalize61More = new(405, "AccountingMtrUncapitalize61More");
#pragma warning restore CA2211 // Non-constant fields should not be visible

        public AccountingMtrByPeriodsType(int id, string name) : base(id, name)
        {
        }

        internal static AccountingMtrByPeriodsType GetAccountingMtrByPeriodsType(ValueRecordType type)
        {
            var name = type.Name switch
            {
                nameof(ValueRecordType.AccountingMtrTotalSupplies) => AccountingMtrTotalSupplies.Name,
                nameof(ValueRecordType.AccountingMtrProcessing) => AccountingMtrProcessing.Name,
                nameof(ValueRecordType.AccountingMtrUncapitalize0_14) => AccountingMtrUncapitalize0_14.Name,
                nameof(ValueRecordType.AccountingMtrUncapitalize15_30) => AccountingMtrUncapitalize15_30.Name,
                nameof(ValueRecordType.AccountingMtrUncapitalize31_60) => AccountingMtrUncapitalize31_60.Name,
                nameof(ValueRecordType.AccountingMtrUncapitalize61More) => AccountingMtrUncapitalize61More.Name,

                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<AccountingMtrByPeriodsType>(name)!;
        }
    }
}
