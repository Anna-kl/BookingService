﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.UseCases.Contexts.GetContextList;
using Supply.Dashboards.Domain.AggregatesModel.Core;
using Supply.Dashboards.Domain.Types;
using Supply.Dashboards.Infrastructure.Data;

using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.Infrastructure.UseCasesRepositories.Contexts
{
    public sealed class GetContextListRepository : IGetContextList
    {
        private readonly ILogger<GetContextListRepository> _logger;
        private readonly DashboardsContext _dashboardsContext;

        public GetContextListRepository(
            ILogger<GetContextListRepository> logger,
            DashboardsContext dashboardsContext)
        {
            _logger = logger;
            _dashboardsContext = dashboardsContext;
        }

        public async Task<IEnumerable<Context>> Get(
            List<StatusType> statuses,
            List<int>? ids,
            CancellationToken cancellationToken)
        {
            var queryable = _dashboardsContext
                .Contexts
                .Include(_ => _.ContextUsers)
                .ThenInclude(_ => _.User)
                .Where(_ => statuses.Contains(_.Status));

            if (ids != null && ids.Any())
                queryable = queryable.Where(_ => ids.Contains(_.Id));

            return (await queryable.ToListAsync(cancellationToken))
                .AsReadOnly();
        }
    }
}
