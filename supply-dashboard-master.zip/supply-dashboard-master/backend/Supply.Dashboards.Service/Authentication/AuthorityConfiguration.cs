﻿namespace Supply.Dashboards.Service.Authentication
{
    public sealed class AuthorityConfiguration
    {
        public string? AuthorityUrl { get; set; }
    }
}
