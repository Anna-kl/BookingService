﻿using Common.SeedWork;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Supply.Dashboards.App.UserInfo;
using Supply.Dashboards.Domain.AggregatesModel.Bids;
using Supply.Dashboards.Domain.AggregatesModel.Core;
using Supply.Dashboards.Domain.Types;

namespace Supply.Dashboards.Infrastructure.TypeConfigurations.AggregatesModel.Bids
{
    public sealed class BidTypeConfig : IEntityTypeConfiguration<Bid>
    {
        public void Configure(EntityTypeBuilder<Bid> builder)
        {
            builder.ToTable("bids");

            builder.HasKey(_ => _.Id);
            builder.HasAlternateKey(_ => _.InnerId);
            builder
                .Property(_ => _.Id)
                .ValueGeneratedOnAdd();

            builder
                .Property(_ => _.XMin)
                .HasColumnName("xmin")
                .HasColumnType("xid")
                .ValueGeneratedOnAddOrUpdate()
                .IsConcurrencyToken();

            builder
                .HasOne<Context>()
                .WithMany()
                .HasForeignKey("ContextId")
                .IsRequired();
            builder.HasQueryFilter(_ => UserInfo.Context == null
                ? EF.Property<int>(_, "ContextId") != 0
                : EF.Property<int>(_, "ContextId") == UserInfo.Context.Id);

            builder
                .OwnsOne(_ => _.Payload)
                .Property(payload => payload.Type)
                .HasConversion(
                    type => type.Id,
                    key => Enumeration.FromValue<BidType>(key)!);

            builder
                .OwnsOne(_ => _.Payload)
                .Property(payload => payload.InputType)
                .HasConversion(
                    type => type.Id,
                    key => Enumeration.FromValue<InputType>(key)!);

            builder.Ignore(valueRecord => valueRecord.DomainEvents);
        }
    }
}
