﻿using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Charts.HseIndicators
{
    public sealed class HseIndicatorsResponseViewModel
    {
        public int DaysWithoutIncident { get; set; }
        public HseIndicatorIncidentResponseViewModel? LastIncident { get; set; }
        public List<HseIndicatorsUnitResponseViewModel>? Units { get; set; }
    }
}
