﻿using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.Charts.TransportResources.Output
{
    public sealed class TransportResourcesByPeriodsOutput
    {
        private readonly List<TransportResourcesByPeriodsParamOutput> _periods;

        internal TransportResourcesByPeriodsOutput(List<TransportResourcesByPeriodsParamOutput> periods)
        {
            _periods = periods;
        }

        public IEnumerable<TransportResourcesByPeriodsParamOutput> Periods =>
            _periods.OrderBy(_ => _.Period).ToList().AsReadOnly();
    }
}
