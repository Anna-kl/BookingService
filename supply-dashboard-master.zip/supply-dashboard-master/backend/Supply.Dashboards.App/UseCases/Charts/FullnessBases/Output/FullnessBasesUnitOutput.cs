﻿using Supply.Dashboards.App.UseCases.Charts.FullnessBases.Types;

namespace Supply.Dashboards.App.UseCases.Charts.FullnessBases.Output
{
    public sealed class FullnessBasesUnitOutput
    {
        public FullnessBasesUnitOutput(
            FullnessBasesType type,
            double value)
        {
            Type = type;
            Value = value;
        }

        public FullnessBasesType Type { get; }
        public double Value { get; }
    }
}
