﻿using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Import.ImportMtr
{
    public sealed class ImportMtrResponseViewModel
    {
        public List<ImportMtrItemResponseViewModel>? Added { get; set; }
        public List<ImportMtrItemResponseViewModel>? Updated { get; set; }
        public List<ImportMtrItemResponseViewModel>? Removed { get; set; }
    }
}
