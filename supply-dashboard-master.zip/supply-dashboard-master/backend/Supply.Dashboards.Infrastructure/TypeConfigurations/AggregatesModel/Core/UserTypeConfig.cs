﻿using Common.SeedWork;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Supply.Dashboards.Domain.AggregatesModel.Core;
using Supply.Dashboards.Domain.Types;

namespace Supply.Dashboards.Infrastructure.TypeConfigurations.AggregatesModel.Core
{
    public sealed class UserTypeConfig : IEntityTypeConfiguration<User>
    {
        public void Configure(EntityTypeBuilder<User> builder)
        {
            builder.ToTable("users");

            builder.HasKey(_ => _.Id);
            builder.HasAlternateKey(_ => _.InnerId);
            builder
                .Property(_ => _.Id)
                .ValueGeneratedOnAdd();

            builder
                .Property(_ => _.Status)
                .HasConversion(
                    type => type.Id,
                    key => Enumeration.FromValue<StatusType>(key)!);

            builder.Ignore(_ => _.DomainEvents);
        }
    }
}
