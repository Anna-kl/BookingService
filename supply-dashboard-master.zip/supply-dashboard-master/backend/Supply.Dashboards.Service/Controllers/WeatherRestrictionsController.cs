﻿using Common.SeedWork;

using MediatR;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Common.Extensions;
using Supply.Dashboards.Shared.ViewModels.WeatherRestrictions.WeatherRestrictionsList;
using Supply.Dashboards.App.UseCases.WeatherRestrictions.GetWeatherRestrictionsList.Input;
using Supply.Dashboards.Shared.ViewModels.WeatherRestrictions.WeatherRestrictionsDelete;
using Supply.Dashboards.Shared.ViewModels.WeatherRestrictions.WeatherRestrictionsAddOrUpdate;
using Supply.Dashboards.App.UseCases.WeatherRestrictions.WetherRestrictionAddOrUpdate.Input;
using Supply.Dashboards.App.UseCases.WeatherRestrictions.WeatherRestrictionDelete.Input;

namespace Supply.Dashboards.Service.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public sealed class WeatherRestrictionsController : ControllerBase
    {
        private readonly ILogger<WeatherRestrictionsController> _logger;
        private readonly IMediator _mediator;

        public WeatherRestrictionsController(
            ILogger<WeatherRestrictionsController> logger,
            IMediator mediator)
        {
            _logger = logger;
            _mediator = mediator;
        }

        [HttpPost("list")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        public async Task<ActionResult<WeatherRestrictionsListResponseViewModel>> GetList(
            [FromBody] WeatherRestrictionsListRequestViewModel request,
            CancellationToken cancellationToken)
        {
            var query = new GetWeatherRestrictionsListQuery(request.StartDate, request.EndDate, request.CustomerIds, request.LocationIds);

            if (!query.ValidationResult.IsValid)
                return BadRequest(
                    query
                        .ValidationResult
                        .Errors
                        .Select(failure => new
                        {
                            failure.ErrorCode,
                            failure.ErrorMessage
                        }));

            var (validationResult, output) = await _mediator.Send(
                query,
                cancellationToken);

            if (!validationResult.IsValid)
                return BadRequest(
                    query
                        .ValidationResult
                        .Errors
                        .Select(failure => new
                        {
                            failure.ErrorCode,
                            failure.ErrorMessage
                        }));

            var result = new WeatherRestrictionsListResponseViewModel()
            {
                Items = output.Items.Select(_ => new WeatherRestrictionsListItemResponseViewModel
                {
                    Id = _.Id,
                    Aktirovka = _.Aktirovka,
                    CustomerId = _.CustomerId,
                    DateTime = _.DateTime,
                    LocationId = _.LocationId,
                    LocationTitle = _.LocationTitle,
                    LocationLatitude = _.LocationLatitude,
                    LocationLongitude = _.LocationLongitude,
                    Temperature = _.Temperature,
                    WindSpeed = _.WindSpeed

                }).ToList()
            };

            return result;
        }

        [HttpPost("addupdate")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        public async Task<ActionResult> AddOrUpdate(
            [FromBody] WeatherRestrictionsAddOrUpdateRequestViewModel request,
            CancellationToken cancellationToken)
        {
            var query = new WeatherRestrictionAddOrUpdateQuery(request.Id, request.DateTime, request.locationId, request.customerId, request.Temperature, request.WindSpeed, request.Aktirovka);

            if (!query.ValidationResult.IsValid)
                return BadRequest(
                    query
                        .ValidationResult
                        .Errors
                        .Select(failure => new
                        {
                            failure.ErrorCode,
                            failure.ErrorMessage
                        }));

            var (validationResult, output) = await _mediator.Send(
                query,
                cancellationToken);

            if (!validationResult.IsValid)
                return BadRequest(
                    query
                        .ValidationResult
                        .Errors
                        .Select(failure => new
                        {
                            failure.ErrorCode,
                            failure.ErrorMessage
                        }));

            return Ok();
        }

        [HttpPost("remove")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        public async Task<ActionResult> Delete(
            [FromBody] WeatherRestrictionsDeleteRequestViewModel request,
            CancellationToken cancellationToken)
        {
            var query = new WeatherRestrictionDeleteQuery(request.Id);

            if (!query.ValidationResult.IsValid)
                return BadRequest(
                    query
                        .ValidationResult
                        .Errors
                        .Select(failure => new
                        {
                            failure.ErrorCode,
                            failure.ErrorMessage
                        }));

            var (validationResult, output) = await _mediator.Send(
                query,
                cancellationToken);

            if (!validationResult.IsValid)
                return BadRequest(
                    query
                        .ValidationResult
                        .Errors
                        .Select(failure => new
                        {
                            failure.ErrorCode,
                            failure.ErrorMessage
                        }));

            return Ok();
        }
    }
}
