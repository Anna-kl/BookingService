﻿namespace Supply.Dashboards.App.UseCases.Charts.CargoGroupByPeriods.Output
{
    public sealed class CargoGroupByPeriodsUnitOutput
    {
        internal CargoGroupByPeriodsUnitOutput(double value)
        {
            Value = value;
        }

        public double Value { get; }
    }
}
