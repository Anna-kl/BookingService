import { DateTime } from "luxon";

export interface IExecutionOfOrdersDataResponse {
    date: DateTime;
    plan: number;
    forecast: number;
    totalFact?: number;
}

export interface IExecutionOfOrdersDataRequest {
    startPeriod: string;
    locationsIds?: string[] | null;
    customersIds?: string[] | null;
}

export interface IExecutionOfOrdersChartData {
    date: string;
    plan: number;
    forecast: number;
    totalFact?: number;
}
