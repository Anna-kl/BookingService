﻿using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Supply.Dashboards.App.UseCases;
using Supply.Dashboards.App.UseCases.Charts.AccountingMtrByPeriods;
using Supply.Dashboards.App.UseCases.Charts.ArrivalByLocations;
using Supply.Dashboards.App.UseCases.Charts.ExpenditureByLocations;
using Supply.Dashboards.App.UseCases.Charts.CargoGroupByLocations;
using Supply.Dashboards.App.UseCases.Charts.CargoGroupByPeriods;
using Supply.Dashboards.App.UseCases.Charts.HseIndicators;
using Supply.Dashboards.App.UseCases.Charts.OtifChart;
using Supply.Dashboards.App.UseCases.Charts.ExecutionOfOrders;
using Supply.Dashboards.App.UseCases.Charts.SeasonalDelivery;
using Supply.Dashboards.App.UseCases.Charts.TransportResources;
using Supply.Dashboards.App.UseCases.Contexts.GetContextList;
using Supply.Dashboards.App.UseCases.Customers.GetCustomerList;
using Supply.Dashboards.App.UseCases.Data.DataMtr;
using Supply.Dashboards.App.UseCases.Imports.ImportDirectories;
using Supply.Dashboards.App.UseCases.Imports.ImportMtr;
using Supply.Dashboards.App.UseCases.Locations.GetLocationList;
using Supply.Dashboards.App.UseCases.MtrTypes.GetMtrTypeList;
using Supply.Dashboards.App.UseCases.ValueRecords;
using Supply.Dashboards.App.UseCases.WeatherRestrictions;
using Supply.Dashboards.App.UserInfo;
using Supply.Dashboards.Infrastructure.Data;
using Supply.Dashboards.Infrastructure.UseCasesRepositories;
using Supply.Dashboards.Infrastructure.UseCasesRepositories.Charts;
using Supply.Dashboards.Infrastructure.UseCasesRepositories.Contexts;
using Supply.Dashboards.Infrastructure.UseCasesRepositories.Customers;
using Supply.Dashboards.Infrastructure.UseCasesRepositories.Imports;
using Supply.Dashboards.Infrastructure.UseCasesRepositories.Locations;
using Supply.Dashboards.Infrastructure.UseCasesRepositories.MtrTypes;
using Supply.Dashboards.Infrastructure.UseCasesRepositories.WeatherRestrictions;
using System;
using Supply.Dashboards.App.InnerEventHandlers;

namespace Supply.Dashboards.Infrastructure.Extensions
{
    public static class StartupInfraExtensions
    {
        public static IServiceCollection AddStartupInfraExtensions(
            this IServiceCollection services,
            IConfiguration configuration)
        {
            var loggerFactory = LoggerFactory.Create(builder =>
                {
                    builder
                        .AddConsole()
                        .AddFilter(string.Empty, LogLevel.Debug);
                });

            var t = configuration.GetConnectionString("SupplyDashboardsContext");

            services
                    .AddDbContext<DashboardsContext>(options =>
                    {
                        options.UseNpgsql(
                            configuration.GetConnectionString("SupplyDashboardsContext"),
                            providerOptions => providerOptions.SetPostgresVersion(new Version(12, 6))
                        );
                        options
                            .EnableSensitiveDataLogging()
                            .UseLoggerFactory(loggerFactory);
                    });

            services
                .AddTransient<IGetContextList, GetContextListRepository>()
                .AddTransient<IAuthInfo, UserRepository>()

                .AddTransient<IAccountingMtrByPeriods, AccountingMtrByLocationsRepository>()
                .AddTransient<ICargoGroupByPeriods, CargoGroupByPeriodsRepository>()
                .AddTransient<ICargoGroupByLocations, CargoGroupByLocationsRepository>()
                .AddTransient<IHseIndicators, HseIndicatorsRepository>()
                .AddTransient<IArrivalByLocations, ArrivalByLocationsRepository>()
                .AddTransient<IExpenditureByLocations, ExpenditureByLocationsRepository>()

                .AddTransient<IExecutionOfOrdersChart, ExecutionOfOrdersRepository>()
                .AddTransient<IOtifChart, OtifChartRepository>()
                .AddTransient<ITransportResources, TransportResourcesRepository>()

                .AddTransient<IGetLocationList, GetLocationListRepository>()
                .AddTransient<IGetCustomerList, GetCustomerListRepository>()
                .AddTransient<IGetMtrTypeList, GetMtrTypeListRepository>()

                .AddTransient<IImportDirectories, ImportDirectoriesRepository>()
                .AddTransient<IImportMtr, ImportMtrRepository>()

                .AddTransient<IDataMtr, DataMtrRepository>()

                .AddTransient<IValueRecords, ValueRecordsRepository>()

                .AddTransient<IWeatherRestrictions, WeatherRestrictionsRepository>()

                .AddTransient<IBaseUseCase, BaseUseCaseRepository>()

                .AddTransient<IDomainEventHandler, DomainEventRepository>();

            return services;
        }

        public static IApplicationBuilder UseStartupInfraExtensions(
            this IApplicationBuilder app)
        {
            try
            {
                app.ApplyMigrations();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                app
                    .ApplicationServices
                    .GetRequiredService<ILoggerFactory>()
                    .CreateLogger(nameof(MigrationExtensions))
                    .LogCritical(e, e.Message);

                throw;
            }

            app.UseSeedDataExtensions();

            return app;
        }
    }
}
