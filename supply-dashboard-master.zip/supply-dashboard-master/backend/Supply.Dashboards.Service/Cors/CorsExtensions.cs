﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Supply.Dashboards.Service.Cors
{
    public static class CorsExtensions
    {
        private const string DefaultCors = "allowSpecificOrigins";

        public static IServiceCollection AddCorsExtension(
            this IServiceCollection services,
            IConfiguration configuration)
        {
            var corsConfiguration = configuration
                .GetSection("CORS")
                .Get<CorsConfiguration>();

            services.AddCors(options =>
            {
                options.AddPolicy(DefaultCors, policy =>
                {
                    policy.WithOrigins(corsConfiguration.AllowedOrigins)
                        .AllowAnyHeader()
                        .AllowAnyMethod()
                        .AllowCredentials();
                });

                options.DefaultPolicyName = DefaultCors;
            });

            return services;
        }

        public static IApplicationBuilder UseCorsExtension(this IApplicationBuilder app) =>
            app.UseCors(DefaultCors);
    }
}
