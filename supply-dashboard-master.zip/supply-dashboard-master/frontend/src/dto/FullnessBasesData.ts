export interface IFullnessBasesByLocationDataResponse {
    locations: IFullnessBasesByLocationResponse[];
}

export interface IFullnessBasesByLocationResponse {
    locationId: string;
    locationTitle: string;
    units: IFullnessBasesUnitResponse[];
}

export interface IFullnessBasesUnitResponse {
    square: number;
    type: string;
}

export interface IGroupDataByParent {
    id: string;
    dbId: string;
    title: string;
    selected: boolean;
    childrenGroups: IGroupDataByParent[];
}

export interface IFullnessBasesDataRequest {
    period: string;
    startPeriod: string;
    duration?: string;
    locationType?: string;
    parentLocationId?: string;
    locationsIds?: string[] | null;
    customersIds?: string[] | null;
}

export interface IFullnessBasesByLocationChartData {
    locationId: string;
    location: string;
    free?: number;
    loaded?: number;
    rubles?: number;
    weight?: number;
    total?: number;
}
