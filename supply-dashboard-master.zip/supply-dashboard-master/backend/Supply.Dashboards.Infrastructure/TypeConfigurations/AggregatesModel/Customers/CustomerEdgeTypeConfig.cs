﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Supply.Dashboards.App.UserInfo;
using Supply.Dashboards.Domain.AggregatesModel.Core;
using Supply.Dashboards.Domain.AggregatesModel.Customers;

namespace Supply.Dashboards.Infrastructure.TypeConfigurations.AggregatesModel.Customers
{
    public sealed class CustomerEdgeTypeConfig : IEntityTypeConfiguration<CustomerEdge>
    {
        public void Configure(EntityTypeBuilder<CustomerEdge> builder)
        {
            builder.ToTable("customers_edges");

            builder.HasKey(_ => new { _.SourceId, _.DestinationId });

            builder
                .HasOne(_ => _.Source)
                .WithMany(_ => _.DestinationEdges)
                .HasForeignKey(_ => _.SourceId)
                .OnDelete(DeleteBehavior.NoAction);

            builder
                .HasOne(_ => _.Destination)
                .WithMany(_ => _.SourceEdges)
                .HasForeignKey(_ => _.DestinationId)
                .OnDelete(DeleteBehavior.NoAction);

            builder
                .HasIndex(_ => new { _.SourceInnerId, _.DestinationInnerId })
                .IsUnique();

            builder
                .HasOne<Context>()
                .WithMany()
                .HasForeignKey("ContextId")
                .IsRequired();
            builder.HasQueryFilter(_ => UserInfo.Context == null
                ? EF.Property<int>(_, "ContextId") != 0
                : EF.Property<int>(_, "ContextId") == UserInfo.Context.Id);
        }
    }
}
