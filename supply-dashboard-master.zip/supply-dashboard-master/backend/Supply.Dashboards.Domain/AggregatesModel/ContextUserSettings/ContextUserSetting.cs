﻿using Common.SeedWork;
using Supply.Dashboards.Domain.AggregatesModel.Core;
using Supply.Dashboards.Domain.Exceptions;
using System;

namespace Supply.Dashboards.Domain.AggregatesModel.ContextUserSettings
{
    public sealed class ContextUserSetting
    {
        #region c'tors

        public ContextUserSetting(int contextId,
            int userId, string dashboardsState)
        {
            ContextId = contextId;
            UserId = userId;
            CreateAt = DateTime.UtcNow;
            UpdateAt = DateTime.UtcNow;
            DashboardsState = dashboardsState;
        }

        public void Change(string dashboardsState)
        {
            UpdateAt = DateTime.UtcNow;
            DashboardsState = dashboardsState;
        }

        private ContextUserSetting()
        {

        }


        #endregion

        #region props
        public int ContextId { get; init; }
        public int UserId { get; init; }
        public DateTime CreateAt { get; init; }
        public DateTime UpdateAt { get; private set; }
        public string DashboardsState { get; private set; }

        #endregion

    }
}
