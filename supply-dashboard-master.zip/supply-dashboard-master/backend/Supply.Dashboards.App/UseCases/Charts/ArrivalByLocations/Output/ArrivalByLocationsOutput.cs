﻿using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.Charts.ArrivalByLocations.Output
{
    public sealed class ArrivalByLocationsOutput
    {
        private readonly List<ArrivalByLocationsParamOutput> _locations;

        internal ArrivalByLocationsOutput(List<ArrivalByLocationsParamOutput> locations)
        {
            _locations = locations;
        }

        public IEnumerable<ArrivalByLocationsParamOutput> Locations =>
            _locations.OrderBy(_ => _.LocationId).ToList().AsReadOnly();
    }
}
