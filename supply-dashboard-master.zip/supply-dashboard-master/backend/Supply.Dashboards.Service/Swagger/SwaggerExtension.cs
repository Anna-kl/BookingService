﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;

using System;

namespace Supply.Dashboards.Service.Swagger
{
    public static class SwaggerExtension
    {
        public static IServiceCollection AddSwagger(
            this IServiceCollection services,
            IConfiguration configuration,
            string xmlPath)
        {
            var swaggerConfig = new SwaggerConfig();

            configuration
                .GetSection("Swagger")
                .Bind(swaggerConfig);

            if (!swaggerConfig.IsConfigured())
                throw new InvalidProgramException("Swagger not configured.");

            services
                .AddSwaggerGen(_ =>
                {
                    _.SwaggerDoc(
                        swaggerConfig.Name,
                        new OpenApiInfo
                        {
                            Title = swaggerConfig.Title,
                            Version = swaggerConfig.Version

                        });

                    _.IncludeXmlComments(xmlPath);

                    _.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                    {
                        In = ParameterLocation.Header,
                        Description = "Please insert JWT with Bearer into field",
                        Name = "Authorization",
                        Type = SecuritySchemeType.ApiKey
                    });

                    _.AddSecurityRequirement(new OpenApiSecurityRequirement {
                        {
                            new OpenApiSecurityScheme
                            {
                                Reference = new OpenApiReference
                                {
                                    Type = ReferenceType.SecurityScheme,
                                    Id = "Bearer"
                                }
                            },
                            new string[] { }
                        }
                    });
                });

            return services;
        }

        public static IApplicationBuilder UseSwagger(
            this IApplicationBuilder app,
            IConfiguration configuration)
        {
            var config = new SwaggerConfig();

            configuration
                .GetSection("Swagger")
                .Bind(config);

            if (!config.IsConfigured())
                throw new InvalidProgramException("Swagger not configured.");

            app
                .UseSwagger()
                .UseSwaggerUI(
                    _ =>
                    {
                        _.SwaggerEndpoint(config.Url, config.Name);
                        _.RoutePrefix = config.RoutePrefix;
                    });

            return app;
        }
    }
}
