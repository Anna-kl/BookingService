﻿using Common.SeedWork;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Input;
using Supply.Dashboards.App.UseCases.Imports.ImportMtr.Input;
using Supply.Dashboards.App.UseCases.Imports.ImportMtr.Types;
using Supply.Dashboards.Shared.Types;
using Supply.Dashboards.Shared.ViewModels.Import.ImportDirectories.Request;
using Supply.Dashboards.Shared.ViewModels.Import.ImportDirectories.Response;
using Supply.Dashboards.Shared.ViewModels.Import.ImportMtr;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.Service.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public sealed class ImportsController : ControllerBase
    {
        private readonly ILogger<ImportsController> _logger;
        private readonly IMediator _mediator;

        public ImportsController(
            ILogger<ImportsController> logger,
            IMediator mediator)
        {
            _logger = logger;
            _mediator = mediator;
        }

        /// <summary>
        /// Import of cargo turnover, cargo handling, accounting of materials and equipment, OTIF.
        /// Removal is done by setting the "value" property to null.
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [HttpPost("mtr")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        public async Task<ActionResult<ImportMtrResponseViewModel>> ImportMtr(
            [FromBody] ImportMtrRequestViewModel request,
            CancellationToken cancellationToken)
        {
            var inputs = request
                .Items
                ?.Where(model => !string.IsNullOrWhiteSpace(model.Type.ToString()))
                .Select(model => new ImportMtrItemInput(
                    model.RowVersion,
                    model.StartPeriod,
                    model.StartPeriod.Add(model.Duration),
                    model.CustomerId,
                    model.LocationId,
                    model.MtrTypeId,
                    Enumeration.IsDefined<ImportMtrType>(model.Type.ToString())
                        ? Enumeration.FromDisplayName<ImportMtrType>(model.Type.ToString()!)
                        : ImportMtrType.Default,
                    model.Value))
                .ToList();

            var command = new ImportMtrCommand(
                inputs,
                AppInputType.ManualInput);

            if (!command.ValidationResult.IsValid)
                return BadRequest(
                    command
                        .ValidationResult
                        .Errors
                        .Select(failure => new
                        {
                            failure.ErrorCode,
                            failure.ErrorMessage
                        }));

            var (validationResult, mtrOutput) = await _mediator.Send(
                command,
                cancellationToken);

            if (!validationResult.IsValid)
                return BadRequest(
                    command
                        .ValidationResult
                        .Errors
                        .Select(failure => new
                        {
                            failure.ErrorCode,
                            failure.ErrorMessage
                        }));

            return new ImportMtrResponseViewModel
            {
                Added = mtrOutput
                    ?.Added
                    .Select(output => new ImportMtrItemResponseViewModel
                    {
                        RowVersion = output.RowVersion,
                        StartPeriod = output.StartPeriod,
                        Duration = output.EndPeriod,
                        CustomerId = output.CustomerId,
                        LocationId = output.LocationId,
                        MtrTypeId = output.MtrTypeId,
                        Value = output.Value,
                        Type = (ValueRecordEnum)Enum.Parse(typeof(ValueRecordEnum), output.Type.ToString())
                    }).ToList(),
                Updated = mtrOutput
                    ?.Updated
                    .Select(output => new ImportMtrItemResponseViewModel
                    {
                        RowVersion = output.RowVersion,
                        StartPeriod = output.StartPeriod,
                        Duration = output.EndPeriod,
                        CustomerId = output.CustomerId,
                        LocationId = output.LocationId,
                        MtrTypeId = output.MtrTypeId,
                        Value = output.Value,
                        Type = (ValueRecordEnum)Enum.Parse(typeof(ValueRecordEnum), output.Type.ToString())
                    }).ToList(),
                Removed = mtrOutput
                    ?.Removed
                    .Select(output => new ImportMtrItemResponseViewModel
                    {
                        RowVersion = output.RowVersion,
                        StartPeriod = output.StartPeriod,
                        Duration = output.EndPeriod,
                        CustomerId = output.CustomerId,
                        LocationId = output.LocationId,
                        MtrTypeId = output.MtrTypeId,
                        Value = output.Value,
                        Type = (ValueRecordEnum)Enum.Parse(typeof(ValueRecordEnum), output.Type.ToString())
                    }).ToList()
            };
        }

        /// <summary>
        /// Import graphs of customers, locations, mtr types.
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        [HttpPost("directories")]
        public async Task<ActionResult<ImportDirectoriesResponseViewModel>> ImportDirectories(
            [FromBody] ImportDirectoriesRequestViewModel request,
            CancellationToken cancellationToken)
        {
            var command = new ImportDirectoriesCommand(
                request
                    .Customers
                    ?.Select(_ => new ImportDirectoriesCustomerInput(
                        _.Id,
                        _.RowVersion,
                        Enumeration.IsDefined<AppCustomerType>(_.Type.ToString())
                            ? Enumeration.FromDisplayName<AppCustomerType>(_.Type.ToString())!
                            : AppCustomerType.Default,
                        _.Title!,
                        _.Description,
                        _.IsObsolete)),
                request
                    .CustomersEdges
                    ?.Select(_ => new ImportDirectoriesCustomerEdgeInput(
                        _.SourceId,
                        _.DestinationId,
                        _.IsObsolete)),
                request
                    .Locations
                    ?.Select(_ => new ImportDirectoriesLocationInput(
                        _.Id,
                        _.RowVersion,
                        Enumeration.IsDefined<AppLocationType>(_.Type.ToString())
                            ? Enumeration.FromDisplayName<AppLocationType>(_.Type.ToString())!
                            : AppLocationType.Default,
                        _.Title,
                        _.Description,
                        _.Longitude,
                        _.Latitude,
                        _.Diameter,
                        _.IsObsolete)),
                request
                    .LocationsEdges
                    ?.Select(_ => new ImportDirectoriesLocationEdgeInput(
                        _.SourceId,
                        _.DestinationId,
                        _.IsObsolete)),
                request
                    .MtrTypes
                    ?.Select(_ => new ImportDirectoriesMtrTypeInput(
                        _.Id,
                        _.RowVersion,
                        _.Title!,
                        _.Description ?? string.Empty,
                        _.IsObsolete)),
                request
                    .CustomersEdges
                    ?.Select(_ => new ImportDirectoriesMtrTypeEdgeInput(
                        _.SourceId,
                        _.DestinationId,
                        _.IsObsolete))
                    .ToList());

            if (!command.ValidationResult.IsValid)
                return BadRequest(
                    command
                        .ValidationResult
                        .Errors
                        .Select(failure => new
                        {
                            failure.ErrorCode,
                            failure.ErrorMessage
                        }));

            var (validationResult, importDirectoriesOutput) = await _mediator.Send(
                command,
                cancellationToken);

            if (!validationResult.IsValid)
                return BadRequest(
                    command
                        .ValidationResult
                        .Errors
                        .Select(failure => new
                        {
                            failure.ErrorCode,
                            failure.ErrorMessage
                        }));

            return new ImportDirectoriesResponseViewModel
            {
                AddedCustomers = importDirectoriesOutput?.AddedCustomers.Select(_ => new ImportDirectoriesCustomerResponseViewModel()
                {
                    Id = _.Id,
                    RowVersion = _.RowVersion,
                    Status = Enum.Parse<StatusEnum>(_.Status.Name),
                    Type = Enum.Parse<CustomerTypeEnum>(_.Type.Name),
                    Title = _.Title,
                    Description = _.Description
                }).ToList(),
                UpdatedCustomers = importDirectoriesOutput?.UpdatedCustomers.Select(_ => new ImportDirectoriesCustomerResponseViewModel()
                {
                    Id = _.Id,
                    RowVersion = _.RowVersion,
                    Status = Enum.Parse<StatusEnum>(_.Status.Name),
                    Type = Enum.Parse<CustomerTypeEnum>(_.Type.Name),
                    Title = _.Title,
                    Description = _.Description
                }).ToList(),
                RemovedCustomersIds = importDirectoriesOutput?.RemovedCustomers.Select(_ => new ImportDirectoriesCustomerResponseViewModel()
                {
                    Id = _.Id,
                    RowVersion = _.RowVersion,
                    Status = Enum.Parse<StatusEnum>(_.Status.Name),
                    Type = Enum.Parse<CustomerTypeEnum>(_.Type.Name),
                    Title = _.Title,
                    Description = _.Description
                }).ToList(),
                AddedCustomersRelations = importDirectoriesOutput?.AddedCustomersRelations.Select(_ => new ImportDirectoriesEdgeResponseViewModel
                {
                    SourceId = _.SourceId,
                    DestinationId = _.DestinationId
                }).ToList(),
                RemovedCustomersRelations = importDirectoriesOutput?.RemovedCustomersRelations.Select(_ => new ImportDirectoriesEdgeResponseViewModel
                {
                    SourceId = _.SourceId,
                    DestinationId = _.DestinationId
                }).ToList(),
                AddedLocations = importDirectoriesOutput?.AddedLocations.Select(_ => new ImportDirectoriesLocationResponseViewModel
                {
                    Id = _.Id,
                    RowVersion = _.RowVersion,
                    Status = Enum.Parse<StatusEnum>(_.Status.Name),
                    Type = Enum.Parse<LocationTypeEnum>(_.Type.Name),
                    Title = _.Title,
                    Description = _.Description,
                    Longitude = _.Longitude,
                    Latitude = _.Latitude,
                    Diameter = _.Diameter
                }).ToList(),
                UpdatedLocations = importDirectoriesOutput?.UpdatedLocations.Select(_ => new ImportDirectoriesLocationResponseViewModel
                {
                    Id = _.Id,
                    RowVersion = _.RowVersion,
                    Status = Enum.Parse<StatusEnum>(_.Status.Name),
                    Type = Enum.Parse<LocationTypeEnum>(_.Type.Name),
                    Title = _.Title,
                    Description = _.Description,
                    Longitude = _.Longitude,
                    Latitude = _.Latitude,
                    Diameter = _.Diameter
                }).ToList(),
                RemovedLocations = importDirectoriesOutput?.RemovedLocations.Select(_ => new ImportDirectoriesLocationResponseViewModel
                {
                    Id = _.Id,
                    RowVersion = _.RowVersion,
                    Status = Enum.Parse<StatusEnum>(_.Status.Name),
                    Type = Enum.Parse<LocationTypeEnum>(_.Type.Name),
                    Title = _.Title,
                    Description = _.Description,
                    Longitude = _.Longitude,
                    Latitude = _.Latitude,
                    Diameter = _.Diameter
                }).ToList(),
                AddedLocationsRelations = importDirectoriesOutput?.AddedLocationsRelations.Select(_ => new ImportDirectoriesEdgeResponseViewModel
                {
                    SourceId = _.SourceId,
                    DestinationId = _.DestinationId
                }).ToList(),
                RemovedLocationsRelations = importDirectoriesOutput?.RemovedLocationsRelations.Select(_ => new ImportDirectoriesEdgeResponseViewModel
                {
                    SourceId = _.SourceId,
                    DestinationId = _.DestinationId
                }).ToList(),
                AddedMtrTypes = importDirectoriesOutput?.AddedMtrTypes.Select(_ => new ImportDirectoriesMtrTypeResponseViewModel
                {
                    Id = _.Id,
                    Status = Enum.Parse<StatusEnum>(_.Status.Name),
                    Title = _.Title
                }).ToList(),
                UpdatedMtrTypes = importDirectoriesOutput?.UpdatedMtrTypes.Select(_ => new ImportDirectoriesMtrTypeResponseViewModel
                {
                    Id = _.Id,
                    Status = Enum.Parse<StatusEnum>(_.Status.Name),
                    Title = _.Title
                }).ToList(),
                RemovedMtrTypes = importDirectoriesOutput?.RemovedMtrTypes.Select(_ => new ImportDirectoriesMtrTypeResponseViewModel
                {
                    Id = _.Id,
                    Status = Enum.Parse<StatusEnum>(_.Status.Name),
                    Title = _.Title
                }).ToList(),
                AddedMtrTypesRelations = importDirectoriesOutput?.AddedMtrTypesRelations.Select(_ => new ImportDirectoriesEdgeResponseViewModel
                {
                    SourceId = _.SourceId,
                    DestinationId = _.DestinationId
                }).ToList(),
                RemovedMtrTypesRelations = importDirectoriesOutput?.RemovedMtrTypesRelations.Select(_ => new ImportDirectoriesEdgeResponseViewModel
                {
                    SourceId = _.SourceId,
                    DestinationId = _.DestinationId
                }).ToList(),
            };
        }
    }
}