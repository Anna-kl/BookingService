﻿using FluentValidation;

using Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Input;

namespace Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Validator
{
    public sealed class ImportDirectoriesMtrTypeEdgeValidator
        : AbstractValidator<ImportDirectoriesMtrTypeEdgeInput>
    {
        public ImportDirectoriesMtrTypeEdgeValidator()
        {
            ValidateSourceId();
            ValidateDestinationId();
        }

        private void ValidateSourceId() =>
            RuleFor(_ => _.SourceId)
                .NotEmpty();

        private void ValidateDestinationId() =>
            RuleFor(_ => _.DestinationId)
                .NotEmpty();
    }
}
