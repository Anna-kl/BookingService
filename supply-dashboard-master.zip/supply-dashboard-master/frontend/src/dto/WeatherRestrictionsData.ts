export interface IWeatherRestrictionsRequest {
    startDate: string;
    endDate: string;
    locationIds?: string[];
    customerIds?: string[];
}

export interface IWeatherRestrictionsResponse {
    items: IWeatherRestrictionsItemResponse[];
}

export interface IWeatherRestrictionsItemResponse {
    id: string;
    aktirovka: string;
    customerId: string;
    dateTime: Date;
    locationId: string;
    locationTitle: string;
    locationLatitude: number;
    locationLongitude: number;
    temperature: number;
    windSpeed: number;
}

export interface IWeatherRestrictionsWorkboardData {
    id: string;
    aktirovka: string;
    locationTitle: string;
    locationLatitude: number;
    locationLongitude: number;
    temperature: number;
    windSpeed: number;
}