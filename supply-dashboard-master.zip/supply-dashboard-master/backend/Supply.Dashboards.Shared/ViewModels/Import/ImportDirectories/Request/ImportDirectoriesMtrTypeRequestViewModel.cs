﻿using System;

namespace Supply.Dashboards.Shared.ViewModels.Import.ImportDirectories.Request
{
    public sealed class ImportDirectoriesMtrTypeRequestViewModel
    {
        public Guid Id { get; set; }
        public uint RowVersion { get; set; }
        public string? Title { get; set; }
        public string? Description { get; set; }

        public bool? IsObsolete { get; set; }
    }
}
