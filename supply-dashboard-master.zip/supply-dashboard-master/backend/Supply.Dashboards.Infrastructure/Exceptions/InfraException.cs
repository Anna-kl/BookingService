﻿using System;

namespace Supply.Dashboards.Infrastructure.Exceptions
{
    public sealed class InfraException : Exception
    {
        public InfraException(string message)
            : base(message)
        {
        }

        public InfraException(
            string message,
            Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
