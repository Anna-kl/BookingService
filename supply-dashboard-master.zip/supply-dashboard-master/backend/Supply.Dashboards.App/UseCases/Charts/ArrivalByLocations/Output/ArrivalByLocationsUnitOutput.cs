﻿using Supply.Dashboards.App.UseCases.Charts.ArrivalByLocations.Types;

namespace Supply.Dashboards.App.UseCases.Charts.ArrivalByLocations.Output
{
    public sealed class ArrivalByLocationsUnitOutput
    {
        public ArrivalByLocationsUnitOutput(
            ArrivalType type,
            double value)
        {
            Type = type;
            Value = value;
        }

        public ArrivalType Type { get; }
        public double Value { get; }
    }
}
