﻿using FluentValidation;

namespace Supply.Dashboards.App.UseCases.MtrTypes.GetMtrTypeList.Input
{
    public sealed class GetMtrTypeListValidator
        : AbstractValidator<GetMtrTypeListQuery>
    {
        public GetMtrTypeListValidator()
        {
            ValidateStatuses();
            ValidateParentIds();
            ValidateIds();
        }

        private void ValidateStatuses() =>
            RuleForEach(_ => _.Statuses)
                .Must(_ => _.Id != 0); // TODO add description

        private void ValidateParentIds() =>
            RuleForEach(_ => _.SourceIds);

        private void ValidateIds() =>
            RuleForEach(_ => _.Ids)
                .Must(_ => _ != default);
    }
}
