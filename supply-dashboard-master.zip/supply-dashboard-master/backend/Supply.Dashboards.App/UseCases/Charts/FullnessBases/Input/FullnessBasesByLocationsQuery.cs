﻿using Common.SeedWork;

using FluentValidation.Results;

using MediatR;

using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.Charts.FullnessBases.Output;

using System;
using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.Charts.FullnessBases.Input
{
    public sealed class FullnessBasesByLocationsQuery
        : IRequest<(ValidationResult validationResult, FullnessBasesByLocationsOutput? output)>
    {
        public FullnessBasesByLocationsQuery(
            AppLocationType? locationType,
            DateTime startPeriod,
            DateTime endPeriod,
            Guid? parentLocationId,
            List<Guid>? locationsIds,
            List<Guid>? customersIds,
            List<Guid>? mtrTypesIds)
        {
            LocationType = locationType;

            StartPeriod = startPeriod;
            EndPeriod = endPeriod;

            ParentLocationId = parentLocationId;
            LocationsIds = locationsIds;
            CustomersIds = customersIds;
            MtrTypesIds = mtrTypesIds;

            ValidationResult = new FullnessBasesByLocationsValidator()
                .Validate(this);
        }

        public AppLocationType? LocationType { get; }
        public DateTime StartPeriod { get; }
        public DateTime EndPeriod { get; }

        public Guid? ParentLocationId { get; set; }
        public List<Guid>? LocationsIds { get; }

        public List<Guid>? CustomersIds { get; }

        public List<Guid>? MtrTypesIds { get; }

        public ValidationResult ValidationResult { get; }
    }
}
