﻿using Common.SeedWork;

using Supply.Dashboards.App.Exceptions;
using Supply.Dashboards.Domain.Types;

namespace Supply.Dashboards.App.UseCases.Charts.FullnessBases.Types
{
    public sealed class FullnessBasesType : Enumeration
    {
        public static FullnessBasesType FullnessBasesTotalSquare = new(801, "FullnessBasesTotalSquare");
        public static FullnessBasesType FullnessBasesLoaded = new(802, "FullnessBasesLoaded");
        public static FullnessBasesType FullnessBasesLoadedRubles = new(803, "FullnessBasesLoadedRubles");
        public static FullnessBasesType FullnessBasesLoadedWeight = new(804, "FullnessBasesLoadedWeight");

        public FullnessBasesType(int id, string name) : base(id, name)
        {
        }

        internal static FullnessBasesType GetFullnessBasesType(ValueRecordType type)
        {
            var name = type.Name switch
            {
                nameof(ValueRecordType.FullnessBasesTotalSquare) => FullnessBasesTotalSquare.Name,
                nameof(ValueRecordType.FullnessBasesLoaded) => FullnessBasesLoaded.Name,
                nameof(ValueRecordType.FullnessBasesLoadedRubles) => FullnessBasesLoadedRubles.Name,
                nameof(ValueRecordType.FullnessBasesLoadedWeight) => FullnessBasesLoadedWeight.Name,

                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<FullnessBasesType>(name)!;
        }
    }
}
