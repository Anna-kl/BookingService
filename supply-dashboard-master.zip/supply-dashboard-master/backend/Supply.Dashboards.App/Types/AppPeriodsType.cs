﻿using Common.SeedWork;

namespace Supply.Dashboards.App.Types
{
    public sealed class AppPeriodsType : Enumeration
    {
        public static AppPeriodsType Default = new(0, "Default");
        public static AppPeriodsType Day = new(1, "Day");
        public static AppPeriodsType Week = new(2, "Week");
        public static AppPeriodsType TwoWeeks = new(3, "TwoWeeks");
        public static AppPeriodsType Month = new(4, "Month");
        public static AppPeriodsType Quarter = new(5, "Quarter");
        public static AppPeriodsType HalfYear = new(6, "HalfYear");
        public static AppPeriodsType Year = new(7, "Year");

        public AppPeriodsType(int id, string name) : base(id, name)
        {
        }
    }
}
