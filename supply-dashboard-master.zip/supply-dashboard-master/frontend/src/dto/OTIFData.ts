
export interface IOTIFDataResponse {
    otif: number;
    notOtif: number;
}

export interface IOTIFDataRequest {
    startPeriod: string;
    endPeriod: string;
    locationsIds?: string[] | null;
    customersIds?: string[] | null;
    mtrTypesIds?: string[] | null;

}

export interface IOTIFChartData {
    value: string;
    percent: number;
}