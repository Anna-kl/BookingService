﻿using System;

namespace Supply.Dashboards.Shared.ViewModels.Charts.HseIndicators
{
    public sealed class HseIndicatorIncidentResponseViewModel
    {
        public DateTime DateTime { get; set; }
        public HseIndicatorEnum Type { get; set; }
        public string Text { get; set; } = string.Empty;
    }
}
