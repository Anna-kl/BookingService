﻿using FluentValidation;

using Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Input;

namespace Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Validator
{
    public sealed class ImportDirectoriesMtrTypeValidator
        : AbstractValidator<ImportDirectoriesMtrTypeInput>
    {
        public ImportDirectoriesMtrTypeValidator()
        {
            ValidateId();
            ValidateTitle();
        }

        private void ValidateId() =>
            RuleFor(_ => _.Id)
                .Must(_ => _ != default); // TODO add description

        private void ValidateTitle() =>
            RuleFor(_ => _.Title)
                .NotEmpty();
    }
}
