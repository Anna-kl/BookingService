﻿using Common.SeedWork;

using Supply.Dashboards.App.Exceptions;
using Supply.Dashboards.Domain.Types;

namespace Supply.Dashboards.App.UseCases.Charts.HseIndicators.Types
{
    public sealed class HseIndicatorType : Enumeration
    {
#pragma warning disable CA2211 // Non-constant fields should not be visible
        public static HseIndicatorType Default = new(0, "Default");
        public static HseIndicatorType Death = new(1, "Death");
        public static HseIndicatorType Disability = new(2, "Disability");
        public static HseIndicatorType MedicalCare = new(3, "MedicalCare");
        public static HseIndicatorType NearMiss = new(4, "NearMiss");
        public static HseIndicatorType DangerWarning = new(5, "DangerWarning");
#pragma warning restore CA2211 // Non-constant fields should not be visible

        public HseIndicatorType(int id, string name) : base(id, name)
        {
        }

        internal static HseIncidentType GetValueRecordType(HseIndicatorType type)
        {
            var name = type.Name switch
            {
                nameof(Default) => throw new AppException(nameof(Default)),
                nameof(Death) => HseIncidentType.Death.Name,
                nameof(Disability) => HseIncidentType.Disability.Name,
                nameof(MedicalCare) => HseIncidentType.MedicalCare.Name,
                nameof(NearMiss) => HseIncidentType.NearMiss.Name,
                nameof(DangerWarning) => HseIncidentType.DangerWarning.Name,

                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<HseIncidentType>(name)!;
        }

        internal static HseIndicatorType GetHseIndicatorType(HseIncidentType type)
        {
            var name = type.Name switch
            {
                nameof(HseIncidentType.Death) => Death.Name,
                nameof(HseIncidentType.Disability) => Disability.Name,
                nameof(HseIncidentType.MedicalCare) => MedicalCare.Name,
                nameof(HseIncidentType.NearMiss) => NearMiss.Name,
                nameof(HseIncidentType.DangerWarning) => DangerWarning.Name,

                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<HseIndicatorType>(name)!;
        }
    }
}
