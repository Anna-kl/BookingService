﻿using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Charts.HseIndicators
{
    public sealed class HseIndicatorsRequestViewModel
    {
        public DateTime StartPeriod { get; set; }
        public DateTime? EndPeriod { get; set; }

        public List<HseIndicatorEnum> LastIncidentTypes { get; set; } = new();
        public List<Guid>? LocationsIds { get; set; }
        public List<Guid>? CustomersIds { get; set; }
    }
}
