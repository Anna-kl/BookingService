<template>
  <div class="module-inner-container">
    <DxToolbar>
      <DxItem
        widget="dxButton"
        location="after"
        :options="prevButtonOptions"
        v-if="!isDayChart"
      />
      <DxItem location="after" :text="periodText()" v-if="!isDayChart" />
      <DxItem
        widget="dxButton"
        location="after"
        :options="nextButtonOptions"
        v-if="!isDayChart"
      />
    </DxToolbar>
    <div class="title">Показатели HSE</div>
    <div class="row">
      <div class="events">
        <!-- //todo пока отключено, нет инфы что делать
          <div class="lastEvent">
          <p>
            <b>Последнее происшествие.</b> Категория:
            <span class="important">{{ lastIncident.category }}</span>
          </p>
          <p>
            {{ lastIncident.text }}
            <a href="./news">Подробнее</a>
          </p>
        </div> -->
        <div class="diagram">
          <div class="step" v-for="item in dataSource" :key="item.description">
            <div class="zone">{{ item.count }}</div>
            <div class="description" :title="item.description">
              {{ item.description }}
            </div>
          </div>
        </div>
      </div>
      <div class="days-WO-incidents">
        <div class="circle">{{ notIncidentsDays }}</div>
        <div class="circle-title">дней без происшествий</div>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from "vue-property-decorator";
import config from "@/config";
import Chart from "./chart";
import { ChartDataService } from "@/services/chartDataService";
import {
  IHSEChartData,
  IHSEDataRequest,
  IHSEDataResponse,
  IHSELastIncident,
} from "@/dto/HSEData";
import { ChartPeriodEnum, IModuleConfig } from "@/dto/Dashboards";
import { MtrItemTypeEnum } from "@/dto/InputData";
import DxToolbar, { DxItem } from "devextreme-vue/toolbar";
import {
  addMonth,
  getDuration,
  getMonthEnd,
  getMonthStart,
  getYearEnd,
  getYearStart,
  roundDate,
  yesterdayDate,
} from "@/helpers";

@Component({
  components: {
    DxToolbar,
    DxItem,
  },
})
export default class HSEValues extends Chart {
  @Prop({ type: Object, required: false }) public config!: IModuleConfig;

  private lastIncident = { category: "", text: "", dateTime: "" };
  private notIncidentsDays = 0;
  private url = config.remoteHost + "/api/dashboards/hse-indicators";
  private curDate: Date = yesterdayDate();
  private isDayChart: boolean = this.config?.period === ChartPeriodEnum.Day;

  private dataSource: IHSEChartData[] = [];
  private descriptions = [
    {
      name: "Смертельные случаи",
      type: MtrItemTypeEnum.HseDeath,
    },
    {
      name: "+ НС с ВПТ",
      type: MtrItemTypeEnum.HseDisability,
    },
    {
      name: "+ МП на производстве и ПП",
      type: MtrItemTypeEnum.HseMedicalCare,
    },
    {
      name: "Пбп + ДТП + Алког + Аварии, Пожары",
      type: MtrItemTypeEnum.HseNearMiss,
    },
    {
      name: "Опасные Действия + Опасные Условия",
      type: MtrItemTypeEnum.HseDangerWarning,
    },
  ];

  private _chartDataService!: ChartDataService;

  private created() {
    this._chartDataService = new ChartDataService();
  }

  public update() {
    this.getData(this.curDate);
  }

  private mounted(): void {
    this.getData(this.curDate);
  }

  private async getData(curDate: Date) {
    let startPeriod: string;
    let endPeriod: string;

    switch (this.config?.period) {
      case ChartPeriodEnum.Year:
        startPeriod = getYearStart(this.curDate);
        endPeriod = getYearEnd(this.curDate);
        break;
      case ChartPeriodEnum.Day:
        startPeriod = getMonthStart(this.curDate);
        endPeriod = this.curDate.toISOString();
        break;
      case ChartPeriodEnum.Month:
      default:
        startPeriod = getMonthStart(this.curDate);
        endPeriod = getMonthEnd(this.curDate);
        break;
    }
    const request: IHSEDataRequest = {
      startPeriod: startPeriod,
      endPeriod: endPeriod,
      locationsIds:
        this.config.locationsIds !== undefined
          ? this.config.locationsIds
              ?.filter((f) => f.selected)
              .map<string>((s) => s.dbId)
          : [],
      customersIds: this.config.customersIds || [],
      mtrTypesIds: this.config.mtrTypesIds || [],
    };

    const data = await this._chartDataService
      .getHSEData(this.url, request)
      .then((data) => {
        const response = data as IHSEDataResponse;
        if (response) {
          if (response.lastIncident !== null) {
            this.lastIncident = {
              dateTime: response.lastIncident.dateTime,
              category:
                this.descriptions.find(
                  (s) => MtrItemTypeEnum[s.type] === response.lastIncident.type
                )?.name || "",
              text: response.lastIncident.text,
            };
          } else {
            this.lastIncident = { category: "", text: "", dateTime: "" };
          }
          this.dataSource = response.units.map<IHSEChartData>((s) => {
            return {
              description:
                this.descriptions.find(
                  (d) =>
                    MtrItemTypeEnum[d.type].toLowerCase() ===
                    s.type.toLowerCase()
                )?.name || "",
              count: s.count,
            };
          });
          this.notIncidentsDays = response.daysWithoutIncident;
        }
      });
  }

  private formatLabel(arg: any) {
    if (arg.value !== 1) {
      return `<span class="label">${arg.item.data.count}</span>`;
    } else {
      return null;
    }
  }

  private customizeTooltip(arg: any) {
    return {
      text: `${arg.item.data.description}`,
    };
  }

  private prevButtonOptions = {
    icon: "arrowleft",
    hint: "Предыдущий период",
    onClick: () => this.prevPeriod(),
  };

  private nextButtonOptions = {
    icon: "arrowright",
    hint: "Следующий период",
    onClick: () => this.nextPeriod(),
  };
  private prevPeriod() {
    switch (this.config?.period) {
      case ChartPeriodEnum.Year:
        this.curDate.setFullYear(this.curDate.getFullYear() - 1);
        break;
      case ChartPeriodEnum.Month:
      default:
        this.curDate = addMonth(this.curDate, -1);
        break;
    }
    this.getData(this.curDate);
  }

  private nextPeriod() {
    switch (this.config?.period) {
      case ChartPeriodEnum.Year:
        this.curDate.setFullYear(this.curDate.getFullYear() + 1);
        break;
      case ChartPeriodEnum.Month:
      default:
        this.curDate = addMonth(this.curDate, 1);
        break;
    }
    this.getData(this.curDate);
  }

  private periodText() {
    let result: string;
    switch (this.config?.period) {
      case ChartPeriodEnum.Month:
        result = `${this.curDate.toLocaleString("ru", {
          month: "long",
        })} ${this.curDate.getFullYear()}`;
        break;
      case ChartPeriodEnum.Year:
      default:
        result = this.curDate.getFullYear().toString();
        break;
    }
    return result;
  }
}
</script>
<style lang="scss">
$radius: 2em;

.title {
  white-space: pre;
  font-size: 28px;
  font-family: "Segoe UI Light", "Helvetica Neue Light", "Segoe UI",
    "Helvetica Neue", "Trebuchet MS", Verdana, sans-serif;
  font-weight: 200;
  fill: #fff;
  cursor: default;
}

.events {
  @media screen and (min-width: 767px) {
    float: left;
    width: 69%;
    border-right: 1px white solid;
  }

  .diagram {
    .step {
      height: 43px;
      text-overflow: ellipsis;
      white-space: nowrap;
      overflow: hidden;

      .zone {
        border-left: 9px solid transparent;
        border-right: 9px solid transparent;
        height: 0;
        line-height: 40px;
        margin-bottom: 3px;
        text-align: center;
        display: inline-block;
        font-size: 1.5em;
        font-weight: bold;
      }

      .description {
        display: inline;
      }
    }
  }

  @each $zone, $color in (1, #db3b26), (2, #e3782e), (3, #f3b03e), (4, #a5f66a),
    (5, #54ad32)
  {
    .step:nth-of-type(#{$zone}) {
      .zone {
        border-bottom: 40px solid $color;
        width: 30px * $zone - 10px * ($zone - 1);
        max-width: 110px;
        margin-left: 50px - 10px * $zone;
      }
    }
  }

  .important {
    color: #d2bb53;
    font-weight: bold;
  }
}

.days-WO-incidents {
  @media screen and (min-width: 767px) {
    width: 30%;
    display: inline-block;
  }
  text-align: -webkit-center;
  margin-top: 10%;

  .circle {
    width: $radius;
    height: $radius;
    text-align: center;
    border: 4px #42a2f8 solid;
    border-radius: 50%;
    line-height: $radius;
    font-size: 4em;
  }

  .circle-title {
    font-size: $radius - 0.7em;
    white-space: pre-wrap;
  }
}
</style>

<style scoped>
.dx-toolbar {
  background: none;
}
</style>