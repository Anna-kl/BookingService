﻿using FluentValidation;

namespace Supply.Dashboards.App.UseCases.Charts.TransportResources.Input
{
    public sealed class TransportResourcesByPeriodsValidator
        : AbstractValidator<TransportResourcesByPeriodsQuery>
    {
        public TransportResourcesByPeriodsValidator()
        {
            ValidateLocationType();
            ValidateStartPeriod();
            ValidateEndPeriod();
            ValidateCustomersIds();
            ValidateLocationsIds();
        }

        private void ValidateLocationType() =>
            RuleFor(_ => _.PeriodType)
                .NotEmpty()
                .Must(_ => _.Id != 0); // TODO add description

        private void ValidateStartPeriod() =>
            RuleFor(_ => _.StartPeriod)
                .NotEmpty();

        private void ValidateEndPeriod() =>
            RuleFor(_ => _.EndPeriod)
                .NotEmpty();

        private void ValidateCustomersIds() =>
            RuleForEach(_ => _.CustomersIds);

        private void ValidateLocationsIds() =>
            RuleForEach(_ => _.LocationsIds);
    }
}
