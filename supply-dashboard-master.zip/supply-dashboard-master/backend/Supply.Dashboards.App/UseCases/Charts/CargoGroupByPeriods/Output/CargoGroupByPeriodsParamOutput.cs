﻿using System;

namespace Supply.Dashboards.App.UseCases.Charts.CargoGroupByPeriods.Output
{
    public sealed class CargoGroupByPeriodsParamOutput
    {
        internal CargoGroupByPeriodsParamOutput(
            DateTime period,
            CargoGroupByPeriodsUnitOutput? fact,
            CargoGroupByPeriodsUnitOutput? plan,
            CargoGroupByPeriodsUnitOutput? adjustedPlan,
            CargoGroupByPeriodsUnitOutput? dailyPlan)
        {
            Period = period;
            Fact = fact;
            Plan = plan;
            AdjustedPlan = adjustedPlan;
            DailyPlan = dailyPlan;
        }

        public DateTime Period { get; }

        public CargoGroupByPeriodsUnitOutput? Fact { get; private set; }
        public CargoGroupByPeriodsUnitOutput? Plan { get; private set; }
        public CargoGroupByPeriodsUnitOutput? AdjustedPlan { get; private set; }
        public CargoGroupByPeriodsUnitOutput? DailyPlan { get; private set; }

        public void ReplaceFactUnit(CargoGroupByPeriodsUnitOutput fact) => Fact = fact;
        public void ReplacePlanUnit(CargoGroupByPeriodsUnitOutput plan) => Plan = plan;
        public void ReplaceAdjustedPlanUnit(CargoGroupByPeriodsUnitOutput adjustedPlan) => AdjustedPlan = adjustedPlan;
        public void ReplaceDailyPlanUnit(CargoGroupByPeriodsUnitOutput dailyPlan) => DailyPlan = dailyPlan;
    }
}
