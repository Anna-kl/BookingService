﻿using Common.SeedWork;

namespace Supply.Dashboards.Domain.Types
{
    // TODO change types
    public sealed class LogisticNotificationsType : Enumeration
    {
        public static LogisticNotificationsType Active = new(1, "Active");
        public static LogisticNotificationsType Disable = new(2, "Disable");
        public static LogisticNotificationsType Archived = new(3, "Archived");

        public LogisticNotificationsType(int id, string name) : base(id, name)
        {
        }
    }
}
