﻿using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Charts.ExecutionOfOrders
{
    public sealed class ExecutionOfOrdersChartResponseViewModel
    {
        public DateTime Date { get; set; }
        public int Forecast { get; set; }
        public int Plan { get; set; }
        public int? TotalFact { get; set; }
    }
}
