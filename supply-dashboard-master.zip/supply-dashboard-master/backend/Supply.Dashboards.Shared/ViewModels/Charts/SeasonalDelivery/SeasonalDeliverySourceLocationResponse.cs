﻿using System;

namespace Supply.Dashboards.Shared.ViewModels.Charts.SeasonalDelivery
{
    public sealed class SeasonalDeliverySourceLocationResponse
    {
        public Guid Id { get; set; } = Guid.Empty;
        public string Title { get; set; } = string.Empty;
    }
}
