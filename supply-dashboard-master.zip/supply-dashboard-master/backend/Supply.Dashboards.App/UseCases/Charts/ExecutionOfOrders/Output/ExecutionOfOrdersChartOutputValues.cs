﻿using System;

namespace Supply.Dashboards.App.UseCases.Charts.ExecutionOfOrders.Output
{
    public class ExecutionOfOrdersChartOutputValues
    {
        public DateTime Date { get; set; }
        public int Forecast { get; set; }
        public int Plan { get; set; }
        public int? TotalFact { get; set; }
    }
}
