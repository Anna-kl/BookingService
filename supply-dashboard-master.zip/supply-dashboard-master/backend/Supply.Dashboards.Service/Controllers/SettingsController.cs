﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.UserInfo;
using Supply.Dashboards.Service.Authentication;
using Supply.Dashboards.Service.Types;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.Service.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public sealed class SettingsController : ControllerBase
    {
        private readonly ILogger<SettingsController> _logger;
        private readonly IConfiguration _configuration;

        public SettingsController(ILogger<SettingsController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }

        [AllowAnonymous]
        [HttpGet]
        public async Task<ClientSettingsType> Get(CancellationToken cancellationToken)
        {
            var authentication = _configuration
                .GetSection("Authentication")
                .Get<AuthorityConfiguration>();
            var result = new ClientSettingsType()
            {
                AuthenticationHost = authentication.AuthorityUrl
            };
            return result;
        }
    }
}
