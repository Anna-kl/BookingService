import config from '@/config';
import { UserManager, WebStorageStateStore, User } from 'oidc-client';
import SettingsService from './settingsService';

export default class AuthService {
    private userManager: UserManager;

    constructor(settings?: any) {
        this.userManager = new UserManager(settings);
    }

    async init() {
        const clientSettings = await new SettingsService().getClientSettings();
        const settings: any = {
            userStore: new WebStorageStateStore({ store: window.localStorage }),
            authority: clientSettings.authenticationHost,
            client_id: 'js',
            response_type: 'id_token token',
            scope: 'openid profile api',
            filterProtocolClaims: true,
            loadUserInfo: true,
            automaticSilentRenew: true,
            revokeAccessTokenOnSignout: true,
            redirect_uri: `${config.applicationHost}callback.html`,
            silent_redirect_uri: `${config.applicationHost}silent-renew.html`,
            post_logout_redirect_uri: `${config.applicationHost}`
        };
        this.userManager = new UserManager(settings);
    }

    public getUser(): Promise<User | null> {
        return this.userManager.getUser();
    }

    public login(): Promise<void> {
        return this.userManager.signinRedirect();
    }

    public logout(): Promise<void> {
        return this.userManager.signoutRedirect();
    }

    public getAccessToken(): Promise<string> {
        return this.userManager.getUser().then((data: any) => {
            return data.access_token;
        });
    }
}
