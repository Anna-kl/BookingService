/**
 * Returns valid window.location.origin in IE11-.
 * @export
 * @returns {string}
 */
export function getLocationOrigin(): string {
    const location = window.location;
    let origin = location.origin;
    if (!origin) {
        origin = `${location.protocol}/${location.hostname}`;
        if (location.port) {
            origin += location.port;
        }
    }
    return origin;
}

/**
 * Returns application base url bases on BASE_URL from env.
 * @export
 * @returns {string}
 */
export function getBaseUrl(): string {
    const origin = getLocationOrigin();
    return `${origin}${process.env.BASE_URL}`;
}

export function getMonthStart(curDate?: Date): string {
    const date = curDate ?? new Date();

    return new Date(Date.UTC(
        date.getFullYear(),
        date.getMonth(),
        1,
        0,
        0,
        0
    )).toISOString();
}

export function getMonthEnd(curDate?: Date): string {
    const date = curDate ?? new Date();
    const result = new Date(Date.UTC(
        date.getFullYear(),
        date.getMonth() + 1,
        1,
        0,
        0,
        0
    ));
    result.setDate(result.getDate() - 1);

    return result.toISOString();
}

export function getYearStart(curDate?: Date): string {
    const date = curDate ?? new Date();
    return new Date(Date.UTC(
        date.getUTCFullYear(),
        0,
        1,
        0,
        0,
        0
    )).toISOString();
}

export function getYearEnd(curDate?: Date): string {
    const date = curDate ?? new Date();
    const result = new Date(Date.UTC(
        date.getUTCFullYear() + 1,
        0,
        1,
        0,
        0,
        0
    ));

    result.setDate(result.getDate() - 1);

    return result.toISOString();
}

export function getSeasonStart(): string {
    const curDate = new Date();
    const result = new Date(
        curDate.getFullYear(),
        6,
        1, 0, -curDate.getTimezoneOffset(), 0, 0);

    result.setDate(result.getDate() - 1);

    return result.toISOString();
}

export function getSeasonEnd(): string {
    const curDate = new Date();
    const result = new Date(
        curDate.getFullYear(),
        12,
        1, 0, -curDate.getTimezoneOffset(), 0, 0);

    result.setDate(result.getDate() - 1);

    return result.toISOString();
}

export function getShortMonth(month: number) {
    const shortMonthes = [
        "Янв",
        "Фев",
        "Мар",
        "Апр",
        "Май",
        "Июн",
        "Июл",
        "Авг",
        "Сен",
        "Окт",
        "Ноя",
        "Дек",
    ];
    return shortMonthes[month];
}

export function addMonth(date: Date, month: number) {
    return new Date(date.setMonth(date.getMonth() + month));
}

export function getNumberOfWeek(d: Date) {
    const firstJan = new Date(d.getFullYear(), 0, 1);
    const week = Math.ceil((((d.getTime() - firstJan.getTime()) / 86400000) + firstJan.getDay() + 1) / 7);
    return week;
}

export function getDateFromWeekNumber(w: number, y: number): Date {
    const d = (1 + (w - 1) * 7);

    return new Date(y, 0, d);
}

export function daysInMonth(month: number, year: number) {
    return new Date(year, month, 0).getDate();
}

export function getDuration(start: string, end: string): string {
    return ((new Date(addDurationToDate(end, 1)).valueOf() - new Date(start).valueOf()) / (60 * 60 * 24 * 1000)).toString();
}

export function roundDate(dateTime: Date): Date {
    const utc = Date.UTC(
        dateTime.getUTCFullYear(),
        dateTime.getUTCMonth(),
        dateTime.getUTCDate(),
        0,
        0,
        0
    );

    return new Date(utc);
}

export function addDurationToDate(dateTime: string, duration: number): Date {
    const date = new Date(dateTime);
    date.setDate(date.getDate() + duration);
    return date;
}

export function yesterdayDate(): Date {
    return roundDate(addDurationToDate(new Date().toString(), -1));
}

export function utcFromLocalDate(localDate: Date) {
    const utc = Date.UTC(
        localDate.getFullYear(),
        localDate.getMonth(),
        localDate.getDate(),
        0,
        0,
        0
    );
    return new Date(utc).toISOString();
}