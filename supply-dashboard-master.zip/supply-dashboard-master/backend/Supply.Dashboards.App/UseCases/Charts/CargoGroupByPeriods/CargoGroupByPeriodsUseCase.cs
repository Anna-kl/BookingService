﻿using Common.Extensions;

using FluentValidation.Results;

using MediatR;

using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.Charts.CargoGroupByPeriods.Input;
using Supply.Dashboards.App.UseCases.Charts.CargoGroupByPeriods.Output;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;
using Supply.Dashboards.Domain.AggregatesModel.ValueRecords;
using Supply.Dashboards.Domain.Types;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.Charts.CargoGroupByPeriods
{
    public sealed class CargoGroupByPeriodsUseCase
       : IRequestHandler<CargoGroupByPeriodsQuery, (ValidationResult validationResult, CargoGroupByPeriodsOutput? output)>
    {
        private readonly ILogger<CargoGroupByPeriodsUseCase> _logger;
        private readonly IMediator _mediator;
        private readonly ICargoGroupByPeriods _cargoGroupByPeriods;

        private List<Customer> _customers;
        private List<Location> _locations;
        private List<MtrType> _mtrTypes;
        private ValidationResult _validationResult;
        private readonly List<StatusType> _selectStatus;

        public CargoGroupByPeriodsUseCase(
            ILogger<CargoGroupByPeriodsUseCase> logger,
            IMediator mediator,
            ICargoGroupByPeriods cargoGroupByPeriods)
        {
            _logger = logger;
            _mediator = mediator;
            _cargoGroupByPeriods = cargoGroupByPeriods;

            _customers = new List<Customer>();
            _locations = new List<Location>();
            _mtrTypes = new List<MtrType>();
            _validationResult = new ValidationResult();
            _selectStatus = new List<StatusType> { StatusType.Active };
        }

        public async Task<(ValidationResult validationResult, CargoGroupByPeriodsOutput? output)> Handle(
            CargoGroupByPeriodsQuery request,
            CancellationToken cancellationToken)
        {
            _validationResult = request.ValidationResult;

            // If there are validation errors, abort the method and return errors.
            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            await Customers(request, cancellationToken);
            await Locations(request, cancellationToken);
            await MtrTypes(request, cancellationToken);

            // If there are validation errors, abort the method and return errors.
            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            var valueRecordTypes = new List<ValueRecordType>();

            if (request.DataType == AppDataType.CargoHandling)
                valueRecordTypes.AddRange(
                    new List<ValueRecordType>
                    {
                        ValueRecordType.CargoHandlingFact,
                        ValueRecordType.CargoHandlingPlan,
                        ValueRecordType.CargoHandlingAdjustedPlan,
                        ValueRecordType.CargoHandlingDailyPlan
                    });

            if (request.DataType == AppDataType.FreightTurnover)
                valueRecordTypes.AddRange(
                    new List<ValueRecordType>
                    {
                        ValueRecordType.FreightTurnoverFact,
                        ValueRecordType.FreightTurnoverPlan,
                        ValueRecordType.FreightTurnoverAdjustedPlan,
                        ValueRecordType.FreightTurnoverDailyPlan
                    });

            var (subset, superset, crossing) = await _cargoGroupByPeriods.GetRecords(
                valueRecordTypes,
                request.StartPeriod,
                request.EndPeriod,
                _locations,
                _customers,
                _mtrTypes,
                cancellationToken);

            var records = new List<ValueRecord>();
            records.AddRange(subset);
            records.AddRange(superset);
            records.AddRange(crossing);

            var fact =
                ToSequences(
                    records
                        .Where(_ => _.Payload.Type == ValueRecordType.CargoHandlingFact ||
                                    _.Payload.Type == ValueRecordType.FreightTurnoverFact)
                        .ToList(),
                    request.StartPeriod,
                    request.EndPeriod ?? DateTime.UtcNow);

            var plan =
                ToSequences(
                    records
                        .Where(_ => _.Payload.Type == ValueRecordType.CargoHandlingPlan ||
                                    _.Payload.Type == ValueRecordType.FreightTurnoverPlan)
                        .ToList(),
                    request.StartPeriod,
                    request.EndPeriod ?? DateTime.UtcNow);

            var adjustedPlanData =
                ToSequences(
                    records
                        .Where(_ => _.Payload.Type == ValueRecordType.CargoHandlingPlan ||
                                    _.Payload.Type == ValueRecordType.CargoHandlingAdjustedPlan ||
                                    _.Payload.Type == ValueRecordType.FreightTurnoverPlan ||
                                    _.Payload.Type == ValueRecordType.FreightTurnoverAdjustedPlan)
                        .ToList(),
                    request.StartPeriod,
                    request.EndPeriod ?? DateTime.UtcNow);

            List<ValueRecordPerDay> adjustedPlan = new();

            foreach (var groupingRecords in adjustedPlanData.GroupBy(_ => new { _.DateTime, _.Location }))
            {
                var recordTypePlan = request.DataType == AppDataType.CargoHandling
                    ? ValueRecordType.CargoHandlingPlan
                    : ValueRecordType.FreightTurnoverPlan;

                var recordTypeAdjustedPlan = request.DataType == AppDataType.CargoHandling
                    ? ValueRecordType.CargoHandlingAdjustedPlan
                    : ValueRecordType.FreightTurnoverAdjustedPlan;

                adjustedPlan.AddRange(groupingRecords.Any(_ => _.Type == recordTypeAdjustedPlan)
                    ? groupingRecords.Where(_ => _.Type == recordTypeAdjustedPlan)
                    : groupingRecords.Where(_ => _.Type == recordTypePlan));
            }

            var dailyPlan =
                ToSequences(
                    records
                        .Where(_ => _.Payload.Type == ValueRecordType.CargoHandlingDailyPlan ||
                                    _.Payload.Type == ValueRecordType.FreightTurnoverDailyPlan)
                        .ToList(),
                    request.StartPeriod,
                    request.EndPeriod ?? DateTime.UtcNow);

            var dict = new Dictionary<DateTime, CargoGroupByPeriodsParamOutput>();

            #region day || week

            if (request.PeriodType == AppPeriodsType.Day ||
                request.PeriodType == AppPeriodsType.Week)
            {
                var factDictionary = new Dictionary<DateTime, List<ValueRecordPerDay>>();
                var planDictionary = new Dictionary<DateTime, List<ValueRecordPerDay>>();
                var adjustedPlanDictionary = new Dictionary<DateTime, List<ValueRecordPerDay>>();
                var dailyPlanDictionary = new Dictionary<DateTime, List<ValueRecordPerDay>>();

                if (request.PeriodType == AppPeriodsType.Day)
                {
                    factDictionary = fact
                        .GroupBy(_ => _.DateTime.Date)
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                    planDictionary = plan
                        .GroupBy(_ => _.DateTime.Date)
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                    adjustedPlanDictionary = adjustedPlan
                        .GroupBy(_ => _.DateTime.Date)
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                    dailyPlanDictionary = dailyPlan
                        .GroupBy(_ => _.DateTime.Date)
                        .ToDictionary(_ => _.Key, _ => _.ToList());
                }

                if (request.PeriodType == AppPeriodsType.Week)
                {
                    factDictionary = fact
                        .GroupBy(_ => _.DateTime.Date.AddDays(-((int)_.DateTime.Date.DayOfWeek - 1)))
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                    planDictionary = plan
                        .GroupBy(_ => _.DateTime.Date.AddDays(-((int)_.DateTime.Date.DayOfWeek - 1)))
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                    adjustedPlanDictionary = adjustedPlan
                        .GroupBy(_ => _.DateTime.Date.AddDays(-((int)_.DateTime.Date.DayOfWeek - 1)))
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                    dailyPlanDictionary = dailyPlan
                        .GroupBy(_ => _.DateTime.Date.AddDays(-((int)_.DateTime.Date.DayOfWeek - 1)))
                        .ToDictionary(_ => _.Key, _ => _.ToList());
                }

                foreach (var (key, value) in factDictionary)
                {
                    if (dict.TryGetValue(key, out var cargoGroupingByLocationsOutput))
                    {
                        cargoGroupingByLocationsOutput.ReplaceFactUnit(
                            new CargoGroupByPeriodsUnitOutput(value.Sum(record => record.Value) ?? 0));
                    }
                    else
                    {
                        dict.TryAdd(
                            key,
                            new CargoGroupByPeriodsParamOutput(
                                key,
                                new CargoGroupByPeriodsUnitOutput(value.Sum(record => record.Value) ?? 0),
                                null,
                                null,
                                null));
                    }
                }

                foreach (var (key, value) in planDictionary)
                {
                    if (dict.TryGetValue(key, out var cargoGroupingByLocationsOutput))
                    {
                        cargoGroupingByLocationsOutput.ReplacePlanUnit(
                            new CargoGroupByPeriodsUnitOutput(value.Sum(record => record.Value) ?? 0));
                    }
                    else
                    {
                        dict.TryAdd(
                            key,
                            new CargoGroupByPeriodsParamOutput(
                                key,
                                null,
                                new CargoGroupByPeriodsUnitOutput(value.Sum(record => record.Value) ?? 0),
                                null,
                                null));
                    }
                }

                foreach (var (key, value) in adjustedPlanDictionary)
                {
                    if (dict.TryGetValue(key, out var cargoGroupingByLocationsOutput))
                    {
                        cargoGroupingByLocationsOutput.ReplaceAdjustedPlanUnit(
                            new CargoGroupByPeriodsUnitOutput(value.Sum(record => record.Value) ?? 0));
                    }
                    else
                    {
                        dict.TryAdd(
                            key,
                            new CargoGroupByPeriodsParamOutput(
                                key,
                                null,
                                null,
                                new CargoGroupByPeriodsUnitOutput(value.Sum(record => record.Value) ?? 0),
                                null));
                    }
                }

                foreach (var (key, value) in dailyPlanDictionary)
                {
                    if (dict.TryGetValue(key, out var cargoGroupingByLocationsOutput))
                    {
                        cargoGroupingByLocationsOutput.ReplaceDailyPlanUnit(
                            new CargoGroupByPeriodsUnitOutput(value.Sum(record => record.Value) ?? 0));
                    }
                    else
                    {
                        dict.TryAdd(
                            key,
                            new CargoGroupByPeriodsParamOutput(
                                key,
                                null,
                                null,
                                null,
                                new CargoGroupByPeriodsUnitOutput(value.Sum(record => record.Value) ?? 0)));
                    }
                }

                return (_validationResult, new CargoGroupByPeriodsOutput(dict.Values.ToList()));
            }

            #endregion

            #region month || year

            if (request.PeriodType == AppPeriodsType.TwoWeeks ||
                request.PeriodType == AppPeriodsType.Month ||
                request.PeriodType == AppPeriodsType.Quarter ||
                request.PeriodType == AppPeriodsType.HalfYear ||
                request.PeriodType == AppPeriodsType.Year)
            {
                var factDictionary = new Dictionary<(int month, int year), List<ValueRecordPerDay>>();
                var planDictionary = new Dictionary<(int month, int year), List<ValueRecordPerDay>>();
                var adjustedPlanDictionary = new Dictionary<(int month, int year), List<ValueRecordPerDay>>();
                var dailyPlanDictionary = new Dictionary<(int month, int year), List<ValueRecordPerDay>>();

                if (request.PeriodType == AppPeriodsType.TwoWeeks)
                {
                    throw new NotImplementedException();
                }

                if (request.PeriodType == AppPeriodsType.Month)
                {
                    factDictionary = fact
                        .GroupBy(_ => (_.DateTime.Month, _.DateTime.Year))
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                    planDictionary = plan
                        .GroupBy(_ => (_.DateTime.Month, _.DateTime.Year))
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                    adjustedPlanDictionary = adjustedPlan
                        .GroupBy(_ => (_.DateTime.Month, _.DateTime.Year))
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                    dailyPlanDictionary = dailyPlan
                        .GroupBy(_ => (_.DateTime.Month, _.DateTime.Year))
                        .ToDictionary(_ => _.Key, _ => _.ToList());
                }

                if (request.PeriodType == AppPeriodsType.Quarter)
                {
                    factDictionary = fact
                        .GroupBy(_ => (Month: (_.DateTime.Month - 1) / 3, _.DateTime.Year))
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                    planDictionary = plan
                        .GroupBy(_ => (Month: (_.DateTime.Month - 1) / 3, _.DateTime.Year))
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                    adjustedPlanDictionary = adjustedPlan
                        .GroupBy(_ => (Month: (_.DateTime.Month - 1) / 3, _.DateTime.Year))
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                    dailyPlanDictionary = dailyPlan
                        .GroupBy(_ => (Month: (_.DateTime.Month - 1) / 3, _.DateTime.Year))
                        .ToDictionary(_ => _.Key, _ => _.ToList());
                }

                if (request.PeriodType == AppPeriodsType.HalfYear)
                {
                    factDictionary = fact
                        .GroupBy(_ => (Month: (_.DateTime.Month - 1) / 6, _.DateTime.Year))
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                    planDictionary = plan
                        .GroupBy(_ => (Month: (_.DateTime.Month - 1) / 6, _.DateTime.Year))
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                    adjustedPlanDictionary = adjustedPlan
                        .GroupBy(_ => (Month: (_.DateTime.Month - 1) / 6, _.DateTime.Year))
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                    dailyPlanDictionary = dailyPlan
                        .GroupBy(_ => (Month: (_.DateTime.Month - 1) / 6, _.DateTime.Year))
                        .ToDictionary(_ => _.Key, _ => _.ToList());
                }

                if (request.PeriodType == AppPeriodsType.Year)
                {
                    factDictionary = fact
                        .GroupBy(_ => (1, _.DateTime.Year))
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                    planDictionary = plan
                        .GroupBy(_ => (1, _.DateTime.Year))
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                    adjustedPlanDictionary = adjustedPlan
                        .GroupBy(_ => (1, _.DateTime.Year))
                        .ToDictionary(_ => _.Key, _ => _.ToList());

                    dailyPlanDictionary = dailyPlan
                        .GroupBy(_ => (1, _.DateTime.Year))
                        .ToDictionary(_ => _.Key, _ => _.ToList());
                }

                foreach (var ((month, year), value) in factDictionary)
                {
                    var dateTime = DateTime.Parse($"{month}-{year}");

                    if (dict.TryGetValue(dateTime, out var cargoGroupingByLocationsOutput))
                    {
                        cargoGroupingByLocationsOutput.ReplaceFactUnit(
                            new CargoGroupByPeriodsUnitOutput(value.Sum(record => record.Value) ?? 0));
                    }
                    else
                    {
                        dict.TryAdd(
                            dateTime,
                            new CargoGroupByPeriodsParamOutput(
                                dateTime,
                                new CargoGroupByPeriodsUnitOutput(value.Sum(record => record.Value) ?? 0),
                                null,
                                null,
                                null));
                    }
                }

                foreach (var ((month, year), value) in planDictionary)
                {
                    var dateTime = DateTime.Parse($"{month}-{year}");

                    if (dict.TryGetValue(dateTime, out var cargoGroupingByLocationsOutput))
                    {
                        cargoGroupingByLocationsOutput.ReplacePlanUnit(
                            new CargoGroupByPeriodsUnitOutput(value.Sum(record => record.Value) ?? 0));
                    }
                    else
                    {
                        dict.TryAdd(
                            dateTime,
                            new CargoGroupByPeriodsParamOutput(
                                dateTime,
                                null,
                                new CargoGroupByPeriodsUnitOutput(value.Sum(record => record.Value) ?? 0),
                                null,
                                null));
                    }
                }

                foreach (var ((month, year), value) in adjustedPlanDictionary)
                {
                    var dateTime = DateTime.Parse($"{month}-{year}");

                    if (dict.TryGetValue(dateTime, out var cargoGroupingByLocationsOutput))
                    {
                        cargoGroupingByLocationsOutput.ReplaceAdjustedPlanUnit(
                            new CargoGroupByPeriodsUnitOutput(value.Sum(record => record.Value) ?? 0));
                    }
                    else
                    {
                        dict.TryAdd(
                            dateTime,
                            new CargoGroupByPeriodsParamOutput(
                                dateTime,
                                null,
                                null,
                                new CargoGroupByPeriodsUnitOutput(value.Sum(record => record.Value) ?? 0),
                                null));
                    }
                }

                foreach (var ((month, year), value) in dailyPlanDictionary)
                {
                    var dateTime = DateTime.Parse($"{month}-{year}");

                    if (dict.TryGetValue(dateTime, out var cargoGroupingByLocationsOutput))
                    {
                        cargoGroupingByLocationsOutput.ReplaceDailyPlanUnit(
                            new CargoGroupByPeriodsUnitOutput(value.Sum(record => record.Value) ?? 0));
                    }
                    else
                    {
                        dict.TryAdd(
                            dateTime,
                            new CargoGroupByPeriodsParamOutput(
                                dateTime,
                                null,
                                null,
                                null,
                                new CargoGroupByPeriodsUnitOutput(value.Sum(record => record.Value) ?? 0)));
                    }
                }

                return (_validationResult, new CargoGroupByPeriodsOutput(dict.Values.ToList()));
            }

            #endregion

            return (_validationResult, null);
        }

        private async Task Customers(
            CargoGroupByPeriodsQuery query,
            CancellationToken cancellationToken)
        {
            var existingIdsFromFilter = (await _cargoGroupByPeriods.GetCustomersExistingIds(
                _selectStatus,
                query.CustomersIds.ToList(),
                cancellationToken)).ToList();
            var nonExistentIdsFromFilter = query
                .CustomersIds
                .Except(existingIdsFromFilter)
                .ToList();

            if (nonExistentIdsFromFilter.Any())
            {
                foreach (var id in nonExistentIdsFromFilter)
                    _validationResult.Errors.Add(new ValidationFailure(
                        "CustomerId",
                        $"{nameof(Customer)} with id \"{id}\" is not exist."));

                return;
            }

            var allCustomers = (await _cargoGroupByPeriods.GetCustomers(
                _selectStatus,
                cancellationToken))
                .Where(_ => _.SourceEdges == null || !_.SourceEdges.Any())
                .SelectMany(_ => _.DepthFirstSearch(
                    edge => edge.Destination,
                    customer => customer.DestinationEdges,
                    _ => { }))
                .ToList();
            var allCustomersIds = allCustomers
                .Select(_ => _.InnerId)
                .ToList();
            var allCustomersEdges = (await _cargoGroupByPeriods.GetCustomersEdges(
                allCustomersIds,
                cancellationToken)).ToList();

            foreach (var customer in allCustomers)
            {
                var sourceIds = allCustomersEdges
                    .Where(_ => _.DestinationId == customer.Id)
                    .Select(_ => _.SourceId);
                var sourcesVertex = allCustomers.Where(_ => sourceIds.Contains(_.Id));
                customer.AddSourceEdges(sourcesVertex.Select(_ => new CustomerEdge(_, customer)));

                var destinationIds = allCustomersEdges
                    .Where(_ => _.SourceId == customer.Id)
                    .Select(_ => _.DestinationId);
                var destinationVertex = allCustomers.Where(_ => destinationIds.Contains(_.Id));
                customer.AddDestinationEdges(destinationVertex.Select(_ => new CustomerEdge(customer, _)));
            }

            if (!query.CustomersIds.Any())
            {
                _customers = allCustomers;
                return;
            }

            var customersFromFilter = new List<Customer>();

            foreach (var customer in allCustomers)
            {
                customer.DepthFirstSearch(
                    _ => _.Destination,
                    _ => _.DestinationEdges!,
                    _ =>
                    {
                        if (existingIdsFromFilter.Contains(_.InnerId))
                            customersFromFilter.Add(_);
                    });
            }

            var customers = new List<Customer>();

            foreach (var customer in customersFromFilter)
            {
                customers.AddRange(customer.DepthFirstSearch(
                    _ => _.Destination,
                    _ => _.DestinationEdges!,
                    _ => { }));
            }

            if (!customers.Any())
                customers = allCustomers;

            _customers = customers
                .Distinct()
                .ToList();
        }

        private async Task Locations(
            CargoGroupByPeriodsQuery query,
           CancellationToken cancellationToken)
        {
            var existingIdsFromFilter = (await _cargoGroupByPeriods.GetLocationsExistingIds(
                _selectStatus,
                query.LocationsIds.ToList(),
                cancellationToken)).ToList();
            var nonExistentIdsFromFilter = query
                .LocationsIds
                .Except(existingIdsFromFilter)
                .ToList();

            if (nonExistentIdsFromFilter.Any())
            {
                foreach (var id in nonExistentIdsFromFilter)
                    _validationResult.Errors.Add(new ValidationFailure(
                        "LocationId",
                        $"{nameof(Location)} with id \"{id}\" is not exist."));

                return;
            }

            var allLocations = (await _cargoGroupByPeriods.GetLocations(
                _selectStatus,
                cancellationToken))
                .Where(_ => _.SourceEdges == null || !_.SourceEdges.Any())
                .SelectMany(_ => _.DepthFirstSearch(
                    edge => edge.Destination,
                    location => location.DestinationEdges,
                    _ => { }))
                .ToList();

            var allLocationsIds = allLocations
                .Select(_ => _.InnerId)
                .ToList();
            var allLocationsEdges = (await _cargoGroupByPeriods.GetLocationsEdges(
                allLocationsIds,
                cancellationToken)).ToList();

            foreach (var location in allLocations)
            {
                var sourceIds = allLocationsEdges
                    .Where(_ => _.DestinationId == location.Id)
                    .Select(_ => _.SourceId);
                var sourcesVertex = allLocations.Where(_ => sourceIds.Contains(_.Id));
                location.AddSourceEdges(sourcesVertex.Select(_ => new LocationEdge(_, location)));

                var destinationIds = allLocationsEdges
                    .Where(_ => _.SourceId == location.Id)
                    .Select(_ => _.DestinationId);
                var destinationVertex = allLocations.Where(_ => destinationIds.Contains(_.Id));
                location.AddDestinationEdges(destinationVertex.Select(_ => new LocationEdge(location, _)));
            }

            if (!query.LocationsIds.Any())
            {
                _locations = allLocations;
                return;
            }

            var locationsFromFilter = new List<Location>();

            foreach (var location in allLocations)
            {
                location.DepthFirstSearch(
                    _ => _.Destination,
                    _ => _.DestinationEdges!,
                    _ =>
                    {
                        if (existingIdsFromFilter.Contains(_.InnerId))
                            locationsFromFilter.Add(_);
                    });
            }

            var locations = new List<Location>();

            foreach (var location in locationsFromFilter)
            {
                locations.AddRange(location.DepthFirstSearch(
                    _ => _.Destination,
                    _ => _.DestinationEdges!,
                    _ => { }));
            }

            if (!locations.Any())
                locations = allLocations;

            _locations = locations
                .Distinct()
                .ToList();
        }

        private async Task MtrTypes(
            CargoGroupByPeriodsQuery query,
            CancellationToken cancellationToken)
        {
            var existingIdsFromFilter = (await _cargoGroupByPeriods.GetMtrTypesExistingIds(
                _selectStatus,
                query.MtrTypesIds.ToList(),
                cancellationToken)).ToList();
            var nonExistentIdsFromFilter = query
                .MtrTypesIds
                .Except(existingIdsFromFilter)
                .ToList();

            if (nonExistentIdsFromFilter.Any())
            {
                foreach (var id in nonExistentIdsFromFilter)
                    _validationResult.Errors.Add(new ValidationFailure(
                        "MtrTypeId",
                        $"{nameof(MtrType)} with id \"{id}\" is not exist."));

                return;
            }

            var allMtrTypes = (await _cargoGroupByPeriods.GetMtrTypes(
                _selectStatus,
                cancellationToken))
                .Where(_ => _.SourceEdges == null || !_.SourceEdges.Any())
                .SelectMany(_ => _.DepthFirstSearch(
                    edge => edge.Destination,
                    mtrType => mtrType.DestinationEdges,
                    _ => { }))
                .ToList();
            var allMtrTypesIds = allMtrTypes
                .Select(_ => _.InnerId)
                .ToList();
            var allMtrTypesEdges = (await _cargoGroupByPeriods.GetMtrTypesEdges(
                allMtrTypesIds,
                cancellationToken)).ToList();

            foreach (var mtrType in allMtrTypes)
            {
                var sourceIds = allMtrTypesEdges
                    .Where(_ => _.DestinationId == mtrType.Id)
                    .Select(_ => _.SourceId);
                var sourcesVertex = allMtrTypes
                    .Where(_ => sourceIds.Contains(_.Id))
                    .ToList();
                mtrType.AddSourceEdges(sourcesVertex.Select(_ => new MtrTypeEdge(_, mtrType)));

                var destinationIds = allMtrTypesEdges
                    .Where(_ => _.SourceId == mtrType.Id)
                    .Select(_ => _.DestinationId);
                var destinationVertex = sourcesVertex.Where(_ => destinationIds.Contains(_.Id));
                mtrType.AddDestinationEdges(destinationVertex.Select(_ => new MtrTypeEdge(mtrType, _)));
            }

            if (!query.MtrTypesIds.Any())
            {
                _mtrTypes = allMtrTypes;
                return;
            }

            var mtrTypesFromFilter = new List<MtrType>();

            foreach (var mtrType in allMtrTypes)
            {
                mtrType.DepthFirstSearch(
                    _ => _.Destination,
                    _ => _.DestinationEdges!,
                    _ =>
                    {
                        if (existingIdsFromFilter.Contains(_.InnerId))
                            mtrTypesFromFilter.Add(_);
                    });
            }

            var mtrTypes = new List<MtrType>();

            foreach (var location in mtrTypesFromFilter)
            {
                mtrTypes.AddRange(location.DepthFirstSearch(
                    _ => _.Destination,
                    _ => _.DestinationEdges!,
                    _ => { }));
            }

            if (!mtrTypes.Any())
                mtrTypes = allMtrTypes;

            _mtrTypes = mtrTypes
                .Distinct()
                .ToList();
        }

        private static List<ValueRecordPerDay> ToSequences(
            List<ValueRecord> records,
            DateTime startPeriod,
            DateTime endPeriod)
        {
            var valuePeriods = new List<ValueRecordPerDay>();

            records.ForEach(_ => valuePeriods.AddRange(ToDailySequences(_, 0)));

            return valuePeriods
                .Where(_ => _.DateTime >= startPeriod && _.DateTime <= endPeriod)
                .ToList();
        }

        private static IEnumerable<ValueRecordPerDay> ToDailySequences(
            ValueRecord record,
            int priority)
        {
            var valuePeriods = new List<ValueRecordPerDay>();
            var date = record.Payload.StartPeriod;
            var dayCount = (record.Payload.EndPeriod - record.Payload.StartPeriod).Days;

            for (var i = 0; i < dayCount; i++)
            {
                var valueRecordPerDay = new ValueRecordPerDay(
                    date.AddDays(i),
                    record,
                    priority);

                if (dayCount != 0)
                    valueRecordPerDay.UpdateValue(record.Payload.Value / dayCount);

                valuePeriods.Add(valueRecordPerDay);
            }

            return valuePeriods;
        }
    }
}
