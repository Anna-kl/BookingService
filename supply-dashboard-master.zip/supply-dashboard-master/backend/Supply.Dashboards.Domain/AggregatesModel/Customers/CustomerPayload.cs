﻿using Common.SeedWork;

using Supply.Dashboards.Domain.Exceptions;
using Supply.Dashboards.Domain.Types;

using System.Collections.Generic;

namespace Supply.Dashboards.Domain.AggregatesModel.Customers
{
    public sealed class CustomerPayload : ValueObject
    {
        public CustomerPayload(
            CustomerType type,
            string title,
            string? description)
        {
            Type = type
                          ?? throw new DomainException($"{nameof(type)} can't be null.");
            Title = string.IsNullOrWhiteSpace(title)
                ? throw new DomainException($"{nameof(title)} can't be null or white-space.")
                : title;
            Description = description;
        }

#pragma warning disable 8618
        // ReSharper disable once UnusedMember.Local
        private CustomerPayload()
        {
        }
#pragma warning restore 8618

        public CustomerType Type { get; init; }

        public string Title { get; init; }
        public string? Description { get; init; }

        protected override IEnumerable<object> GetAtomicValues()
        {
            yield return Type;
            yield return Title;
            yield return Description!;
        }
    }
}
