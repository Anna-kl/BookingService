﻿using Supply.Dashboards.App.Types;
using Supply.Dashboards.Domain.AggregatesModel.Core;

using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.Contexts.GetContextList.Output
{
    public sealed class GetContextListOutput
    {
        private readonly List<GetContextListItemOutput> _contexts;

        internal GetContextListOutput(IEnumerable<Context> contexts)
        {
            _contexts = contexts
                .Select(ToGetContextListItemOutput)
                .ToList();
        }

        public IEnumerable<GetContextListItemOutput> Items =>
            _contexts.AsReadOnly();

        private static GetContextListItemOutput ToGetContextListItemOutput(Context context) =>
            new(
                context.Id,
                context.XMin,
                AppStatusType.GetAppStatusType(context.Status),
                context.Title,
                context.ContextUsers.Select(_ => _.User));
    }
}
