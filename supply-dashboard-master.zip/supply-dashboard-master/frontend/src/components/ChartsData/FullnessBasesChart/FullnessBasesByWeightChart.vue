<template>
  <div class="module-inner-container">
    <Toolbar
      :curDate.sync="curDate"
      :config="config"
      :selectedOnChartLocationId.sync="selectedOnChartLocationId"
      :isDayChart="true"
      @update="update"
    />
    <MultiChartComponent :dynamicConfig="chartConfig" />
  </div>
</template>

<script lang='ts'>
import { Component, Prop } from "vue-property-decorator";
import Toolbar from "@/components/controls/toolbar/Toolbar.vue";
import MultiChartComponent from "@/components/Charts";
import { yesterdayDate, utcFromLocalDate } from "@/helpers/utils";
import config from "@/config";
import notify from "devextreme/ui/notify";
import {
  IFullnessBasesDataRequest,
  IFullnessBasesByLocationChartData,
  IFullnessBasesByLocationResponse,
  IGroupDataByParent,
} from "@/dto/FullnessBasesData";
import { ITreeListSelectedItem } from "../../controls/filterTree/types";
import {
  GraphLocationGroupEnum,
  IModuleConfig,
  IModuleSeries,
} from "@/dto/Dashboards";
import { ChartDataService } from "@/services/chartDataService";
import Chart from "../chart";
import { MtrItemTypeEnum } from "@/dto/InputData";
import IMultiChartConfig from "@/dto/IMultiChartConfig";

@Component({
  components: {
    Toolbar,
    MultiChartComponent,
  },
})
export default class FullnessBasesByWeightChart extends Chart {
  @Prop({ type: Object, required: false }) public config!: IModuleConfig;
  @Prop({ type: Array, required: false }) public series!: IModuleSeries[];

  private url: string = config.remoteHost + "/api/dashboards/fullness-basess";
  private curDate: Date = yesterdayDate();
  private selectedOnChartLocationId: string = "";
  private _chartDataService!: ChartDataService;

  public update() {
    this.getData(this.curDate);
  }

  private chartConfig: Partial<IMultiChartConfig> = {
    dataSource: [],
    functions: {
      onPointClick: this.onPointClick,
      customizeTooltip: this.customizeTooltip,
    },
    series: this.series,
    titleText: "Хранение на базах",
    subtitleText: "тонн",
    columns: this.config.columns,
  };

  private created() {
    this._chartDataService = new ChartDataService();
  }

  private mounted(): void {
    this.update();
  }

  private onPointClick({ target }: any) {
    this.selectedOnChartLocationId = target.data.locationId;
    this.update();
  }

  private customizeTooltip(pointInfo: any) {
    return {
      text: `${pointInfo.argument}(${pointInfo.seriesName}): ${pointInfo.valueText}`,
    };
  }

  private async getData(curDate: Date) {
    this.chartConfig.dataSource = [];
    const dateTime = utcFromLocalDate(curDate);
    const request: IFullnessBasesDataRequest = {
      startPeriod: dateTime,
      period: "Day",
      duration: "1.00:00:00",
      locationType:
        this.config.defaultLocationsGroup! ===
          GraphLocationGroupEnum.Division &&
        this.selectedOnChartLocationId === ""
          ? "Division"
          : "All",
      parentLocationId: this.selectedOnChartLocationId,
      locationsIds: this.config.locationsIds
        ?.filter((f) => f.selected)
        .map<string>((s) => s.dbId),
      customersIds: this.config.customersIds,
    };
    await this._chartDataService
      .getFullnessBasesDataByLocation(this.url, request)
      .then((data) => {
        if (data) {
          this.loadToDataSource(data);
        }
      })
      .catch((error: any) => {
        notify(error, "error", 2000);
        throw new Error(error);
      });
  }

  private loadToDataSource(data: IFullnessBasesByLocationResponse[]) {
    const groupedItems: IGroupDataByParent[] = [];
    const chartData: IFullnessBasesByLocationChartData[] = [];
    const selectedLocationRelations = this.config.locationsIds || [];

    if (selectedLocationRelations.length === 0) {
      chartData.push(
        ...this.createChartDataFromResponse(data).sort((a, b) =>
          a.location! > b.location! ? 1 : b.location! > a.location! ? -1 : 0
        )
      );
    } else {
      selectedLocationRelations.forEach((locationRelation) => {
        const finedItem = selectedLocationRelations.find(
          (s) => s.id === locationRelation.parentId
        );

        if (
          finedItem === undefined &&
          groupedItems.find((s) => s.id === locationRelation.parentId) ===
            undefined
        ) {
          // root items
          groupedItems.push({
            id: locationRelation.id,
            dbId: locationRelation.dbId,
            selected: locationRelation.selected,
            title: locationRelation.title,
            childrenGroups: [],
          });
        }
      });

      const sortedGroupItems = groupedItems.sort((a, b) =>
        a.title > b.title ? 1 : b.title > a.title ? -1 : 0
      );

      sortedGroupItems.forEach((element) => {
        this.createChildrenItems(selectedLocationRelations, element, data);
      });

      sortedGroupItems.forEach((element) => {
        const tmpChartData = this.getChartData(element, data);
        if (tmpChartData.length > 0) {
          chartData.push(...tmpChartData);
        }
      });
    }
    this.chartConfig.dataSource.push(...chartData);
  }

  private createChartDataFromResponse(
    data: IFullnessBasesByLocationResponse[]
  ): IFullnessBasesByLocationChartData[] {
    const retData: IFullnessBasesByLocationChartData[] = [];

    if (data !== undefined) {
      data.forEach((location) => {
        const weight =
          location.units.find(
            (s) =>
              s.type ===
              MtrItemTypeEnum[MtrItemTypeEnum.FullnessBasesLoadedWeight]
          )?.square ?? 0;

        retData.push({
          locationId: location.locationId,
          location: location.locationTitle,
          weight: weight,
        });
      });
    }

    return retData;
  }

  private createChildrenItems(
    selectedLocationRelations: ITreeListSelectedItem[],
    groupedItem: IGroupDataByParent,
    data: IFullnessBasesByLocationResponse[]
  ) {
    const notSortedItems: IGroupDataByParent[] = [];

    const tmpItems = selectedLocationRelations.filter(
      (s) => s.parentId === groupedItem.id
    );
    tmpItems.forEach((tmpItem) => {
      const subItem: IGroupDataByParent = {
        id: tmpItem.id,
        dbId: tmpItem.dbId,
        title: tmpItem.title,
        selected: tmpItem.selected,
        childrenGroups: [],
      };

      this.createChildrenItems(selectedLocationRelations, subItem, data);
      notSortedItems.push(subItem);
    });

    groupedItem.childrenGroups.push(
      ...notSortedItems.sort((a, b) =>
        a.title > b.title ? 1 : b.title > a.title ? -1 : 0
      )
    );
  }

  private getChartData(
    groupItem: IGroupDataByParent,
    data: IFullnessBasesByLocationResponse[]
  ): any[] {
    const retChartData: any[] = [];

    const tmpData = data.filter((s) => s.locationId === groupItem.dbId);

    if (tmpData.length > 0) {
      retChartData.push(
        ...this.createChartDataFromResponse(tmpData).sort((a, b) =>
          a.location! > b.location! ? 1 : b.location! > a.location! ? -1 : 0
        )
      );
    }

    groupItem.childrenGroups.forEach((element) => {
      const tmpChartData = this.getChartData(element, data);
      if (tmpChartData.length > 0) {
        retChartData.push(...tmpChartData);
      }
    });

    return retChartData;
  }
}
</script>