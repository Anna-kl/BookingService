﻿namespace Supply.Dashboards.Shared.Types
{
    public enum TransportResourcesEnum
    {
        TransportPlan = 1,
        TransportFact = 2,
        GPMPlan = 3,
        GPMFact = 4,
        LaborResourcesPlan = 5,
        LaborResourcesFact = 6,
    }
}
