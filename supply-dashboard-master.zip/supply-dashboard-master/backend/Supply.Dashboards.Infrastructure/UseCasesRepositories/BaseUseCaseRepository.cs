﻿using Common.SeedWork;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Supply.Dashboards.App.UseCases;
using Supply.Dashboards.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supply.Dashboards.Infrastructure.UseCasesRepositories
{
    public class BaseUseCaseRepository : IBaseUseCase
    {
        private readonly ILogger<BaseUseCaseRepository> _logger;
        private readonly DashboardsContext _dashboardsContext;

        public BaseUseCaseRepository(
            ILogger<BaseUseCaseRepository> logger,
            DashboardsContext dashboardsContext)
        {
            _logger = logger;
            _dashboardsContext = dashboardsContext;
        }

        public IUnitOfWork UnitOfWork => _dashboardsContext;

        public IEnumerable<TEntity> GetAsEnumerable<TEntity>(Func<TEntity, bool> predicate) where TEntity : class
        {
            return _dashboardsContext.Set<TEntity>().Where(predicate);
        }

        public TEntity? GetFirstOrDefault<TEntity>(Func<TEntity, bool> predicate) where TEntity : class
        {
            return _dashboardsContext.Set<TEntity>().FirstOrDefault(predicate);
        }

        public TEntity? GetSingleOrDefault<TEntity>(Func<TEntity, bool> predicate) where TEntity : class
        {
            return _dashboardsContext.Set<TEntity>().SingleOrDefault(predicate);
        }

        public void Create<TEntity>(TEntity item) where TEntity : class
        {
            _dashboardsContext.Set<TEntity>().Add(item);

        }
        public void Update<TEntity>(TEntity item) where TEntity : class
        {
            _dashboardsContext.Entry(item).State = EntityState.Modified;
        }
        public void Remove<TEntity>(TEntity item) where TEntity : class
        {
            _dashboardsContext.Set<TEntity>().Remove(item);
        }
    }

}
