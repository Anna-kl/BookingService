﻿using System;

namespace Supply.Dashboards.Shared.ViewModels.Import.ImportDirectories.Request
{
    public sealed class ImportDirectoriesEdgeRequestViewModel
    {
        public Guid SourceId { get; set; }
        public Guid DestinationId { get; set; }

        public bool? IsObsolete { get; set; }
    }
}
