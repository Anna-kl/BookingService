﻿using Supply.Dashboards.Shared.Types;

using System;

namespace Supply.Dashboards.Shared.ViewModels.Import.ImportDirectories.Response
{
    public sealed class ImportDirectoriesCustomerResponseViewModel
    {
        public Guid Id { get; set; }
        public uint RowVersion { get; set; }
        public StatusEnum Status { get; set; }
        public CustomerTypeEnum Type { get; set; }
        public string? Title { get; set; }
        public string? Description { get; set; }
    }
}
