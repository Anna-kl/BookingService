﻿using Common.Extensions;
using Supply.Dashboards.Shared.Types;

using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.WeatherRestrictions.WeatherRestrictionsDelete
{
    public sealed class WeatherRestrictionsDeleteRequestViewModel
    {
        public Guid Id { get; set; }

    }
}
