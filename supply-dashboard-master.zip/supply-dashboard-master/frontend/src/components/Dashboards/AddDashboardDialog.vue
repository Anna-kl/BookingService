<template>
  <DxPopup
    :visible="true"
    :drag-enabled="true"
    :close-on-outside-click="true"
    :show-title="true"
    :width="550"
    :height="180"
    title="Добавление информационной панели"
    @hidden="hide"
  >
    <template>
      <div class="dx-field">
        <div class="dx-field-label">Имя:</div>
        <div class="dx-field-value">
          <DxTextBox
            :value.sync="newDashboardName"
            placeholder="Введите название..."
          />
        </div>
      </div>
      <div class="dx-field">
        <div class="dx-field-label"></div>
        <div class="dx-field-value">
          <DxButton text="Добавить" @click="addDashboard()" />
        </div>
      </div>
    </template>
  </DxPopup>
</template>

<script lang='ts'>
import { DashboardsState } from "@/store";
import Vue from "vue";
import { EventBus } from "@/event-bus";
import { Component, Watch, Prop } from "vue-property-decorator";
import DxTextBox from "devextreme-vue/text-box";
import { DxPopup } from "devextreme-vue/popup";
import DxButton from "devextreme-vue/button";
import config from "@/config";

@Component({
  components: { DxTextBox, DxPopup, DxButton },
})
export default class AddDashboardDialog extends Vue {
  private newDashboardName: string = "";

  private addDashboard() {
    DashboardsState.addDashboard({
      id: DashboardsState.dashboards.length,
      name: this.newDashboardName,
      layouts: config.dashboardLayouts,
    });

    EventBus.$emit("hide-adddashboarddialog");
  }

  private hide() {
    EventBus.$emit("hide-adddashboarddialog");
  }
}
</script>
<style lang="scss" scoped>
</style>