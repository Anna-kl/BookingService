﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Supply.Dashboards.Infrastructure.Migrations
{
    public partial class RemoveContextFromValueRecord : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_value_records_contexts_contextid1",
                table: "value_records");

            migrationBuilder.DropIndex(
                name: "IX_value_records_contextid1",
                table: "value_records");

            migrationBuilder.DropColumn(
                name: "contextid1",
                table: "value_records");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "contextid1",
                table: "value_records",
                type: "integer",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_value_records_contextid1",
                table: "value_records",
                column: "contextid1");

            migrationBuilder.AddForeignKey(
                name: "FK_value_records_contexts_contextid1",
                table: "value_records",
                column: "contextid1",
                principalTable: "contexts",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
