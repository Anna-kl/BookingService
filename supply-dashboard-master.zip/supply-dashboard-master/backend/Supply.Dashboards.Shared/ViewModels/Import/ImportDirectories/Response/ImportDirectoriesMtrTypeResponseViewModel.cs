﻿using Supply.Dashboards.Shared.Types;

using System;

namespace Supply.Dashboards.Shared.ViewModels.Import.ImportDirectories.Response
{
    public sealed class ImportDirectoriesMtrTypeResponseViewModel
    {
        public Guid Id { get; set; }
        public uint RowVersion { get; set; }
        public StatusEnum Status { get; set; }
        public string? Title { get; set; }
    }
}
