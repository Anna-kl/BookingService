﻿using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Charts.ArrivalByLocations
{
    public sealed class ArrivalByLocationsResponseViewModel
    {
        public List<ArrivalByLocationsResponseParamViewModel>? Locations { get; set; }
    }
}
