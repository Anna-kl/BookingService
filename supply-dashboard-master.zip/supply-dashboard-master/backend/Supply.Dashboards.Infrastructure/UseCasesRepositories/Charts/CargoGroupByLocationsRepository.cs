using Common.Extensions;

using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.UseCases.Charts.CargoGroupByLocations;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;
using Supply.Dashboards.Domain.AggregatesModel.ValueRecords;
using Supply.Dashboards.Domain.Types;
using Supply.Dashboards.Infrastructure.Data;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.Infrastructure.UseCasesRepositories.Charts
{
    public sealed class CargoGroupByLocationsRepository : ICargoGroupByLocations
    {
        private readonly ILogger<CargoGroupByLocationsRepository> _logger;
        private readonly DashboardsContext _dashboardsContext;

        public CargoGroupByLocationsRepository(
            ILogger<CargoGroupByLocationsRepository> logger,
            DashboardsContext dashboardsContext)
        {
            _logger = logger;
            _dashboardsContext = dashboardsContext;
        }

        #region customers

        public async Task<IEnumerable<Guid>> GetCustomersExistingIds(
            List<StatusType> statuses,
            List<Guid> ids,
            CancellationToken cancellationToken) =>
            await _dashboardsContext
                .Customers
                .AsNoTracking()
                .Where(_ => statuses.Contains(_.Status))
                .Where(_ => ids.Contains(_.InnerId))
                .Select(_ => _.InnerId)
                .ToListAsync(cancellationToken);

        public async Task<IEnumerable<Customer>> GetCustomers(
            List<StatusType> statuses,
            CancellationToken cancellationToken) =>
            await _dashboardsContext
                .Customers
                .AsNoTracking()
                .Where(_ => statuses.Contains(_.Status))
                .ToListAsync(cancellationToken);

        public async Task<IEnumerable<CustomerEdge>> GetCustomersEdges(
            List<Guid> ids,
            CancellationToken cancellationToken) =>
            await _dashboardsContext
                .CustomersEdges
                .AsNoTracking()
                .Where(_ => ids.Contains(_.SourceInnerId))
                .Where(_ => ids.Contains(_.DestinationInnerId))
                .ToListAsync(cancellationToken);

        #endregion

        #region locations

        public async Task<IEnumerable<Guid>> GetLocationsExistingIds(
            List<StatusType> statuses,
            List<Guid> ids,
            CancellationToken cancellationToken) =>
            await _dashboardsContext
                .Locations
                .AsNoTracking()
                .Where(_ => statuses.Contains(_.Status))
                .Where(_ => ids.Contains(_.InnerId))
                .Select(_ => _.InnerId)
                .ToListAsync(cancellationToken);

        public async Task<IEnumerable<Location>> GetLocations(
            List<StatusType> statuses,
            CancellationToken cancellationToken) =>
            await _dashboardsContext
                .Locations
                .AsNoTracking()
                .Where(_ => statuses.Contains(_.Status))
                .ToListAsync(cancellationToken);

        public async Task<IEnumerable<LocationEdge>> GetLocationsEdges(
            List<Guid> ids,
            CancellationToken cancellationToken) =>
            await _dashboardsContext
                .LocationEdges
                .AsNoTracking()
                .Where(_ => ids.Contains(_.SourceInnerId))
                .Where(_ => ids.Contains(_.DestinationInnerId))
                .ToListAsync(cancellationToken);

        #endregion

        #region mtr types

        public async Task<IEnumerable<Guid>> GetMtrTypesExistingIds(
            List<StatusType> statuses,
            List<Guid> ids, CancellationToken cancellationToken) =>
            await _dashboardsContext
                .MtrTypes
                .AsNoTracking()
                .Where(_ => statuses.Contains(_.Status))
                .Where(_ => ids.Contains(_.InnerId))
                .Select(_ => _.InnerId)
                .ToListAsync(cancellationToken);

        public async Task<IEnumerable<MtrType>> GetMtrTypes(
            List<StatusType> statuses,
            CancellationToken cancellationToken) =>
            await _dashboardsContext
                .MtrTypes
                .AsNoTracking()
                .Where(_ => statuses.Contains(_.Status))
                .ToListAsync(cancellationToken);


        public async Task<IEnumerable<MtrTypeEdge>> GetMtrTypesEdges(
            List<Guid> ids,
            CancellationToken cancellationToken) =>
            await _dashboardsContext
                .MtrTypesEdges
                .AsNoTracking()
                .Where(_ => ids.Contains(_.SourceInnerId))
                .Where(_ => ids.Contains(_.DestinationInnerId))
                .ToListAsync(cancellationToken);

        #endregion

        public async Task<IEnumerable<MtrType>> GetMtrTypesByInnerIds(
            List<Guid> innerIds,
            CancellationToken cancellationToken) =>
            (await _dashboardsContext
                .MtrTypes
                .AsNoTracking()
                .Where(_ => _.Status == StatusType.Active)
                .Where(_ => innerIds.Contains(_.InnerId))
                .ToListAsync(cancellationToken)).AsReadOnly();

        public async Task<(
                IEnumerable<ValueRecord> subset,
                IEnumerable<ValueRecord> superset,
                IEnumerable<ValueRecord> crossing)>
            GetRecords(
                List<ValueRecordType> recordsTypes,
                DateTime startPeriod,
                DateTime? endPeriod,
                List<Location>? locations,
                List<Customer>? customers,
                List<MtrType>? mtrTypes,
                CancellationToken cancellationToken)
        {
            var queryable = _dashboardsContext
                .ValueRecords
                .AsNoTracking()
                .Include(_ => _.Payload.Location)
                .Include(_ => _.Payload.Customer)
                .Include(_ => _.Payload.MtrType)
                .Where(_ => recordsTypes.Contains(_.Payload.Type));

            if (locations != null && locations.Any())
                queryable = queryable.Where(_ => _.Payload.Location == null || locations.Contains(_.Payload.Location!));

            if (customers != null && customers.Any())
                queryable = queryable.Where(_ => _.Payload.Customer == null || customers.Contains(_.Payload.Customer!));

            if (mtrTypes != null && mtrTypes.Any())
                queryable = queryable.Where(_ => _.Payload.MtrType == null || mtrTypes.Contains(_.Payload.MtrType!));

            var subset = (await queryable.Where(_ => endPeriod == null
                    ? _.Payload.StartPeriod >= startPeriod
                    : _.Payload.StartPeriod >= startPeriod && _.Payload.EndPeriod <= endPeriod)
                .ToListAsync(cancellationToken))
                .DistinctBy(_ => _.Payload);

            var superset = new List<ValueRecord>();

            if (endPeriod != null)
                superset = (await queryable
                    .Where(record =>
                        record.Payload.StartPeriod < startPeriod && record.Payload.EndPeriod > endPeriod)
                    .ToListAsync(cancellationToken))
                    .DistinctBy(_ => _.Payload)
                    .ToList();

            var crossing = (await queryable.Where(record => endPeriod == null
                    ? record.Payload.StartPeriod <= startPeriod && record.Payload.EndPeriod > startPeriod
                    : (record.Payload.StartPeriod < startPeriod && record.Payload.EndPeriod > startPeriod)
                      | (record.Payload.StartPeriod < endPeriod && record.Payload.EndPeriod > endPeriod)
                      && !(record.Payload.StartPeriod < startPeriod && record.Payload.EndPeriod > endPeriod))
                .ToListAsync(cancellationToken))
                .DistinctBy(_ => _.Payload);


            return (subset, superset, crossing);
        }
    }
}
