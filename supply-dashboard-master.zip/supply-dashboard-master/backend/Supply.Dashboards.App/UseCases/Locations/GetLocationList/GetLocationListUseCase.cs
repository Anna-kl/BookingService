﻿using FluentValidation.Results;

using MediatR;

using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.Locations.GetLocationList.Input;
using Supply.Dashboards.App.UseCases.Locations.GetLocationList.Output;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.Types;

using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.Locations.GetLocationList
{
    public sealed class GetLocationListUseCase
        : IRequestHandler<GetLocationListQuery, (ValidationResult validationResult, GetLocationListOutput? output)>
    {
        private readonly ILogger<GetLocationListUseCase> _logger;
        private readonly IGetLocationList _getLocationsList;

        public GetLocationListUseCase(
            ILogger<GetLocationListUseCase> logger,
            IGetLocationList getLocationsList)
        {
            _logger = logger;
            _getLocationsList = getLocationsList;
        }

        public async Task<(ValidationResult validationResult, GetLocationListOutput? output)> Handle(
            GetLocationListQuery request,
            CancellationToken cancellationToken)
        {
            // If there are validation errors, abort the method and return errors.
            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            var statuses = request
                .Statuses
                .Select(AppStatusType.GetStatusType)
                .Distinct()
                .ToList();

            // If the statuses r not contained in the request, then add the "Active" status.
            if (!statuses.Any())
                statuses.Add(StatusType.Active);

            var sourceLocations = new List<Location>();

            if (request.SourceIds != null && request.SourceIds.Any(_ => _ != null))
                sourceLocations = (await _getLocationsList.GetByIds(
                    statuses,
                    request.SourceIds?.Where(_ => _ != null).Select(_ => _!.Value).ToList()!,
                    cancellationToken)).ToList();

            if (!sourceLocations.Any() || request.SourceIds?.Count() != sourceLocations.Count)
                request.SourceIds
                    ?.Where(_ => _ != null)
                    .Select(_ => _.Value)
                    .Except(sourceLocations.Select(_ => _.InnerId)).ToList().ForEach(id =>
                    {
                        request.ValidationResult.Errors.Add(new ValidationFailure(
                            "LocationId",
                            $"{nameof(Location)} with id \"{id}\" is not exist."));
                    });

            // If there are validation errors, abort the method and return errors.
            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            var types = request
                .Types
                ?.Select(AppLocationType.GetLocationType)
                .Distinct()
                .ToList();

            var locations = (await _getLocationsList.Get(
                statuses,
                sourceLocations,
                request.Ids?.ToList(),
                types,
                request.SourceIds != null && request.SourceIds.Any(_ => _ == null),
                cancellationToken)).ToList();

            return !locations.Any()
                ? (request.ValidationResult, null)
                : (request.ValidationResult, new GetLocationListOutput(locations));
        }
    }
}
