﻿using Microsoft.EntityFrameworkCore.Migrations;

using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

using System;

namespace Supply.Dashboards.Infrastructure.Migrations
{
    public partial class AddContext : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_value_records_users_payload_userid",
                table: "value_records");

            migrationBuilder.DropTable(
                name: "aliasid");

            migrationBuilder.DropTable(
                name: "customer_types");

            migrationBuilder.DropTable(
                name: "input_types");

            migrationBuilder.DropTable(
                name: "location_types");

            migrationBuilder.DropTable(
                name: "value_records_types");

            migrationBuilder.DropTable(
                name: "externalsystem");

            migrationBuilder.DropTable(
                name: "status_types");

            migrationBuilder.RenameColumn(
                name: "payload_userid",
                table: "value_records",
                newName: "contextid1");

            migrationBuilder.RenameIndex(
                name: "IX_value_records_payload_userid",
                table: "value_records",
                newName: "IX_value_records_contextid1");

            migrationBuilder.AddColumn<int>(
                name: "contextid",
                table: "value_records",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "nameidentifier",
                table: "users",
                type: "text",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "contextid",
                table: "mtr_types_edges",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "contextid",
                table: "mtr_types",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "contextid",
                table: "locations_edges",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "contextid",
                table: "locations",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "contextid",
                table: "customers_edges",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "contextid",
                table: "customers",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "aliasids",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    innerid = table.Column<Guid>(type: "uuid", nullable: false),
                    type = table.Column<string>(type: "text", nullable: false),
                    externalsystemid = table.Column<int>(type: "integer", nullable: false),
                    ownerid = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_aliasids", x => x.id);
                    table.ForeignKey(
                        name: "FK_aliasids_contexts_ownerid",
                        column: x => x.ownerid,
                        principalTable: "contexts",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_aliasids_users_externalsystemid",
                        column: x => x.externalsystemid,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "context_user",
                columns: table => new
                {
                    contextid = table.Column<int>(type: "integer", nullable: false),
                    userid = table.Column<int>(type: "integer", nullable: false),
                    contextinnerid = table.Column<Guid>(type: "uuid", nullable: false),
                    userinnerid = table.Column<Guid>(type: "uuid", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_context_user", x => new { x.contextid, x.userid });
                    table.ForeignKey(
                        name: "FK_context_user_contexts_contextid",
                        column: x => x.contextid,
                        principalTable: "contexts",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "FK_context_user_users_userid",
                        column: x => x.userid,
                        principalTable: "users",
                        principalColumn: "id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_value_records_contextid",
                table: "value_records",
                column: "contextid");

            migrationBuilder.CreateIndex(
                name: "IX_mtr_types_edges_contextid",
                table: "mtr_types_edges",
                column: "contextid");

            migrationBuilder.CreateIndex(
                name: "IX_mtr_types_contextid",
                table: "mtr_types",
                column: "contextid");

            migrationBuilder.CreateIndex(
                name: "IX_locations_edges_contextid",
                table: "locations_edges",
                column: "contextid");

            migrationBuilder.CreateIndex(
                name: "IX_locations_contextid",
                table: "locations",
                column: "contextid");

            migrationBuilder.CreateIndex(
                name: "IX_customers_edges_contextid",
                table: "customers_edges",
                column: "contextid");

            migrationBuilder.CreateIndex(
                name: "IX_customers_contextid",
                table: "customers",
                column: "contextid");

            migrationBuilder.CreateIndex(
                name: "IX_aliasids_externalsystemid",
                table: "aliasids",
                column: "externalsystemid");

            migrationBuilder.CreateIndex(
                name: "IX_aliasids_ownerid",
                table: "aliasids",
                column: "ownerid");

            migrationBuilder.CreateIndex(
                name: "IX_context_user_contextinnerid_userinnerid",
                table: "context_user",
                columns: new[] { "contextinnerid", "userinnerid" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_context_user_userid",
                table: "context_user",
                column: "userid");

            migrationBuilder.AddForeignKey(
                name: "FK_customers_contexts_contextid",
                table: "customers",
                column: "contextid",
                principalTable: "contexts",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_customers_edges_contexts_contextid",
                table: "customers_edges",
                column: "contextid",
                principalTable: "contexts",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_locations_contexts_contextid",
                table: "locations",
                column: "contextid",
                principalTable: "contexts",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_locations_edges_contexts_contextid",
                table: "locations_edges",
                column: "contextid",
                principalTable: "contexts",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_mtr_types_contexts_contextid",
                table: "mtr_types",
                column: "contextid",
                principalTable: "contexts",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_mtr_types_edges_contexts_contextid",
                table: "mtr_types_edges",
                column: "contextid",
                principalTable: "contexts",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_value_records_contexts_contextid",
                table: "value_records",
                column: "contextid",
                principalTable: "contexts",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_value_records_contexts_contextid1",
                table: "value_records",
                column: "contextid1",
                principalTable: "contexts",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_customers_contexts_contextid",
                table: "customers");

            migrationBuilder.DropForeignKey(
                name: "FK_customers_edges_contexts_contextid",
                table: "customers_edges");

            migrationBuilder.DropForeignKey(
                name: "FK_locations_contexts_contextid",
                table: "locations");

            migrationBuilder.DropForeignKey(
                name: "FK_locations_edges_contexts_contextid",
                table: "locations_edges");

            migrationBuilder.DropForeignKey(
                name: "FK_mtr_types_contexts_contextid",
                table: "mtr_types");

            migrationBuilder.DropForeignKey(
                name: "FK_mtr_types_edges_contexts_contextid",
                table: "mtr_types_edges");

            migrationBuilder.DropForeignKey(
                name: "FK_value_records_contexts_contextid",
                table: "value_records");

            migrationBuilder.DropForeignKey(
                name: "FK_value_records_contexts_contextid1",
                table: "value_records");

            migrationBuilder.DropTable(
                name: "aliasids");

            migrationBuilder.DropTable(
                name: "context_user");

            migrationBuilder.DropIndex(
                name: "IX_value_records_contextid",
                table: "value_records");

            migrationBuilder.DropIndex(
                name: "IX_mtr_types_edges_contextid",
                table: "mtr_types_edges");

            migrationBuilder.DropIndex(
                name: "IX_mtr_types_contextid",
                table: "mtr_types");

            migrationBuilder.DropIndex(
                name: "IX_locations_edges_contextid",
                table: "locations_edges");

            migrationBuilder.DropIndex(
                name: "IX_locations_contextid",
                table: "locations");

            migrationBuilder.DropIndex(
                name: "IX_customers_edges_contextid",
                table: "customers_edges");

            migrationBuilder.DropIndex(
                name: "IX_customers_contextid",
                table: "customers");

            migrationBuilder.DropColumn(
                name: "contextid",
                table: "value_records");

            migrationBuilder.DropColumn(
                name: "nameidentifier",
                table: "users");

            migrationBuilder.DropColumn(
                name: "contextid",
                table: "mtr_types_edges");

            migrationBuilder.DropColumn(
                name: "contextid",
                table: "mtr_types");

            migrationBuilder.DropColumn(
                name: "contextid",
                table: "locations_edges");

            migrationBuilder.DropColumn(
                name: "contextid",
                table: "locations");

            migrationBuilder.DropColumn(
                name: "contextid",
                table: "customers_edges");

            migrationBuilder.DropColumn(
                name: "contextid",
                table: "customers");

            migrationBuilder.RenameColumn(
                name: "contextid1",
                table: "value_records",
                newName: "payload_userid");

            migrationBuilder.RenameIndex(
                name: "IX_value_records_contextid1",
                table: "value_records",
                newName: "IX_value_records_payload_userid");

            migrationBuilder.CreateTable(
                name: "customer_types",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false),
                    name = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_customer_types", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "input_types",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false),
                    name = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_input_types", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "location_types",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false),
                    name = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_location_types", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "status_types",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false),
                    name = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_status_types", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "value_records_types",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false),
                    name = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_value_records_types", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "externalsystem",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    createat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    innerid = table.Column<Guid>(type: "uuid", nullable: false),
                    statusid = table.Column<int>(type: "integer", nullable: true),
                    title = table.Column<string>(type: "text", nullable: false),
                    updateat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_externalsystem", x => x.id);
                    table.ForeignKey(
                        name: "FK_externalsystem_status_types_statusid",
                        column: x => x.statusid,
                        principalTable: "status_types",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "aliasid",
                columns: table => new
                {
                    contextid = table.Column<int>(type: "integer", nullable: false),
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    contextinnerid = table.Column<Guid>(type: "uuid", nullable: false),
                    externalid = table.Column<string>(type: "text", nullable: false),
                    externalsystemid = table.Column<int>(type: "integer", nullable: false),
                    innerid = table.Column<Guid>(type: "uuid", nullable: false),
                    type = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_aliasid", x => new { x.contextid, x.id });
                    table.ForeignKey(
                        name: "FK_aliasid_contexts_contextid",
                        column: x => x.contextid,
                        principalTable: "contexts",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_aliasid_externalsystem_externalsystemid",
                        column: x => x.externalsystemid,
                        principalTable: "externalsystem",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_aliasid_externalsystemid",
                table: "aliasid",
                column: "externalsystemid");

            migrationBuilder.CreateIndex(
                name: "IX_externalsystem_statusid",
                table: "externalsystem",
                column: "statusid");

            migrationBuilder.AddForeignKey(
                name: "FK_value_records_users_payload_userid",
                table: "value_records",
                column: "payload_userid",
                principalTable: "users",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
