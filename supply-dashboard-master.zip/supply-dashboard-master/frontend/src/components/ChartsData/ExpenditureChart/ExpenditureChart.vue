<template>
  <div class="module-inner-container">
    <Toolbar
      :curDate.sync="curDate"
      :config="config"
      :selectedOnChartLocationId.sync="selectedOnChartLocationId"
      :isDayChart="isDayChart"
      @update="update"
    />
    <MultiChartComponent :dynamicConfig="chartConfig" />
  </div>
</template>

<script lang='ts'>
import { Component, Prop } from "vue-property-decorator";
import Toolbar from "@/components/controls/toolbar/Toolbar.vue";
import MultiChartComponent from "@/components/Charts";
import {
  getYearStart,
  getYearEnd,
  getMonthStart,
  getMonthEnd,
  getDuration,
  yesterdayDate,
  utcFromLocalDate,
} from "@/helpers/utils";
import config from "@/config";
import notify from "devextreme/ui/notify";
import {
  ICargoDataByLocationsResponse,
  ICargoDataByLocationsRequest,
} from "@/dto/CargoData";
import {
  ChartPeriodEnum,
  GraphLocationGroupEnum,
  IModuleConfig,
  IModuleSeries,
} from "@/dto/Dashboards";
import { ChartDataService } from "@/services/chartDataService";
import Chart from "../chart";
import { MtrItemTypeEnum } from "@/dto/InputData";
import IMultiChartConfig from "@/dto/IMultiChartConfig";

@Component({
  components: {
    Toolbar,
    MultiChartComponent,
  },
})
export default class ExpenditureChart extends Chart {
  @Prop({ type: Object, required: false }) public config!: IModuleConfig;
  @Prop({ type: Array, required: false }) public series!: IModuleSeries[];

  private url: string =
    config.remoteHost + "/api/dashboards/expenditure-by-locations";
  private isDayChart: boolean = this.config?.period === ChartPeriodEnum.Day;
  private curDate: Date = yesterdayDate();
  private selectedOnChartLocationId: string = "";
  private _chartDataService!: ChartDataService;

  public update() {
    this.getData(this.curDate!);
  }

  private chartConfig: Partial<IMultiChartConfig> = {
    dataSource: [],
    functions: {
      onPointClick: this.onPointClick,
      customizeTooltip: this.customizeTooltip,
    },
    series: this.series,
    titleText: "Расход",
    subtitleText: "тыс. тонн",
    columns: this.config.columns,
  };

  private created() {
    this._chartDataService = new ChartDataService();
  }

  private mounted(): void {
    this.update();
  }

  private onPointClick({ target }: any) {
    this.selectedOnChartLocationId = target.data.locationId;
    this.update();
  }

  private customizeTooltip(pointInfo: any) {
    return {
      text: `${pointInfo.argument}(${pointInfo.seriesName}): ${pointInfo.valueText}`,
    };
  }

  private getData(curDate: Date) {
    let startPeriod: string;
    let duration: string | undefined;

    switch (this.config?.period) {
      case ChartPeriodEnum.Year:
        startPeriod = getYearStart(curDate);
        duration = getDuration(startPeriod, getYearEnd(curDate));
        break;
      case ChartPeriodEnum.Day:
        startPeriod = getMonthStart(curDate);
        duration = getDuration(startPeriod, utcFromLocalDate(curDate));
        break;
      case ChartPeriodEnum.Month:
      default:
        startPeriod = getMonthStart(curDate);
        duration = getDuration(startPeriod, getMonthEnd(curDate));
        break;
    }

    this.getLocationData(startPeriod, duration);
  }

  private async getLocationData(startPeriod: string, duration: string) {
    this.chartConfig.dataSource = [];
    const request: ICargoDataByLocationsRequest = {
      startPeriod,
      duration,
      locationType:
        this.config.defaultLocationsGroup! ===
          GraphLocationGroupEnum.Division &&
        this.selectedOnChartLocationId === ""
          ? "Division"
          : "All",
      dataType: this.config.type || "",
      parentLocationId: this.selectedOnChartLocationId,
      locationsIds: this.config.locationsIds
        ?.filter((f) => f.selected)
        .map<string>((s) => s.dbId),
      customersIds: this.config.customersIds,
      mtrTypesIds: this.config.mtrTypesIds,
    };

    if (duration) {
      request.duration = duration;
    }

    await this._chartDataService
      .getCargoDataByLocations(this.url, request)
      .then((data) => {
        if (data) {
          this.chartConfig.dataSource = (data as ICargoDataByLocationsResponse[]).map(
            (element) => {
              return {
                locationId: element.locationId,
                location: element.locationTitle,
                plan:
                  element.units.find(
                    (s) =>
                      s.type ===
                      MtrItemTypeEnum[MtrItemTypeEnum.ExpenditurePlan]
                  )?.tons ?? 0,
                fact:
                  element.units.find(
                    (s) =>
                      s.type ===
                      MtrItemTypeEnum[MtrItemTypeEnum.ExpenditureFact]
                  )?.tons ?? 0,
                adjustedPlan:
                  element.units.find(
                    (s) =>
                      s.type ===
                      MtrItemTypeEnum[MtrItemTypeEnum.ExpenditureAdjustedPlan]
                  )?.tons ?? 0,
                dailyPlan:
                  element.units.find(
                    (s) =>
                      s.type ===
                      MtrItemTypeEnum[MtrItemTypeEnum.ExpenditureDailyPlan]
                  )?.tons ?? 0,
              };
            }
          );
        }
      })
      .catch((errors: any) => {
        notify(errors.title, "error", 2000);
        throw new Error(errors.title);
      });
  }
}
</script>