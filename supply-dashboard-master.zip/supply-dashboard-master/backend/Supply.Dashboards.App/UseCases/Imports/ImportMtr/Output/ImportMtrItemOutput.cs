﻿using Supply.Dashboards.App.UseCases.Imports.ImportMtr.Types;

using System;

namespace Supply.Dashboards.App.UseCases.Imports.ImportMtr.Output
{
    public sealed class ImportMtrItemOutput
    {
        public ImportMtrItemOutput(
            uint xMin,
            DateTime startPeriod,
            DateTime endPeriod,
            Guid? customerId,
            Guid? locationId,
            Guid? mtrTypeId,
            ImportMtrType type,
            double value)
        {
            RowVersion = xMin;
            StartPeriod = startPeriod;
            EndPeriod = endPeriod - startPeriod;
            CustomerId = customerId;
            LocationId = locationId;
            MtrTypeId = mtrTypeId;
            Type = type;
            Value = value;
        }

        public uint RowVersion { get; }
        public DateTime StartPeriod { get; }
        public TimeSpan EndPeriod { get; }
        public Guid? CustomerId { get; }
        public Guid? LocationId { get; }
        public Guid? MtrTypeId { get; }
        public ImportMtrType Type { get; }
        public double Value { get; }
    }
}
