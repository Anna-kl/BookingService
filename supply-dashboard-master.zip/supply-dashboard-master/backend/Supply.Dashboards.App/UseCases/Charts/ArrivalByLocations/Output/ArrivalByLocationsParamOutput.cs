﻿using System;
using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.Charts.ArrivalByLocations.Output
{
    public class ArrivalByLocationsParamOutput
    {
        private readonly List<ArrivalByLocationsUnitOutput> _units;

        internal ArrivalByLocationsParamOutput(
            Guid locationId,
            string locationTitle,
            List<ArrivalByLocationsUnitOutput>? units)
        {
            LocationId = locationId;
            LocationTitle = locationTitle;
            _units = units ?? new List<ArrivalByLocationsUnitOutput>();
        }

        public Guid LocationId { get; }
        public string LocationTitle { get; }

        public IEnumerable<ArrivalByLocationsUnitOutput>? Units =>
            _units.AsReadOnly();
    }
}
