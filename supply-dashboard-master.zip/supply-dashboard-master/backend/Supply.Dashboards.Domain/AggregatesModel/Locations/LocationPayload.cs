﻿using Common.SeedWork;

using Supply.Dashboards.Domain.Exceptions;
using Supply.Dashboards.Domain.Types;

using System.Collections.Generic;

namespace Supply.Dashboards.Domain.AggregatesModel.Locations
{
    public sealed class LocationPayload : ValueObject
    {
        public LocationPayload(
            LocationType type,
            string title,
            string? description,
            double? longitude,
            double? latitude,
            double? diameter)
        {
            Type = type
                   ?? throw new DomainException($"{nameof(type)} can't be null.");
            Title = string.IsNullOrWhiteSpace(title)
                ? throw new DomainException($"{nameof(title)} can't be null or white-space.")
                : title;
            Description = description;
            Diameter = diameter ?? 0;

            if (longitude != null && latitude != null)
            {
                Longitude = longitude.Value < -180.0 || longitude.Value > 180.0
                    ? throw new DomainException($"{nameof(longitude.Value)} is not a valid latitude.")
                    : longitude.Value;

                Latitude = latitude.Value < -90.0 || latitude.Value > 90.0
                    ? throw new DomainException($"{nameof(latitude.Value)} is not a valid latitude.")
                    : latitude.Value;

                Diameter = diameter == null || diameter!.Value > 0
                    ? diameter
                    : throw new DomainException($"{nameof(diameter)} must be null or more zero.");
            }
        }

#pragma warning disable 8618
        // ReSharper disable once UnusedMember.Local
        private LocationPayload()
        {
        }
#pragma warning restore 8618

        public LocationType Type { get; init; }
        public string Title { get; init; }
        public string? Description { get; init; }

        public double? Longitude { get; init; }
        public double? Latitude { get; init; }
        public double? Diameter { get; init; }

        protected override IEnumerable<object> GetAtomicValues()
        {
            yield return Type;
            yield return Title;
            yield return Description!;
            yield return Longitude!;
            yield return Latitude!;
            yield return Diameter!;
        }
    }
}
