﻿namespace Supply.Dashboards.Shared.ViewModels.Charts.AccountingMtrByPeriods
{
    public sealed class AccountingMtrByPeriodsUnitViewModel
    {
        public AccountingMtrByPeriodsEnum Type { get; set; }
        public double Tons { get; set; }
    }
}
