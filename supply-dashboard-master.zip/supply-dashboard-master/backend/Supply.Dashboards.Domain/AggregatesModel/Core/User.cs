﻿using Common.SeedWork;

using Supply.Dashboards.Domain.Exceptions;
using Supply.Dashboards.Domain.Types;

using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Domain.AggregatesModel.Core
{
    // TODO User
    public sealed class User : Aggregate
    {
        private readonly List<ContextUser> _contextUsers;

        #region c'tors

        public User(
            Guid id,
            string nameIdentifier,
            StatusType status,
            string fullName,
            Context context)
        {
            Id = default;
            InnerId = id == default
                ? throw new DomainException($"{nameof(id)} can't be null.")
                : id;
            NameIdentifier = string.IsNullOrWhiteSpace(nameIdentifier)
                ? throw new DomainException($"{nameof(nameIdentifier)} can't be null.")
                : nameIdentifier;
            CreateAt = DateTime.UtcNow;
            UpdateAt = DateTime.UtcNow;
            Status = status
                     ?? throw new DomainException($"{nameof(status)} can't be null.");

            FullName = string.IsNullOrWhiteSpace(fullName)
                ? throw new DomainException($"{nameof(fullName)} can't be null or white-space.")
                : fullName;

            if (context == null)
                throw new DomainException($"{nameof(context)} can't be null.");

            _contextUsers = new List<ContextUser> { new(context, this) };

            AddDomainEvent(new Event(InnerId.ToString(), Status, (FullName, ContextUsers)));
        }

#pragma warning disable 8618
        // ReSharper disable once UnusedMember.Local
        private User()
        {
        }
#pragma warning restore 8618

        #endregion

        #region props

        public string NameIdentifier { get; init; }
        public DateTime CreateAt { get; init; }
        public DateTime UpdateAt { get; private set; }
        public StatusType Status { get; private set; }

        public IEnumerable<ContextUser> ContextUsers => _contextUsers.AsReadOnly();

        public string FullName { get; private set; }

        public override string ToString() =>
            FullName;

        #endregion

        #region methods

        public void ChangeStatus(StatusType status)
        {
            UpdateAt = DateTime.UtcNow;
            Status = status
                     ?? throw new DomainException($"{nameof(status)} can't be null.");

            AddDomainEvent(new Event(InnerId.ToString(), Status, (FullName, ContextUsers)));
        }

        #endregion
    }
}
