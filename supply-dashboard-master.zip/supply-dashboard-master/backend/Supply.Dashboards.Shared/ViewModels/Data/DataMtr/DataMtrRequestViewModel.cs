﻿using Supply.Dashboards.Shared.Types;
using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Data.DataMtr
{
    public sealed class DataMtrRequestViewModel
    {
        public DateTime StartPeriod { get; set; }
        public TimeSpan? EndPeriod { get; set; }
        public List<Guid>? CustomersIds { get; set; }
        public List<Guid>? LocationsIds { get; set; }
        public List<Guid>? MtrTypesIds { get; set; }
        public List<ValueRecordEnum>? Types { get; set; }
    }
}
