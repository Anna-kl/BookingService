﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Supply.Dashboards.App.UseCases.Locations.GetLocationList;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.Types;
using Supply.Dashboards.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.Infrastructure.UseCasesRepositories.Locations
{
    public sealed class GetLocationListRepository : IGetLocationList
    {
        private readonly ILogger<GetLocationListRepository> _logger;
        private readonly DashboardsContext _dashboardsContext;

        public GetLocationListRepository(
            ILogger<GetLocationListRepository> logger,
            DashboardsContext dashboardsContext)
        {
            _logger = logger;
            _dashboardsContext = dashboardsContext;
        }

        public async Task<IEnumerable<Location>> Get(
            List<StatusType> statuses,
            List<Location>? sourceList,
            List<Guid>? ids,
            List<LocationType>? types,
            bool includeRoot,
            CancellationToken cancellationToken)
        {
            var queryable = _dashboardsContext
                .Locations
                .Include(_ => _.SourceEdges!.Where(edge => statuses.Contains(edge.Source.Status)))
                .Include(_ => _.DestinationEdges!.Where(edge => statuses.Contains(edge.Destination.Status)))
                .Where(_ => statuses.Contains(_.Status));

            queryable = includeRoot switch
            {
                true => queryable.Where(_ => sourceList != null && sourceList.Any()
                    ? _.SourceEdges!.Any(edge => sourceList.Select(location => location.Id).Contains(edge.SourceId)) |
                      !_.SourceEdges!.Any()
                    : !_.SourceEdges!.Any()),
                _ => (sourceList != null && sourceList.Any())
                    ? queryable.Where(_ =>
                        _.SourceEdges!.Any(edge => sourceList.Select(location => location.Id).Contains(edge.SourceId)))
                    : queryable
            };

            if (ids != null && ids.Any())
                queryable = queryable.Where(_ => ids.Contains(_.InnerId));

            if (types != null && types.Any())
                queryable = queryable.Where(_ => types.Contains(_.Payload.Type));

            var locations = await queryable.ToListAsync(cancellationToken);

            return (await queryable.ToListAsync(cancellationToken))
                .Distinct()
                .ToList()
                .AsReadOnly();
        }

        public async Task<IEnumerable<Location>> GetByIds(
            List<StatusType> statuses,
            List<Guid> ids,
            CancellationToken cancellationToken) =>
            (await _dashboardsContext
                .Locations
                .Where(_ => ids.Contains(_.InnerId))
                .Where(_ => statuses.Contains(_.Status))
                .ToListAsync(cancellationToken)).AsReadOnly();

        /// <summary>
        /// cловарь дивизионов с дочерними локациями всех уровней вложенности 
        /// </summary>
        /// <returns></returns>
        public Dictionary<Location, List<Location>> GetActiveDivisionsWithChildrenLocations()
        {
            var returnedDic = new Dictionary<Location, List<Location>>();

            var queryable = _dashboardsContext
             .Locations
             .AsNoTracking()
             .Include(_ => _.DestinationEdges)
             .Include("DestinationEdges.Destination")
             .Where(_ => _.Status == StatusType.Active);

            var locationsWithDestinationEdges = queryable.ToList();

            var divisions = locationsWithDestinationEdges.Where(_ => _.Payload.Type == LocationType.Division);

            foreach (var division in divisions)
            {
                returnedDic.Add(division, GetChildreLocations(division.InnerId, locationsWithDestinationEdges));
            }

            return returnedDic;
        }

        private List<Location> GetChildreLocations(Guid locationId, List<Location> allLocations)
        {
            List<Location> returnedList = new List<Location>();

            var oneLevelchildrenIdsList = allLocations
                .Where(_ => _.InnerId == locationId)
                .SelectMany(_ => _.DestinationEdges!
                .Where(_ => _.Destination.Status == StatusType.Active && _.DestinationInnerId != locationId) // исключая ссылки на самого себя
                .Select(_ => _.Destination));

            returnedList.AddRange(oneLevelchildrenIdsList);

            foreach (var item in oneLevelchildrenIdsList)
            {
                returnedList.AddRange(GetChildreLocations(item.InnerId, allLocations));
            }

            return returnedList;
        }


    }
}
