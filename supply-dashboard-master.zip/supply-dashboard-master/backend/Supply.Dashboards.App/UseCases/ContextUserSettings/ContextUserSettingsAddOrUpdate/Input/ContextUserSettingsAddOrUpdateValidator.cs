﻿using FluentValidation;

namespace Supply.Dashboards.App.UseCases.ContextUserSettings.ContextUserSettingsAddOrUpdate.Input
{
    public sealed class ContextUserSettingsAddOrUpdateValidator
        : AbstractValidator<ContextUserSettingsAddOrUpdateQuery>
    {
        public ContextUserSettingsAddOrUpdateValidator()
        {
            ValidateContextId();
            ValidateUserId();
            ValidateDashboardsState();
        }

        private void ValidateContextId() =>
            RuleFor(_ => _.ContextId)
                .Must(_ => _ > 0);

        private void ValidateUserId() =>
            RuleFor(_ => _.UserId)
                .Must(_ => _ > 0);

        private void ValidateDashboardsState() =>
            RuleFor(_ => _.DashboardsState)
            .Must(_ => !string.IsNullOrEmpty(_));

    }
}
