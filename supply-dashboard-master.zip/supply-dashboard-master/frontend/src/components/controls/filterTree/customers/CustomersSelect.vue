<template>
  <div>
    <CustomerEdit
      ref="customerEditRef"
      :reloadTree="reloadCustomerTree"
      :loadDataItemFromApi="loadCustomerFromApi"
      :loadDataItemsFromApi="loadCustomersFromApi"
    />
    <DirectoryTree
      ref="customersDirectoryTreeRef"
      treeRef="customersTreeRef"
      :loadDataItemFromApi="loadCustomerFromApi"
      :loadDataItemsFromApi="loadCustomersFromApi"
      :createRootItem="createCustomersTreeRoot"
      :deleteDataItem="deleteCustomer"
      :addDataItem="addCustomer"
      :editDataItem="editCustomer"
      :setSelectedDataItems="setSelectedCustomers"
      :refreshTree="refreshCustomersTree"
      :pageType="pageType"
    />
  </div>
</template>

<script lang='ts'>
import Vue from "vue";

import { DxCheckBox } from "devextreme-vue/check-box";
import { Component, Prop, Watch } from "vue-property-decorator";
import DxButton from "devextreme-vue/button";
import { InputDataState, SettingsState } from "@/store";
import { InputDataService } from "@/services/inputDataService";
import { Guid } from "@/helpers/guid";
import { confirm } from "devextreme/ui/dialog";
import notify from "devextreme/ui/notify";
import DirectoryTree from "../DirectoryTree.vue";
import CustomerEdit from "./CustomerEdit.vue";
import {
  IDirectoryDataItem,
  IDirectoryTreeDataItem,
  ILocationDataItem,
  CustomerTypeEnum,
  ICustomer,
  IRelation,
  ISelectedCustomer,
  ITreeListSelectedItem,
} from "../types";
import { ICustomerForGrid } from "@/components/InputData/common/models";

@Component({
  components: {
    DxCheckBox,
    CustomerEdit,
    DxButton,
    DirectoryTree,
  },
})
export default class CustomersForm extends Vue {
  @Prop({ type: String, required: true }) public pageType!: string;

  private currentVisibleCheck: string = "";
  private _inputDataService!: InputDataService;
  private contextMenuClickItem!: any;
  private showTreeEdit: boolean = false;
  private customLoadTree: boolean = false;
  //private selectedСustomers: ISelectedCustomer[] = [];

  private created() {
    this._inputDataService = new InputDataService();
  }

  private mounted(): void {}

  public reloadCustomerTree(): any {
    this.customersTree.reloadTree();
  }
  private get CustomersTree() {
    return this.$refs["CustomersDirectoryTreeRef"] as DirectoryTree;
  }

  private refreshCustomersTree() {
    const pickedCustomersIds = SettingsState.pickedDashboardItem!.config
      ?.customersIds;
    const items: string[] = [];

    pickedCustomersIds?.forEach((id: string) => {
      const finedId = this.customersTree.getTreeItemIdByDbId(id);
      if (finedId) {
        items.push(finedId);
      }
    });

    const directoryTree = this.customersTree.directoryTree;

    SettingsState.setReadOnly(true);
    directoryTree.clearSelection();
    SettingsState.setReadOnly(false);
    directoryTree.selectRows(items, false);
  }

  private get customersTree() {
    return this.$refs["customersDirectoryTreeRef"] as DirectoryTree;
  }

  private addCustomer(parentDbId: string) {
    this.showTreeEdit = true;
    const newItem = {
      id: Guid.newGuid(),
      rowVersion: 0,
      type: CustomerTypeEnum.Inner,
      dbId: "",
      hasItems: false,
      parentIds: [parentDbId],
      title: "",
      description: "",
      childrenIds: [],
    };
    this.customerEdit.add(newItem);
  }

  private get customerEdit() {
    return this.$refs["customerEditRef"] as CustomerEdit;
  }

  private createCustomersTreeRoot(
    rootId: string,
    childrenIds: string[]
  ): IDirectoryTreeDataItem {
    return {
      id: rootId,
      rowVersion: 0,
      title: "Заказчики",
      description: "Корневой элемент",
      hasItems: childrenIds.length > 0 ? true : false,
      parentId: "",
    };
  }

  private async editCustomer(dbId: string) {
    const customer = await this._inputDataService.getCustomerForId(dbId);

    if (customer === null) {
      return;
    }

    this.customerEdit.edit({
      id: customer.id,
      rowVersion: customer.rowVersion,
      parentIds: customer.parentIds === undefined ? [] : customer.parentIds!,
      type: customer.type,
      title: customer.title === undefined ? "" : customer.title,
      description:
        customer.description === undefined ? "" : customer.description,
      childrenIds: customer.childrenIds,
    });
  }

  private async deleteCustomer(dbId: string) {
    const customer = await this._inputDataService.getCustomerForId(dbId);

    if (customer === null) {
      return;
    }

    const relations: IRelation[] = [];

    customer!.childrenIds.forEach((childrenId) => {
      relations.push({
        sourceId: customer!.id,
        destinationId: childrenId,
        isObsolete: true,
      });
    });

    customer!.parentIds!.forEach((parentDbId) => {
      relations.push({
        sourceId: parentDbId,
        destinationId: customer.id,
        isObsolete: true,
      });
    });

    this._inputDataService
      .saveCustomer(
        {
          id: customer.id,
          rowVersion: customer.rowVersion,
          isObsolete: true,
          title: customer.title,
          type: customer.type,
          childrenIds: customer.childrenIds,
        },
        relations
      )
      .then(() => {
        this.reloadCustomerTree();
      });
  }

  private async loadCustomerFromApi(dbId: string): Promise<IDirectoryDataItem> {
    const customers: ICustomer[] = await this._inputDataService.getActiveCustomersForIds(
      [dbId],
      []
    );
    return {
      id: customers[0].id,
      rowVersion: customers[0].rowVersion,
      parentIds:
        customers[0].parentIds === undefined ? [] : customers[0].parentIds!,
      title: customers[0].title === undefined ? "" : customers[0].title,
      childrenIds: customers[0].childrenIds,
      description: customers[0].description,
    };
  }

  private async loadCustomersFromApi(
    parentDbIds: any[],
    types: any[]
  ): Promise<IDirectoryDataItem[]> {
    const customers: ICustomer[] = await this._inputDataService.getActiveCustomersForParentIds(
      parentDbIds,
      types
    );

    if (customers !== null && customers !== undefined) {
      return customers.map((s) => {
        return {
          id: s.id,
          rowVersion: s.rowVersion,
          parentIds: s.parentIds === undefined ? [] : s.parentIds!,
          title: s.title === undefined ? "" : s.title,
          childrenIds: s.childrenIds,
          description: s.description,
        };
      });
    } else {
      return [];
    }
  }

  private async setSelectedCustomers(items: ITreeListSelectedItem[]) {
    if (this.pageType === "inputData") {
      const resultItems: ICustomerForGrid[] = [];
      const ids = items.filter((a) => a.selected).map<string>((s) => s.dbId);
      const finedEmptyItem = ids.find((s) => s === "");
      if (finedEmptyItem === undefined) {
        const customers: ICustomer[] = await this._inputDataService.getActiveCustomersForIds(
          ids,
          []
        );
        const finedCustomers = customers.map<ICustomerForGrid>((s) => {
          return { id: s.id, rowVersion: s.rowVersion, title: s.title! };
        });

        resultItems.push(...finedCustomers);
      } else {
        resultItems.push({ id: null, title: "Не указан" });
      }

      InputDataState.setSelectedCustomers(resultItems);
    }
  }
}
</script>

<style scoped>
.item-container {
  overflow: hidden;
  width: 100%;
  height: 26px;
}
.box {
  white-space: inherit;
}
.box div {
  width: 34px;
  float: left;
}
.box div.item-title {
  width: 300px;
  float: left;
  padding-left: 34px;
}

.action-buttons {
  position: absolute;
  left: 320px;
  width: 110px;
  margin-top: -5px;
}

.action-buttons div {
  float: left;
}
</style>