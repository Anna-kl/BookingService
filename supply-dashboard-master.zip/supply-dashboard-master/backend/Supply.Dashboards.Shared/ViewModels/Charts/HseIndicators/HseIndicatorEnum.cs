﻿namespace Supply.Dashboards.Shared.ViewModels.Charts.HseIndicators
{
    public enum HseIndicatorEnum
    {
        HSEDeath = 1,
        HSEDisability = 2,
        HSEMedicalCare = 3,
        HSENearMiss = 4,
        HSEDangerWarning = 5
    }
}
