﻿using FluentValidation;
using System;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.WeatherRestrictions.WeatherRestrictionDelete.Input
{
    public sealed class WeatherRestrictionDeleteValidator
        : AbstractValidator<WeatherRestrictionDeleteQuery>
    {
        public WeatherRestrictionDeleteValidator()
        {
            ValidateId();
        }

        private void ValidateId()
        {
            RuleFor(_ => _.Id)
                .Must(_ => _ != default);
        }
    }
}
