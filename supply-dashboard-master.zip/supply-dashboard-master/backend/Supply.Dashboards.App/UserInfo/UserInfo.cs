﻿using Supply.Dashboards.Domain.AggregatesModel.Core;

using System.Threading;

namespace Supply.Dashboards.App.UserInfo
{
    public sealed class UserInfo
    {
        private static readonly AsyncLocal<Context?> ContextLocal = new();
        private static readonly AsyncLocal<string?> UserNameIdentifierLocal = new();

        public static void SetValue(
            Context? context,
            string? userNameIdentifier)
        {
            ContextLocal.Value = context;
            UserNameIdentifierLocal.Value = userNameIdentifier;
        }

        public static Context? Context =>
            ContextLocal.Value;

        public static string? NameIdentifier() =>
            UserNameIdentifierLocal.Value;
    }
}
