﻿using Common.SeedWork;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Supply.Dashboards.App.UserInfo;
using Supply.Dashboards.Domain.AggregatesModel.Core;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;
using Supply.Dashboards.Domain.Types;

namespace Supply.Dashboards.Infrastructure.TypeConfigurations.AggregatesModel.MtrTypes
{
    public sealed class MtrTypeTypeConfig : IEntityTypeConfiguration<MtrType>
    {
        public void Configure(EntityTypeBuilder<MtrType> builder)
        {
            builder.ToTable("mtr_types");

            builder.HasKey(_ => _.Id);
            builder.HasAlternateKey(_ => _.InnerId);
            builder
                .Property(_ => _.Id)
                .ValueGeneratedOnAdd();

            builder
                .Property(_ => _.XMin)
                .HasColumnName("xmin")
                .HasColumnType("xid")
                .ValueGeneratedOnAddOrUpdate()
                .IsConcurrencyToken();

            builder
                .HasOne<Context>()
                .WithMany()
                .HasForeignKey("ContextId")
                .IsRequired();
            builder.HasQueryFilter(_ => UserInfo.Context == null
                ? EF.Property<int>(_, "ContextId") != 0
                : EF.Property<int>(_, "ContextId") == UserInfo.Context.Id);

            builder
                .Property(_ => _.Status)
                .HasConversion(
                    type => type.Id,
                    key => Enumeration.FromValue<StatusType>(key)!);

            builder.OwnsOne(_ => _.Payload);

            builder.Ignore(_ => _.DomainEvents);
        }
    }
}
