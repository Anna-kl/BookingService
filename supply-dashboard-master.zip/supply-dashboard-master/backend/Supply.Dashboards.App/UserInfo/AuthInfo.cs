﻿using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.Exceptions;
using Supply.Dashboards.Domain.AggregatesModel.Core;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;

namespace Supply.Dashboards.App.UserInfo
{
    public sealed class AuthInfo
    {
        private readonly ILogger<AuthInfo> _logger;
        private readonly ClaimsPrincipal? _principal;
        private readonly IAuthInfo _authInfo;

        public AuthInfo(
            ILogger<AuthInfo> logger,
            IPrincipal principal,
            IAuthInfo authInfo)
        {
            _logger = logger;
            _authInfo = authInfo;
            _principal = principal as ClaimsPrincipal;
        }

        public string? GetClientId()
        {
            return _principal
                ?.Claims
                .First(_ => _.Type == "client_id" && !string.IsNullOrWhiteSpace(_.Value))
                .Value;
        }

        public string? GetCurrentUserNameIdentifier() =>
            _principal
                ?.Claims
                .FirstOrDefault(_ => _.Type == ClaimTypes.NameIdentifier)
                ?.Value;

        public List<string> GetCurrentUserRoles() =>
            _principal
                ?.Claims
                .Where(_ => _.Type == ClaimTypes.Role && !string.IsNullOrWhiteSpace(_.Value))
                .Select(_ => _.Value)
                .ToList()!;

        public Context? GetCurrentUserContext()
        {
            var nameIdentifier = GetCurrentUserNameIdentifier();

            if (string.IsNullOrWhiteSpace(nameIdentifier))
                return null;

            //var isSuccess = RequestInfo.Query.TryGetValue("context_id", out var stringContextId);

            //if (isSuccess == false)
            //    throw new AppException("context_id in query can't be null.");

            //if (!int.TryParse(stringContextId, out var contextId))
            //    throw new AppException("context_id is not a type int.");

            var contextInnerId = Guid.Parse("91c8087f-4525-458c-a5b6-075f90aed7de");
            var context = _authInfo.GetContextByInnerId(contextInnerId);

            return context;
        }

        public void CreateUser()
        {
            var nameIdentifier = GetCurrentUserNameIdentifier();

            if (string.IsNullOrWhiteSpace(nameIdentifier))
                return;

            var context = _authInfo.GetContextByInnerId(
                Guid.Parse("91c8087f-4525-458c-a5b6-075f90aed7de"));

            if (context == null)
                throw new AppException("Context is null.");

            _logger.LogInformation($"Create user. ContextId: {context.Id}");

            _authInfo.CreateUser(nameIdentifier, context);
        }
    }
}
