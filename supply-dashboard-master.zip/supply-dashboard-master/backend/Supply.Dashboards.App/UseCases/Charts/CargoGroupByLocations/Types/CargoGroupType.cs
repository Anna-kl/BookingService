﻿using Common.SeedWork;
using Supply.Dashboards.App.Exceptions;
using Supply.Dashboards.Domain.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.Charts.CargoGroupByLocations.Types
{

    public sealed class CargoGroupType : Enumeration
    {
        public static CargoGroupType CargoHandlingFact = new(1, "CargoHandlingFact");
        public static CargoGroupType CargoHandlingPlan = new(2, "CargoHandlingPlan");
        public static CargoGroupType CargoHandlingAdjustedPlan = new(3, "CargoHandlingAdjustedPlan");
        public static CargoGroupType CargoHandlingDailyPlan = new(19, "CargoHandlingDailyPlan");
        public static CargoGroupType FreightTurnoverFact = new(5, "FreightTurnoverFact");
        public static CargoGroupType FreightTurnoverPlan = new(6, "FreightTurnoverPlan");
        public static CargoGroupType FreightTurnoverAdjustedPlan = new(7, "FreightTurnoverAdjustedPlan");
        public static CargoGroupType FreightTurnoverDailyPlan = new(20, "FreightTurnoverDailyPlan");

        public CargoGroupType(int id, string name) : base(id, name)
        {
        }

        internal static CargoGroupType GetCargoGroupType(ValueRecordType type)
        {
            var name = type.Name switch
            {
                nameof(ValueRecordType.CargoHandlingFact) => CargoHandlingFact.Name,
                nameof(ValueRecordType.CargoHandlingPlan) => CargoHandlingPlan.Name,
                nameof(ValueRecordType.CargoHandlingAdjustedPlan) => CargoHandlingAdjustedPlan.Name,
                nameof(ValueRecordType.CargoHandlingDailyPlan) => CargoHandlingDailyPlan.Name,
                nameof(ValueRecordType.FreightTurnoverFact) => FreightTurnoverFact.Name,
                nameof(ValueRecordType.FreightTurnoverPlan) => FreightTurnoverPlan.Name,
                nameof(ValueRecordType.FreightTurnoverAdjustedPlan) => FreightTurnoverAdjustedPlan.Name,
                nameof(ValueRecordType.FreightTurnoverDailyPlan) => FreightTurnoverDailyPlan.Name,

                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<CargoGroupType>(name)!;
        }
    }
}

