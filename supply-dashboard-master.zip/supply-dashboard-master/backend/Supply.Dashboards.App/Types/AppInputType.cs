﻿using Common.SeedWork;

using Supply.Dashboards.App.Exceptions;
using Supply.Dashboards.Domain.Types;

namespace Supply.Dashboards.App.Types
{
    public sealed class AppInputType : Enumeration
    {
        public static AppInputType Default = new(0, "Default");
        public static AppInputType ManualInput = new(1, "ManualInput");
        public static AppInputType Xlsx = new(2, "Xlsx");
        public static AppInputType Json = new(3, "Json");

        public AppInputType(int id, string name) : base(id, name)
        {
        }

        internal static InputType GetInputType(AppInputType type)
        {
            var name = type.Name switch
            {
                nameof(Default) => throw new AppException(nameof(Default)),
                nameof(ManualInput) => InputType.ManualInput.Name,
                nameof(Xlsx) => InputType.Xlsx.Name,
                nameof(Json) => InputType.Json.Name,
                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<InputType>(name)!;
        }

        internal static AppInputType GetAppInputType(InputType type)
        {
            var name = type.Name switch
            {
                nameof(InputType.ManualInput) => ManualInput.Name,
                nameof(InputType.Xlsx) => Xlsx.Name,
                nameof(InputType.Json) => Json.Name,
                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<AppInputType>(name)!;
        }
    }
}
