﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supply.Dashboards.Shared.ViewModels.Charts.FullnessBases
{
    public sealed class FullnessBasesByLocationsParamResponseViewModel
    {
        public Guid LocationId { get; set; }
        public string? LocationTitle { get; set; }

        public List<FullnessBasesUnitResponseViewModel>? Units { get; set; }
    }
}
