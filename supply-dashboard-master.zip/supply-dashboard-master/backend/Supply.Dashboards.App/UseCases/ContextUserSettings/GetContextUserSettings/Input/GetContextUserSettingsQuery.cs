﻿using FluentValidation.Results;

using MediatR;

using Supply.Dashboards.App.UseCases.ContextUserSettings.GetContextUserSettings.Output;

using System;
using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.ContextUserSettings.GetContextUserSettings.Input
{
    public sealed class GetContextUserSettingsQuery
        : IRequest<(ValidationResult validationResult, GetContextUserSettingsOutput? output)>
    {
        public GetContextUserSettingsQuery(
            int userId,
            int contextId)
        {
            UserId = userId;
            ContextId = contextId;

            ValidationResult = new GetContextUserSettingsValidator()
                .Validate(this);
        }

        public int UserId { get; }
        public int ContextId { get; }

        public ValidationResult ValidationResult { get; }
    }
}
