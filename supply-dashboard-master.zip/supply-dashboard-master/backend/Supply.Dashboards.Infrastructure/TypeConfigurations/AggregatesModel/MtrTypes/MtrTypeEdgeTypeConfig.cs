﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Supply.Dashboards.App.UserInfo;
using Supply.Dashboards.Domain.AggregatesModel.Core;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;

namespace Supply.Dashboards.Infrastructure.TypeConfigurations.AggregatesModel.MtrTypes
{
    public sealed class MtrTypeEdgeTypeConfig
        : IEntityTypeConfiguration<MtrTypeEdge>
    {
        public void Configure(EntityTypeBuilder<MtrTypeEdge> builder)
        {
            builder.ToTable("mtr_types_edges");

            builder.HasKey(_ => new { _.SourceId, _.DestinationId });

            builder
                .HasOne(_ => _.Source)
                .WithMany(_ => _.DestinationEdges)
                .HasForeignKey(_ => _.SourceId)
                .OnDelete(DeleteBehavior.NoAction);

            builder
                .HasOne(_ => _.Destination)
                .WithMany(_ => _.SourceEdges)
                .HasForeignKey(_ => _.DestinationId)
                .OnDelete(DeleteBehavior.NoAction);

            builder
                .HasIndex(_ => new { _.SourceInnerId, _.DestinationInnerId })
                .IsUnique();

            builder
                .HasOne<Context>()
                .WithMany()
                .HasForeignKey("ContextId")
                .IsRequired();
            builder.HasQueryFilter(_ => UserInfo.Context == null
                ? EF.Property<int>(_, "ContextId") != 0
                : EF.Property<int>(_, "ContextId") == UserInfo.Context.Id);
        }
    }
}