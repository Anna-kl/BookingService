﻿using System;
using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.Charts.TransportResources.Output
{
    public sealed class TransportResourcesByLocationsParamOutput
    {
        private readonly List<TransportResourcesUnitOutput> _units;

        internal TransportResourcesByLocationsParamOutput(
            Guid locationId,
            string locationTitle,
            List<TransportResourcesUnitOutput>? units)
        {
            LocationId = locationId;
            LocationTitle = locationTitle;
            _units = units ?? new List<TransportResourcesUnitOutput>();
        }

        public Guid LocationId { get; }
        public string LocationTitle { get; }

        public IEnumerable<TransportResourcesUnitOutput>? Units =>
            _units.AsReadOnly();
    }
}
