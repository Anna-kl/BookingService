﻿using Supply.Dashboards.Shared.Types;

using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Locations.LocationList
{
    public sealed class LocationListRequestViewModel
    {
        public List<StatusEnum>? Statuses { get; set; }
        public List<Guid?>? ParentIds { get; set; }
        public List<Guid>? Ids { get; set; }
        public List<LocationTypeEnum>? Types { get; set; }
    }
}
