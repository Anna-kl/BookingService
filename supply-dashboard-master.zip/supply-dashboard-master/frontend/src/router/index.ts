import Vue from 'vue'
import VueRouter, { RouteConfig } from 'vue-router'
import Index from '../views/Index.vue'
import InputData from '../views/InputData.vue'

Vue.use(VueRouter)

const routes: Array<RouteConfig> = [
  {
    path: '/',
    name: 'Index',
    component: Index
    },
    {
        path: '/inputdata',
        name: 'Input data',
        component: InputData
    }
]

const router = new VueRouter({
  routes
})

export default router
