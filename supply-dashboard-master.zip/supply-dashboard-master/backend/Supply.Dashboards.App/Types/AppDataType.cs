﻿using Common.SeedWork;

namespace Supply.Dashboards.App.Types
{
    public sealed class AppDataType : Enumeration
    {
#pragma warning disable CA2211 // Non-constant fields should not be visible
        public static AppDataType Default = new(0, "Default");
        public static AppDataType CargoHandling = new(1, "CargoHandling");
        public static AppDataType FreightTurnover = new(2, "FreightTurnover");
#pragma warning restore CA2211 // Non-constant fields should not be visible

        public AppDataType(int id, string name) : base(id, name)
        {
        }
    }
}
