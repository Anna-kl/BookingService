﻿using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.Charts.AccountingMtrByPeriods.Output
{
    public sealed class AccountingMtrByPeriodsOutput
    {
        private readonly List<AccountingMtrByPeriodsParamOutput> _periods;

        internal AccountingMtrByPeriodsOutput(List<AccountingMtrByPeriodsParamOutput> periods)
        {
            _periods = periods;
        }

        public IEnumerable<AccountingMtrByPeriodsParamOutput> Periods =>
            _periods.OrderBy(_ => _.Period).ToList().AsReadOnly();
    }
}
