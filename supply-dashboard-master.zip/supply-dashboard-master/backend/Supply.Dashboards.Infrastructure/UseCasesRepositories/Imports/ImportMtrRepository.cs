﻿using Common.SeedWork;

using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.UseCases.Imports.ImportMtr;
using Supply.Dashboards.Domain.AggregatesModel.Bids;
using Supply.Dashboards.Domain.AggregatesModel.Core;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.HseIncidents;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;
using Supply.Dashboards.Domain.AggregatesModel.ValueRecords;
using Supply.Dashboards.Domain.Types;
using Supply.Dashboards.Infrastructure.Data;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.Infrastructure.UseCasesRepositories.Imports
{
    public sealed class ImportMtrRepository : IImportMtr
    {
        private readonly ILogger<ImportMtrRepository> _logger;
        private readonly DashboardsContext _dashboardsContext;

        public ImportMtrRepository(
            ILogger<ImportMtrRepository> logger,
            DashboardsContext dashboardsContext)
        {
            _logger = logger;
            _dashboardsContext = dashboardsContext;
        }

        public IUnitOfWork UnitOfWork => _dashboardsContext;

        public async Task<IEnumerable<ValueRecord>> ValueRecordsGet(
            List<Customer> customers,
            List<Location> locations,
            List<MtrType> mtrTypes,
            List<ValueRecordType> valueRecordTypes,
            List<(DateTime startPeriod, DateTime endPeriod)> periodList,
            CancellationToken cancellationToken)
        {
            var queryable = _dashboardsContext
                .ValueRecords
                .Include(_ => _.Payload.Customer)
                .Include(_ => _.Payload.Location)
                .Include(_ => _.Payload.MtrType)
                .AsQueryable();

            if (customers.Any())
                queryable = queryable.Where(_ => customers.Contains(_.Payload.Customer!));

            if (locations.Any())
                queryable = queryable.Where(_ => locations.Contains(_.Payload.Location!));

            if (mtrTypes.Any())
                queryable = queryable.Where(_ => mtrTypes.Contains(_.Payload.MtrType!));

            if (valueRecordTypes.Any())
                queryable = queryable.Where(_ => valueRecordTypes.Contains(_.Payload.Type));

            if (periodList.Any())
                queryable = queryable.Where(_ =>
                    periodList.Select(tuple => tuple.startPeriod).Contains(_.Payload.StartPeriod)
                    && periodList.Select(tuple => tuple.endPeriod).Contains(_.Payload.EndPeriod));

            return (await queryable.ToListAsync(cancellationToken))
                .AsReadOnly();
        }

        public async Task<IEnumerable<ValueRecord>> ValueRecordsAdd(
            List<ValueRecord> records,
            CancellationToken cancellationToken)
        {
            await _dashboardsContext.ValueRecords.AddRangeAsync(
                records,
                cancellationToken);

            return records;
        }

        public void ValueRecordsRemove(ValueRecord record) =>
            _dashboardsContext
                .ValueRecords
                .Remove(record);

        public async Task<IEnumerable<HseIncident>> HseIncidentGet(
            List<Customer> customers,
            List<Location> locations,
            List<HseIncidentType> incidentTypes,
            List<DateTime> periodList,
            CancellationToken cancellationToken)
        {
            var queryable = _dashboardsContext
                .HseIncidents
                .Include(_ => _.Payload.Customer)
                .Include(_ => _.Payload.Location)
                .AsQueryable();

            if (customers.Any())
                queryable = queryable.Where(_ => customers.Contains(_.Payload.Customer!));

            if (locations.Any())
                queryable = queryable.Where(_ => locations.Contains(_.Payload.Location!));

            if (incidentTypes.Any())
                queryable = queryable.Where(_ => incidentTypes.Contains(_.Payload.Type));

            if (periodList.Any())
                queryable = queryable.Where(_ => periodList.Contains(_.Payload.DateTime.Date));

            return (await queryable.ToListAsync(cancellationToken))
                .AsReadOnly();
        }

        public async Task<IEnumerable<HseIncident>> HseIncidentsAdd(
            List<HseIncident> hseIncidents,
            CancellationToken cancellationToken)
        {
            await _dashboardsContext.HseIncidents.AddRangeAsync(
                hseIncidents,
                cancellationToken);

            return hseIncidents;
        }

        public void HseIncidentsRemove(HseIncident hseIncident) =>
            _dashboardsContext
                .HseIncidents
                .Remove(hseIncident);

        public void HseIncidentsRemove(List<HseIncident> hseIncidents) =>
            _dashboardsContext
                .HseIncidents
                .RemoveRange(hseIncidents);

        public async Task<IEnumerable<Bid>> BidsGet(
            List<Customer> customers,
            List<Location> locations,
            List<BidType> bidTypes,
            List<DateTime> periodList,
            CancellationToken cancellationToken)
        {
            var queryable = _dashboardsContext
                .Bids
                .Include(_ => _.Payload.Customer)
                .Include(_ => _.Payload.Location)
                .AsQueryable();

            if (customers.Any())
                queryable = queryable.Where(_ => customers.Contains(_.Payload.Customer!));

            if (locations.Any())
                queryable = queryable.Where(_ => locations.Contains(_.Payload.Location!));

            if (bidTypes.Any())
                queryable = queryable.Where(_ => bidTypes.Contains(_.Payload.Type));

            if (periodList.Any())
                queryable = queryable.Where(_ => periodList.Contains(_.Payload.DateTime.Date));

            return (await queryable.ToListAsync(cancellationToken))
                .AsReadOnly();
        }

        public async Task<IEnumerable<Bid>> BidsAdd(
            List<Bid> bids,
            CancellationToken cancellationToken)
        {
            await _dashboardsContext.Bids.AddRangeAsync(
                bids,
                cancellationToken);

            return bids;
        }

        public void BidsRemove(Bid hseIncident) =>
            _dashboardsContext
                .Bids
                .Remove(hseIncident);

        public void BidsRemove(List<Bid> bids) =>
            _dashboardsContext
                .Bids
                .RemoveRange(bids);

        public async Task<User?> GetUserByInnerId(
            Guid innerId,
            CancellationToken cancellationToken) =>
            await _dashboardsContext.Users.SingleOrDefaultAsync(
                _ => _.InnerId == innerId,
                cancellationToken);

        public async Task<IEnumerable<Customer>> GetCustomersByInnerIds(
            List<Guid> innerIds,
            CancellationToken cancellationToken) =>
            (await _dashboardsContext
                .Customers
                .Where(_ => _.Status == StatusType.Active)
                .Where(_ => innerIds.Contains(_.InnerId))
                .ToListAsync(cancellationToken)).AsReadOnly();

        public async Task<IEnumerable<Location>> GetLocationsByInnerIds(
            List<Guid> innerIds,
            CancellationToken cancellationToken) =>
            (await _dashboardsContext
                .Locations
                .Where(_ => _.Status == StatusType.Active)
                .Where(_ => innerIds.Contains(_.InnerId))
                .ToListAsync(cancellationToken))
            .AsReadOnly();

        public async Task<IEnumerable<MtrType>> GetMtrTypesByInnerIds(
            List<Guid> innerIds,
            CancellationToken cancellationToken) =>
            (await _dashboardsContext
                .MtrTypes
                .Where(_ => _.Status == StatusType.Active)
                .Where(_ => innerIds.Contains(_.InnerId))
                .ToListAsync(cancellationToken)).AsReadOnly();
    }
}