﻿using FluentValidation;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.WeatherRestrictions.GetWeatherRestrictionsList.Input
{
    public sealed class GetWeatherRestrictionsListValidator
        : AbstractValidator<GetWeatherRestrictionsListQuery>
    {
        public GetWeatherRestrictionsListValidator()
        {
            ValidateLocationsIds();
        }

        private void ValidateLocationsIds()
        {

            RuleForEach(_ => _.LocationIds)
                .Must(_ => _ != default);
        }
    }
}
