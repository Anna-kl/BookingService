﻿using Common.Extensions;
using Supply.Dashboards.Shared.Types;

using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.WeatherRestrictions.WeatherRestrictionsAddOrUpdate
{
    public sealed class WeatherRestrictionsAddOrUpdateRequestViewModel
    {
        public Guid? Id { get; set; }
        public DateTime DateTime { get; set; }
        public Guid locationId { get; set; }
        public Guid? customerId { get; set; } = null;
        public double Temperature { get; set; }
        public double WindSpeed { get; set; }
        public string? Aktirovka { get; set; }

    }
}
