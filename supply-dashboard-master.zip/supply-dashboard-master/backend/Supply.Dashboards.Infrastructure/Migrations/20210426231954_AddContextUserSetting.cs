﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Supply.Dashboards.Infrastructure.Migrations
{
    public partial class AddContextUserSetting : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "context_user_settings",
                columns: table => new
                {
                    contextid = table.Column<int>(type: "integer", nullable: false),
                    userid = table.Column<int>(type: "integer", nullable: false),
                    createat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    updateat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    dashboardsstate = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_context_user_settings", x => new { x.contextid, x.userid });
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "context_user_settings");
        }
    }
}
