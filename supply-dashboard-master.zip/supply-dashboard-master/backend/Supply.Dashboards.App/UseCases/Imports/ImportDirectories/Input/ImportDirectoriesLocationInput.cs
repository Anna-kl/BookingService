﻿using Common.SeedWork;

using Supply.Dashboards.App.Types;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.Types;

using System;

namespace Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Input
{
    public sealed class ImportDirectoriesLocationInput
    {
        public ImportDirectoriesLocationInput(
            Guid? id,
            uint rowVersion,
            AppLocationType? type,
            string? title,
            string? description,
            double? longitude,
            double? latitude,
            double? diameter,
            bool? isObsolete)
        {
            Id = id ?? default;
            XMin = rowVersion;
            Type = type ?? AppLocationType.Default;
            Title = title ?? string.Empty;
            Description = description;
            Longitude = longitude;
            Latitude = latitude;
            Diameter = diameter;
            IsObsolete = isObsolete;
        }

        public Guid Id { get; }
        public uint XMin { get; }
        public AppLocationType Type { get; }
        public string Title { get; }
        public string? Description { get; }

        public double? Longitude { get; }
        public double? Latitude { get; }
        public double? Diameter { get; }

        public bool? IsObsolete { get; }

        internal Location ToLocation()
        {
            return new Location(
                Id,
                new LocationPayload(
                    Enumeration.FromDisplayName<LocationType>(Type.Name)!,
                    Title,
                    Description,
                    Longitude,
                    Latitude,
                    Diameter));
        }
    }
}
