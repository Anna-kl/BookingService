﻿using System;

namespace Supply.Dashboards.Shared.ViewModels.WeatherRestrictions.WeatherRestrictionsList
{
    public sealed class WeatherRestrictionsListItemResponseViewModel
    {
        public Guid Id { get; set; }
        public DateTime DateTime { get; set; }
        public Guid? CustomerId { get; set; }
        public Guid LocationId { get; set; }
        public string LocationTitle { get; set; } = string.Empty;
        public double LocationLatitude { get; set; }
        public double LocationLongitude { get; set; }
        public double Temperature { get; set; }
        public double WindSpeed { get; set; }
        public string? Aktirovka { get; set; }
    }
}
