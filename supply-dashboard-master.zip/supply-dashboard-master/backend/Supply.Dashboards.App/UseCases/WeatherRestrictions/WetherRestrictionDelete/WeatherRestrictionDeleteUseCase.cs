﻿using FluentValidation.Results;

using MediatR;

using Microsoft.Extensions.Logging;
using Supply.Dashboards.App.UseCases.WeatherRestrictions.WeatherRestrictionDelete.Input;

using Supply.Dashboards.Domain.AggregatesModel.WeatherRestrictions;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.WeatherRestrictions.WeatherRestrictionDelete
{
    public sealed class WeatherRestrictionDeleteUseCase
        : IRequestHandler<WeatherRestrictionDeleteQuery, (ValidationResult validationResult, bool result)>
    {
        private readonly ILogger<WeatherRestrictionDeleteUseCase> _logger;
        private readonly IBaseUseCase _baseRepo;

        private ValidationResult _validationResult;

        public WeatherRestrictionDeleteUseCase(
            ILogger<WeatherRestrictionDeleteUseCase> logger,
            IBaseUseCase baseRepo)
        {
            _logger = logger;
            _baseRepo = baseRepo;
            _validationResult = new ValidationResult();
        }

        public async Task<(ValidationResult validationResult, bool result)> Handle(
            WeatherRestrictionDeleteQuery request,
            CancellationToken cancellationToken)
        {
            _validationResult = request.ValidationResult;

            if (!_validationResult.IsValid) return (_validationResult, false);

            var weatherRestriction = _baseRepo.GetFirstOrDefault<WeatherRestriction>(_ => _.InnerId == request.Id);

            if (weatherRestriction == null)
            {
                _validationResult.Errors.Add(new ValidationFailure(
                 "Id",
                 $"{nameof(WeatherRestriction)} with id \"{request.Id}\" is not exist."));

            }
            else
            {
                _baseRepo.Remove<WeatherRestriction>(weatherRestriction);
                await _baseRepo.UnitOfWork.SaveChangesAsync(cancellationToken);
            }

            return (_validationResult, true);
        }



    }
}
