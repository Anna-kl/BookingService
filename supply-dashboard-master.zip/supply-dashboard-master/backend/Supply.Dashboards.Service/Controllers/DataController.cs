﻿using Common.SeedWork;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Supply.Dashboards.App.UseCases.Data.DataMtr.Input;
using Supply.Dashboards.App.UseCases.Data.DataMtr.Types;
using Supply.Dashboards.Shared.Types;
using Supply.Dashboards.Shared.ViewModels.Data.DataMtr;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.Service.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public sealed class DataController : ControllerBase
    {
        private readonly ILogger<DataController> _logger;
        private readonly IMediator _mediator;

        public DataController(
            ILogger<DataController> logger,
            IMediator mediator)
        {
            _logger = logger;
            _mediator = mediator;
        }

        /// <summary>
        /// Get a MTR data with optional filtering
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [HttpPost("mtr")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<ActionResult<List<DataMtrResponseViewModel>?>> ImportMtr(
            [FromBody] DataMtrRequestViewModel request,
            CancellationToken cancellationToken)
        {
            var types = request
                .Types?
                .Select(_ => Enumeration.IsDefined<DataMtrType>(_.ToString())
                    ? Enumeration.FromDisplayName<DataMtrType>(_.ToString())!
                    : DataMtrType.Default
                )
                .ToList();

            var query = new DataMtrQuery(
                request.StartPeriod,
                request.EndPeriod == null
                    ? (DateTime?)null
                    : request.StartPeriod.Add(request.EndPeriod.Value),
                request.CustomersIds,
                request.LocationsIds,
                request.MtrTypesIds,
                types
            );

            if (!query.ValidationResult.IsValid)
            {
                return BadRequest(
                    query
                        .ValidationResult
                        .Errors
                        .Select(failure => new
                        {
                            failure.ErrorCode,
                            failure.ErrorMessage
                        })
                );
            }

            var (validationResult, dataMtrOutput) = await _mediator.Send(
                query,
                cancellationToken
            );

            if (!validationResult.IsValid)
            {
                return BadRequest(
                    query
                        .ValidationResult
                        .Errors
                        .Select(failure => new
                        {
                            failure.ErrorCode,
                            failure.ErrorMessage
                        })
                );
            }

            if (dataMtrOutput == null || !dataMtrOutput.Items.Any())
            {
                return NoContent();
            }

            return dataMtrOutput
                .Items
                .Select(output => new DataMtrResponseViewModel
                {
                    RowVersion = output.RowVersion,
                    StartPeriod = output.StartPeriod,
                    EndPeriod = output.EndPeriod.Date - output.StartPeriod.Date == TimeSpan.Zero
                        ? TimeSpan.FromDays(1)
                        : output.EndPeriod - output.StartPeriod,
                    CustomerId = output.CustomerId,
                    LocationId = output.LocationId,
                    MtrTypeId = output.MtrTypeId,
                    Value = output.Value,
                    Type = (ValueRecordEnum)Enum.Parse(typeof(ValueRecordEnum), output.Type.ToString()),
                    InputType = (InputTypeEnum)Enum.Parse(typeof(InputTypeEnum), output.InputType.ToString())
                })
                .ToList();
        }
    }
}
