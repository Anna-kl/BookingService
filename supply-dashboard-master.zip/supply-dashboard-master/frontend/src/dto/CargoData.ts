import { ChartPeriodEnum } from "./Dashboards";

export interface ICargoDataByPeriodsResponse {
    period: string;
    factUnit?: ICargoDataUnitResponse;
    planUnit?: ICargoDataUnitResponse;
    adjustedPlanUnit?: ICargoDataUnitResponse;
    dailyPlanUnit?: ICargoDataUnitResponse;
}

export interface ICargoDataByLocationsResponse {
    locationId: string;
    locationTitle: string;
    units: ICargoDataUnitResponse[];
}

export interface ICargoDataUnitResponse {
    tons: number;
    type: string;
}

export interface ICargoDataByPeriodsRequest {
    period: ChartPeriodEnum;
    dataType: string;
    startPeriod: string;
    duration?: string;
    locationsIds?: string[];
    customersIds?: string[];
    mtrTypesIds?: string[];
}

export interface ICargoDataByLocationsRequest {
    startPeriod: string;
    duration: string;
    dataType: string;
    locationType?: string;
    parentLocationId?: string;
    locationsIds?: string[];
    customersIds?: string[];
    mtrTypesIds?: string[];
}

export interface ICargoChartData {
    month?: string;
    locationId?: string;
    location?: string;
    fact?: number;
    plan?: number;
    adjustedPlan?: number;
    dailyPlan?: number;
}
