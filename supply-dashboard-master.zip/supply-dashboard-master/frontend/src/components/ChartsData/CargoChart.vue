<template>
  <div class="module-inner-container">
    <DxToolbar>
      <DxItem
        widget="dxButton"
        location="before"
        :options="homeButtonOptions"
        :disabled="selectedOnChartLocationId === ''"
        v-if="config.columns === 'location'"
      />
      <DxItem
        widget="dxButton"
        location="before"
        :options="backButtonOptions"
        :disabled="selectedOnChartLocationId === ''"
        v-if="config.columns === 'location'"
      />
      <DxItem location="after" v-if="config.columns === 'location'">
        <template #default>
          <DxDateBox
            width="150px"
            hint="Выбор даты данных"
            type="date"
            picker-type="calendar"
            displayFormat="dd.MM.yyyy"
            :on-value-changed="dateChanged"
            :value.sync="curDate"
          />
        </template>
      </DxItem>
      <DxItem
        widget="dxButton"
        location="after"
        :options="prevButtonOptions"
        v-if="!isDayChart"
      />
      <DxItem location="after" :text="periodText()" v-if="!isDayChart" />
      <DxItem
        widget="dxButton"
        location="after"
        :options="nextButtonOptions"
        v-if="!isDayChart"
      />
    </DxToolbar>
    <DxChart
      :data-source="dataSource"
      @pointClick="onPointClick"
      class="chart-module"
    >
      <DxCommonSeriesSettings
        :argument-field="config.columns"
        type="bar"
        hover-mode="allArgumentPoints"
        selection-mode="allArgumentPoints"
      >
        <DxLabel :visible="true" backgroundColor="none" :rotationAngle="-55">
          <DxFormat :precision="0" type="fixedPoint" />
          <DxFont color="white" />
        </DxLabel>
      </DxCommonSeriesSettings>
      <DxSeries
        v-for="seriesItem in series.filter((s) => s.value)"
        :key="seriesItem.id"
        :value-field="seriesItem.id"
        :name="seriesItem.name"
        :color="seriesItem.color"
      />
      <DxTitle :text="title" horizontalAlignment="left">
        <DxSubtitle text="тыс тонн">
          <DxFont color="#42a2f6" />
        </DxSubtitle>
      </DxTitle>
      <DxLegend vertical-alignment="bottom" horizontal-alignment="center" />
      <DxTooltip :enabled="true" :customize-tooltip="customizeTooltip">
        <DxFormat :precision="3" type="fixedPoint" />
      </DxTooltip>
    </DxChart>
  </div>
</template>

<script lang='ts'>
import {
  DxChart,
  DxSeries,
  DxCommonSeriesSettings,
  DxLabel,
  DxFormat,
  DxLegend,
  DxTooltip,
  DxTitle,
  DxSubtitle,
  DxFont,
} from "devextreme-vue/chart";
import { Component, Prop } from "vue-property-decorator";
import {
  getYearStart,
  getYearEnd,
  getMonthStart,
  getMonthEnd,
  getShortMonth,
  getDuration,
  addMonth,
  roundDate,
  addDurationToDate,
  yesterdayDate,
  utcFromLocalDate,
} from "@/helpers/utils";
import config from "@/config";
import notify from "devextreme/ui/notify";
import {
  ICargoDataByPeriodsRequest,
  ICargoChartData,
  ICargoDataByPeriodsResponse,
  ICargoDataByLocationsResponse,
  ICargoDataByLocationsRequest,
} from "@/dto/CargoData";
import {
  ChartPeriodEnum,
  GraphLocationGroupEnum,
  IModuleConfig,
  IModuleSeries,
} from "@/dto/Dashboards";
import { ChartDataService } from "@/services/chartDataService";
import DxButton from "devextreme-vue/button";
import DxToolbar, { DxItem } from "devextreme-vue/toolbar";
import { DateTimeFormatOptions } from "luxon";
import Chart from "./chart";
import { SettingsState } from "@/store";
import { MtrItemTypeEnum } from "@/dto/InputData";
import DxDateBox from "devextreme-vue/date-box";

@Component({
  components: {
    DxChart,
    DxSeries,
    DxCommonSeriesSettings,
    DxLabel,
    DxFormat,
    DxLegend,
    DxTooltip,
    DxTitle,
    DxSubtitle,
    DxFont,
    DxButton,
    DxToolbar,
    DxItem,
    DxDateBox,
  },
})
export default class CargoChart extends Chart {
  @Prop({ type: Object, required: false }) public config!: IModuleConfig;
  @Prop({ type: Array, required: false }) public series!: IModuleSeries[];

  private title: string = "";
  private url: string = "";
  private dataSource: ICargoChartData[] = [];
  private curDate: Date = yesterdayDate();
  private isDayChart: boolean = this.config?.period === ChartPeriodEnum.Day;
  private selectedOnChartLocationId: string = "";
  private navigateHistory: string[] = [];
  private _chartDataService!: ChartDataService;

  public update() {
    this.getData(this.curDate);
  }

  private created() {
    this._chartDataService = new ChartDataService();
  }

  private mounted(): void {
    switch (this.config.type) {
      case "FreightTurnover":
        this.title = "Грузооборот";
        break;
      case "CargoHandling":
      default:
        this.title = "Грузопереработка";
        break;
    }

    this.getData(this.curDate);
  }

  private onPointClick({ target }: any) {
    this.selectedOnChartLocationId = target.data.locationId;
    this.navigateHistory.push(target.data.locationId);
    this.update();
  }

  private navigateToHome() {
    this.selectedOnChartLocationId = "";
    this.navigateHistory = [];
    this.update();
  }

  private navigateToBack() {
    if (this.navigateHistory.length <= 1) {
      this.navigateToHome();
    } else {
      this.navigateHistory.pop();
      this.selectedOnChartLocationId = this.navigateHistory[
        this.navigateHistory.length - 1
      ];
      this.update();
    }
  }
  private homeButtonOptions = {
    icon: "home",
    hint: "Отображить значения по умолчанию",
    onClick: () => this.navigateToHome(),
  };

  private backButtonOptions = {
    icon: "arrowleft",
    hint: "Назад",
    onClick: () => this.navigateToBack(),
  };

  private prevButtonOptions = {
    icon: "arrowleft",
    hint: "Предыдущий период",
    onClick: () => this.prevPeriod(),
  };

  private nextButtonOptions = {
    icon: "arrowright",
    hint: "Следующий период",
    onClick: () => this.nextPeriod(),
  };

  private dateChanged(args: any) {
    this.curDate = args.value;
    this.update();
  }
  private getData(curDate: Date) {
    let startPeriod: string;
    let duration: string | undefined;

    switch (this.config?.period) {
      case ChartPeriodEnum.Year:
        startPeriod = getYearStart(curDate);
        duration = getDuration(startPeriod, getYearEnd(curDate));
        break;
      case ChartPeriodEnum.Day:
        startPeriod = getMonthStart(curDate);
        duration = getDuration(startPeriod, utcFromLocalDate(curDate));
        break;
      case ChartPeriodEnum.Month:
      default:
        startPeriod = getMonthStart(curDate);
        duration = getDuration(startPeriod, getMonthEnd(curDate));
        break;
    }

    switch (this.config?.columns) {
      case "location":
        this.url = config.remoteHost + "/api/dashboards/cargo-by-locations";
        this.getLocationData(startPeriod, duration);
        break;
      case "period":
      default:
        this.url = config.remoteHost + "/api/dashboards/cargo-by-periods";
        this.getPeriodData(startPeriod, duration);
        break;
    }
  }

  private async getPeriodData(startPeriod: string, duration?: string) {
    this.dataSource = [];
    const requestPeriod = config.durationPickerValues.find(
      (value) => value.chartPeriod === this.config.period
    )!.groupBy;

    const request: ICargoDataByPeriodsRequest = {
      period: requestPeriod,
      dataType: this.config.type || "",
      startPeriod,
      duration,
      locationsIds:
        this.config.locationsIds !== undefined
          ? this.config.locationsIds
              ?.filter((f) => f.selected)
              .map<string>((s) => s.dbId)
          : [],
      customersIds: this.config.customersIds || [],
      mtrTypesIds: this.config.mtrTypesIds || [],
    };

    await this._chartDataService
      .getCargoDataByPeriods(this.url, request)
      .then((data) => {
        if (data) {
          switch (this.config.period) {
            case ChartPeriodEnum.Month:
              for (let i = 0; i < Number(duration); i++) {
                const xValue = addDurationToDate(startPeriod, i);

                const obj = {
                  period: xValue.getDate(),
                  fact: 0,
                  plan: 0,
                  adjustedPlan: 0,
                  dailyPlan: 0,
                };

                const dayData = (data as ICargoDataByPeriodsResponse[])?.filter(
                  (x) =>
                    new Date(x.period).toDateString() == xValue.toDateString()
                )[0];

                if (dayData !== undefined) {
                  obj.fact = dayData.factUnit?.tons ?? 0;
                  obj.plan = dayData.planUnit?.tons ?? 0;
                  obj.adjustedPlan = dayData.adjustedPlanUnit?.tons ?? 0;
                  obj.dailyPlan = dayData.dailyPlanUnit?.tons ?? 0;
                }

                this.dataSource.push(obj);
              }
              break;
            case ChartPeriodEnum.Year:
            default:
              for (let i = 0; i < 12; i++) {
                const obj = {
                  period: getShortMonth(i),
                  fact: 0,
                  plan: 0,
                  adjustedPlan: 0,
                  dailyPlan: 0,
                };

                const monthData = (data as ICargoDataByPeriodsResponse[])?.filter(
                  (x) => new Date(x.period).getMonth() == i
                )[0];

                if (monthData !== undefined) {
                  obj.fact = monthData.factUnit?.tons ?? 0;
                  obj.plan = monthData.planUnit?.tons ?? 0;
                  obj.adjustedPlan = monthData.adjustedPlanUnit?.tons ?? 0;
                  obj.dailyPlan = monthData.dailyPlanUnit?.tons ?? 0;
                }

                this.dataSource.push(obj);
              }
              break;
          }
        }
      })
      .catch((errors: any) => {
        notify(errors.title, "error", 2000);
        throw new Error(errors.title);
      });
  }

  private async getLocationData(startPeriod: string, duration: string) {
    this.dataSource = [];
    const request: ICargoDataByLocationsRequest = {
      startPeriod,
      duration,
      locationType:
        this.config.defaultLocationsGroup! ===
          GraphLocationGroupEnum.Division &&
        this.selectedOnChartLocationId === ""
          ? "Division"
          : "All",
      dataType: this.config.type || "",
      parentLocationId: this.selectedOnChartLocationId,
      locationsIds: this.config.locationsIds
        ?.filter((f) => f.selected)
        .map<string>((s) => s.dbId),
      customersIds: this.config.customersIds,
      mtrTypesIds: this.config.mtrTypesIds,
    };

    if (duration) {
      request.duration = duration;
    }

    await this._chartDataService
      .getCargoDataByLocations(this.url, request)
      .then((data) => {
        if (data) {
          (data as ICargoDataByLocationsResponse[]).forEach((element) => {
            const obj: ICargoChartData = {
              locationId: element.locationId,
              location: element.locationTitle,
              plan:
                element.units.find(
                  (s) =>
                    s.type ===
                      MtrItemTypeEnum[MtrItemTypeEnum.CargoHandlingPlan] ||
                    s.type ===
                      MtrItemTypeEnum[MtrItemTypeEnum.FreightTurnoverPlan]
                )?.tons ?? 0,
              fact:
                element.units.find(
                  (s) =>
                    s.type ===
                      MtrItemTypeEnum[MtrItemTypeEnum.CargoHandlingFact] ||
                    s.type ===
                      MtrItemTypeEnum[MtrItemTypeEnum.FreightTurnoverFact]
                )?.tons ?? 0,
              adjustedPlan:
                element.units.find(
                  (s) =>
                    s.type ===
                      MtrItemTypeEnum[
                        MtrItemTypeEnum.CargoHandlingAdjustedPlan
                      ] ||
                    s.type ===
                      MtrItemTypeEnum[
                        MtrItemTypeEnum.FreightTurnoverAdjustedPlan
                      ]
                )?.tons ?? 0,
              dailyPlan:
                element.units.find(
                  (s) =>
                    s.type ===
                      MtrItemTypeEnum[MtrItemTypeEnum.CargoHandlingDailyPlan] ||
                    s.type ===
                      MtrItemTypeEnum[MtrItemTypeEnum.FreightTurnoverDailyPlan]
                )?.tons ?? 0,
            };
            this.dataSource.push(obj);
          });
        }
      })
      .catch((errors: any) => {
        notify(errors.title, "error", 2000);
        throw new Error(errors.title);
      });
  }

  private prevPeriod() {
    switch (this.config?.period) {
      case ChartPeriodEnum.Year:
        this.curDate.setFullYear(this.curDate.getFullYear() - 1);
        break;
      case ChartPeriodEnum.Month:
      default:
        this.curDate = addMonth(this.curDate, -1);
        break;
    }
    this.getData(this.curDate);
  }

  private nextPeriod() {
    switch (this.config?.period) {
      case ChartPeriodEnum.Year:
        this.curDate.setFullYear(this.curDate.getFullYear() + 1);
        break;
      case ChartPeriodEnum.Month:
      default:
        this.curDate = addMonth(this.curDate, 1);
        break;
    }
    this.getData(this.curDate);
  }

  private periodText() {
    let result: string;
    switch (this.config?.period) {
      case ChartPeriodEnum.Month:
        result = `${this.curDate.toLocaleString("ru", {
          month: "long",
        })} ${this.curDate.getFullYear()}`;
        break;
      case ChartPeriodEnum.Year:
      default:
        result = this.curDate.getFullYear().toString();
        break;
    }
    return result;
  }

  private customizeTooltip(pointInfo: any) {
    return {
      text: `${pointInfo.argument}(${pointInfo.seriesName}): ${pointInfo.valueText}`,
    };
  }
}
</script>
<style scoped>
.dx-toolbar {
  background: none;
}
</style>