import { ChartPeriodEnum } from "./Dashboards";

export interface IAccountingMtrResponse {
    periods: IAccountingMtrPeriodResponse[];
}

export interface IAccountingMtrPeriodResponse {
    period: ChartPeriodEnum;
    units: IAccountingMtrUnitResponse[];
}

export interface IAccountingMtrUnitResponse {
    tons: number;
    type: string;
}

export interface IAccountingMtrRequest {
    period: ChartPeriodEnum;
    startPeriod: string;
    duration?: string;
    locationsIds?: string[];
    customersIds?: string[];
    mtrTypesIds?: string[];
}

export interface IAccountingMtrChartData {
    period: string;
    totalSupplies?: number;
    processing?: number;
    uncapitalize0_14?: number;
    uncapitalize15_30?: number;
    uncapitalize31_60?: number;
    uncapitalize61More?: number;
}

export class AccountingMtrResponse implements IAccountingMtrResponse {
    periods: IAccountingMtrPeriodResponse[];
    constructor(periods: IAccountingMtrPeriodResponse[] = []) {
        if (!periods) { throw new Error('DTO is not set'); }
        this.periods = periods;
    }
}
