﻿using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.Charts.TransportResources.Output
{
    public sealed class TransportResourcesByLocationsOutput
    {
        private readonly List<TransportResourcesByLocationsParamOutput> _locations;

        internal TransportResourcesByLocationsOutput(List<TransportResourcesByLocationsParamOutput> locations)
        {
            _locations = locations;
        }
        public IEnumerable<TransportResourcesByLocationsParamOutput> Locations =>
            _locations.OrderBy(_ => _.LocationTitle).ToList().AsReadOnly();

    }
}
