import { ITreeListMtrItemDataType } from './components/controls/filterTree/mtrItemTypes/MtrItemTypesSelect';
import { MtrItemTypeEnum } from './dto/InputData';
import { ChartPeriodEnum, DurationPickerData, GraphLocationGroupData, GraphLocationGroupEnum, IModuleItem, IDashboard, ModuleTypeEnum, IDashboardLayout, IDashboardItem } from './dto/Dashboards';
import { getBaseUrl, getLocationOrigin } from './helpers/utils';

// https://cli.vuejs.org/guide/mode-and-env.html#environment-variables
// If project is build use 'serve' command (isDev), automatically will
// be used variables from .env file.
// You can locally override them in .env.local file, and this will be ignored by git.

const isDev = process.env.NODE_ENV === 'development';
const remoteHost = isDev
    ? process.env.VUE_APP_REMOTE_HOST
    : getLocationOrigin();
const authHost = isDev 
    ? process.env.VUE_APP_AUTH_HOST
    : process.env.VUE_APP_AUTH_HOST_PROD;
const applicationHost = getBaseUrl();
const durationPickerValues: DurationPickerData[] = [
    {
        text: "Год",
        chartPeriod: ChartPeriodEnum.Year,
        groupBy: ChartPeriodEnum.Month,
        defaultPicker: true

    },
    {
        text: "Месяц",
        chartPeriod: ChartPeriodEnum.Month,
        groupBy: ChartPeriodEnum.Day,
        defaultPicker: true
    },
    {
        text: "День",
        chartPeriod: ChartPeriodEnum.Day,
        groupBy: ChartPeriodEnum.Day,
    },
];

const graphLocationGroupValues: GraphLocationGroupData[] = [
    {
        text: "Суммировать в дивизионы",
        locationsGroup: GraphLocationGroupEnum.Division,
        defaultPicker: true
    },
    {
        text: "По отдельности, с данными",
        locationsGroup: GraphLocationGroupEnum.AllLocationsWithData,
        defaultPicker: false
    },
];

const defaultDashboardItems: IDashboardItem[] = [
    {
        id: "1",
        x: 0,
        y: 0,
        moduleId: "FreightTurnover_Period"
    },
    {
        id: "2",
        x: 3,
        y: 0,
        moduleId: "CargoHandling_Period"
    },
    {
        id: "3",
        x: 6,
        y: 0,
        moduleId: "HSE"
    },
    {
        id: "6",
        x: 8,
        y: 0,
        moduleId: "OTIF"
    },
    {
        id: "4",
        x: 0,
        y: 2,
        moduleId: "FreightTurnover_Locations"
    },
    {
        id: "5",
        x: 3,
        y: 2,
        moduleId: "CargoHandling_Locations"
    },
    {
        id: "8",
        x: 6,
        y: 2,
        moduleId: "AccountingMtr"
    },
    {
        id: "12",
        x: 8,
        y: 2,
        moduleId: "WeatherRestrictions"
    },
    {
        id: "7",
        x: 0,
        y: 4,
        moduleId: "SeasonalDelivery"
    },

    {
        id: "9",
        x: 3,
        y: 4,
        moduleId: "TransportResource"
    },
    {
        id: "10",
        x: 6,
        y: 4,
        moduleId: "ExecutionOfOrders"
    },
    {
        id: "13",
        x: 0,
        y: 6,
        moduleId: "GPMResource"
    },
    {
        id: "14",
        x: 3,
        y: 6,
        moduleId: "LaborResource"
    },
    {
        id: "15",
        x: 6,
        y: 6,
        moduleId: "Arrival"
    },
    {
        id: "16",
        x: 0,
        y: 9,
        moduleId: "Expenditure"
    },
    {
        id: "17",
        x: 3,
        y: 8,
        moduleId: "FullnessBasesByCurrency"
    },
    {
        id: "18",
        x: 6,
        y: 8,
        moduleId: "FullnessBasesByWeight"
    },
    {
        id: "11",
        x: 0,
        y: 8,
        moduleId: "FullnessBases"
    },
];
const allDashboardModules: IModuleItem[] = [
    {
        id: "FreightTurnover_Period",
        name: "Грузооборот, по периодам",
        defaultMinHeight: 2,
        defaultMinWidth: 2,
        defaultHeight: 2,
        defaultWidth: 3,
        type: ModuleTypeEnum.CargoChart,
        defaultSeries: [
            {
                id: 'plan',
                name: 'План',
                color: '#42a2f6',
                value: true,
            },
            {
                id: 'adjustedPlan',
                name: 'Скорректированный план',
                color: '#071de0',
                value: false
            },
            {
                id: 'dailyPlan',
                name: 'Суточный план',
                color: '#33176f',
                value: false
            },
            {
                id: 'fact',
                name: 'Факт',
                color: '#8dc548',
                value: true,
            }
        ],
        defaultConfig: {
            columns: "period",
            type: "FreightTurnover",
            period: ChartPeriodEnum.Year
        }
    },
    {
        id: "CargoHandling_Period",
        name: "Грузопереработка, по периодам",
        defaultMinHeight: 2,
        defaultMinWidth: 2,
        defaultHeight: 2,
        defaultWidth: 3,
        type: ModuleTypeEnum.CargoChart,
        defaultSeries: [
            {
                id: 'plan',
                name: 'План',
                color: '#42a2f6',
                value: true,
            },
            {
                id: 'adjustedPlan',
                name: 'Скорректированный план',
                color: '#071de0',
                value: false
            }, {
                id: 'dailyPlan',
                name: 'Суточный план',
                color: '#33176f',
                value: false
            },
            {
                id: 'fact',
                name: 'Факт',
                color: '#8dc548',
                value: true,
            }
        ],
        defaultConfig: {
            columns: "period",
            type: "CargoHandling",
            period: ChartPeriodEnum.Year
        }
    },
    {
        id: "HSE",
        name: "HSE",
        defaultMinHeight: 2,
        defaultMinWidth: 2,
        defaultHeight: 2,
        defaultWidth: 2,
        type: ModuleTypeEnum.HSEValues,
        defaultConfig: {
            period: ChartPeriodEnum.Year
        },
    },
    {
        id: "FreightTurnover_Locations",
        name: "Грузооборот, по локациям",
        defaultMinHeight: 2,
        defaultMinWidth: 2,
        defaultHeight: 2,
        defaultWidth: 3,
        type: ModuleTypeEnum.CargoChart,
        defaultSeries: [
            {
                id: 'plan',
                name: 'План',
                color: '#42a2f6',
                value: true,
            },
            {
                id: 'adjustedPlan',
                name: 'Скорректированный план',
                color: '#071de0',
                value: false
            },
            {
                id: 'dailyPlan',
                name: 'Суточный план',
                color: '#33176f',
                value: false
            },
            {
                id: 'fact',
                name: 'Факт',
                color: '#8dc548',
                value: true,
            }
        ],
        defaultConfig: {
            columns: "location",
            type: "FreightTurnover",
            period: ChartPeriodEnum.Day,
            defaultLocationsGroup: GraphLocationGroupEnum.Division
        }
    },
    {
        id: "CargoHandling_Locations",
        name: "Грузопереработка, по периодам",
        defaultMinHeight: 2,
        defaultMinWidth: 2,
        defaultHeight: 2,
        defaultWidth: 3,
        type: ModuleTypeEnum.CargoChart,
        defaultSeries: [
            {
                id: 'plan',
                name: 'План',
                color: '#42a2f6',
                value: true,
            },
            {
                id: 'adjustedPlan',
                name: 'Скорректированный план',
                color: '#071de0',
                value: false
            },
            {
                id: 'dailyPlan',
                name: 'Суточный план',
                color: '#33176f',
                value: false
            },
            {
                id: 'fact',
                name: 'Факт',
                color: '#8dc548',
                value: true,
            }
        ],
        defaultConfig: {
            columns: "location",
            type: "CargoHandling",
            period: ChartPeriodEnum.Day,
            defaultLocationsGroup: GraphLocationGroupEnum.Division
        }
    },
    {
        id: "OTIF",
        name: "OTIF",
        defaultMinHeight: 2,
        defaultMinWidth: 2,
        defaultHeight: 2,
        defaultWidth: 2,
        type: ModuleTypeEnum.OTIFValues,
        defaultConfig: {
            period: ChartPeriodEnum.Month,
            allowPeriods: [ChartPeriodEnum.Day, ChartPeriodEnum.Month, ChartPeriodEnum.Year]
        },
    },
    {
        id: "SeasonalDelivery",
        name: "Сезонный завоз",
        defaultMinHeight: 2,
        defaultMinWidth: 2,
        defaultHeight: 2,
        defaultWidth: 3,
        type: ModuleTypeEnum.SeasonalDeliveryChart,
        defaultConfig: {
            columns: "location",
        },
        defaultSeries: [
            {
                id: 'plan',
                name: 'Накопительный план',
                color: '#42a2f6',
                value: true,
            },
            {
                id: 'adjustedPlan',
                name: 'Накопительный скор. план',
                color: '#071de0',
                value: false,
            },
            {
                id: 'dailyPlan',
                name: 'Накопительный суточный план',
                color: '#33176f',
                value: false,
            }, {
                id: 'fact',
                name: 'Накопительный факт',
                color: '#8dc548',
                value: true,
            },
        ],
    },
    {
        id: "AccountingMtr",
        name: "Учет МТР",
        defaultMinHeight: 2,
        defaultMinWidth: 2,
        defaultHeight: 2,
        defaultWidth: 2,
        type: ModuleTypeEnum.AccountingMtr,
        defaultConfig: {
            period: ChartPeriodEnum.Year
        },
        defaultSeries: [
            {
                id: 'processing',
                name: 'В работе',
                color: '#11FF55',
                value: true,
                stack: "processing"
            },
            {
                id: 'totalSupplies',
                name: 'Итого поставок',
                color: '#00B0F0',
                value: true,
                stack: "total"
            },
            {
                id: 'uncapitalize0_14',
                name: 'Не оприходованно 0-14',
                color: '#FBE5D6',
                value: true,
                stack: "uncapitalize"
            },
            {
                id: 'uncapitalize15_30',
                name: '15-30',
                color: '#F8CBAD',
                value: true,
                stack: "uncapitalize"
            }, {
                id: 'uncapitalize31_60',
                name: '31-60',
                color: '#F4B183',
                value: true,
                stack: "uncapitalize"
            }, {
                id: 'uncapitalize61More',
                name: '>60',
                color: '#C55A11',
                value: true,
                stack: "uncapitalize"
            }
        ],
    },
    {
        id: "TransportResource",
        name: "Транспортные ресурсы",
        defaultMinHeight: 2,
        defaultMinWidth: 2,
        defaultHeight: 2,
        defaultWidth: 3,
        type: ModuleTypeEnum.TransportResourceChart,
        defaultConfig: {
            columns: "location",
            defaultLocationsGroup: GraphLocationGroupEnum.Division
        },
        defaultSeries: [
            {
                id: 'transportPlan',
                name: 'План транспорт',
                color: '#42a2f6',
                value: true,
            },
            {
                id: 'transportFact',
                name: 'Факт транспорт',
                color: '#071de0',
                value: true,
            }
        ],
    },
    {
        id: "GPMResource",
        name: "ГПМ",
        defaultMinHeight: 2,
        defaultMinWidth: 2,
        defaultHeight: 2,
        defaultWidth: 3,
        type: ModuleTypeEnum.GPMResourceChart,
        defaultConfig: {
            columns: "location",
            defaultLocationsGroup: GraphLocationGroupEnum.Division
        },
        defaultSeries: [
            {
                id: 'GPMPlan',
                name: 'План',
                color: '#42a2f6',
                value: true,
            }, {
                id: 'GPMFact',
                name: 'Факт',
                color: '#071de0',
                value: true,
            }
        ],
    },

    {
        id: "LaborResource",
        name: "Трудовые ресурсы",
        defaultMinHeight: 2,
        defaultMinWidth: 2,
        defaultHeight: 2,
        defaultWidth: 3,
        type: ModuleTypeEnum.LaborResourceChart,
        defaultConfig: {
            columns: "location",
            defaultLocationsGroup: GraphLocationGroupEnum.Division
        },
        defaultSeries: [
            {
                id: 'laborResourcesPlan',
                name: 'План',
                color: '#42a2f6',
                value: true,
            }, {
                id: 'laborResourcesFact',
                name: 'Факт',
                color: '#071de0',
                value: true,
            },
        ],
    },
    {
        id: "ExecutionOfOrders",
        name: "Исполнение заявок",
        defaultMinHeight: 2,
        defaultMinWidth: 2,
        defaultHeight: 2,
        defaultWidth: 2,
        type: ModuleTypeEnum.ExecutionOfOrdersChart,
        defaultConfig: {
            columns: "date",
            defaultLocationsGroup: GraphLocationGroupEnum.Division
        },
        defaultSeries: [
            {
                id: 'forecast',
                name: 'Прогноз',
                color: '#f7c142',
                value: true,
            },
            {
                id: 'plan',
                name: 'Заявлено',
                color: '#58a2f1',
                value: true,
            },
            {
                id: 'totalFact',
                name: 'Факт на вчерашний день',
                color: '#97b763',
                value: true,
            }
        ],
    },
    {
        id: "Arrival",
        name: "Приход",
        defaultMinHeight: 2,
        defaultMinWidth: 2,
        defaultHeight: 2,
        defaultWidth: 3,
        type: ModuleTypeEnum.ArrivalChart,
        defaultSeries: [
            {
                id: 'plan',
                name: 'План',
                color: '#42a2f6',
                value: true,
            },
            {
                id: 'adjustedPlan',
                name: 'Скорректированный план',
                color: '#071de0',
                value: false
            },
            {
                id: 'dailyPlan',
                name: 'Суточный план',
                color: '#33176f',
                value: false
            },
            {
                id: 'fact',
                name: 'Факт',
                color: '#8dc548',
                value: true,
            }
        ],
        defaultConfig: {
            columns: "location",
            period: ChartPeriodEnum.Day,
            defaultLocationsGroup: GraphLocationGroupEnum.Division
        }
    },

    {
        id: "Expenditure",
        name: "Расход",
        defaultMinHeight: 2,
        defaultMinWidth: 2,
        defaultHeight: 2,
        defaultWidth: 3,
        type: ModuleTypeEnum.ExpenditureChart,
        defaultSeries: [
            {
                id: 'plan',
                name: 'План',
                color: '#42a2f6',
                value: true,
            },
            {
                id: 'adjustedPlan',
                name: 'Скорректированный план',
                color: '#071de0',
                value: false
            },
            {
                id: 'dailyPlan',
                name: 'Суточный план',
                color: '#33176f',
                value: false
            },
            {
                id: 'fact',
                name: 'Факт',
                color: '#8dc548',
                value: true,
            }
        ],
        defaultConfig: {
            columns: "location",
            period: ChartPeriodEnum.Day,
            defaultLocationsGroup: GraphLocationGroupEnum.Division
        }
    },
    {
        id: "FullnessBases",
        name: "Загруженность баз",
        defaultMinHeight: 2,
        defaultMinWidth: 2,
        defaultHeight: 2,
        defaultWidth: 3,
        type: ModuleTypeEnum.FullnessBasesChart,
        defaultConfig: {
            columns: "location",
            defaultLocationsGroup: GraphLocationGroupEnum.Division
        },
        defaultSeries: [
            {
                id: 'loaded',
                name: 'Загружено',
                color: '#8dc548',
                value: true,
            },
            {
                id: 'free',
                name: 'Свободно',
                color: '#42a2f6',
                value: true,
            },
        ],
    },
    {
        id: "FullnessBasesByCurrency",
        name: "Загруженность баз, в валюте",
        defaultMinHeight: 2,
        defaultMinWidth: 2,
        defaultHeight: 2,
        defaultWidth: 3,
        type: ModuleTypeEnum.FullnessBasesByCurrencyChart,
        defaultConfig: {
            columns: "location",
            defaultLocationsGroup: GraphLocationGroupEnum.Division
        },
        defaultSeries: [
            {
                id: 'rubles',
                name: 'Загружено',
                color: '#8dc548',
                value: true,
            }
        ],
    },
    {
        id: "FullnessBasesByWeight",
        name: "Загруженность баз, в тоннах",
        defaultMinHeight: 2,
        defaultMinWidth: 2,
        defaultHeight: 2,
        defaultWidth: 3,
        type: ModuleTypeEnum.FullnessBasesByWeightChart,
        defaultConfig: {
            columns: "location",
            defaultLocationsGroup: GraphLocationGroupEnum.Division
        },
        defaultSeries: [
            {
                id: 'weight',
                name: 'Загружено',
                color: '#8dc548',
                value: true,
            }
        ],
    },
    {
        id: "WeatherRestrictions",
        name: "Погодные ограничения",
        defaultMinHeight: 1,
        defaultMinWidth: 2,
        defaultHeight: 2,
        defaultWidth: 2,
        type: ModuleTypeEnum.WeatherRestrictionsList,
        defaultConfig: {}
    },

];
const dashboardLayouts: IDashboardLayout[] = [
    {
        breakpoint: "custom",
        numberOfCols: 10,
        margin: { x: 5, y: 5 },
        items: []
    },
    // в дальнейшем можно использовать под разные разрешения экрана как разные модули, так и их положение
    // {
    //     breakpoint: "lg",
    //     breakpointWidth: 1200,
    //     numberOfCols: 12,
    //     items: defaultDashboardItems
    // },
    // {
    //     breakpoint: "md",
    //     breakpointWidth: 996,
    //     numberOfCols: 10,
    //     items: defaultDashboardItems,
    // },
    // {
    //     breakpoint: "sm",
    //     breakpointWidth: 768,
    //     numberOfCols: 6,
    //     items: [],
    // },
    // {
    //     breakpoint: "xs",
    //     breakpointWidth: 480,
    //     numberOfCols: 2,
    //     items: [],
    // }
];
const defaultDashboards: IDashboard[] = [
    {
        id: 0,
        name: "Основная",
        layouts: dashboardLayouts,
    }
];

const inputDataCommonTableMtrItemTypes: ITreeListMtrItemDataType[] = [
    {
        id: "Arrival",
        parentId: "root",
        name: "Приход",
        selected: false
    },
    {
        id: "ArrivalPlan",
        parentId: "Arrival",
        name: "План",
        type: MtrItemTypeEnum.ArrivalPlan,
    },
    {
        id: "ArrivalAdjustedPlan",
        parentId: "Arrival",
        name: "Скорректированный план",
        type: MtrItemTypeEnum.ArrivalAdjustedPlan,
    },
    {
        id: "ArrivalDailyPlan",
        parentId: "Arrival",
        name: "Суточный план",
        type: MtrItemTypeEnum.ArrivalDailyPlan,
    },
    {
        id: "ArrivalFact",
        parentId: "Arrival",
        name: "Факт",
        type: MtrItemTypeEnum.ArrivalFact,
    },
    {
        id: "Expenditure",
        parentId: "root",
        name: "Расход",
        selected: false
    },
    {
        id: "ExpenditurePlan",
        parentId: "Expenditure",
        name: "План",
        type: MtrItemTypeEnum.ExpenditurePlan,
    },
    {
        id: "ExpenditureAdjustedPlan",
        parentId: "Expenditure",
        name: "Скорректированный план",
        type: MtrItemTypeEnum.ExpenditureAdjustedPlan,
    },
    {
        id: "ExpenditureDailyPlan",
        parentId: "Expenditure",
        name: "Суточный план",
        type: MtrItemTypeEnum.ExpenditureDailyPlan,
    },
    {
        id: "ExpenditureFact",
        parentId: "Expenditure",
        name: "Факт",
        type: MtrItemTypeEnum.ExpenditureFact,
    },
    {
        id: "FreightTurnover",
        parentId: "root",
        name: "Грузооборот",
        selected: true
    },
    {
        id: "FreightTurnoverPlan",
        parentId: "FreightTurnover",
        name: "План",
        type: MtrItemTypeEnum.FreightTurnoverPlan,
    },
    {
        id: "FreightTurnoverAdjustedPlan",
        parentId: "FreightTurnover",
        name: "Скорректированный план",
        type: MtrItemTypeEnum.FreightTurnoverAdjustedPlan,
    },
    {
        id: "FreightTurnoverDailyPlan",
        parentId: "FreightTurnover",
        name: "Суточный план",
        type: MtrItemTypeEnum.FreightTurnoverDailyPlan,
    },
    {
        id: "FreightTurnoverFact",
        parentId: "FreightTurnover",
        name: "Факт",
        type: MtrItemTypeEnum.FreightTurnoverFact,
    },
    {
        id: "FreightTurnoverPerformed",
        parentId: "FreightTurnover",
        name: "Выполнено, %",
        type: MtrItemTypeEnum.FreightTurnoverPerformed,
    },
    {
        id: "CargoHandling",
        parentId: "root",
        name: "Грузопереработка",
    },
    {
        id: "CargoHandlingPlan",
        parentId: "CargoHandling",
        name: "План",
        type: MtrItemTypeEnum.CargoHandlingPlan,
    },
    {
        id: "CargoHandlingAdjustedPlan",
        parentId: "CargoHandling",
        name: "Скорректированный план",
        type: MtrItemTypeEnum.CargoHandlingAdjustedPlan,
    },
    {
        id: "CargoHandlingDailyPlan",
        parentId: "CargoHandling",
        name: "Суточный план",
        type: MtrItemTypeEnum.CargoHandlingDailyPlan,
    },
    {
        id: "CargoHandlingFact",
        parentId: "CargoHandling",
        name: "Факт",
        type: MtrItemTypeEnum.CargoHandlingFact,
    },
    {
        id: "CargoHandlingPerformed",
        parentId: "CargoHandling",
        name: "Выполнено, %",
        type: MtrItemTypeEnum.CargoHandlingPerformed,
    },
    {
        id: "SeasonalDelivery",
        parentId: "root",
        name: "Сезонный завоз",
    },
    {
        id: "SeasonalDeliveryPlan",
        parentId: "SeasonalDelivery",
        name: "План",
        type: MtrItemTypeEnum.SeasonalDeliveryPlan,
    },
    {
        id: "SeasonalDeliveryAdjustedPlan",
        parentId: "SeasonalDelivery",
        name: "Скорректированный план",
        type: MtrItemTypeEnum.SeasonalDeliveryAdjustedPlan,
    },
    {
        id: "SeasonalDeliveryDailyPlan",
        parentId: "SeasonalDelivery",
        name: "Суточный план",
        type: MtrItemTypeEnum.SeasonalDeliveryDailyPlan,
    },
    {
        id: "SeasonalDeliveryFact",
        parentId: "SeasonalDelivery",
        name: "Факт",
        type: MtrItemTypeEnum.SeasonalDeliveryFact,
    },
    {
        id: "SeasonalDeliveryPerformed",
        parentId: "SeasonalDelivery",
        name: "Выполнено, %",
        type: MtrItemTypeEnum.SeasonalDeliveryPerformed,
    },
    {
        id: "AccountingMtr",
        parentId: "root",
        name: "Учет МТР",
        selected: false
    },
    {
        id: "AccountingMtrTotalSupplies",
        parentId: "AccountingMtr",
        name: "Итого поставок",
        type: MtrItemTypeEnum.AccountingMtrTotalSupplies,
    },
    {
        id: "AccountingMtrProcessing",
        parentId: "AccountingMtr",
        name: "В работе",
        type: MtrItemTypeEnum.AccountingMtrProcessing,
    },
    {
        id: "AccountingMtrUncapitalize",
        parentId: "AccountingMtr",
        name: "Не оприходовано",
    },
    {
        id: "AccountingMtrUncapitalize0_14",
        parentId: "AccountingMtrUncapitalize",
        name: "0-14",
        type: MtrItemTypeEnum.AccountingMtrUncapitalize0_14,
    },
    {
        id: "AccountingMtrUncapitalize15_30",
        parentId: "AccountingMtrUncapitalize",
        name: "15-30",
        type: MtrItemTypeEnum.AccountingMtrUncapitalize15_30,
    },
    {
        id: "AccountingMtrUncapitalize31_60",
        parentId: "AccountingMtrUncapitalize",
        name: "31-60",
        type: MtrItemTypeEnum.AccountingMtrUncapitalize31_60,
    },
    {
        id: "AccountingMtrUncapitalize61More",
        parentId: "AccountingMtrUncapitalize",
        name: "Более 60",
        type: MtrItemTypeEnum.AccountingMtrUncapitalize61More,
    },
    {
        id: "HSE",
        parentId: "root",
        name: "HSE",
        selected: false
    },
    {
        id: "HSEDeath",
        parentId: "HSE",
        name: "Смерть",
        type: MtrItemTypeEnum.HseDeath,
    },
    {
        id: "HSEDisability",
        parentId: "HSE",
        name: "НС с ВПТ",
        type: MtrItemTypeEnum.HseDisability,
    },
    {
        id: "HSEMedicalCare",
        parentId: "HSE",
        name: "МП на производстве + ПП",
        type: MtrItemTypeEnum.HseMedicalCare,
    },
    {
        id: "HSENearMiss",
        parentId: "HSE",
        name: "ПбП + ДТП + Алко + Аварии",
        type: MtrItemTypeEnum.HseNearMiss,
    },
    {
        id: "HSEDangerWarning",
        parentId: "HSE",
        name: "Опасные случаи и действия",
        type: MtrItemTypeEnum.HseDangerWarning,
    },
    {
        id: "Bid",
        parentId: "root",
        name: "Заявки",
        selected: false
    },
    {
        id: "BidPlan",
        parentId: "Bid",
        name: "План",
        type: MtrItemTypeEnum.BidPlan,
    },
    {
        id: "BidForecast",
        parentId: "Bid",
        name: "Прогноз",
        type: MtrItemTypeEnum.BidForecast,
    },
    {
        id: "BidTotalFact",
        parentId: "Bid",
        name: "Факт Всего",
        type: MtrItemTypeEnum.BidTotalFact,
    },
    {
        id: "BidScheduledFact",
        parentId: "Bid",
        name: "Факт в срок",
        type: MtrItemTypeEnum.BidScheduledFact,
    },
    {
        id: "BidUnplanned",
        parentId: "Bid",
        name: "Не запланированные",
        type: MtrItemTypeEnum.BidUnplanned,
    },
    {
        id: "BidOTIF",
        parentId: "Bid",
        name: "OTIF",
        type: MtrItemTypeEnum.BidOTIF,
    },
    {
        id: "Resources",
        parentId: "root",
        name: "Ресурсы",
        selected: false
    },
    {
        id: "Transport",
        parentId: "Resources",
        name: "Транспорт",
    },
    {
        id: "TransportPlan",
        parentId: "Transport",
        name: "План",
        type: MtrItemTypeEnum.TransportPlan,
    },
    {
        id: "TransportFact",
        parentId: "Transport",
        name: "Факт",
        type: MtrItemTypeEnum.TransportFact,
    },
    {
        id: "GPMP",
        parentId: "Resources",
        name: "ГПМ",
    },
    {
        id: "GPMPlan",
        parentId: "GPMP",
        name: "План",
        type: MtrItemTypeEnum.GPMPlan,
    },
    {
        id: "GPMFact",
        parentId: "GPMP",
        name: "Факт",
        type: MtrItemTypeEnum.GPMFact,
    },
    {
        id: "LaborResources",
        parentId: "Resources",
        name: "Трудовые ресурсы",
    },
    {
        id: "LaborResourcesPlan",
        parentId: "LaborResources",
        name: "План",
        type: MtrItemTypeEnum.LaborResourcesPlan,
    },
    {
        id: "LaborResourcesFact",
        parentId: "LaborResources",
        name: "Факт",
        type: MtrItemTypeEnum.LaborResourcesFact,
    },
    {
        id: "FullnessBases",
        parentId: "root",
        name: "Хранение на базах",
        selected: false
    },
    {
        id: "FullnessBasesTotalSquare",
        parentId: "FullnessBases",
        name: "Общая площадь, Га",
        type: MtrItemTypeEnum.FullnessBasesTotalSquare,
    },
    {
        id: "FullnessBasesLoaded",
        parentId: "FullnessBases",
        name: "Загружено, Га",
        type: MtrItemTypeEnum.FullnessBasesLoaded,
    },
    {
        id: "FullnessBasesLoadedRubles",
        parentId: "FullnessBases",
        name: "Загружено, руб",
        type: MtrItemTypeEnum.FullnessBasesLoadedRubles,
    },
    {
        id: "FullnessBasesLoadedWeight",
        parentId: "FullnessBases",
        name: "Загружено, тонн",
        type: MtrItemTypeEnum.FullnessBasesLoadedWeight,
    }
];

export default {
    authHost,
    remoteHost,
    applicationHost,
    defaultDashboards,
    durationPickerValues,
    inputDataCommonTableMtrItemTypes,
    graphLocationGroupValues,
    allDashboardModules,
    defaultDashboardItems,
    dashboardLayouts
};
