﻿using MediatR;
using Microsoft.Extensions.Logging;
using Supply.Dashboards.Domain.AggregatesModel;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.InnerEventHandlers
{
    public sealed class DomainEventHandler 
        : INotificationHandler<Event>
    {
        private readonly ILogger<DomainEventHandler> _logger;
        private readonly IDomainEventHandler _domainEventHandler;

        public DomainEventHandler(
            ILogger<DomainEventHandler> logger, 
            IDomainEventHandler domainEventHandler)
        {
            _logger = logger;
            _domainEventHandler = domainEventHandler;
        }

        public async Task Handle(Event @event, CancellationToken cancellationToken)
        {
            await _domainEventHandler.AddEvent(@event, cancellationToken);
        }
    }
}
