﻿using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.Charts.ExpenditureByLocations.Output
{
    public sealed class ExpenditureByLocationsOutput
    {
        private readonly List<ExpenditureByLocationsParamOutput> _locations;

        internal ExpenditureByLocationsOutput(List<ExpenditureByLocationsParamOutput> locations)
        {
            _locations = locations;
        }

        public IEnumerable<ExpenditureByLocationsParamOutput> Locations =>
            _locations.OrderBy(_ => _.LocationId).ToList().AsReadOnly();
    }
}
