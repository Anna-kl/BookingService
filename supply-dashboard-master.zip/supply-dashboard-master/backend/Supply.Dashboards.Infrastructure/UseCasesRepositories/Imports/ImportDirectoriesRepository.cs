﻿using Common.SeedWork;

using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.UseCases.Imports.ImportDirectories;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;
using Supply.Dashboards.Domain.Types;
using Supply.Dashboards.Infrastructure.Data;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.Infrastructure.UseCasesRepositories.Imports
{
    public sealed class ImportDirectoriesRepository : IImportDirectories
    {
        private readonly ILogger<ImportDirectoriesRepository> _logger;
        private readonly DashboardsContext _dashboardsContext;

        public ImportDirectoriesRepository(
            ILogger<ImportDirectoriesRepository> logger,
            DashboardsContext dashboardsContext)
        {
            _logger = logger;
            _dashboardsContext = dashboardsContext;
        }

        public IUnitOfWork UnitOfWork => _dashboardsContext;

        public async Task<IEnumerable<Customer>> GetCustomersByInnerIds(
            List<StatusType> statuses,
            List<Guid> innerIds,
            CancellationToken cancellationToken)
        {
            var queryable = _dashboardsContext
                .Customers
                .Include(_ => _.SourceEdges)
                .Where(_ => innerIds.Contains(_.InnerId))
                .AsQueryable();

            if (statuses.Any())
                queryable = queryable.Where(_ => statuses.Contains(_.Status));

            return (await queryable.ToListAsync(cancellationToken)).ToList().AsReadOnly();
        }

        public async Task<IEnumerable<Customer>> AddCustomers(
            List<Customer> customers,
            CancellationToken cancellationToken)
        {
            await _dashboardsContext
                .Customers
                .AddRangeAsync(customers, cancellationToken);

            return customers;
        }

        public async Task<CustomerEdge> AddCustomerEdge(
            CustomerEdge edge,
            CancellationToken cancellationToken)
        {
            await _dashboardsContext.CustomersEdges.AddAsync(edge, cancellationToken);

            return edge;
        }

        public Task<List<CustomerEdge>> RemoveCustomerEdges(
            List<CustomerEdge> edges,
            CancellationToken cancellationToken)
        {
            _dashboardsContext.CustomersEdges.RemoveRange(edges);

            return Task.FromResult(edges);
        }

        public async Task<IEnumerable<Location>> GetLocationsByInnerIds(
            List<StatusType> statuses,
            List<Guid> innerIds,
            CancellationToken cancellationToken)
        {
            var queryable = _dashboardsContext
                .Locations
                .Include(_ => _.SourceEdges)
                .Include(_ => _.DestinationEdges)
                .Where(_ => innerIds.Contains(_.InnerId))
                .AsQueryable();

            if (statuses.Any())
                queryable = queryable.Where(_ => statuses.Contains(_.Status));

            return (await queryable.ToListAsync(cancellationToken)).ToList().AsReadOnly();
        }

        public async Task<IEnumerable<Location>> AddLocations(
            List<Location> locations,
            CancellationToken cancellationToken)
        {
            await _dashboardsContext
                .Locations
                .AddRangeAsync(locations, cancellationToken);

            return locations;
        }

        public async Task<LocationEdge> AddLocationEdge(
            LocationEdge edge,
            CancellationToken cancellationToken)
        {
            await _dashboardsContext.LocationEdges.AddAsync(edge, cancellationToken);

            return edge;
        }

        public Task<List<LocationEdge>> RemoveLocationEdges(
            List<LocationEdge> edges,
            CancellationToken cancellationToken)
        {
            _dashboardsContext.LocationEdges.RemoveRange(edges);

            return Task.FromResult(edges);
        }

        public async Task<IEnumerable<MtrType>> GetMtrTypesByInnerIds(
            List<StatusType> statuses,
            List<Guid> innerIds,
            CancellationToken cancellationToken)
        {
            var queryable = _dashboardsContext
                .MtrTypes
                .Include(_ => _.SourceEdges)
                .Where(_ => innerIds.Contains(_.InnerId))
                .AsQueryable();

            if (statuses.Any())
                queryable = queryable.Where(_ => statuses.Contains(_.Status));

            return (await queryable.ToListAsync(cancellationToken)).ToList().AsReadOnly();
        }

        public async Task<IEnumerable<MtrType>> AddMtrTypes(
            List<MtrType> mtrTypes,
            CancellationToken cancellationToken)
        {
            await _dashboardsContext
                .MtrTypes
                .AddRangeAsync(mtrTypes, cancellationToken);

            return mtrTypes;
        }

        public async Task<MtrTypeEdge> AddMtrTypeEdge(
            MtrTypeEdge edge,
            CancellationToken cancellationToken)
        {
            await _dashboardsContext.MtrTypesEdges.AddAsync(edge, cancellationToken);

            return edge;
        }

        public Task<List<MtrTypeEdge>> RemoveMtrTypeEdges(
            List<MtrTypeEdge> edges,
            CancellationToken cancellationToken)
        {
            _dashboardsContext.MtrTypesEdges.RemoveRange(edges);

            return Task.FromResult(edges);
        }
    }
}
