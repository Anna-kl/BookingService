﻿using Microsoft.AspNetCore.Http;

using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace Common.RequestInfo
{
    public sealed class RequestInfo
    {
        private static readonly AsyncLocal<IHeaderDictionary> HeaderDictionary = new();
        private static readonly AsyncLocal<IQueryCollection> QueryCollection = new();

        public static void SetValues(HttpContext context)
        {
            HeaderDictionary.Value = context.Request.Headers;
            QueryCollection.Value = context.Request.Query;
        }

        public static Dictionary<string, string> Headers =>
            HeaderDictionary.Value == null
                ? new Dictionary<string, string>()
                : HeaderDictionary.Value.ToDictionary(_ => _.Key, _ => _.Value.ToString());

        public static Dictionary<string, string> Query =>
            QueryCollection.Value == null
                ? new Dictionary<string, string>()
                : QueryCollection.Value.ToDictionary(_ => _.Key, _ => _.Value.ToString());
    }
}
