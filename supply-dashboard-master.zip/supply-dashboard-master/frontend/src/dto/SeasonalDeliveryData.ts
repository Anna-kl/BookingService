export interface ISeasonalDeliveryDataResponse {
    locationId: string;
    locationTitle: string;
    units: ISeasonalDeliveryDataUnitResponse[];
}

export interface ISeasonalDeliverySourceLocationResponse {
    id: string;
    title: string;
}

export interface ISeasonalDeliveryDataUnitResponse {
    tons: number;
    type: string;
}

export interface ISeasonalDeliveryDataRequest {
    dateTime: string;
    parentLocationId?: string;
    locationsIds?: string[] | null;
    customersIds?: string[] | null;
    mtrTypesIds?: string[] | null;
}

export interface ISeasonalDeliveryChartData {
    location: string;
    locationId?: string;
    fact?: number;
    plan?: number;
    adjustedPlan?: number;
    dailyPlan?: number;
}
