﻿using FluentValidation;

using Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Input;

namespace Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Validator
{
    public sealed class ImportDirectoriesCustomerValidator
        : AbstractValidator<ImportDirectoriesCustomerInput>
    {
        public ImportDirectoriesCustomerValidator()
        {
            ValidateId();
            ValidateType();
            ValidateTitle();
            ValidateDescription();
        }

        private void ValidateId() =>
            RuleFor(_ => _.Id)
                .Must(_ => _ != default); // TODO add description

        private void ValidateType() =>
            RuleFor(_ => _.Type)
                .NotEmpty()
                .Must(_ => _.Id != 0); // TODO add description

        private void ValidateTitle() =>
            RuleFor(_ => _.Title)
                .NotEmpty();

        private void ValidateDescription() =>
            RuleFor(_ => _.Description);
    }
}
