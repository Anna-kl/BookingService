﻿using Microsoft.EntityFrameworkCore.Migrations;

using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

using System;

namespace Supply.Dashboards.Infrastructure.Migrations
{
    public partial class Init : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "contexts",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    createat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    updateat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    status = table.Column<int>(type: "integer", nullable: false),
                    title = table.Column<string>(type: "text", nullable: false),
                    innerid = table.Column<Guid>(type: "uuid", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_contexts", x => x.id);
                    table.UniqueConstraint("AK_contexts_innerid", x => x.innerid);
                });

            migrationBuilder.CreateTable(
                name: "customer_types",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false),
                    name = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_customer_types", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "customers",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    createat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    updateat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    status = table.Column<int>(type: "integer", nullable: false),
                    payload_type = table.Column<int>(type: "integer", nullable: false),
                    payload_title = table.Column<string>(type: "text", nullable: false),
                    payload_description = table.Column<string>(type: "text", nullable: true),
                    innerid = table.Column<Guid>(type: "uuid", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_customers", x => x.id);
                    table.UniqueConstraint("AK_customers_innerid", x => x.innerid);
                });

            migrationBuilder.CreateTable(
                name: "input_types",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false),
                    name = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_input_types", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "location_types",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false),
                    name = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_location_types", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "locations",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    createat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    updateat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    status = table.Column<int>(type: "integer", nullable: false),
                    payload_type = table.Column<int>(type: "integer", nullable: false),
                    payload_title = table.Column<string>(type: "text", nullable: false),
                    payload_description = table.Column<string>(type: "text", nullable: true),
                    payload_longitude = table.Column<double>(type: "double precision", nullable: true),
                    payload_latitude = table.Column<double>(type: "double precision", nullable: true),
                    payload_diameter = table.Column<double>(type: "double precision", nullable: true),
                    innerid = table.Column<Guid>(type: "uuid", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_locations", x => x.id);
                    table.UniqueConstraint("AK_locations_innerid", x => x.innerid);
                });

            migrationBuilder.CreateTable(
                name: "mtr_types",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    createat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    updateat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    status = table.Column<int>(type: "integer", nullable: false),
                    payload_title = table.Column<string>(type: "text", nullable: false),
                    payload_description = table.Column<string>(type: "text", nullable: true),
                    innerid = table.Column<Guid>(type: "uuid", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mtr_types", x => x.id);
                    table.UniqueConstraint("AK_mtr_types_innerid", x => x.innerid);
                });

            migrationBuilder.CreateTable(
                name: "status_types",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false),
                    name = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_status_types", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "users",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    createat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    updateat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    status = table.Column<int>(type: "integer", nullable: false),
                    fullname = table.Column<string>(type: "text", nullable: false),
                    innerid = table.Column<Guid>(type: "uuid", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_users", x => x.id);
                    table.UniqueConstraint("AK_users_innerid", x => x.innerid);
                });

            migrationBuilder.CreateTable(
                name: "value_records_types",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false),
                    name = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_value_records_types", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "customers_edges",
                columns: table => new
                {
                    sourceid = table.Column<int>(type: "integer", nullable: false),
                    destinationid = table.Column<int>(type: "integer", nullable: false),
                    sourceinnerid = table.Column<Guid>(type: "uuid", nullable: false),
                    destinationinnerid = table.Column<Guid>(type: "uuid", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_customers_edges", x => new { x.sourceid, x.destinationid });
                    table.ForeignKey(
                        name: "FK_customers_edges_customers_destinationid",
                        column: x => x.destinationid,
                        principalTable: "customers",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "FK_customers_edges_customers_sourceid",
                        column: x => x.sourceid,
                        principalTable: "customers",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "locations_edges",
                columns: table => new
                {
                    sourceid = table.Column<int>(type: "integer", nullable: false),
                    destinationid = table.Column<int>(type: "integer", nullable: false),
                    sourceinnerid = table.Column<Guid>(type: "uuid", nullable: false),
                    destinationinnerid = table.Column<Guid>(type: "uuid", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_locations_edges", x => new { x.sourceid, x.destinationid });
                    table.ForeignKey(
                        name: "FK_locations_edges_locations_destinationid",
                        column: x => x.destinationid,
                        principalTable: "locations",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "FK_locations_edges_locations_sourceid",
                        column: x => x.sourceid,
                        principalTable: "locations",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "mtr_types_edges",
                columns: table => new
                {
                    sourceid = table.Column<int>(type: "integer", nullable: false),
                    destinationid = table.Column<int>(type: "integer", nullable: false),
                    sourceinnerid = table.Column<Guid>(type: "uuid", nullable: false),
                    destinationinnerid = table.Column<Guid>(type: "uuid", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mtr_types_edges", x => new { x.sourceid, x.destinationid });
                    table.ForeignKey(
                        name: "FK_mtr_types_edges_mtr_types_destinationid",
                        column: x => x.destinationid,
                        principalTable: "mtr_types",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "FK_mtr_types_edges_mtr_types_sourceid",
                        column: x => x.sourceid,
                        principalTable: "mtr_types",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "externalsystem",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    createat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    updateat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    statusid = table.Column<int>(type: "integer", nullable: true),
                    title = table.Column<string>(type: "text", nullable: false),
                    innerid = table.Column<Guid>(type: "uuid", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_externalsystem", x => x.id);
                    table.ForeignKey(
                        name: "FK_externalsystem_status_types_statusid",
                        column: x => x.statusid,
                        principalTable: "status_types",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "value_records",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    createat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    updateat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    payload_startperiod = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    payload_endperiod = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    payload_type = table.Column<int>(type: "integer", nullable: false),
                    payload_customerid = table.Column<int>(type: "integer", nullable: true),
                    payload_locationid = table.Column<int>(type: "integer", nullable: true),
                    payload_mtrtypeid = table.Column<int>(type: "integer", nullable: true),
                    payload_value = table.Column<double>(type: "double precision", nullable: false),
                    payload_userid = table.Column<int>(type: "integer", nullable: true),
                    payload_inputtype = table.Column<int>(type: "integer", nullable: false),
                    innerid = table.Column<Guid>(type: "uuid", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_value_records", x => x.id);
                    table.UniqueConstraint("AK_value_records_innerid", x => x.innerid);
                    table.ForeignKey(
                        name: "FK_value_records_customers_payload_customerid",
                        column: x => x.payload_customerid,
                        principalTable: "customers",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_value_records_locations_payload_locationid",
                        column: x => x.payload_locationid,
                        principalTable: "locations",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_value_records_mtr_types_payload_mtrtypeid",
                        column: x => x.payload_mtrtypeid,
                        principalTable: "mtr_types",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_value_records_users_payload_userid",
                        column: x => x.payload_userid,
                        principalTable: "users",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "aliasid",
                columns: table => new
                {
                    contextid = table.Column<int>(type: "integer", nullable: false),
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    contextinnerid = table.Column<Guid>(type: "uuid", nullable: false),
                    externalsystemid = table.Column<int>(type: "integer", nullable: false),
                    type = table.Column<string>(type: "text", nullable: false),
                    innerid = table.Column<Guid>(type: "uuid", nullable: false),
                    externalid = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_aliasid", x => new { x.contextid, x.id });
                    table.ForeignKey(
                        name: "FK_aliasid_contexts_contextid",
                        column: x => x.contextid,
                        principalTable: "contexts",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_aliasid_externalsystem_externalsystemid",
                        column: x => x.externalsystemid,
                        principalTable: "externalsystem",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_aliasid_externalsystemid",
                table: "aliasid",
                column: "externalsystemid");

            migrationBuilder.CreateIndex(
                name: "IX_customers_edges_destinationid",
                table: "customers_edges",
                column: "destinationid");

            migrationBuilder.CreateIndex(
                name: "IX_customers_edges_sourceinnerid_destinationinnerid",
                table: "customers_edges",
                columns: new[] { "sourceinnerid", "destinationinnerid" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_externalsystem_statusid",
                table: "externalsystem",
                column: "statusid");

            migrationBuilder.CreateIndex(
                name: "IX_locations_edges_destinationid",
                table: "locations_edges",
                column: "destinationid");

            migrationBuilder.CreateIndex(
                name: "IX_locations_edges_sourceinnerid_destinationinnerid",
                table: "locations_edges",
                columns: new[] { "sourceinnerid", "destinationinnerid" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_mtr_types_edges_destinationid",
                table: "mtr_types_edges",
                column: "destinationid");

            migrationBuilder.CreateIndex(
                name: "IX_mtr_types_edges_sourceinnerid_destinationinnerid",
                table: "mtr_types_edges",
                columns: new[] { "sourceinnerid", "destinationinnerid" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_value_records_payload_customerid",
                table: "value_records",
                column: "payload_customerid");

            migrationBuilder.CreateIndex(
                name: "IX_value_records_payload_locationid",
                table: "value_records",
                column: "payload_locationid");

            migrationBuilder.CreateIndex(
                name: "IX_value_records_payload_mtrtypeid",
                table: "value_records",
                column: "payload_mtrtypeid");

            migrationBuilder.CreateIndex(
                name: "IX_value_records_payload_userid",
                table: "value_records",
                column: "payload_userid");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "aliasid");

            migrationBuilder.DropTable(
                name: "customer_types");

            migrationBuilder.DropTable(
                name: "customers_edges");

            migrationBuilder.DropTable(
                name: "input_types");

            migrationBuilder.DropTable(
                name: "location_types");

            migrationBuilder.DropTable(
                name: "locations_edges");

            migrationBuilder.DropTable(
                name: "mtr_types_edges");

            migrationBuilder.DropTable(
                name: "value_records");

            migrationBuilder.DropTable(
                name: "value_records_types");

            migrationBuilder.DropTable(
                name: "contexts");

            migrationBuilder.DropTable(
                name: "externalsystem");

            migrationBuilder.DropTable(
                name: "customers");

            migrationBuilder.DropTable(
                name: "locations");

            migrationBuilder.DropTable(
                name: "mtr_types");

            migrationBuilder.DropTable(
                name: "users");

            migrationBuilder.DropTable(
                name: "status_types");
        }
    }
}
