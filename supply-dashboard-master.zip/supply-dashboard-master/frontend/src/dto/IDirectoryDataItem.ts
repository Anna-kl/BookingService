export interface IDirectoryDataItem {
    id: string;
    parentIds: any[];
    title: string;
    // type?: string;
    childrenIds: string[];
    description?: string;
}