﻿using Supply.Dashboards.Shared.Types;
using System;

namespace Supply.Dashboards.Shared.ViewModels.Contexts.GetContextList
{
    public sealed class GetContextListResponseUsersViewModel
    {
        public Guid Id { get; set; }
        public StatusEnum Status { get; set; }

        public string NameIdentifier { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
    }
}
