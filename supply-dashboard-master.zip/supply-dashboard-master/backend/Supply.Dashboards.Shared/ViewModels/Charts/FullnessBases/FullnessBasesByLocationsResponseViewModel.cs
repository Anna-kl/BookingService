﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supply.Dashboards.Shared.ViewModels.Charts.FullnessBases
{
    public sealed class FullnessBasesByLocationsResponseViewModel
    {
        public List<FullnessBasesByLocationsParamResponseViewModel>? Locations { get; set; }
    }
}
