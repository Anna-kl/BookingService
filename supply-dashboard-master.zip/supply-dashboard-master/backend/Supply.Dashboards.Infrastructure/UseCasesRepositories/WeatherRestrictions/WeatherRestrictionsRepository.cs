﻿using Common.SeedWork;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Supply.Dashboards.App.UseCases.WeatherRestrictions;
using Supply.Dashboards.Domain.AggregatesModel.WeatherRestrictions;
using Supply.Dashboards.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.Infrastructure.UseCasesRepositories.WeatherRestrictions
{
    public sealed class WeatherRestrictionsRepository : IWeatherRestrictions
    {
        private readonly ILogger<WeatherRestrictionsRepository> _logger;
        private readonly DashboardsContext _dashboardsContext;

        public WeatherRestrictionsRepository(
            ILogger<WeatherRestrictionsRepository> logger,
            DashboardsContext dashboardsContext)
        {
            _logger = logger;
            _dashboardsContext = dashboardsContext;
        }

        public IUnitOfWork UnitOfWork => _dashboardsContext;

        public IQueryable<WeatherRestriction> GetWeatherRestrictionsAsQueryable(
           DateTime startDate,
           DateTime endDate,
           IEnumerable<Guid?> customersIds,
           IEnumerable<Guid>? locationsIds)
        {
            var queryable = _dashboardsContext
                 .WeatherRestrictions
                 .AsNoTracking()
                 .Include(record => record.Payload.Location)
                 .Include(record => record.Payload.Customer)
                 .AsQueryable();

            var locationIdList = locationsIds?.ToList();

            if (locationIdList != null && locationIdList.Any())
            {
                queryable = queryable.Where(_ => locationIdList.Contains(_.Payload.Location!.InnerId));
            }

            if (locationIdList != null && locationIdList.Any())
            {
                queryable = queryable.Where(_ => customersIds.Contains(_.Payload.Customer!.InnerId));
            }

            queryable = queryable.Where(_ => _.Payload.DateTime >= startDate && _.Payload.DateTime <= endDate);

            return queryable;
        }

    }
}
