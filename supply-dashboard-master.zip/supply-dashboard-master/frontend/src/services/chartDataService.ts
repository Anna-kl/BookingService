import { ICargoDataByLocationsRequest, ICargoDataByLocationsResponse, ICargoDataByPeriodsRequest, ICargoDataByPeriodsResponse } from "@/dto/CargoData";
import { IAccountingMtrRequest, IAccountingMtrPeriodResponse } from "@/dto/AccountingMtrData";
import { ISeasonalDeliveryDataRequest, ISeasonalDeliveryDataResponse } from "@/dto/SeasonalDeliveryData";
import { FetchService } from "./fetchService"
import { IHSEDataRequest, IHSEDataResponse } from "@/dto/HSEData";
import { IOTIFDataRequest, IOTIFDataResponse } from "@/dto/OTIFData";
import { IExecutionOfOrdersDataResponse, IExecutionOfOrdersDataRequest } from "@/dto/ExecutionOfOrdersData";
import { ITransportResourcesDataRequest, ITransportResourcesByPeriodDataResponse, ITransportResourcesByLocationDataResponse, ITransportResourcesByLocationResponse } from "@/dto/TransportResourcesData";
import { IFullnessBasesByLocationResponse, IFullnessBasesDataRequest } from "@/dto/FullnessBasesData";
import { IWeatherRestrictionsRequest, IWeatherRestrictionsResponse } from "@/dto/WeatherRestrictionsData";

export class ChartDataService {

    private _fetchService = new FetchService();

    public async getCargoDataByPeriods(url: string, request: ICargoDataByPeriodsRequest): Promise<ICargoDataByPeriodsResponse[]> {
        return await this._fetchService.post<ICargoDataByPeriodsResponse[]>(
            url, request
        );
    }

    public async getCargoDataByLocations(url: string, request: ICargoDataByLocationsRequest): Promise<ICargoDataByLocationsResponse[]> {
        return await this._fetchService.post<ICargoDataByLocationsResponse[]>(
            url, request
        );
    }

    public async getAccountingMtrPeriod(url: string, request: IAccountingMtrRequest): Promise<IAccountingMtrPeriodResponse[]> {
        return await this._fetchService.post<IAccountingMtrPeriodResponse[]>(
            url, request
        );
    }

    public async getTransportResourcesDataByPeriod(url: string, request: ITransportResourcesDataRequest): Promise<ITransportResourcesByPeriodDataResponse> {
        return await this._fetchService.post<ITransportResourcesByPeriodDataResponse>(
            url, request
        );
    }

    public async getTransportResourcesDataByLocation(url: string, request: ITransportResourcesDataRequest): Promise<ITransportResourcesByLocationResponse[]> {
        return await this._fetchService.post<ITransportResourcesByLocationResponse[]>(
            url, request
        );
    }

    public async getSeasonalDeliveryData(url: string, request: ISeasonalDeliveryDataRequest): Promise<ISeasonalDeliveryDataResponse[]> {
        return await this._fetchService.post<ISeasonalDeliveryDataResponse[]>(
            url, request
        );
    }

    public async getHSEData(url: string, request: IHSEDataRequest): Promise<IHSEDataResponse> {
        return await this._fetchService.post<IHSEDataResponse>(
            url, request
        );
    }

    public async getOTIFData(url: string, request: IOTIFDataRequest): Promise<IOTIFDataResponse> {
        return await this._fetchService.post<IOTIFDataResponse>(
            url, request
        );
    }

    public async getExecutionOfOrdersData(url: string, request: IExecutionOfOrdersDataRequest)
        : Promise<IExecutionOfOrdersDataResponse[]> {
        return await this._fetchService.post<IExecutionOfOrdersDataResponse[]>(
            url, request
        );
    }

    public async getFullnessBasesDataByLocation(url: string, request: IFullnessBasesDataRequest): Promise<IFullnessBasesByLocationResponse[]> {
        return await this._fetchService.post<IFullnessBasesByLocationResponse[]>(
            url, request
        );
    }

    public async getWeatherRestrictions(url: string, request: IWeatherRestrictionsRequest): Promise<IWeatherRestrictionsResponse> {

        return await this._fetchService.post<IWeatherRestrictionsResponse>(
            url, request
        );
    }
}