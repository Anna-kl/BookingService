﻿using FluentValidation.Results;
using MediatR;
using Microsoft.Extensions.Logging;
using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.Imports.ImportMtr.Input;
using Supply.Dashboards.App.UseCases.Imports.ImportMtr.Output;
using Supply.Dashboards.App.UseCases.Imports.ImportMtr.Types;
using Supply.Dashboards.Domain.AggregatesModel.Bids;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.HseIncidents;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;
using Supply.Dashboards.Domain.AggregatesModel.ValueRecords;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.Imports.ImportMtr
{
    public sealed class ImportMtrUseCase
        : IRequestHandler<ImportMtrCommand, (ValidationResult validationResult, ImportMtrOutput? output)>
    {
        private readonly ILogger<ImportMtrUseCase> _logger;
        private readonly IImportMtr _importMtr;

        private List<Customer> _customers;
        private List<Location> _locations;
        private List<MtrType> _mtrTypes;
        private ValidationResult _validationResult;
        private readonly List<ImportMtrItemOutput> _newItemOutputs;
        private readonly List<ImportMtrItemOutput> _updatedItemOutputs;
        private readonly List<ImportMtrItemOutput> _removedItemOutputs;

        public ImportMtrUseCase(
            ILogger<ImportMtrUseCase> logger,
            IImportMtr importMtr)
        {
            _logger = logger;
            _importMtr = importMtr;

            _customers = new List<Customer>();
            _locations = new List<Location>();
            _mtrTypes = new List<MtrType>();
            _validationResult = new ValidationResult();
            _newItemOutputs = new List<ImportMtrItemOutput>();
            _updatedItemOutputs = new List<ImportMtrItemOutput>();
            _removedItemOutputs = new List<ImportMtrItemOutput>();
        }

        public async Task<(ValidationResult validationResult, ImportMtrOutput? output)> Handle(
            ImportMtrCommand request,
            CancellationToken cancellationToken)
        {
            _validationResult = request.ValidationResult;

            if (!_validationResult.IsValid) return (_validationResult, null);

            await Customers(request, cancellationToken);
            await Locations(request, cancellationToken);
            await MtrTypes(request, cancellationToken);

            if (!_validationResult.IsValid) return (_validationResult, null);

            await ValueRecords(request, cancellationToken);
            await HseIncidents(request, cancellationToken);
            await Bids(request, cancellationToken);

            await _importMtr.UnitOfWork.SaveEntitiesAsync(cancellationToken);

            return (_validationResult, new ImportMtrOutput(
                _newItemOutputs,
                _updatedItemOutputs,
                _removedItemOutputs));
        }

        private async Task Customers(
            ImportMtrCommand command,
            CancellationToken cancellationToken)
        {
            var inputCustomersIds = command
                .Items
                .Where(input => input.CustomerId != null)
                .Select(input => input.CustomerId!.Value)
                .Distinct()
                .ToList();

            inputCustomersIds = inputCustomersIds.Distinct().ToList();

            var customers = await _importMtr.GetCustomersByInnerIds(
                inputCustomersIds,
                cancellationToken);

            _customers = customers.ToList();

            if (!_customers.Any() || inputCustomersIds.Count != _customers.Count)
                inputCustomersIds.Except(_customers.Select(_ => _.InnerId)).ToList().ForEach(id =>
                {
                    _validationResult.Errors.Add(new ValidationFailure(
                        "CustomerId",
                        $"{nameof(Customer)} with id \"{id}\" is not exist."));
                });
        }

        private async Task Locations(
            ImportMtrCommand command,
            CancellationToken cancellationToken)
        {
            var inputLocationsIds = command
                .Items
                .Where(input => input.LocationId != null)
                .Select(input => input.LocationId!.Value)
                .Distinct()
                .ToList();

            inputLocationsIds = inputLocationsIds.Distinct().ToList();

            var locations = await _importMtr.GetLocationsByInnerIds(
                inputLocationsIds,
                cancellationToken);

            _locations = locations.ToList();

            if (!_locations.Any() || inputLocationsIds.Count != _locations.Count)
                inputLocationsIds.Except(_locations.Select(_ => _.InnerId)).ToList().ForEach(id =>
                {
                    _validationResult.Errors.Add(new ValidationFailure(
                        "LocationId",
                        $"{nameof(Location)} with id \"{id}\" is not exist."));
                });
        }

        private async Task MtrTypes(
            ImportMtrCommand command,
            CancellationToken cancellationToken)
        {
            var inputMtrTypesIds = command
                .Items
                .Where(input => input.MtrTypeId != null)
                .Select(input => input.MtrTypeId!.Value)
                .Distinct()
                .ToList();

            inputMtrTypesIds = inputMtrTypesIds.Distinct().ToList();

            var mtrTypes = await _importMtr.GetMtrTypesByInnerIds(
                inputMtrTypesIds,
                cancellationToken);

            _mtrTypes = mtrTypes.ToList();

            if (!_mtrTypes.Any() || inputMtrTypesIds.Count != _mtrTypes.Count)
                inputMtrTypesIds.Except(_locations.Select(_ => _.InnerId)).ToList().ForEach(id =>
                {
                    _validationResult.Errors.Add(new ValidationFailure(
                        "MtyTypeId",
                        $"{nameof(MtrType)} with id \"{id}\" is not exist."));
                });
        }

        private async Task ValueRecords(
            ImportMtrCommand request,
            CancellationToken cancellationToken)
        {
            var valueRecordsInRepo = (await _importMtr
               .ValueRecordsGet(
                   _customers,
                   _locations,
                   _mtrTypes,
                   request
                       .Items
                       .Where(_ => _.Type != null)
                       .Where(_ => ImportMtrType.IsValueRecordType(_.Type))
                       .Select(_ => ImportMtrType.GetValueRecordType(_.Type))
                       .ToList(),
                   request.Items.Select(input => (input.StartPeriod, input.EndPeriod)).ToList(),
                   cancellationToken))
               .ToList();

            var deleteList = new List<ValueRecord>();

            // update & remove section
            if (valueRecordsInRepo.Any())
            {
                foreach (var input in request
                    .Items
                    .Where(_ => _.Type != null)
                    .Where(_ => ImportMtrType.IsValueRecordType(_.Type)))
                {
                    foreach (var valueRecord in valueRecordsInRepo
                        .Where(_ => _.Payload.Type == ImportMtrType.GetValueRecordType(input.Type))
                        .Where(_ => input.StartPeriod == _.Payload.StartPeriod)
                        .Where(_ => input.EndPeriod == _.Payload.EndPeriod)
                        .Where(_ => input.CustomerId == _.Payload.Customer?.InnerId)
                        .Where(_ => input.LocationId == _.Payload.Location?.InnerId)
                        .Where(_ => input.MtrTypeId == _.Payload.MtrType?.InnerId))
                    {
                        if (input.Value == null)
                        {
                            _importMtr.ValueRecordsRemove(valueRecord);
                            deleteList.Add(valueRecord);
                            continue;
                        }

                        valueRecord.Update(new ValueRecordPayload(
                            input.StartPeriod,
                            input.EndPeriod,
                            ImportMtrType.GetValueRecordType(input.Type),
                            _customers.SingleOrDefault(_ => _.InnerId == input.CustomerId),
                            _locations.Single(_ => _.InnerId == input.LocationId),
                            _mtrTypes.SingleOrDefault(_ => _.InnerId == input.MtrTypeId),
                            input.Value.Value,
                            AppInputType.GetInputType(request.InputType)));
                    }
                }
            }

            _removedItemOutputs.AddRange(deleteList.Select(_ => new ImportMtrItemOutput(
                _.XMin,
                _.Payload.StartPeriod,
                _.Payload.EndPeriod,
                _.Payload.Customer?.InnerId,
                _.Payload.Location?.InnerId,
                _.Payload.MtrType?.InnerId,
                ImportMtrType.GetImportMtrType(_.Payload.Type),
                _.Payload.Value)));

            var newValueRecords = new List<ValueRecord>();
            newValueRecords.AddRange(
                request
                    .Items
                    .Where(input => input.Value != null)
                    .Where(input => ImportMtrType.IsValueRecordType(input.Type))
                    .Where(input => !valueRecordsInRepo
                        .Where(_ => _.Payload.Type == ImportMtrType.GetValueRecordType(input.Type))
                        .Where(_ => input.CustomerId == _.Payload.Customer?.InnerId)
                        .Where(_ => input.LocationId == _.Payload.Location?.InnerId)
                        .Where(_ => input.MtrTypeId == _.Payload.MtrType?.InnerId)
                        .Select(_ => _.Payload.StartPeriod).Contains(input.StartPeriod))
                    .Select(input => input.ToValueRecord(
                        _customers.SingleOrDefault(_ => _.InnerId == input.CustomerId),
                        _locations.SingleOrDefault(_ => _.InnerId == input.LocationId),
                        _mtrTypes.SingleOrDefault(_ => _.InnerId == input.MtrTypeId),
                        AppInputType.GetInputType(request.InputType)))
                    .ToList());

            _newItemOutputs.AddRange(newValueRecords.Select(_ => new ImportMtrItemOutput(
                _.XMin,
                _.Payload.StartPeriod,
                _.Payload.EndPeriod,
                _.Payload.Customer?.InnerId,
                _.Payload.Location?.InnerId,
                _.Payload.MtrType?.InnerId,
                ImportMtrType.GetImportMtrType(_.Payload.Type),
                _.Payload.Value)));

            _updatedItemOutputs.AddRange(valueRecordsInRepo
                .Except(deleteList)
                .Select(_ => new ImportMtrItemOutput(
                    _.XMin,
                    _.Payload.StartPeriod,
                    _.Payload.EndPeriod,
                    _.Payload.Customer?.InnerId,
                    _.Payload.Location?.InnerId,
                    _.Payload.MtrType?.InnerId,
                    ImportMtrType.GetImportMtrType(_.Payload.Type),
                    _.Payload.Value))
                );

            if (newValueRecords.Any())
                await _importMtr.ValueRecordsAdd(newValueRecords, cancellationToken);
        }

        private async Task HseIncidents(
            ImportMtrCommand request,
            CancellationToken cancellationToken)
        {
            var hseIncidentsInRepo = (await _importMtr
                    .HseIncidentGet(
                        _customers,
                        _locations,
                        request
                            .Items
                            .Where(_ => _.Type != null)
                            .Where(_ => ImportMtrType.IsHseIncidentType(_.Type))
                            .Select(_ => ImportMtrType.GetHseIncidentType(_.Type))
                            .ToList(),
                        request.Items.Select(input => input.StartPeriod).ToList(),
                        cancellationToken))
                .GroupBy(_ => (
                    date: _.Payload.DateTime.Date,
                    type: _.Payload.Type,
                    customer: _.Payload.Customer,
                    location: _.Payload.Location,
                    inputType: _.Payload.InputType))
                .ToList();

            // update & remove section
            if (hseIncidentsInRepo.Any())
                foreach (var input in request
                    .Items
                    .Where(_ => _.Type != null)
                    .Where(_ => ImportMtrType.IsHseIncidentType(_.Type)))
                    foreach (var inRepo in hseIncidentsInRepo
                        .Where(_ => _.Key.type == ImportMtrType.GetHseIncidentType(input.Type))
                        .Where(_ => input.StartPeriod.Date == _.Key.date)
                        .Where(_ => input.CustomerId == _.Key.customer?.InnerId)
                        .Where(_ => input.LocationId == _.Key.location?.InnerId))
                    {
                        if (input.Value == null || input.Value == 0)
                        {
                            _importMtr.HseIncidentsRemove(inRepo.ToList());
                            continue;
                        }

                        var hseIncidents = inRepo.ToList();

                        if (input.Value < inRepo.Count())
                            for (var i = 0; i < inRepo.Count() - input.Value; i++)
                                _importMtr.HseIncidentsRemove(hseIncidents[i]);

                        if (input.Value > inRepo.Count())
                            for (var i = 0; i < input.Value - inRepo.Count(); i++)
                                await _importMtr.HseIncidentsAdd(
                                    new List<HseIncident>
                                    {
                                        new (new HseIncidentPayload(
                                            inRepo.Key.date,
                                            inRepo.Key.type,
                                            inRepo.Key.customer,
                                            inRepo.Key.location,
                                            "-",
                                            inRepo.Key.inputType))
                                    },
                                    cancellationToken);
                    }

            var deleteList = new List<HseIncident>();

            _removedItemOutputs.AddRange(deleteList.Select(_ => new ImportMtrItemOutput(
                _.XMin,
                _.Payload.DateTime,
                _.Payload.DateTime,
                _.Payload.Customer?.InnerId,
                _.Payload.Location?.InnerId,
                null,
                ImportMtrType.GetImportMtrType(_.Payload.Type),
                0)));

            var newHseIncidents = new List<HseIncident>();
            var newHseList = request
                .Items
                .Where(_ => _.Value != null)
                .Where(_ => ImportMtrType.IsHseIncidentType(_.Type))
                .Where(_ => !hseIncidentsInRepo
                    .Where(grouping => grouping.Key.type == ImportMtrType.GetHseIncidentType(_.Type))
                    .Where(grouping => _.CustomerId == grouping.Key.customer?.InnerId)
                    .Where(grouping => _.LocationId == grouping.Key.location?.InnerId)
                    .Select(grouping => grouping.Key.date).Contains(_.StartPeriod.Date))
                .Select(_ => (
                    newHse: _.ToHseIncident(
                        _customers.SingleOrDefault(customer => customer.InnerId == _.CustomerId),
                        _locations.SingleOrDefault(location => location.InnerId == _.LocationId),
                        AppInputType.GetInputType(request.InputType)),
                    count: _.Value ?? 0))
                .ToList();

            foreach (var (newHse, count) in newHseList)
            {
                for (var i = 0; i < count; i++)
                {
                    await _importMtr.HseIncidentsAdd(
                        new List<HseIncident>
                        {
                            new(new HseIncidentPayload(
                                newHse.Payload.DateTime,
                                newHse.Payload.Type,
                                newHse.Payload.Customer,
                                newHse.Payload.Location,
                                "-",
                                newHse.Payload.InputType))
                        },
                        cancellationToken);
                }
            }

            _newItemOutputs.AddRange(
                newHseList
                    .Select(_ => new ImportMtrItemOutput(
                        _.newHse.XMin,
                        _.newHse.Payload.DateTime,
                        _.newHse.Payload.DateTime,
                        _.newHse.Payload.Customer?.InnerId,
                        _.newHse.Payload.Location?.InnerId,
                        null,
                        ImportMtrType.GetImportMtrType(_.newHse.Payload.Type),
                        0)));

            if (newHseIncidents.Any())
                await _importMtr.HseIncidentsAdd(newHseIncidents, cancellationToken);
        }

        private async Task Bids(
            ImportMtrCommand request,
            CancellationToken cancellationToken)
        {
            var bidsInRepo = (await _importMtr
                    .BidsGet(
                        _customers,
                        _locations,
                        request
                            .Items
                            .Where(_ => _.Type != null)
                            .Where(_ => ImportMtrType.IsBidType(_.Type))
                            .Select(_ => ImportMtrType.GetBidType(_.Type))
                            .ToList(),
                        request.Items.Select(input => input.StartPeriod).ToList(),
                        cancellationToken))
                .GroupBy(_ => (
                    date: _.Payload.DateTime.Date,
                    type: _.Payload.Type,
                    customer: _.Payload.Customer,
                    location: _.Payload.Location,
                    inputType: _.Payload.InputType))
                .ToList();

            // update & remove section
            if (bidsInRepo.Any())
                foreach (var input in request
                    .Items
                    .Where(_ => _.Type != null)
                    .Where(_ => ImportMtrType.IsBidType(_.Type)))
                    foreach (var inRepo in bidsInRepo
                        .Where(_ => _.Key.type == ImportMtrType.GetBidType(input.Type))
                        .Where(_ => input.StartPeriod.Date == _.Key.date)
                        .Where(_ => input.CustomerId == _.Key.customer?.InnerId)
                        .Where(_ => input.LocationId == _.Key.location?.InnerId))
                    {
                        if (input.Value == null || input.Value == 0)
                        {
                            _importMtr.BidsRemove(inRepo.ToList());
                            continue;
                        }

                        var bids = inRepo.ToList();

                        if (input.Value < inRepo.Count())
                            for (var i = 0; i < inRepo.Count() - input.Value; i++)
                                _importMtr.BidsRemove(bids[i]);

                        if (input.Value > inRepo.Count())
                            for (var i = 0; i < input.Value - inRepo.Count(); i++)
                                await _importMtr.BidsAdd(
                                    new List<Bid>
                                    {
                                        new (new BidPayload(
                                            inRepo.Key.date,
                                            inRepo.Key.type,
                                            inRepo.Key.customer,
                                            inRepo.Key.location,
                                            inRepo.Key.inputType))
                                    },
                                    cancellationToken);
                    }

            var deleteList = new List<Bid>();

            _removedItemOutputs.AddRange(deleteList.Select(_ => new ImportMtrItemOutput(
                _.XMin,
                _.Payload.DateTime,
                _.Payload.DateTime,
                _.Payload.Customer?.InnerId,
                _.Payload.Location?.InnerId,
                null,
                ImportMtrType.GetImportMtrType(_.Payload.Type),
                0)));

            var newBids = new List<Bid>();
            var newBidList = request
                .Items
                .Where(_ => _.Value != null)
                .Where(_ => ImportMtrType.IsBidType(_.Type))
                .Where(_ => !bidsInRepo
                    .Where(grouping => grouping.Key.type == ImportMtrType.GetBidType(_.Type))
                    .Where(grouping => _.CustomerId == grouping.Key.customer?.InnerId)
                    .Where(grouping => _.LocationId == grouping.Key.location?.InnerId)
                    .Select(grouping => grouping.Key.date).Contains(_.StartPeriod.Date))
                .Select(_ => (
                    newBid: _.ToBid(
                        _customers.SingleOrDefault(customer => customer.InnerId == _.CustomerId),
                        _locations.SingleOrDefault(location => location.InnerId == _.LocationId),
                        AppInputType.GetInputType(request.InputType)),
                    count: _.Value ?? 0))
                .ToList();

            foreach (var (newBid, count) in newBidList)
            {
                for (var i = 0; i < count; i++)
                {
                    await _importMtr.BidsAdd(
                        new List<Bid>
                        {
                            new(new BidPayload(
                                newBid.Payload.DateTime,
                                newBid.Payload.Type,
                                newBid.Payload.Customer,
                                newBid.Payload.Location,
                                newBid.Payload.InputType))
                        },
                        cancellationToken);
                }
            }

            _newItemOutputs.AddRange(
                newBidList
                    .Select(_ => new ImportMtrItemOutput(
                        _.newBid.XMin,
                        _.newBid.Payload.DateTime,
                        _.newBid.Payload.DateTime,
                        _.newBid.Payload.Customer?.InnerId,
                        _.newBid.Payload.Location?.InnerId,
                        null,
                        ImportMtrType.GetImportMtrType(_.newBid.Payload.Type),
                        0)));

            if (newBids.Any())
                await _importMtr.BidsAdd(newBids, cancellationToken);
        }
    }
}