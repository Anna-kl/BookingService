﻿using FluentValidation.Results;

using MediatR;

using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.MtrTypes.GetMtrTypeList.Input;
using Supply.Dashboards.App.UseCases.MtrTypes.GetMtrTypeList.Output;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;
using Supply.Dashboards.Domain.Types;

using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.MtrTypes.GetMtrTypeList
{
    public sealed class GetMtrTypeListUseCase
        : IRequestHandler<GetMtrTypeListQuery, (ValidationResult validationResult, GetMtrTypeListOutput? output)>
    {
        private readonly ILogger<GetMtrTypeListUseCase> _logger;
        private readonly IGetMtrTypeList _getMtrTypeList;

        public GetMtrTypeListUseCase(
            ILogger<GetMtrTypeListUseCase> logger,
            IGetMtrTypeList getMtrTypeList)
        {
            _logger = logger;
            _getMtrTypeList = getMtrTypeList;
        }

        public async Task<(ValidationResult validationResult, GetMtrTypeListOutput? output)> Handle(
            GetMtrTypeListQuery request,
            CancellationToken cancellationToken)
        {
            // If the statuses r not contained in the request, then add the "Active" status.
            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            var statuses = request
                .Statuses
                .Select(AppStatusType.GetStatusType)
                .Distinct()
                .ToList();

            // If the statuses r not contained in the request, then add the "Active" status.
            if (!statuses.Any())
                statuses.Add(StatusType.Active);

            var sourceMtrTypes = new List<MtrType>();

            if (request.SourceIds != null && request.SourceIds.Any(_ => _ != null))
                sourceMtrTypes = (await _getMtrTypeList.GetByIds(
                    statuses,
                    request.SourceIds?.Where(_ => _ != null).Select(_ => _!.Value).ToList()!,
                    cancellationToken)).ToList();

            if (!sourceMtrTypes.Any() || request.SourceIds?.Count() != sourceMtrTypes.Count)
                request.SourceIds
                    ?.Where(_ => _ != null)
                    .Select(_ => _.Value)
                    .Except(sourceMtrTypes.Select(_ => _.InnerId)).ToList().ForEach(id =>
                    {
                        request.ValidationResult.Errors.Add(new ValidationFailure(
                            "CustomerId",
                            $"{nameof(MtrType)} with id \"{id}\" is not exist."));
                    });

            // If the statuses r not contained in the request, then add the "Active" status.
            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            var mtrTypes = (await _getMtrTypeList.Get(
                statuses,
                sourceMtrTypes,
                request.Ids?.ToList(),
                request.SourceIds != null && request.SourceIds.Any(_ => _ == null),
                cancellationToken)).ToList();

            return !mtrTypes.Any()
                ? (request.ValidationResult, null)
                : (request.ValidationResult, new GetMtrTypeListOutput(mtrTypes));
        }
    }
}
