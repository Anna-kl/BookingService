﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.UseCases.Data.DataMtr;
using Supply.Dashboards.Domain.AggregatesModel.Bids;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.HseIncidents;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;
using Supply.Dashboards.Domain.AggregatesModel.ValueRecords;
using Supply.Dashboards.Domain.Types;
using Supply.Dashboards.Infrastructure.Data;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.Infrastructure.UseCasesRepositories
{
    public sealed class DataMtrRepository : IDataMtr
    {
        private readonly ILogger<DataMtrRepository> _logger;
        private readonly DashboardsContext _dashboardsContext;

        public DataMtrRepository(
            ILogger<DataMtrRepository> logger,
            DashboardsContext dashboardsContext)
        {
            _logger = logger;
            _dashboardsContext = dashboardsContext;
        }

        public async Task<IEnumerable<ValueRecord>>
            ValueRecordsGet(
                List<ValueRecordType> recordsTypes,
                DateTime startPeriod,
                DateTime? endPeriod,
                List<Guid>? locationsInnerIds,
                List<Guid>? customersInnerIds,
                List<Guid>? mtrTypesInnerIds,
                CancellationToken cancellationToken)
        {
            var queryable = _dashboardsContext
                .ValueRecords
                .AsNoTracking()
                .Include(_ => _.Payload.Location)
                .Include(_ => _.Payload.Customer)
                .Include(_ => _.Payload.MtrType)
                .AsQueryable();

            if (recordsTypes.Any())
                queryable = queryable.Where(_ => recordsTypes.Contains(_.Payload.Type));

            if (customersInnerIds != null && customersInnerIds.Any())
                queryable = queryable.Where(_ => customersInnerIds.Contains(_.Payload.Customer!.InnerId));

            if (locationsInnerIds != null && locationsInnerIds.Any())
                queryable = queryable.Where(_ => locationsInnerIds.Contains(_.Payload.Location!.InnerId));

            if (mtrTypesInnerIds != null && mtrTypesInnerIds.Any())
                queryable = queryable.Where(_ => mtrTypesInnerIds.Contains(_.Payload.MtrType!.InnerId));

            var result = await queryable.Where(_ => endPeriod == null
                    ? _.Payload.StartPeriod >= startPeriod
                    : _.Payload.StartPeriod >= startPeriod && _.Payload.EndPeriod <= endPeriod)
                .ToListAsync(cancellationToken);

            return result.ToList().AsReadOnly();
        }

        public async Task<IEnumerable<HseIncident>> HseIncidentGet(
            List<HseIncidentType> incidentTypes,
            DateTime startPeriod,
            DateTime? endPeriod,
            List<Guid>? locationsInnerIds,
            List<Guid>? customersInnerIds,
            CancellationToken cancellationToken)
        {
            var queryable = _dashboardsContext
                .HseIncidents
                .AsNoTracking()
                .Include(_ => _.Payload.Location)
                .Include(_ => _.Payload.Customer)
                .AsQueryable();

            if (incidentTypes.Any())
                queryable = queryable.Where(_ => incidentTypes.Contains(_.Payload.Type));

            if (customersInnerIds != null && customersInnerIds.Any())
                queryable = queryable.Where(_ => customersInnerIds.Contains(_.Payload.Customer!.InnerId));

            if (locationsInnerIds != null && locationsInnerIds.Any())
                queryable = queryable.Where(_ => locationsInnerIds.Contains(_.Payload.Location!.InnerId));

            var result = await queryable.Where(_ => endPeriod == null
                    ? _.Payload.DateTime >= startPeriod
                    : _.Payload.DateTime >= startPeriod && _.Payload.DateTime <= endPeriod)
                .ToListAsync(cancellationToken);

            return result.ToList().AsReadOnly();
        }

        public async Task<IEnumerable<Bid>> BidsGet(
            List<BidType> bidTypes,
            DateTime startPeriod,
            DateTime? endPeriod,
            List<Guid>? locationsInnerIds,
            List<Guid>? customersInnerIds,
            CancellationToken cancellationToken)
        {
            var queryable = _dashboardsContext
                .Bids
                .AsNoTracking()
                .Include(_ => _.Payload.Location)
                .Include(_ => _.Payload.Customer)
                .AsQueryable();

            if (bidTypes.Any())
                queryable = queryable.Where(_ => bidTypes.Contains(_.Payload.Type));

            if (customersInnerIds != null && customersInnerIds.Any())
                queryable = queryable.Where(_ => customersInnerIds.Contains(_.Payload.Customer!.InnerId));

            if (locationsInnerIds != null && locationsInnerIds.Any())
                queryable = queryable.Where(_ => locationsInnerIds.Contains(_.Payload.Location!.InnerId));

            var result = await queryable.Where(_ => endPeriod == null
                    ? _.Payload.DateTime >= startPeriod
                    : _.Payload.DateTime >= startPeriod && _.Payload.DateTime <= endPeriod)
                .ToListAsync(cancellationToken);

            return result.ToList().AsReadOnly();
        }

        public async Task<IEnumerable<Customer>> GetCustomersByInnerIds(
            List<Guid> innerIds,
            CancellationToken cancellationToken)
        {
            var result = await _dashboardsContext
                .Customers
                .AsNoTracking()
                .Where(_ => innerIds.Contains(_.InnerId))
                .ToListAsync(cancellationToken);

            return result.AsReadOnly();
        }

        public async Task<IEnumerable<Location>> GetLocationsByInnerIds(
            List<Guid> innerIds,
            CancellationToken cancellationToken)
        {
            var result = await _dashboardsContext
                .Locations
                .AsNoTracking()
                .Where(_ => innerIds.Contains(_.InnerId))
                .ToListAsync(cancellationToken);

            return result.AsReadOnly();
        }

        public async Task<IEnumerable<MtrType>> GetMtrTypesByInnerIds(
            List<Guid> innerIds,
            CancellationToken cancellationToken)
        {
            var result = await _dashboardsContext
                .MtrTypes
                .AsNoTracking()
                .Where(_ => innerIds.Contains(_.InnerId))
                .ToListAsync(cancellationToken);

            return result.AsReadOnly();
        }
    }
}
