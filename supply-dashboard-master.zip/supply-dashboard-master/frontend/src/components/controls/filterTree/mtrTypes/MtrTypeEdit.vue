<template>
  <div v-if="popupVisible">
    <DxPopup
      :visible.sync="popupVisible"
      ref="mtrTypeTreeEditPopup"
      :drag-enabled="false"
      :close-on-outside-click="true"
      :show-title="true"
      width="600px"
      height="auto"
      @hidden="closeOnClick"
      title="Тип МТР"
    >
      <div class="field">
        <div class="label">Название</div>
        <div class="value">
          <DxTextBox v-model="currentData.title" />
        </div>
      </div>
      <div class="field">
        <div class="label">Описание</div>
        <div class="value">
          <DxTextBox v-model="currentData.description" />
        </div>
      </div>
      <div class="field">
        <div class="label">Родители</div>
        <div class="value tree-container">
          <DirectoryEdgesEditor
            v-if="popupVisible"
            ref="mtrTypeEdgesEditor"
            :editedItem="editedItem"
            :loadDataItemFromApi="loadDataItemFromApi"
            :loadDataItemsFromApi="loadDataItemsFromApi"
          />
        </div>
      </div>
      <DxButton
        icon="save"
        type="success"
        text="Сохранить"
        @click="saveClick()"
      />
    </DxPopup>
  </div>
</template>

<script lang='ts'>
import DirectoryEdit from "../DirectoryEdit";
import { DxCheckBox } from "devextreme-vue/check-box";
import { Component, Watch, Prop } from "vue-property-decorator";
import DxTextBox from "devextreme-vue/text-box";
import DxSelectBox from "devextreme-vue/select-box";
import { DxPopup } from "devextreme-vue/popup";
import DxButton from "devextreme-vue/button";
import { DxNumberBox } from "devextreme-vue/number-box";
import notify from "devextreme/ui/notify";
import { InputDataState } from "@/store";
import { InputDataService } from "@/services/inputDataService";
import { Guid } from "@/helpers/guid";
import DirectoryEdgesEditor from "../DirectoryEdgesEditor.vue";
import { 
  ILocationDataItem, 
  IMtrTypeDataItem,
  ILocation,
  LocationTypeEnum,
  IRelation,
  IMtrType
} from "../types";

@Component({
  components: {
    DxCheckBox,
    DxPopup,
    DxTextBox,
    DxButton,
    DxNumberBox,
    DirectoryEdgesEditor,
    DxSelectBox,
  },
})
export default class MtrTypeEdit extends DirectoryEdit<IMtrTypeDataItem> {
  private created() {
    this._inputDataService = new InputDataService();
    this.currentData = {
      id: Guid.newGuid(),
      rowVersion: 0,
      parentIds: [],
      title: "",
      description: "",
      childrenIds: [],
    };
    this.itemRelations = [];
  }

  private saveClick() {
    const mtrType: IMtrType = {
      id: this.currentData.id,
      rowVersion: this.currentData.rowVersion,
      title: this.currentData.title,
      description: this.currentData.description,
      childrenIds: this.currentData.childrenIds,
    };

    this.itemRelations = (this.$refs[
      "mtrTypeEdgesEditor"
    ] as DirectoryEdgesEditor).getDirectoryEdges();

    this._inputDataService
      .saveMtrType(mtrType, this.itemRelations)
      .then((data) => {
        this.popupVisible = false;
        notify("Данные успешно сохранены.", "success", 3000);
        this.reloadTree();
      })
      .catch((error) => {
        notify("При сохранении произошла ошибка!", "error", 3000);
      });
  }
}
</script>

<style scoped>
.label {
  font-size: small;
}
.tree-container {
  margin: 5px;
  border-style: ridge;
  border-width: 1px;
}
</style>