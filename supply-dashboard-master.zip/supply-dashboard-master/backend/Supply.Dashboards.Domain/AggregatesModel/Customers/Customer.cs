﻿using Common.SeedWork;
using Supply.Dashboards.Domain.Exceptions;
using Supply.Dashboards.Domain.Types;
using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Domain.AggregatesModel.Customers
{
    public sealed class Customer : Aggregate
    {
        private readonly List<CustomerEdge>? _sourceEdges;
        private readonly List<CustomerEdge>? _destinationEdges;

        #region c'tors

        public Customer(
            Guid id,
            CustomerPayload payload)
        {
            Id = default;
            InnerId = id == default
                ? throw new DomainException($"{nameof(id)} can't be null.")
                : id;
            XMin = default;
            CreateAt = DateTime.UtcNow;
            UpdateAt = DateTime.UtcNow;
            Status = StatusType.Active;
            Payload = payload
                      ?? throw new DomainException($"{nameof(payload)} can't be null.");

            _sourceEdges = new List<CustomerEdge>();
            _destinationEdges = new List<CustomerEdge>();

            AddDomainEvent(new Event(InnerId.ToString(), Status, Payload));
        }

#pragma warning disable 8618
        // ReSharper disable once UnusedMember.Local
        private Customer()
        {
        }
#pragma warning restore 8618

        #endregion

        #region props

        public uint XMin { get; private set; }
        public DateTime CreateAt { get; init; }
        public DateTime UpdateAt { get; private set; }

        public StatusType Status { get; private set; }
        public CustomerPayload Payload { get; private set; }

        public IEnumerable<CustomerEdge>? SourceEdges =>
            _sourceEdges?.AsReadOnly();

        public IEnumerable<CustomerEdge>? DestinationEdges =>
            _destinationEdges?.AsReadOnly();

        #endregion

        #region methods

        public void ChangeStatus(StatusType status)
        {
            UpdateAt = DateTime.UtcNow;
            Status = status
                     ?? throw new DomainException($"{nameof(status)} can't be null.");

            AddDomainEvent(new Event(InnerId.ToString(), Status, Payload));
        }

        public void Update(CustomerPayload payload)
        {
            UpdateAt = DateTime.UtcNow;
            Payload = payload
                      ?? throw new DomainException($"{nameof(payload)} can't be null.");

            AddDomainEvent(new Event(InnerId.ToString(), Status, Payload));
        }

        public void AddSourceEdges(IEnumerable<CustomerEdge> edges)
        {
            _sourceEdges?.AddRange(edges);
            AddDomainEvent(new Event(InnerId.ToString(), Status, Payload));
        }

        public void AddDestinationEdges(IEnumerable<CustomerEdge> edges)
        {
            _destinationEdges?.AddRange(edges);
            AddDomainEvent(new Event(InnerId.ToString(), Status, Payload));
        }

        #endregion
    }
}
