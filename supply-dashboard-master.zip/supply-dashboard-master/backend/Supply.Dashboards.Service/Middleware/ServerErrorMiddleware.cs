﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

using Newtonsoft.Json;

using Supply.Dashboards.App.Exceptions;
using Supply.Dashboards.Domain.Exceptions;

using System;
using System.Threading.Tasks;

namespace Supply.Dashboards.Service.Middleware
{
    public sealed class ServerErrorMiddleware
    {
        private readonly ILogger<ServerErrorMiddleware> _logger;
        private readonly RequestDelegate _next;

        public ServerErrorMiddleware(
            RequestDelegate next,
            ILoggerFactory loggerFactory)
        {
            _next = next
                    ?? throw new ArgumentNullException(nameof(next));

            _logger = loggerFactory.CreateLogger<ServerErrorMiddleware>()
                      ?? throw new ArgumentNullException(nameof(loggerFactory));
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (AppException e)
            {
                if (context.Response.HasStarted)
                {
                    _logger.LogInformation(e.Message, e.StackTrace);

                    throw;
                }

                _logger.LogError(e.Message, e.StackTrace);
                await ValidationErrorResponse(context, e.Message);
            }
            catch (DomainException e)
            {
                if (context.Response.HasStarted)
                {
                    _logger.LogError(e.Message, e.StackTrace);

                    throw;
                }

                _logger.LogError(e.Message, e.StackTrace);
                await ValidationErrorResponse(context, e.Message);
            }
        }

        private async Task ValidationErrorResponse(HttpContext context, string message)
        {
            context.Response.Clear();
            context.Response.StatusCode = 500;
            context.Response.ContentType = @"application/json";
            var json = JsonConvert.SerializeObject(message);
            await context.Response.WriteAsync(json);
        }
    }
}
