﻿using FluentValidation.Results;

using MediatR;

using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.Charts.TransportResources.Input;
using Supply.Dashboards.App.UseCases.Charts.TransportResources.Output;
using Supply.Dashboards.App.UseCases.Charts.TransportResources.Types;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.AggregatesModel.ValueRecords;
using Supply.Dashboards.Domain.Types;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Common.Extensions;
using Supply.Dashboards.App.UseCases.Charts.TransportResources;
using Supply.Dashboards.App.UseCases.ValueRecords;
using Supply.Dashboards.App.UseCases.Locations.GetLocationList;

namespace Supply.Dashboards.App.UseCases.Charts.TransportResourcesByLocations
{
    public sealed class TransportResourcesByLocationsUseCase
        : IRequestHandler<TransportResourcesByLocationsQuery, (ValidationResult validationResult, TransportResourcesByLocationsOutput? output)>
    {
        private readonly ILogger<TransportResourcesByLocationsUseCase> _logger;
        private readonly IMediator _mediator;
        private readonly IValueRecords _valueRecordsRepo;
        private readonly IGetLocationList _locationsRepo;

        private ValidationResult _validationResult;
        private readonly List<StatusType> _selectStatus;

        public TransportResourcesByLocationsUseCase(
            ILogger<TransportResourcesByLocationsUseCase> logger,
            IMediator mediator,
            IValueRecords valueRecordsRepo,
            IGetLocationList locationsRepo)
        {
            _logger = logger;
            _mediator = mediator;
            _valueRecordsRepo = valueRecordsRepo;
            _locationsRepo = locationsRepo;

            _validationResult = new ValidationResult();
            _selectStatus = new List<StatusType> { StatusType.Active };
        }

        public async Task<(ValidationResult validationResult, TransportResourcesByLocationsOutput? output)> Handle(
            TransportResourcesByLocationsQuery request,
            CancellationToken cancellationToken)
        {
            _validationResult = request.ValidationResult;

            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            var records = await _valueRecordsRepo.GetRecordsWithDateFilter(
                new List<ValueRecordType>
                {
                    ValueRecordType.TransportPlan,
                    ValueRecordType.TransportFact,
                    ValueRecordType.GPMPlan,
                    ValueRecordType.GPMFact,
                    ValueRecordType.LaborResourcesPlan,
                    ValueRecordType.LaborResourcesFact
                },
                request.StartPeriod,
                request.EndPeriod,
                null,
                request.ParentLocationId,
                request.LocationsIds,
                request.CustomersIds,
                request.MtrTypesIds,
                _selectStatus,
                false,
                false,
                cancellationToken);
            var recordsByLocations = records.GroupBy(_ => _.Payload.Location);

            var resultItems = new List<TransportResourcesByLocationsParamOutput>();

            var divisionsWithAllChildrensLocations = _locationsRepo.GetActiveDivisionsWithChildrenLocations();

            foreach (var divisionWithLocations in divisionsWithAllChildrensLocations)
            {
                // записи сгруппированные по локациям дивизиона
                var locationsWithRecords = recordsByLocations.Where(locationWithRecords =>
                    divisionWithLocations.Value.Select(_ => _.InnerId).Contains(locationWithRecords.Key!.InnerId)
                    || divisionWithLocations.Key.InnerId == locationWithRecords.Key!.InnerId
                    );

                // если запрос с группировкой(суммой всех локаций) дивизиона
                if (request.LocationType == LocationType.Division)
                {

                    resultItems.Add(new TransportResourcesByLocationsParamOutput(
                        divisionWithLocations.Key.InnerId,
                        divisionWithLocations.Key.Payload.Title,
                        locationsWithRecords.SelectMany(_ => _).GroupBy(gType =>
                           gType.Payload.Type)
                         .Select(gTypeValues =>
                         new TransportResourcesUnitOutput(
                             TransportResourcesType.GetTransportResourcesType(gTypeValues.Key),
                             gTypeValues.Sum(r => r.Payload.Value))
                             ).ToList()
                        ));
                }
                else
                {
                    foreach (var locationWithRecords in locationsWithRecords)
                    {
                        resultItems.Add(new TransportResourcesByLocationsParamOutput(
                        locationWithRecords.Key!.InnerId,
                        locationWithRecords.Key.Payload.Title,
                        locationWithRecords.GroupBy(gType =>
                           gType.Payload.Type)
                         .Select(gTypeValues =>
                         new TransportResourcesUnitOutput(
                             TransportResourcesType.GetTransportResourcesType(gTypeValues.Key),
                             gTypeValues.Sum(r => r.Payload.Value))
                             ).ToList()
                        ));
                    }
                }
            }

            return (_validationResult, new TransportResourcesByLocationsOutput(resultItems));

        }

    }
}
