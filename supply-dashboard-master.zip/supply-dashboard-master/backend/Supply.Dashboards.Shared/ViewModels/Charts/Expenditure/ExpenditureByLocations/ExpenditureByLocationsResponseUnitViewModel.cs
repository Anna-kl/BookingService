﻿using Supply.Dashboards.Shared.Types;

namespace Supply.Dashboards.Shared.ViewModels.Charts.ExpenditureByLocations
{
    public sealed class ExpenditureByLocationsResponseUnitViewModel
    {
        public ValueRecordEnum Type { get; set; }
        public double Tons { get; set; }
    }
}
