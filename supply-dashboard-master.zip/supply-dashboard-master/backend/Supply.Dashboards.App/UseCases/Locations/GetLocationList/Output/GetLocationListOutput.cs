﻿using Supply.Dashboards.App.Types;
using Supply.Dashboards.Domain.AggregatesModel.Locations;

using System;
using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.Locations.GetLocationList.Output
{
    public sealed class GetLocationListOutput
    {
        private readonly List<GetLocationListItemOutput> _locations;

        public GetLocationListOutput(IEnumerable<Location>? locations)
        {
            _locations = locations
                ?.Select(ToGetLocationListItemOutput)
                .ToList() ?? new List<GetLocationListItemOutput>();
        }

        public IEnumerable<GetLocationListItemOutput> Items =>
            _locations.AsReadOnly();

        private static GetLocationListItemOutput ToGetLocationListItemOutput(Location location)
        {
            return new(
                location.InnerId,
                location.XMin,
                location.SourceEdges?.Select(_ => _.SourceInnerId).ToList() ?? new List<Guid>(),
                location.DestinationEdges?.Select(_ => _.DestinationInnerId).ToList() ?? new List<Guid>(),
                location.Status,
                AppLocationType.GetAppLocationType(location.Payload.Type),
                location.Payload.Title,
                location.Payload.Description,
                location.Payload.Longitude,
                location.Payload.Latitude,
                location.Payload.Diameter);
        }
    }
}
