﻿using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;

using System;

namespace Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Input
{
    public sealed class ImportDirectoriesMtrTypeInput
    {
        public ImportDirectoriesMtrTypeInput(
            Guid? id,
            uint rowVersion,
            string? title,
            string? description,
            bool? isObsolete)
        {
            Id = id ?? Guid.Empty;
            XMin = rowVersion;
            Title = title ?? string.Empty;
            Description = description ?? string.Empty;
            IsObsolete = isObsolete;
        }

        public Guid Id { get; }
        public uint XMin { get; }
        public string Title { get; }
        public string Description { get; }

        public bool? IsObsolete { get; }

        internal MtrType ToMtrType()
        {
            return new MtrType(
                Id,
                new MtrTypePayload(Title, Description));
        }
    }
}