﻿using Supply.Dashboards.Domain.AggregatesModel;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.InnerEventHandlers
{
    public interface IDomainEventHandler
    {
        Task AddEvent(Event @event, CancellationToken cancellationToken);
    }
}
