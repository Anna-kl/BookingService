﻿using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.WeatherRestrictions.WeatherRestrictionsList
{
    public sealed class WeatherRestrictionsListResponseViewModel
    {
        public List<WeatherRestrictionsListItemResponseViewModel>? Items { get; set; }
    }
}
