﻿using Common.SeedWork;

using Supply.Dashboards.Domain.Exceptions;

using System.Collections.Generic;

namespace Supply.Dashboards.Domain.AggregatesModel.MtrTypes
{
    public sealed class MtrTypePayload : ValueObject
    {
        public MtrTypePayload(
            string title,
            string description)
        {
            Title = string.IsNullOrWhiteSpace(title)
                ? throw new DomainException($"{nameof(title)} can't be null or white-space.")
                : title;
            Description = description;
        }

#pragma warning disable 8618
        private MtrTypePayload()
        {
        }
#pragma warning restore 8618

        public string Title { get; init; }
        public string? Description { get; init; }

        protected override IEnumerable<object> GetAtomicValues()
        {
            yield return Title;
            yield return Description!;
        }
    }
}
