﻿using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Charts.SeasonalDelivery
{
    public sealed class SeasonalDeliveryResponse
    {
        public List<SeasonalDeliveryParamResponse>? Locations { get; set; }
    }
}
