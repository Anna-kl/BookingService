﻿using System;

namespace Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Output
{
    public sealed class ImportDirectoriesMtrTypeEdgeOutput
    {
        public ImportDirectoriesMtrTypeEdgeOutput(
            Guid sourceId,
            Guid destinationId)
        {
            SourceId = sourceId;
            DestinationId = destinationId;
        }

        public Guid SourceId { get; }
        public Guid DestinationId { get; }
    }
}
