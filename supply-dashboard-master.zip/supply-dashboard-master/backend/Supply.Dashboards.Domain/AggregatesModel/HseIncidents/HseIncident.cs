﻿using Common.SeedWork;

using Supply.Dashboards.Domain.Exceptions;
using Supply.Dashboards.Domain.Types;

using System;

namespace Supply.Dashboards.Domain.AggregatesModel.HseIncidents
{
    public sealed class HseIncident : Aggregate
    {
        #region c'tors

        public HseIncident(HseIncidentPayload payload)
        {
            Id = default;
            InnerId = Guid.NewGuid();
            XMin = default;
            CreateAt = DateTime.UtcNow;
            UpdateAt = DateTime.UtcNow;
            Payload = payload
                      ?? throw new DomainException($"{nameof(payload)} can't be null.");

            AddDomainEvent(new Event(InnerId.ToString(), StatusType.Active, Payload));
        }

#pragma warning disable 8618
        // ReSharper disable once UnusedMember.Local
        private HseIncident()
        {
        }
#pragma warning restore 8618

        #endregion

        #region props

        public uint XMin { get; private set; }
        public DateTime CreateAt { get; init; }
        public DateTime UpdateAt { get; private set; }
        public HseIncidentPayload Payload { get; private set; }

        #endregion

        #region methods

        public void Update(HseIncidentPayload payload)
        {
            UpdateAt = DateTime.UtcNow;
            Payload = payload
                      ?? throw new DomainException($"{nameof(payload)} can't be null.");
            
            AddDomainEvent(new Event(InnerId.ToString(), StatusType.Active, Payload));
        }

        #endregion
    }
}
