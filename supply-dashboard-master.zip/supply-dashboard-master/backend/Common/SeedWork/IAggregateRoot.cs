﻿namespace Common.SeedWork
{
    public interface IAggregateRoot
    {
    }
}
