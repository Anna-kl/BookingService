﻿using System;
using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.ContextUserSettings.GetContextUserSettings.Output
{
    public sealed class GetContextUserSettingsOutput
    {
        public GetContextUserSettingsOutput(
            string dashboardsState)
        {
            DashboardsState = dashboardsState;
        }

        public string DashboardsState { get; }

    }
}
