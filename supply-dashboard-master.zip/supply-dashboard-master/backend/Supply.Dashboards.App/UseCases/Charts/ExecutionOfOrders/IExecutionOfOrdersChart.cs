﻿using Supply.Dashboards.Domain.AggregatesModel.Bids;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.Types;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.Charts.ExecutionOfOrders
{
    public interface IExecutionOfOrdersChart
    {
        #region customers

        Task<IEnumerable<Guid>> GetCustomersExistingIds(
            List<StatusType> statuses,
            List<Guid> ids,
            CancellationToken cancellationToken);

        Task<IEnumerable<Customer>> GetCustomers(
            List<StatusType> statuses,
            CancellationToken cancellationToken);

        Task<IEnumerable<CustomerEdge>> GetCustomersEdges(
            List<Guid> ids,
            CancellationToken cancellationToken);

        #endregion

        #region locations

        Task<IEnumerable<Guid>> GetLocationsExistingIds(
            List<StatusType> statuses,
            List<Guid> ids,
            CancellationToken cancellationToken);

        Task<IEnumerable<Location>> GetLocations(
            List<StatusType> statuses,
            CancellationToken cancellationToken);

        Task<IEnumerable<LocationEdge>> GetLocationsEdges(
            List<Guid> ids,
            CancellationToken cancellationToken);

        #endregion

        public Task<IEnumerable<Bid>> GetRecords(
            DateTime startPeriod,
            DateTime endPeriod,
            List<Location>? locations,
            List<Customer>? customers,
            CancellationToken cancellationToken);
    }
}
