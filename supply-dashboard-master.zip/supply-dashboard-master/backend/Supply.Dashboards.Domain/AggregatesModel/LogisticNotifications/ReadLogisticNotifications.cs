﻿namespace Supply.Dashboards.Domain.AggregatesModel.LogisticNotifications
{
    public sealed class ReadLogisticNotifications
    {
        //public int Id { get; }

        //public int UserId { get; }
        //public User User { get; }

        //public LogisticNotification LogisticNotification { get; }
    }
}
