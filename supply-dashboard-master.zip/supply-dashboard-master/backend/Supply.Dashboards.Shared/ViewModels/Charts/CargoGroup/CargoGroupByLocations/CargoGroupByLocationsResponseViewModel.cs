﻿using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Charts.CargoGroupByLocations
{
    public sealed class CargoGroupByLocationsResponseViewModel
    {
        public List<CargoGroupByLocationsResponseParamViewModel>? Locations { get; set; }
    }
}
