<template>
  <div>
    <h4>Справочники</h4>
    <DxTabPanel>
      <DxItem title="Направления">
        <template #default>
          <div class="directory-tree">
            <LocationsSelect :pageType="pageType" />
          </div>
        </template>
      </DxItem>
      <DxItem title="Заказчики">
        <template #default>
          <div class="directory-tree">
            <CustomersSelect :pageType="pageType" />
          </div>
        </template>
      </DxItem>
      <DxItem title="Тип МТР">
        <template #default>
          <div class="directory-tree">
            <MtrTypesSelect :pageType="pageType" />
          </div>
        </template>
      </DxItem>
      <DxItem v-if="pageType === 'inputData'" title="Тип данных">
        <template #default>
          <div class="directory-tree">
            <MtrItemTypesSelect />
          </div>
        </template>
      </DxItem>
    </DxTabPanel>
  </div>
</template>

<script lang='ts'>
import Vue from "vue";
import DxTabPanel, { DxItem } from "devextreme-vue/tab-panel";
import { Component, Prop, Watch } from "vue-property-decorator";
import LocationsSelect from "./locations/LocationsSelect.vue";
import CustomersSelect from "./customers/CustomersSelect.vue";
import MtrTypesSelect from "./mtrTypes/MtrTypesSelect.vue";
import MtrItemTypesSelect from "./mtrItemTypes/MtrItemTypesSelect.vue";

@Component({
  components: {
    DxTabPanel,
    DxItem,
    LocationsSelect,
    MtrTypesSelect,
    CustomersSelect,
    MtrItemTypesSelect,
  },
})
export default class FilterTree extends Vue {
  @Prop({ type: String, required: true }) public pageType!: string;
}
</script>

<style scoped>
.directory-tree {
  min-height: 350px;
}
</style>