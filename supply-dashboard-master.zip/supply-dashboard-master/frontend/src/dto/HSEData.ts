
export interface IHSELastIncident {
    dateTime: string;
    type: string;
    text: string;
}

export interface IHSEUnit {
    type: string;
    count: number;
}


export interface IHSEDataResponse {
    daysWithoutIncident: number;
    lastIncident: IHSELastIncident;
    units: IHSEUnit[];
}

export interface IHSEDataRequest {
    startPeriod: string;
    endPeriod: string;
    lastIncidentTypes?: string[] | null;
    locationsIds?: string[] | null;
    customersIds?: string[] | null;
    mtrTypesIds?: string[] | null;

}

export interface IHSEChartData {
    description: string;
    count: number;
}