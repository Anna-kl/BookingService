﻿using FluentValidation.Results;

using MediatR;

using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.MtrTypes.GetMtrTypeList.Output;

using System;
using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.MtrTypes.GetMtrTypeList.Input
{
    public sealed class GetMtrTypeListQuery
        : IRequest<(ValidationResult validationResult, GetMtrTypeListOutput? output)>
    {
        private readonly List<AppStatusType>? _statuses;
        private readonly List<Guid?>? _sourceIds;
        private readonly List<Guid>? _ids;

        public GetMtrTypeListQuery(
            IEnumerable<AppStatusType>? statuses,
            IEnumerable<Guid?>? sourceIds,
            IEnumerable<Guid>? ids)
        {
            _statuses = statuses?.ToList() ?? new List<AppStatusType> { AppStatusType.Active };
            _sourceIds = sourceIds?.ToList();
            _ids = ids?.ToList();

            ValidationResult = new GetMtrTypeListValidator()
                .Validate(this);
        }

        public IEnumerable<AppStatusType> Statuses => _statuses!.AsReadOnly();
        public IEnumerable<Guid?>? SourceIds => _sourceIds?.AsReadOnly();
        public IEnumerable<Guid>? Ids => _ids?.AsReadOnly();

        public ValidationResult ValidationResult { get; }
    }
}
