<template>
  <div>
    <span>Временные отметки: </span>
    <ul class="checkBoxList">
      <li v-for="timeStamp in timeStamps" :key="timeStamp.id">
        <DxCheckBox
          :name="'timeStampList' + timeStamp.id"
          :value="timeStamp.value"
          :text="timeStamp.name"
          @value-changed="timeStampListChanged($event, timeStamp)"
        />
      </li>
    </ul>
  </div>
</template>

<script lang='ts'>
import Vue from "vue";

import { DxTreeView } from "devextreme-vue/tree-view";
import { DxCheckBox } from "devextreme-vue/check-box";
import DxSortable from "devextreme-vue/sortable";
import DataSource from "devextreme/data/data_source";
import { Component, Watch } from "vue-property-decorator";
import { dxTreeViewNode } from "devextreme/ui/tree_view";
import { ILocation, LocationTypeEnum } from "@/dto/InputData";
import { InputDataState } from "@/store";
import { InputDataService } from "@/services/inputDataService";

class TimeStampValue {
  id: string;
  name: string;
  value: boolean;
  constructor(id: string, name: string, value: boolean) {
    this.id = id;
    this.name = name;
    this.value = value;
  }
}

@Component({
  components: {
    DxTreeView,
    DxCheckBox,
    DxSortable,
  },
})
export default class TimeStampList extends Vue {
  public _inputDataService!: InputDataService;
  private timeStamps: TimeStampValue[] = [
    new TimeStampValue("year", "Год", true),
    new TimeStampValue("month", "Месяц", true),
    // new TimeStampValue("week", "Неделя", false), // не понятно что с этим делать, пока так
    new TimeStampValue("day", "День", true),
  ];
  private created() {
    this._inputDataService = new InputDataService();
  }

  private mounted(): void {
    InputDataState.setSelectedTimeSpans(
      this.timeStamps.filter((d) => d.value).map((s) => s.id)
    );
  }

  private timeStampListChanged(e: any, timeStamp: TimeStampValue) {
    const newSelectedTimeStampList: string[] = InputDataState.selectedTimeSpans.filter(
      (s) => s != timeStamp.id
    );

    if (e.value) {
      newSelectedTimeStampList.push(timeStamp.id);
    }

    InputDataState.setSelectedTimeSpans(newSelectedTimeStampList);
  }
}
</script>

<style scoped>
.checkBoxList {
  list-style-type: none;
}
</style>