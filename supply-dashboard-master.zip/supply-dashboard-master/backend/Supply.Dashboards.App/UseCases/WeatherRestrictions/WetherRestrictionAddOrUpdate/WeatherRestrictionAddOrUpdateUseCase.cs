﻿using FluentValidation.Results;

using MediatR;

using Microsoft.Extensions.Logging;
using Supply.Dashboards.App.UseCases.WeatherRestrictions.WetherRestrictionAddOrUpdate.Input;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.AggregatesModel.WeatherRestrictions;
using Supply.Dashboards.Domain.Types;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.WeatherRestrictions.WeatherRestrictionAddOrUpdate
{
    public sealed class WeatherRestrictionAddOrUpdateUseCase
        : IRequestHandler<WeatherRestrictionAddOrUpdateQuery, (ValidationResult validationResult, bool result)>
    {
        private readonly ILogger<WeatherRestrictionAddOrUpdateUseCase> _logger;
        private readonly IBaseUseCase _baseRepo;

        private ValidationResult _validationResult;

        public WeatherRestrictionAddOrUpdateUseCase(
            ILogger<WeatherRestrictionAddOrUpdateUseCase> logger,
            IBaseUseCase baseRepo)
        {
            _logger = logger;
            _baseRepo = baseRepo;
            _validationResult = new ValidationResult();
        }

        public async Task<(ValidationResult validationResult, bool result)> Handle(
            WeatherRestrictionAddOrUpdateQuery request,
            CancellationToken cancellationToken)
        {
            _validationResult = request.ValidationResult;

            if (!_validationResult.IsValid) return (_validationResult, false);

            Customer? customer = null;
            if (request.CustomerId != null)
            {
                customer = _baseRepo.GetFirstOrDefault<Customer>(_ => _.InnerId == request.CustomerId);
                if (customer == null)
                {
                    _validationResult.Errors.Add(new ValidationFailure(
                        "CustomerId",
                        $"{nameof(Customer)} with id \"{request.CustomerId}\" is not exist."));
                }
            }

            var location = _baseRepo.GetFirstOrDefault<Location>(_ => _.InnerId == request.LocationId);
            if (location == null)
            {
                _validationResult.Errors.Add(new ValidationFailure(
                    "LocationId",
                    $"{nameof(Location)} with id \"{request.LocationId}\" is not exist."));
            }

            if (request.Id == null)
            {
                var newWeatherRestriction = new WeatherRestriction(
                       new WeatherRestrictionPayload(
                       request.Date,
                       customer,
                       location,
                       InputType.ManualInput,
                       request.Temperature,
                       request.WindSpeed,
                       request.Aktirovka)
                       );
                _baseRepo.Create<WeatherRestriction>(newWeatherRestriction);
                await _baseRepo.UnitOfWork.SaveChangesAsync(cancellationToken);
            }
            else
            {
                var weatherRestriction = _baseRepo.GetFirstOrDefault<WeatherRestriction>(_ => _.InnerId == request.Id);

                if (weatherRestriction == null)
                {
                    _validationResult.Errors.Add(new ValidationFailure(
                     "Id",
                     $"{nameof(WeatherRestriction)} with id \"{request.Id}\" is not exist."));

                }
                else
                {
                    weatherRestriction.ChangePayload(new WeatherRestrictionPayload(
                        request.Date,
                        customer,
                        location,
                        InputType.ManualInput,
                        request.Temperature,
                        request.WindSpeed,
                        request.Aktirovka));
                    await _baseRepo.UnitOfWork.SaveChangesAsync(cancellationToken);
                }
            }

            return (_validationResult, true);
        }



    }
}
