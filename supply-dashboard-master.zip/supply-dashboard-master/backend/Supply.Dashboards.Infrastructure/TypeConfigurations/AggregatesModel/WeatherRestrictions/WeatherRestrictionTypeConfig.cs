﻿using Common.SeedWork;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Supply.Dashboards.App.UserInfo;
using Supply.Dashboards.Domain.AggregatesModel.Core;
using Supply.Dashboards.Domain.AggregatesModel.WeatherRestrictions;
using Supply.Dashboards.Domain.Types;

namespace Supply.Dashboards.Infrastructure.TypeConfigurations.AggregatesModel.WeatherRestrictions
{
    public sealed class WeatherRestrictionTypeConfig : IEntityTypeConfiguration<WeatherRestriction>
    {
        public void Configure(EntityTypeBuilder<WeatherRestriction> builder)
        {
            builder.ToTable("weather_restrictions");

            builder.HasKey(_ => _.Id);
            builder.HasAlternateKey(_ => _.InnerId);

            builder
                .Property(_ => _.Id)
                .ValueGeneratedOnAdd();

            builder
                .HasOne<Context>()
                .WithMany()
                .HasForeignKey("ContextId")
                .IsRequired();
            builder.HasQueryFilter(_ => UserInfo.Context == null
                ? EF.Property<int>(_, "ContextId") != 0
                : EF.Property<int>(_, "ContextId") == UserInfo.Context.Id);

            builder
                .OwnsOne(_ => _.Payload)
                .Property(payload => payload.InputType)
                .HasConversion(
                    type => type.Id,
                    key => Enumeration.FromValue<InputType>(key)!);
        }
    }
}
