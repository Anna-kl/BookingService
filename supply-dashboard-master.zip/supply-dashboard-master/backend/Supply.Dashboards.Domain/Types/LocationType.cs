﻿using Common.SeedWork;

namespace Supply.Dashboards.Domain.Types
{
    public sealed class LocationType : Enumeration
    {
#pragma warning disable CA2211 // Non-constant fields should not be visible
        public static LocationType Division = new(1, "Division");
        public static LocationType Direction = new(2, "Direction");
        public static LocationType Node = new(3, "Node");
#pragma warning restore CA2211 // Non-constant fields should not be visible

        public LocationType(int id, string name) : base(id, name)
        {
        }
    }
}
