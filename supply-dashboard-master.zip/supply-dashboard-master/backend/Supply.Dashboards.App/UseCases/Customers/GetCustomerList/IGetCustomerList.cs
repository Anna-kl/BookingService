﻿using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.Types;

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.Customers.GetCustomerList
{
    public interface IGetCustomerList
    {
        Task<IEnumerable<Customer>> Get(
            List<StatusType> statuses,
            List<Customer>? destinationList,
            List<Guid>? ids,
            List<CustomerType>? types,
            bool includeRoot,
            CancellationToken cancellationToken);

        Task<IEnumerable<Customer>> GetByIds(
            List<StatusType> statuses,
            List<Guid> ids,
            CancellationToken cancellationToken);
    }
}
