﻿using Common.SeedWork;
using Supply.Dashboards.Domain.Exceptions;
using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Domain.AggregatesModel.Core
{
    public sealed class AliasId : ValueObject
    {
        public AliasId(
            Context context,
            Guid id,
            Type type,
            User externalSystem)
        {
            XMin = default;
            Context = context
                      ?? throw new DomainException($"{nameof(context)} can't be null.");
            InnerId = id == Guid.Empty
                ? throw new DomainException($"{nameof(id)} can't be null.")
                : id;
            Type = type.Name
                   ?? throw new DomainException($"{nameof(type)} can't be null.");
            ExternalSystem = externalSystem
                             ?? throw new DomainException($"{nameof(externalSystem)} can't be null.");
        }

#pragma warning disable 8618
        // ReSharper disable once UnusedMember.Local
        private AliasId()
        {
        }
#pragma warning restore 8618

        public uint XMin { get; set; }
        public Guid InnerId { get; init; }
        public string Type { get; init; }

        public Context Context { get; init; }
        public User ExternalSystem { get; init; }


        protected override IEnumerable<object> GetAtomicValues()
        {
            yield return Context;
            yield return ExternalSystem;
            yield return Type;
            yield return InnerId;
        }
    }
}
