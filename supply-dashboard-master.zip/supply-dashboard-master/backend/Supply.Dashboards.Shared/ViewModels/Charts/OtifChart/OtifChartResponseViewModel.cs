﻿namespace Supply.Dashboards.Shared.ViewModels.Charts.OtifChart
{
    public sealed class OtifChartResponseViewModel
    {
        public double Otif { get; set; }
        public double NotOtif { get; set; }
    }
}
