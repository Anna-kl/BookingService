<template>
  <div class="inline-values">
    <div class="label">Информационная панель:</div>
    <DxSelectBox
      :data-source="dashboards"
      :value="currentDashboardId"
      display-expr="name"
      value-expr="id"
      placeholder="Выберите.."
      @valueChanged="changeDashboard"
    />
    <DxButton
      icon="plus"
      styling-mode="contained"
      @click="showAddDashboardDialog"
    />
    <DxButton
      icon="trash"
      styling-mode="contained"
      @click="removeCurrentDashboar"
    />
  </div>
</template>

<script lang='ts'>
import { DashboardsState } from "@/store";
import Vue from "vue";
import { Component, Watch, Prop } from "vue-property-decorator";
import DxSelectBox from "devextreme-vue/select-box";
import DxButton from "devextreme-vue/button";
import { EventBus } from "@/event-bus";

@Component({
  components: { DxSelectBox, DxButton },
})
export default class DashboardToolbar extends Vue {
  public mounted() {}

  private get dashboards() {
    return DashboardsState.dashboards;
  }

  private get currentDashboardId() {
    return DashboardsState.currentDashboardId;
  }

  private changeDashboard(e: any) {
    DashboardsState.setCurrentDashboardId(e.value);
  }

  private showAddDashboardDialog() {
    EventBus.$emit("show-adddashboarddialog");
  }

  private removeCurrentDashboar() {
    DashboardsState.removeCurrentDashboard();
  }
}
</script>
<style lang="scss" scoped>
.inline-values {
  vertical-align: middle;

  div {
    float: left;
  }
  .label {
    position: relative;
    font-size: 16px;
    padding: 5px;
  }
}
</style>