﻿using Supply.Dashboards.Domain.Types;

using System;
using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.MtrTypes.GetMtrTypeList.Output
{
    public sealed class GetMtrTypeListItemOutput
    {
        public GetMtrTypeListItemOutput(
            Guid id,
            uint xMin,
            List<Guid> sourceIds,
            List<Guid> destinationIds,
            StatusType status,
            string title,
            string? description)
        {
            Id = id;
            RowVersion = xMin;
            SourceIds = sourceIds;
            DestinationIds = destinationIds;
            Status = status;
            Title = title;
            Description = description;
        }

        public Guid Id { get; }
        public uint RowVersion { get; }

        public List<Guid> SourceIds { get; }
        public List<Guid> DestinationIds { get; }

        public StatusType Status { get; }

        public string Title { get; }
        public string? Description { get; }
    }
}
