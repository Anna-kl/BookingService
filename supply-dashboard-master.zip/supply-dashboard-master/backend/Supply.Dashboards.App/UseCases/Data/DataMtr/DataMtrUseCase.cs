﻿using Common.Extensions;

using FluentValidation.Results;

using MediatR;

using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.Data.DataMtr.Input;
using Supply.Dashboards.App.UseCases.Data.DataMtr.Output;
using Supply.Dashboards.App.UseCases.Data.DataMtr.Types;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;

using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.Data.DataMtr
{
    public sealed class DataMtrUseCase
        : IRequestHandler<DataMtrQuery, (ValidationResult validationResult, DataMtrOutput? output)>
    {
        private readonly ILogger<DataMtrUseCase> _logger;
        private readonly IMediator _mediator;
        private readonly IDataMtr _dataMtr;

        private List<Customer> _customers;
        private List<Location> _locations;
        private List<MtrType> _mtrTypes;
        private ValidationResult _validationResult;

        public DataMtrUseCase(
            ILogger<DataMtrUseCase> logger,
            IMediator mediator,
            IDataMtr dataMtr)
        {
            _logger = logger;
            _mediator = mediator;
            _dataMtr = dataMtr;

            _customers = new List<Customer>();
            _locations = new List<Location>();
            _mtrTypes = new List<MtrType>();
            _validationResult = new ValidationResult();
        }

        public async Task<(ValidationResult validationResult, DataMtrOutput? output)> Handle(
            DataMtrQuery request,
            CancellationToken cancellationToken)
        {
            _validationResult = request.ValidationResult;

            if (!request.ValidationResult.IsValid)
            {
                return (request.ValidationResult, null);
            }

            await Customers(request, cancellationToken);
            await Locations(request, cancellationToken);
            await MtrTypes(request, cancellationToken);

            if (!request.ValidationResult.IsValid)
            {
                return (request.ValidationResult, null);
            }

            var valueRecords = await _dataMtr.ValueRecordsGet(
                request
                    .Types
                    .Where(DataMtrType.IsValueRecordType)
                    .Select(DataMtrType.GetValueRecordType)
                    .ToList(),
                request.StartPeriod,
                request.EndPeriod,
                request.LocationsIds.ToList(),
                request.CustomersIds.ToList(),
                request.MtrTypesIds.ToList(),
                cancellationToken
            );

            var hseIncidents = await _dataMtr.HseIncidentGet(
                request
                    .Types
                    .Where(DataMtrType.IsHseIncidentType)
                    .Select(DataMtrType.GetHseIncidentType)
                    .ToList(),
                request.StartPeriod,
                request.EndPeriod,
                request.LocationsIds.ToList(),
                request.CustomersIds.ToList(),
                cancellationToken
            );

            var bids = await _dataMtr.BidsGet(
                request
                    .Types
                    .Where(DataMtrType.IsBidType)
                    .Select(DataMtrType.GetBidType)
                    .ToList(),
                request.StartPeriod,
                request.EndPeriod,
                request.LocationsIds.ToList(),
                request.CustomersIds.ToList(),
                cancellationToken
            );

            List<DataMtrItemOutput> itemOutputs = new();

            itemOutputs.AddRange(
                valueRecords
                    .DistinctBy(_ => _.Payload)
                    .Where(_ => _.Payload.Type != null)
                    .Select(_ => new DataMtrItemOutput(
                        _.XMin,
                        _.Payload.StartPeriod,
                        _.Payload.EndPeriod,
                        _.Payload.Customer?.InnerId,
                        _.Payload.Location?.InnerId,
                        _.Payload.MtrType?.InnerId,
                        DataMtrType.GetDataMtrType(_.Payload.Type),
                        _.Payload.Value,
                        AppInputType.GetAppInputType(_.Payload.InputType)
                    ))
            );

            itemOutputs.AddRange(
                hseIncidents
                    .Where(_ => _.Payload.Type != null)
                    .GroupBy(_ => (
                        xMin: _.XMin,
                        date: _.Payload.DateTime.Date,
                        type: _.Payload.Type,
                        customer: _.Payload.Customer,
                        location: _.Payload.Location,
                        inputType: _.Payload.InputType))
                    .Select(_ => new DataMtrItemOutput(
                        _.Key.xMin,
                        _.Key.date,
                        _.Key.date,
                        _.Key.customer?.InnerId,
                        _.Key.location?.InnerId,
                        null,
                        DataMtrType.GetDataMtrType(_.Key.type),
                        _.Count(),
                        AppInputType.GetAppInputType(_.Key.inputType)
                    ))
            );

            itemOutputs.AddRange(
                bids
                    .Where(_ => _.Payload.Type != null)
                    .GroupBy(_ => (
                        xMin: _.XMin,
                        date: _.Payload.DateTime.Date,
                        type: _.Payload.Type,
                        customer: _.Payload.Customer,
                        location: _.Payload.Location,
                        inputType: _.Payload.InputType))
                    .Select(_ => new DataMtrItemOutput(
                        _.Key.xMin,
                        _.Key.date,
                        _.Key.date,
                        _.Key.customer?.InnerId,
                        _.Key.location?.InnerId,
                        null,
                        DataMtrType.GetDataMtrType(_.Key.type),
                        _.Count(),
                        AppInputType.GetAppInputType(_.Key.inputType)
                    ))
            );

            return (_validationResult, new DataMtrOutput(itemOutputs));
        }

        private async Task Customers(
            DataMtrQuery query,
            CancellationToken cancellationToken)
        {
            var customers = await _dataMtr.GetCustomersByInnerIds(
                query.CustomersIds.ToList(),
                cancellationToken
            );

            _customers = customers.ToList();

            if (!_customers.Any() || query.CustomersIds.Count() != _customers.Count)
            {
                query.CustomersIds.Except(_customers.Select(_ => _.InnerId)).ToList().ForEach(id =>
                {
                    _validationResult.Errors.Add(new ValidationFailure(
                        "CustomerId",
                        $"{nameof(Customer)} with id \"{id}\" is not exist."));
                });
            }
        }

        private async Task Locations(
            DataMtrQuery query,
            CancellationToken cancellationToken)
        {
            var locations = await _dataMtr.GetLocationsByInnerIds(
                query.LocationsIds.ToList(),
                cancellationToken
            );

            _locations = locations.ToList();

            if (!_locations.Any() || query.LocationsIds.Count() != _locations.Count)
            {
                query.LocationsIds
                    .Except(_locations.Select(_ => _.InnerId))
                    .ToList()
                    .ForEach(id =>
                    {
                        _validationResult.Errors.Add(new ValidationFailure(
                            "LocationId",
                            $"{nameof(Location)} with id \"{id}\" is not exist."));
                    });
            }
        }

        private async Task MtrTypes(
            DataMtrQuery query,
            CancellationToken cancellationToken)
        {
            var mtrTypes = await _dataMtr.GetMtrTypesByInnerIds(
                query.MtrTypesIds.ToList(),
                cancellationToken
            );

            _mtrTypes = mtrTypes.ToList();

            if (!_mtrTypes.Any() || query.MtrTypesIds.Count() != _mtrTypes.Count)
            {
                query.MtrTypesIds
                    .Except(_mtrTypes.Select(_ => _.InnerId))
                    .ToList()
                    .ForEach(id =>
                    {
                        _validationResult.Errors.Add(new ValidationFailure(
                            "MtrTypeId",
                            $"{nameof(MtrType)} with id \"{id}\" is not exist."));
                    });
            }
        }
    }
}
