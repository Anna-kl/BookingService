﻿using Common.SeedWork;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.Charts.AccountingMtrByPeriods.Input;
using Supply.Dashboards.App.UseCases.Charts.ArrivalByLocations.Input;
using Supply.Dashboards.App.UseCases.Charts.ExpenditureByLocations.Input;
using Supply.Dashboards.App.UseCases.Charts.CargoGroupByLocations.Input;
using Supply.Dashboards.App.UseCases.Charts.CargoGroupByPeriods.Input;
using Supply.Dashboards.App.UseCases.Charts.HseIndicators.Input;
using Supply.Dashboards.App.UseCases.Charts.HseIndicators.Types;
using Supply.Dashboards.App.UseCases.Charts.OtifChart.Input;
using Supply.Dashboards.App.UseCases.Charts.SeasonalDelivery.Input;
using Supply.Dashboards.App.UseCases.Charts.TransportResources.Input;
using Supply.Dashboards.App.UseCases.Charts.ExecutionOfOrders.Input;
using Supply.Dashboards.Shared.Types;
using Supply.Dashboards.Shared.ViewModels.Charts.AccountingMtrByPeriods;
using Supply.Dashboards.Shared.ViewModels.Charts.ArrivalByLocations;
using Supply.Dashboards.Shared.ViewModels.Charts.ExpenditureByLocations;
using Supply.Dashboards.Shared.ViewModels.Charts.CargoGroupByLocations;
using Supply.Dashboards.Shared.ViewModels.Charts.CargoGroupByPeriods;
using Supply.Dashboards.Shared.ViewModels.Charts.HseIndicators;
using Supply.Dashboards.Shared.ViewModels.Charts.OtifChart;
using Supply.Dashboards.Shared.ViewModels.Charts.SeasonalDelivery;
using Supply.Dashboards.Shared.ViewModels.Charts.TransportResources;
using Supply.Dashboards.Shared.ViewModels.Charts.ExecutionOfOrders;

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Supply.Dashboards.App.UseCases.Charts.ExecutionOfOrders.Output;
using Supply.Dashboards.Shared.ViewModels.Charts.FullnessBases;
using Supply.Dashboards.App.UseCases.Charts.FullnessBases.Input;
using Supply.Dashboards.Shared.ViewModels.WeatherRestrictions.WeatherRestrictionsList;
using Supply.Dashboards.App.UseCases.WeatherRestrictions.GetWeatherRestrictionsList.Input;

namespace Supply.Dashboards.Service.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public sealed class DashboardsController : ControllerBase
    {
        private readonly ILogger<DashboardsController> _logger;
        private readonly IMediator _mediator;

        public DashboardsController(
            ILogger<DashboardsController> logger,
            IMediator mediator)
        {
            _logger = logger;
            _mediator = mediator;
        }

        /// <summary>
        /// Get a MTR by periods with optional filtering
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [HttpPost("accounting-mtr-by-periods")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> AccountingMtrByPeriods(
            [FromBody] AccountingMtrByPeriodsRequestViewModel request,
            CancellationToken cancellationToken)
        {
            var accountingMtrQuery = new AccountingMtrByPeriodsQuery(
                request.Period.ToString(),
                request.StartPeriod,
                request.Duration == null
                    ? (DateTime?)null
                    : request.StartPeriod.Add(request.Duration.Value),
                request.LocationsIds,
                request.CustomersIds,
                request.MtrTypesIds);

            if (!accountingMtrQuery.ValidationResult.IsValid)
                return BadRequest(accountingMtrQuery
                    .ValidationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            var (validationResult, accountingMtrOutput) = await _mediator.Send(
                accountingMtrQuery,
                cancellationToken);

            if (!validationResult.IsValid)
                return BadRequest(validationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            if (accountingMtrOutput == null || !accountingMtrOutput.Periods.Any())
                return NoContent();

            var result = accountingMtrOutput
                .Periods
                .Select(output => new AccountingMtrByPeriodsResponseParamViewModel
                {
                    Period = output.Period.ToString(CultureInfo.InvariantCulture),
                    Units = output
                        .Units
                        .Select(_ => new AccountingMtrByPeriodsUnitViewModel
                        {
                            Type = Enum.Parse<AccountingMtrByPeriodsEnum>(_.Type.Name),
                            Tons = _.Value
                        })
                        .ToList()
                })
                .ToList();

            return Ok(result);
        }

        /// <summary>
        /// Get arrival by locations with optional filtering
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [HttpPost("arrival-by-locations")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> ArrivalByLocations(
            [FromBody] ArrivalByLocationsRequestViewModel request,
            CancellationToken cancellationToken)
        {
            var arrivalByLocationsQuery = new ArrivalByLocationsQuery(
                request.LocationType == Shared.Types.ChartLocationEnum.All ? null :
                Enumeration.IsDefined<AppLocationType>(request.LocationType.ToString())
                    ? Enumeration.FromDisplayName<AppLocationType>(request.LocationType.ToString())
                    : AppLocationType.Default,
                request.StartPeriod,
                request.StartPeriod.Add(request.Duration),
                request.ParentLocationId,
                request.LocationsIds,
                request.CustomersIds,
                request.MtrTypesIds);

            if (!arrivalByLocationsQuery.ValidationResult.IsValid)
                return BadRequest(arrivalByLocationsQuery
                    .ValidationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            var (validationResult, arrivalByLocationsOutput) = await _mediator.Send(
                arrivalByLocationsQuery,
                cancellationToken);

            if (!validationResult.IsValid)
                return BadRequest(validationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            if (arrivalByLocationsOutput == null || !arrivalByLocationsOutput.Locations.Any())
                return NoContent();

            var result = arrivalByLocationsOutput
               .Locations
               .Select(output => new ArrivalByLocationsResponseParamViewModel
               {
                   LocationId = output.LocationId,
                   LocationTitle = output.LocationTitle,
                   Units = output
                       .Units
                       ?.Select(_ => new ArrivalByLocationsResponseUnitViewModel
                       {
                           Type = Enum.Parse<ValueRecordEnum>(_.Type.Name),
                           Tons = _.Value
                       })
                       .ToList()
               })
               .ToList();

            return Ok(result);
        }

        /// <summary>
        /// Get expenditure by locations with optional filtering
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [HttpPost("expenditure-by-locations")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> ExpenditureByLocations(
            [FromBody] ExpenditureByLocationsRequestViewModel request,
            CancellationToken cancellationToken)
        {
            var expenditureByLocationsQuery = new ExpenditureByLocationsQuery(
                request.LocationType == Shared.Types.ChartLocationEnum.All ? null :
                Enumeration.IsDefined<AppLocationType>(request.LocationType.ToString())
                    ? Enumeration.FromDisplayName<AppLocationType>(request.LocationType.ToString())
                    : AppLocationType.Default,
                request.StartPeriod,
                request.StartPeriod.Add(request.Duration),
                request.ParentLocationId,
                request.LocationsIds,
                request.CustomersIds,
                request.MtrTypesIds);

            if (!expenditureByLocationsQuery.ValidationResult.IsValid)
                return BadRequest(expenditureByLocationsQuery
                    .ValidationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            var (validationResult, expenditureByLocationsOutput) = await _mediator.Send(
                expenditureByLocationsQuery,
                cancellationToken);

            if (!validationResult.IsValid)
                return BadRequest(validationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            if (expenditureByLocationsOutput == null || !expenditureByLocationsOutput.Locations.Any())
                return NoContent();

            var result = expenditureByLocationsOutput
               .Locations
               .Select(output => new ExpenditureByLocationsResponseParamViewModel
               {
                   LocationId = output.LocationId,
                   LocationTitle = output.LocationTitle,
                   Units = output
                       .Units
                       ?.Select(_ => new ExpenditureByLocationsResponseUnitViewModel
                       {
                           Type = Enum.Parse<ValueRecordEnum>(_.Type.Name),
                           Tons = _.Value
                       })
                       .ToList()
               })
               .ToList();

            return Ok(result);
        }

        /// <summary>
        /// Get a cargo by locations with optional filtering
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [HttpPost("cargo-by-locations")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> CargoGroupingByLocations(
            [FromBody] CargoGroupByLocationsRequestViewModel request,
            CancellationToken cancellationToken)
        {
            var cargoGroupingByLocationsQuery = new CargoGroupByLocationsQuery(
                request.LocationType == ChartLocationEnum.All 
                    ? null 
                    : Enumeration.IsDefined<AppLocationType>(request.LocationType.ToString())
                        ? Enumeration.FromDisplayName<AppLocationType>(request.LocationType.ToString())
                        : AppLocationType.Default,
                Enumeration.IsDefined<AppDataType>(request.DataType.ToString())
                    ? Enumeration.FromDisplayName<AppDataType>(request.DataType.ToString())
                    : AppDataType.Default,
                request.StartPeriod,
                request.StartPeriod.Add(request.Duration),
                request.ParentLocationId,
                request.LocationsIds,
                request.CustomersIds,
                request.MtrTypesIds);

            if (!cargoGroupingByLocationsQuery.ValidationResult.IsValid)
                return BadRequest(cargoGroupingByLocationsQuery
                    .ValidationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            var (validationResult, cargoGroupingByLocationsOutput) = await _mediator.Send(
                cargoGroupingByLocationsQuery,
                cancellationToken);

            if (!validationResult.IsValid)
                return BadRequest(validationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            if (cargoGroupingByLocationsOutput == null || !cargoGroupingByLocationsOutput.Locations.Any())
                return NoContent();

            var result = cargoGroupingByLocationsOutput
               .Locations
               .Select(output => new CargoGroupByLocationsResponseParamViewModel
               {
                   LocationId = output.LocationId,
                   LocationTitle = output.LocationTitle,
                   Units = output
                       .Units
                       ?.Select(_ => new CargoGroupByLocationsResponseUnitViewModel
                       {
                           Type = Enum.Parse<ValueRecordEnum>(_.Type.Name),
                           Tons = _.Value
                       })
                       .ToList()
               })
               .ToList();

            return Ok(result);
        }

        /// <summary>
        /// Get a cargo by periods with optional filtering
        /// </summary>
        [HttpPost("cargo-by-periods")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> CargoGroupingByPeriods(
            [FromBody] CargoGroupByPeriodsRequestViewModel request,
            CancellationToken cancellationToken)
        {
            var cargoGroupingByPeriodsQuery = new CargoGroupByPeriodsQuery(
                Enumeration.IsDefined<AppPeriodsType>(request.Period.ToString())
                    ? Enumeration.FromDisplayName<AppPeriodsType>(request.Period.ToString())
                    : AppPeriodsType.Default,
                Enumeration.IsDefined<AppDataType>(request.DataType.ToString())
                    ? Enumeration.FromDisplayName<AppDataType>(request.DataType.ToString())
                    : AppDataType.Default,
                request.StartPeriod,
                request.Duration == null
                    ? (DateTime?)null
                    : request.StartPeriod.Add(request.Duration.Value),
                request.LocationsIds,
                request.CustomersIds,
                request.MtrTypesIds);

            if (!cargoGroupingByPeriodsQuery.ValidationResult.IsValid)
                return BadRequest(cargoGroupingByPeriodsQuery
                    .ValidationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            var (validationResult, cargoGroupingByPeriodsOutput) = await _mediator.Send(
                cargoGroupingByPeriodsQuery,
                cancellationToken);

            if (!validationResult.IsValid)
                return BadRequest(validationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            if (cargoGroupingByPeriodsOutput == null || !cargoGroupingByPeriodsOutput.Periods.Any())
                return NoContent();

            var result = cargoGroupingByPeriodsOutput
                .Periods
                .Select(output => new CargoGroupByPeriodsResponseParamViewModel
                {
                    Period = output.Period.ToString(CultureInfo.InvariantCulture),
                    FactUnit = new CargoGroupByPeriodsResponseUnitViewModel
                    {
                        Tons = output.Fact?.Value ?? 0
                    },
                    PlanUnit = new CargoGroupByPeriodsResponseUnitViewModel
                    {
                        Tons = output.Plan?.Value ?? 0
                    },
                    AdjustedPlanUnit = new CargoGroupByPeriodsResponseUnitViewModel
                    {
                        Tons = output.AdjustedPlan?.Value ?? 0
                    },
                    DailyPlanUnit = new CargoGroupByPeriodsResponseUnitViewModel
                    {
                        Tons = output.DailyPlan?.Value ?? 0
                    },
                });

            return Ok(result);
        }

        /// <summary>
        /// Get a HSE indicators with optional filtering
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [HttpPost("hse-indicators")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> HseIndicators(
            [FromBody] HseIndicatorsRequestViewModel request,
            CancellationToken cancellationToken)
        {
            var hseIndicatorsQuery = new HseIndicatorsQuery(
                request.StartPeriod,
                request.EndPeriod,
                request
                    .LastIncidentTypes
                    .Select(_ => Enumeration.IsDefined<HseIndicatorType>(_.ToString())
                            ? Enumeration.FromDisplayName<HseIndicatorType>(_.ToString())!
                            : HseIndicatorType.Default)
                    .ToList(),
                request.LocationsIds ?? new List<Guid>(),
                request.CustomersIds ?? new List<Guid>());

            if (!hseIndicatorsQuery.ValidationResult.IsValid)
                return BadRequest(hseIndicatorsQuery
                    .ValidationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            var (validationResult, hseIndicatorsOutput) = await _mediator.Send(
                hseIndicatorsQuery,
                cancellationToken);

            if (!validationResult.IsValid)
                return BadRequest(validationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            if (hseIndicatorsOutput == null)
                return NoContent();

            var result = new HseIndicatorsResponseViewModel
            {
                DaysWithoutIncident = hseIndicatorsOutput.DaysWithoutIncident,
                LastIncident = hseIndicatorsOutput.LastIncident == null
                ? null
                : new HseIndicatorIncidentResponseViewModel
                {
                    Type = (HseIndicatorEnum)hseIndicatorsOutput.LastIncident.Type.Id,
                    DateTime = hseIndicatorsOutput.LastIncident.DateTime,
                    Text = hseIndicatorsOutput.LastIncident.Text
                },
                Units = hseIndicatorsOutput
                .Units
                .Select(_ => new HseIndicatorsUnitResponseViewModel
                {
                    Type = (HseIndicatorEnum)_.Type.Id,
                    Count = _.Count
                })
                .ToList()
            };

            return Ok(result);
        }

        /// <summary>
        /// Get a OTIF with optional filtering
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [HttpPost("otif-chart")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> OtifChart(
            [FromBody] OtifChartRequestViewModel request,
            CancellationToken cancellationToken)
        {
            var otifChartQuery = new OtifChartQuery(
                request.StartPeriod,
                request.EndPeriod,
                request.LocationsIds ?? new List<Guid>(),
                request.CustomersIds ?? new List<Guid>());

            if (!otifChartQuery.ValidationResult.IsValid)
                return BadRequest(otifChartQuery
                    .ValidationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            var (validationResult, otifChartOutput) = await _mediator.Send(
                otifChartQuery,
                cancellationToken);

            if (!validationResult.IsValid)
                return BadRequest(validationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            if (otifChartOutput == null)
                return NoContent();

            var result = new OtifChartResponseViewModel
            {
                Otif = otifChartOutput.Otif,
                NotOtif = otifChartOutput.NotOtif
            };

            return Ok(result);
        }

        /// <summary>
        /// Get a execution of orders with optional filtering
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [HttpPost("execution-of-orders-chart")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> ExecutionOfOrders(
            [FromBody] ExecutionOfOrdersRequestViewModel request,
            CancellationToken cancellationToken)
        {
            var eooChartQuery = new ExecutionOfOrdersChartQuery(
                request.StartPeriod,
                request.LocationsIds ?? new List<Guid>(),
                request.CustomersIds ?? new List<Guid>());

            if (!eooChartQuery.ValidationResult.IsValid)
                return BadRequest(eooChartQuery
                    .ValidationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            var (validationResult, eooChartOutput) = await _mediator.Send(
                eooChartQuery,
                cancellationToken);

            if (!validationResult.IsValid)
                return BadRequest(validationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            if (eooChartOutput == null)
                return NoContent();

            var result = new List<ExecutionOfOrdersChartResponseViewModel>();

            foreach (ExecutionOfOrdersChartOutputValues item in eooChartOutput.output)
            {
                result.Add(new ExecutionOfOrdersChartResponseViewModel
                {
                    Date = item.Date,
                    Plan = item.Plan,
                    Forecast = item.Forecast,
                    TotalFact = item.TotalFact
                });
            }


            return Ok(eooChartOutput.output);
        }

        /// <summary>
        /// Get a cargo by locations with optional filtering
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [HttpPost("seasonal-delivery")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> SeasonalDelivery(
        [FromBody] SeasonalDeliveryRequest request,
        CancellationToken cancellationToken)
        {
            var seasonalDeliveryQuery = new SeasonalDeliveryQuery(
                request.DateTime,
                request.ParentLocationId,
                request.LocationsIds,
                request.CustomersIds,
                request.MtrTypesIds);

            if (!seasonalDeliveryQuery.ValidationResult.IsValid)
                return BadRequest(seasonalDeliveryQuery
                    .ValidationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            var (validationResult, seasonalDeliveryOutput) = await _mediator.Send(
                seasonalDeliveryQuery,
                cancellationToken);

            if (!validationResult.IsValid)
                return BadRequest(validationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            if (seasonalDeliveryOutput == null || !seasonalDeliveryOutput.Locations.Any())
                return NoContent();

            var result = seasonalDeliveryOutput
               .Locations
               .Select(output => new SeasonalDeliveryParamResponse
               {
                   LocationId = output.LocationId,
                   LocationTitle = output.LocationTitle,
                   Units = output
                       .Units
                       ?.Select(_ => new SeasonalDeliveryUnitResponse
                       {

                           Type = Enum.Parse<ValueRecordEnum>(_.Type.Name),
                           Tons = _.Value
                       })
                       .ToList()
               })
               .ToList();

            return Ok(result);
        }

        /// <summary>
        /// Get a transport-resources by periods with optional filtering
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [HttpPost("transport-resources-by-periods")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> TransportResourcesByPeriods(
            [FromBody] TransportResourcesByPeriodsRequestViewModel request,
            CancellationToken cancellationToken)
        {
            var transportResourcesByPeriodsQuery = new TransportResourcesByPeriodsQuery(
                request.Period.ToString(),
                request.StartPeriod,
                request.Duration == null
                    ? (DateTime?)null
                    : request.StartPeriod.Add(request.Duration.Value),
                request.LocationsIds,
                request.CustomersIds);

            if (!transportResourcesByPeriodsQuery.ValidationResult.IsValid)
                return BadRequest(transportResourcesByPeriodsQuery
                    .ValidationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            var (validationResult, transportResourcesByPeriodsOutput) = await _mediator.Send(
                transportResourcesByPeriodsQuery,
                cancellationToken);

            if (!validationResult.IsValid)
                return BadRequest(validationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            if (transportResourcesByPeriodsOutput == null || !transportResourcesByPeriodsOutput.Periods.Any())
                return NoContent();

            var result = transportResourcesByPeriodsOutput
                .Periods
                .Select(output => new TransportResourcesByPeriodsParamResponseViewModel
                {
                    Period = output.Period.ToString(CultureInfo.InvariantCulture),
                    Units = output
                        .Units
                        ?.Select(_ => new TransportResourcesUnitResponseViewModel
                        {

                            Type = Enum.Parse<ValueRecordEnum>(_.Type.Name),
                            Tons = _.Value
                        })
                        .ToList()
                })
                .ToList();

            return Ok(result);
        }

        /// <summary>
        /// Get a transport-resources by locations with optional filtering
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [HttpPost("transport-resources-by-locations")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> TransportResourcesByLocations(
            [FromBody] TransportResourcesByLocationsRequestViewModel request,
            CancellationToken cancellationToken)
        {

            var transportResourcesByLocationsQuery = new TransportResourcesByLocationsQuery(
                request.LocationType == ChartLocationEnum.All ? null :
                Enumeration.IsDefined<AppLocationType>(request.LocationType.ToString())
                    ? Enumeration.FromDisplayName<AppLocationType>(request.LocationType.ToString())
                    : AppLocationType.Default,
                request.StartPeriod,
                request.StartPeriod.Add(request.Duration ?? TimeSpan.FromDays(1)),
                request.ParentLocationId,
                request.LocationsIds,
                request.CustomersIds,
                request.MtrTypesIds
                );

            if (!transportResourcesByLocationsQuery.ValidationResult.IsValid)
                return BadRequest(transportResourcesByLocationsQuery
                    .ValidationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            var (validationResult, transportResourcesByLocationsOutput) = await _mediator.Send(
                transportResourcesByLocationsQuery,
                cancellationToken);

            if (!validationResult.IsValid)
                return BadRequest(validationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            if (transportResourcesByLocationsOutput == null || !transportResourcesByLocationsOutput.Locations.Any())
                return NoContent();

            var result = transportResourcesByLocationsOutput
                .Locations
                .Select(output => new TransportResourcesByLocationsParamResponseViewModel
                {
                    LocationId = output.LocationId,
                    LocationTitle = output.LocationTitle,
                    Units = output
                        .Units
                        ?.Select(_ => new TransportResourcesUnitResponseViewModel
                        {

                            Type = Enum.Parse<ValueRecordEnum>(_.Type.Name),
                            Tons = _.Value
                        })
                        .ToList()
                })
                .ToList();

            return Ok(result);
        }

        /// <summary>
        /// Get a FullnessBases by locations with optional filtering
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [HttpPost("fullness-basess")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<IActionResult> FullnessBasesByLocations(
            [FromBody] FullnessBasesByLocationsRequestViewModel request,
            CancellationToken cancellationToken)
        {

            var fullnessBasesByLocationsQuery = new FullnessBasesByLocationsQuery(
                request.LocationType == Shared.Types.ChartLocationEnum.All ? null :
                Enumeration.IsDefined<AppLocationType>(request.LocationType.ToString())
                    ? Enumeration.FromDisplayName<AppLocationType>(request.LocationType.ToString())
                    : AppLocationType.Default,
                request.StartPeriod,
                request.StartPeriod.Add(request.Duration ?? TimeSpan.FromDays(1)),
                request.ParentLocationId,
                request.LocationsIds,
                request.CustomersIds,
                request.MtrTypesIds
                );

            if (!fullnessBasesByLocationsQuery.ValidationResult.IsValid)
                return BadRequest(fullnessBasesByLocationsQuery
                    .ValidationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            var (validationResult, fullnessBasesByLocationsOutput) = await _mediator.Send(
                fullnessBasesByLocationsQuery,
                cancellationToken);

            if (!validationResult.IsValid)
                return BadRequest(validationResult
                    .Errors
                    .Select(failure => new
                    {
                        failure.ErrorCode,
                        failure.ErrorMessage
                    }));

            if (fullnessBasesByLocationsOutput == null || !fullnessBasesByLocationsOutput.Locations.Any())
                return NoContent();

            var result = fullnessBasesByLocationsOutput
                .Locations
                .Select(output => new FullnessBasesByLocationsParamResponseViewModel
                {
                    LocationId = output.LocationId,
                    LocationTitle = output.LocationTitle,
                    Units = output
                        .Units
                        ?.Select(_ => new FullnessBasesUnitResponseViewModel
                        {

                            Type = Enum.Parse<ValueRecordEnum>(_.Type.Name),
                            Square = _.Value
                        })
                        .ToList()
                })
                .ToList();

            return Ok(result);
        }

        /// <summary>
        /// Get a WeatherRestrictions by locations with optional filtering
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [HttpPost("weather-restrictions")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        public async Task<ActionResult<WeatherRestrictionsListResponseViewModel>> GetList(
            [FromBody] WeatherRestrictionsListRequestViewModel request,
            CancellationToken cancellationToken)
        {
            var query = new GetWeatherRestrictionsListQuery(request.StartDate, request.EndDate, request.CustomerIds, request.LocationIds, true);

            if (!query.ValidationResult.IsValid)
                return BadRequest(
                    query
                        .ValidationResult
                        .Errors
                        .Select(failure => new
                        {
                            failure.ErrorCode,
                            failure.ErrorMessage
                        }));

            var (validationResult, output) = await _mediator.Send(
                query,
                cancellationToken);

            if (!validationResult.IsValid)
                return BadRequest(
                    query
                        .ValidationResult
                        .Errors
                        .Select(failure => new
                        {
                            failure.ErrorCode,
                            failure.ErrorMessage
                        }));

            var result = new WeatherRestrictionsListResponseViewModel()
            {
                Items = output.Items.Select(_ => new WeatherRestrictionsListItemResponseViewModel
                {
                    Id = _.Id,
                    Aktirovka = _.Aktirovka,
                    CustomerId = _.CustomerId,
                    DateTime = _.DateTime,
                    LocationId = _.LocationId,
                    LocationTitle = _.LocationTitle,
                    LocationLatitude = _.LocationLatitude,
                    LocationLongitude = _.LocationLongitude,
                    Temperature = _.Temperature,
                    WindSpeed = _.WindSpeed

                }).ToList()
            };

            return result;
        }
    }
}
