<template>
  <div class="module-inner-container">
    <DxToolbar>
      <DxItem
        widget="dxButton"
        location="before"
        :options="homeButtonOptions"
        :disabled="selectedOnChartLocationId === ''"
      />
      <DxItem
        widget="dxButton"
        location="before"
        :options="backButtonOptions"
        :disabled="selectedOnChartLocationId === ''"
      />
      <DxItem location="after">
        <template #default>
          <DxDateBox
            width="150px"
            hint="Выбор даты данных"
            type="date"
            picker-type="calendar"
            displayFormat="dd.MM.yyyy"
            :on-value-changed="dateChanged"
            :value.sync="curDate"
          />
        </template>
      </DxItem>
    </DxToolbar>
    <DxChart
      class="chart-module"
      :data-source="dataSource"
      @pointClick="onPointClick"
      :customize-point="customizePoint"
      :argument-axis="customizeArgumentAxis"
    >
      <DxCommonSeriesSettings
        :argument-field="config.columns"
        type="bar"
        hover-mode="allArgumentPoints"
        selection-mode="allArgumentPoints"
      >
        <DxLabel :visible="true" backgroundColor="none" :rotationAngle="-55">
          <DxFormat :precision="0" type="fixedPoint" />
          <DxFont color="white" />
        </DxLabel>
      </DxCommonSeriesSettings>
      <DxSeries
        v-for="seriesItem in series.filter((s) => s.value)"
        :key="seriesItem.id"
        :value-field="seriesItem.id"
        :name="seriesItem.name"
        :color="seriesItem.color"
      />
      <DxTitle text="Сезонный завоз" horizontalAlignment="left">
        <DxSubtitle text="тонн">
          <DxFont color="#42a2f6" />
        </DxSubtitle>
      </DxTitle>
      <DxLegend vertical-alignment="bottom" horizontal-alignment="center" />
      <DxTooltip :enabled="true" :customize-tooltip="customizeTooltip">
        <DxFormat :precision="3" type="fixedPoint" />
      </DxTooltip>
    </DxChart>
  </div>
</template>

<script lang='ts'>
import Chart from "@/components/ChartsData/chart";
import {
  DxChart,
  DxSeries,
  DxCommonSeriesSettings,
  DxLabel,
  DxFormat,
  DxLegend,
  DxTooltip,
  DxTitle,
  DxSubtitle,
  DxFont,
} from "devextreme-vue/chart";
import { Component, Prop } from "vue-property-decorator";
import config from "@/config";
import notify from "devextreme/ui/notify";
import { IModuleConfig, IModuleSeries } from "@/dto/Dashboards";
import { ChartDataService } from "@/services/chartDataService";
import DxButton from "devextreme-vue/button";
import DxToolbar, { DxItem } from "devextreme-vue/toolbar";
import {
  ISeasonalDeliveryChartData,
  ISeasonalDeliveryDataRequest,
  ISeasonalDeliveryDataResponse,
} from "@/dto/SeasonalDeliveryData";
import { yesterdayDate } from "@/helpers";
import { ITreeListItemRelation } from "../InputData/common/models";
import { ITreeListSelectedItem } from "../controls/filterTree/types";
import { MtrItemTypeEnum } from "@/dto/InputData";
import DxDateBox from "devextreme-vue/date-box";

interface IGroupDataByParent {
  id: string;
  dbId: string;
  title: string;
  selected: boolean;
  childrenGroups: IGroupDataByParent[];
}

@Component({
  components: {
    DxChart,
    DxSeries,
    DxCommonSeriesSettings,
    DxLabel,
    DxFormat,
    DxLegend,
    DxTooltip,
    DxTitle,
    DxSubtitle,
    DxFont,
    DxButton,
    DxToolbar,
    DxItem,
    DxDateBox,
  },
})
export default class SeasonalDeliveryChart extends Chart {
  @Prop({ type: Object, required: false }) public config!: IModuleConfig;
  @Prop({ type: Array, required: false }) public series!: IModuleSeries[];

  private url: string = config.remoteHost + "/api/dashboards/seasonal-delivery";
  private dataSource: ISeasonalDeliveryChartData[] = [];
  private curDate: Date = yesterdayDate();
  private selectedOnChartLocationId: string = "";
  private navigateHistory: string[] = [];
  private customizeArgumentAxis = {
    label: {
      overlappingBehavior: "none",
      textOverflow: "ellipsis",
    },
  };

  private _chartDataService!: ChartDataService;

  public update() {
    this.getData(this.curDate);
  }

  private created() {
    this._chartDataService = new ChartDataService();
  }

  private chartDateOptions = {
    hint: "Выбор даты данных",
    pickerType: "rollers",
    displayFormat: "dd.MM.yyyy",
    value: this.curDate,
    onValueChanged: (args: any) => {
      const curDate = args.value;
      this.getData(curDate);
    },
  };

  private mounted(): void {
    this.getData(this.curDate);
  }

  private onPointClick({ target }: any) {
    this.selectedOnChartLocationId = target.data.locationId;
    this.navigateHistory.push(target.data.locationId);
    this.update();
  }

  private navigateToHome() {
    this.selectedOnChartLocationId = "";
    this.navigateHistory = [];
    this.update();
  }

  private navigateToBack() {
    if (this.navigateHistory.length <= 1) {
      this.navigateToHome();
    } else {
      this.navigateHistory.pop();
      this.selectedOnChartLocationId = this.navigateHistory[
        this.navigateHistory.length - 1
      ];
      this.update();
    }
  }
  private homeButtonOptions = {
    icon: "home",
    hint: "Отображить значения по умолчанию",
    onClick: () => this.navigateToHome(),
  };

  private backButtonOptions = {
    icon: "arrowleft",
    hint: "Назад",
    onClick: () => this.navigateToBack(),
  };

  private dateChanged(args: any) {
    this.curDate = args.value;
    this.update();
  }

  private async getData(curDate: Date) {
    this.dataSource = [];
    const dateTime = curDate.toISOString();
    const request: ISeasonalDeliveryDataRequest = {
      dateTime,
      parentLocationId: this.selectedOnChartLocationId,
      locationsIds: this.config.locationsIds
        ?.filter((f) => f.selected)
        .map<string>((s) => s.dbId),
      customersIds: this.config.customersIds,
      mtrTypesIds: this.config.mtrTypesIds,
    };
    await this._chartDataService
      .getSeasonalDeliveryData(this.url, request)
      .then((data) => {
        if (data) {
          this.loadToDataSource(data);
        }
      })
      .catch((error: any) => {
        notify(error, "error", 2000);
        throw new Error(error);
      });
  }

  private compare(a: any, b: any) {
    if (a.last_nom < b.last_nom) {
      return -1;
    }
    if (a.last_nom > b.last_nom) {
      return 1;
    }
    return 0;
  }

  private loadToDataSource(data: ISeasonalDeliveryDataResponse[]) {
    const groupedItems: IGroupDataByParent[] = [];
    const chartData: ISeasonalDeliveryChartData[] = [];
    const selectedLocationRelations = this.config.locationsIds || [];

    if (selectedLocationRelations.length === 0) {
      // без сортировки, нет возможности сгруппировать
      chartData.push(
        ...this.createChartDataFromResponse(data).sort((a, b) =>
          a.location > b.location ? 1 : b.location > a.location ? -1 : 0
        )
      );
    } else {
      selectedLocationRelations.forEach((locationRelation) => {
        const finedItem = selectedLocationRelations.find(
          (s) => s.id === locationRelation.parentId
        );

        if (
          finedItem === undefined &&
          groupedItems.find((s) => s.id === locationRelation.parentId) ===
            undefined
        ) {
          // root items
          groupedItems.push({
            id: locationRelation.id,
            dbId: locationRelation.dbId,
            selected: locationRelation.selected,
            title: locationRelation.title,
            childrenGroups: [],
          });
        }
      });

      const sortedGroupItems = groupedItems.sort((a, b) =>
        a.title > b.title ? 1 : b.title > a.title ? -1 : 0
      );

      sortedGroupItems.forEach((element) => {
        this.createChildrenItems(selectedLocationRelations, element, data);
      });

      sortedGroupItems.forEach((element) => {
        const tmpChartData = this.getChartData(element, data);
        if (tmpChartData.length > 0) {
          chartData.push(...tmpChartData);
        }
      });
    }
    this.dataSource.push(...chartData);
  }

  private createChartDataFromResponse(
    data: ISeasonalDeliveryDataResponse[]
  ): ISeasonalDeliveryChartData[] {
    const retData: ISeasonalDeliveryChartData[] = [];

    if (data !== undefined) {
      data.forEach((location) => {
        retData.push({
          locationId: location.locationId,
          location: location.locationTitle,
          fact:
            location.units.find(
              (s) =>
                s.type === MtrItemTypeEnum[MtrItemTypeEnum.SeasonalDeliveryFact]
            )?.tons ?? 0,
          plan:
            location.units.find(
              (s) =>
                s.type === MtrItemTypeEnum[MtrItemTypeEnum.SeasonalDeliveryPlan]
            )?.tons ?? 0,
          adjustedPlan:
            location.units.find(
              (s) =>
                s.type ===
                MtrItemTypeEnum[MtrItemTypeEnum.SeasonalDeliveryAdjustedPlan]
            )?.tons ?? 0,
          dailyPlan:
            location.units.find(
              (s) =>
                s.type ===
                MtrItemTypeEnum[MtrItemTypeEnum.SeasonalDeliveryDailyPlan]
            )?.tons ?? 0,
        });
      });
    }

    return retData;
  }

  private createChildrenItems(
    selectedLocationRelations: ITreeListSelectedItem[],
    groupedItem: IGroupDataByParent,
    data: ISeasonalDeliveryDataResponse[]
  ) {
    const notSortedItems: IGroupDataByParent[] = [];

    const tmpItems = selectedLocationRelations.filter(
      (s) => s.parentId === groupedItem.id
    );
    tmpItems.forEach((tmpItem) => {
      const subItem: IGroupDataByParent = {
        id: tmpItem.id,
        dbId: tmpItem.dbId,
        title: tmpItem.title,
        selected: tmpItem.selected,
        childrenGroups: [],
      };

      this.createChildrenItems(selectedLocationRelations, subItem, data);
      notSortedItems.push(subItem);
    });

    groupedItem.childrenGroups.push(
      ...notSortedItems.sort((a, b) =>
        a.title > b.title ? 1 : b.title > a.title ? -1 : 0
      )
    );
  }

  private getChartData(
    groupItem: IGroupDataByParent,
    data: ISeasonalDeliveryDataResponse[]
  ): any[] {
    const retChartData: any[] = [];

    const tmpData = data.filter((s) => s.locationId === groupItem.dbId);

    if (tmpData.length > 0) {
      retChartData.push(
        ...this.createChartDataFromResponse(tmpData).sort((a, b) =>
          a.location > b.location ? 1 : b.location > a.location ? -1 : 0
        )
      );
    }

    groupItem.childrenGroups.forEach((element) => {
      const tmpChartData = this.getChartData(element, data);
      if (tmpChartData.length > 0) {
        retChartData.push(...tmpChartData);
      }
    });

    return retChartData;
  }

  private customizePoint(column: any) {
    if (
      column.seriesName === "Накопительный факт" &&
      column.data.fact < column.data.dailyPlan
    ) {
      return { color: "#E8574E", hoverStyle: { color: "#E8574E" } };
    }
  }

  private customizeTooltip(pointInfo: any) {
    return {
      text: `<b>${pointInfo.argument}</b><br />${pointInfo.seriesName}: ${pointInfo.valueText}`,
    };
  }
}
</script>
<style scoped>
.dx-toolbar {
  background: none;
}
</style>