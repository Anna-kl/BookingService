﻿using FluentValidation;

namespace Supply.Dashboards.App.UseCases.Contexts.GetContextList.Input
{
    public sealed class GetContextListValidator
        : AbstractValidator<GetContextListQuery>
    {
        public GetContextListValidator()
        {
            ValidateStatuses();
            ValidateIds();
        }

        private void ValidateStatuses() =>
            RuleForEach(_ => _.Statuses)
                .Must(_ => _.Id != 0); // TODO add description

        private void ValidateIds() =>
            RuleForEach(_ => _.Ids)
                .Must(_ => _ != default);
    }
}
