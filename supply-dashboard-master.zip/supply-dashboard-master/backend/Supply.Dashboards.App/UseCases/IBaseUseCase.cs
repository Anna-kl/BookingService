﻿using Common.SeedWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases
{
    public interface IBaseUseCase
    {
        public IUnitOfWork UnitOfWork { get; }
        public IEnumerable<TEntity> GetAsEnumerable<TEntity>(Func<TEntity, bool> predicate) where TEntity : class;
        public TEntity? GetFirstOrDefault<TEntity>(Func<TEntity, bool> predicate) where TEntity : class;
        public TEntity? GetSingleOrDefault<TEntity>(Func<TEntity, bool> predicate) where TEntity : class;
        public void Create<TEntity>(TEntity item) where TEntity : class;
        public void Update<TEntity>(TEntity item) where TEntity : class;
        public void Remove<TEntity>(TEntity item) where TEntity : class;

    }

}
