import MultiChartComponent from "./MultiChart/MultiChart.vue";
import defaultMultichartConfig from "./MultiChart/defaultMultichartConfig";

export {
    MultiChartComponent as default,
    defaultMultichartConfig
};