<template>
  <DxTreeList
    id="mtrItemTypes"
    ref="mtrItemTypesTreeList"
    :data-source="mtrItemTypes"
    :show-row-lines="false"
    :show-borders="true"
    :column-auto-width="true"
    root-value="root"
    data-structure="plain"
    key-expr="id"
    parent-id-expr="parentId"
    :loadPanel="{enabled: false}"
    :selected-row-keys.sync="selectedRowKeys"
  >
    <DxSelection :recursive="true" mode="multiple" />
    <DxColumn data-field="name" caption="Типы данных" />
  </DxTreeList>
</template>

<script lang='ts'>
import Vue from "vue";
import { Component, Prop, Watch } from "vue-property-decorator";
import { DxTreeList, DxSelection, DxColumn } from "devextreme-vue/tree-list";
import { InputDataState } from "@/store";
import { ITreeListMtrItemDataType } from "../mtrItemTypes/MtrItemTypesSelect";

@Component({
  components: {
    DxTreeList,
    DxSelection,
    DxColumn,
  },
})
export default class MtrItemTypesSelect extends Vue {
  private selectedRowKeys: string[] = [];
  private mtrItemTypes: ITreeListMtrItemDataType[] =
    InputDataState.selectedCommonTableDataTypes;

  private created() {
    this.selectedRowKeys = this.mtrItemTypes
      .filter((s) => s.selected)
      .map((a) => a.id);
  }

  @Watch("selectedRowKeys")
  private onSelectedRowKeysChanged() {
    const newSelectedData = this.mtrItemTypes.map<ITreeListMtrItemDataType>(
      (s) => {
        return {
          id: s.id,
          parentId: s.parentId,
          name: s.name,
          selected: false,
          type: s.type,
        };
      }
    );

    for (let index = 0; index < this.selectedRowKeys.length; index++) {
      const selectedKey = this.selectedRowKeys[index];
      newSelectedData.find((s) => s.id === selectedKey)!.selected = true;
    }

    InputDataState.setSelectedCommonTableDataTypes(newSelectedData);
  }
}
</script>

<style scoped>
</style>