﻿using System;
using System.Linq;
using System.Collections.Generic;
using Supply.Dashboards.Domain.AggregatesModel.Bids;
using Supply.Dashboards.Domain.Types;

namespace Supply.Dashboards.App.UseCases.Charts.ExecutionOfOrders.Output
{
    public class ExecutionOfOrdersChartOutput
    {
        public ExecutionOfOrdersChartOutput(IEnumerable<Bid> result)
        {
            var values = result.GroupBy(record => record.Payload.DateTime)
                            .OrderBy(date => date.Key).ToList();

            output = new List<ExecutionOfOrdersChartOutputValues>();

            bool haveFirst = false;

            foreach (IGrouping<DateTime, Bid> bidGroup in values)
            {
                int? factYesterday = !haveFirst ? bidGroup.Count(group => group.Payload.Type == BidType.TotalFact) : null;
                output.Add(new ExecutionOfOrdersChartOutputValues
                {
                    Date = bidGroup.Key,
                    Forecast = bidGroup.Count(group => group.Payload.Type == BidType.Forecast),
                    Plan = bidGroup.Count(group => group.Payload.Type == BidType.Plan),
                    TotalFact = factYesterday
                });

                haveFirst = true;
            }
        }

        public List<ExecutionOfOrdersChartOutputValues> output { get; }
    }
}
