﻿using FluentValidation.Results;

using MediatR;

using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.Contexts.GetContextList.Output;

using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.Contexts.GetContextList.Input
{
    public sealed class GetContextListQuery : IRequest<(ValidationResult validationResult, GetContextListOutput? output)>
    {
        private readonly List<AppStatusType>? _statuses;
        private readonly List<int>? _ids;

        public GetContextListQuery(
            List<AppStatusType>? statuses,
            List<int>? ids)
        {
            _statuses = statuses ?? new List<AppStatusType>();
            _ids = ids ?? new List<int>();

            ValidationResult = new GetContextListValidator()
                .Validate(this);
        }

        public IEnumerable<AppStatusType> Statuses => _statuses!.AsReadOnly();
        public IEnumerable<int>? Ids => _ids?.AsReadOnly();

        public ValidationResult ValidationResult { get; }
    }
}
