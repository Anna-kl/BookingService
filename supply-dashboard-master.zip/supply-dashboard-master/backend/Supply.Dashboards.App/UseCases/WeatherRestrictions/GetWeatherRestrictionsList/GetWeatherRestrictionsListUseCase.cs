﻿using FluentValidation.Results;

using MediatR;

using Microsoft.Extensions.Logging;
using Supply.Dashboards.App.UseCases.WeatherRestrictions.GetWeatherRestrictionsList.Input;
using Supply.Dashboards.App.UseCases.WeatherRestrictions.GetWeatherRestrictionsList.Output;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Supply.Dashboards.App.UseCases.WeatherRestrictions.GetWeatherRestrictionsList
{
    public sealed class GetWeatherRestrictionsListUseCase
        : IRequestHandler<GetWeatherRestrictionsListQuery, (ValidationResult validationResult, GetWeatherRestrictionsListOutput? output)>
    {
        private readonly ILogger<GetWeatherRestrictionsListUseCase> _logger;
        private readonly IWeatherRestrictions _weatherRestrictionsRepo;

        private ValidationResult _validationResult;

        public GetWeatherRestrictionsListUseCase(
            ILogger<GetWeatherRestrictionsListUseCase> logger,
            IWeatherRestrictions weatherRestrictionsRepo)
        {
            _logger = logger;
            _weatherRestrictionsRepo = weatherRestrictionsRepo;

            _validationResult = new ValidationResult();
        }

        public async Task<(ValidationResult validationResult, GetWeatherRestrictionsListOutput? output)> Handle(
            GetWeatherRestrictionsListQuery request,
            CancellationToken cancellationToken)
        {
            _validationResult = request.ValidationResult;

            if (!_validationResult.IsValid) return (_validationResult, null);

            var weatherRestrictionsAsQueryable = _weatherRestrictionsRepo.GetWeatherRestrictionsAsQueryable(
                request.StartDate,
                request.EndDate,
                request.CustomerIds,
                request.LocationIds);

            if (request.NotNullAktirovka)
            {
                weatherRestrictionsAsQueryable = weatherRestrictionsAsQueryable.Where(_ => string.IsNullOrEmpty(_.Payload.Aktirovka) == false);
            }

            return (_validationResult, new GetWeatherRestrictionsListOutput(await weatherRestrictionsAsQueryable.ToListAsync(cancellationToken)));
        }



    }
}
