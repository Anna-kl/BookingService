﻿using System;

namespace Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Input
{
    public sealed class ImportDirectoriesMtrTypeEdgeInput
    {
        public ImportDirectoriesMtrTypeEdgeInput(
            Guid? sourceId,
            Guid? destinationId,
            bool? isObsolete)
        {
            SourceId = sourceId ?? Guid.Empty;
            DestinationId = destinationId ?? Guid.Empty;

            IsObsolete = isObsolete;
        }

        public Guid SourceId { get; }
        public Guid DestinationId { get; }

        public bool? IsObsolete { get; }
    }
}
