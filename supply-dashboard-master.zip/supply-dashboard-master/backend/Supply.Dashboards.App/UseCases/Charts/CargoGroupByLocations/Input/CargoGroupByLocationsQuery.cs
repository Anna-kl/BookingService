﻿
using FluentValidation.Results;

using MediatR;

using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.Charts.CargoGroupByLocations.Output;

using System;
using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.Charts.CargoGroupByLocations.Input
{
    public sealed class CargoGroupByLocationsQuery
        : IRequest<(ValidationResult validationResult, CargoGroupByLocationsOutput? output)>
    {
        public CargoGroupByLocationsQuery(
            AppLocationType? locationType,
            AppDataType? dataType,
            DateTime startPeriod,
            DateTime endPeriod,
            Guid? parentLocationId,
            List<Guid>? locationsIds,
            List<Guid>? customersIds,
            List<Guid>? mtrTypesIds)
        {
            LocationType = locationType;
            DataType = dataType ?? AppDataType.Default;

            StartPeriod = startPeriod.Date;
            EndPeriod = endPeriod.Date;

            ParentLocationId = parentLocationId;
            LocationsIds = locationsIds;
            CustomersIds = customersIds;
            MtrTypesIds = mtrTypesIds;

            ValidationResult = new CargoGroupByLocationsValidator()
                .Validate(this);
        }

        public AppLocationType? LocationType { get; }
        public AppDataType DataType { get; }

        public DateTime StartPeriod { get; }
        public DateTime EndPeriod { get; }

        public Guid? ParentLocationId { get; set; }
        public List<Guid>? LocationsIds { get; }

        public List<Guid>? CustomersIds { get; }

        public List<Guid>? MtrTypesIds { get; }

        public ValidationResult ValidationResult { get; }
    }
}
