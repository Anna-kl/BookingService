﻿using Common.SeedWork;
using Supply.Dashboards.App.Exceptions;
using Supply.Dashboards.Domain.Types;

namespace Supply.Dashboards.App.UseCases.Charts.ArrivalByLocations.Types
{
    public sealed class ArrivalType : Enumeration
    {
        public static ArrivalType ArrivalFact = new(204, "ArrivalFact");
        public static ArrivalType ArrivalPlan = new(205, "ArrivalPlan");
        public static ArrivalType ArrivalAdjustedPlan = new(206, "ArrivalAdjustedPlan");
        public static ArrivalType ArrivalDailyPlan = new(207, "ArrivalDailyPlan");

        public ArrivalType(int id, string name) : base(id, name) {}

        internal static ArrivalType GetArrivalType(ValueRecordType type)
        {
            var name = type.Name switch
            {
                nameof(ValueRecordType.ArrivalFact) => ArrivalFact.Name,
                nameof(ValueRecordType.ArrivalPlan) => ArrivalPlan.Name,
                nameof(ValueRecordType.ArrivalAdjustedPlan) => ArrivalAdjustedPlan.Name,
                nameof(ValueRecordType.ArrivalDailyPlan) => ArrivalDailyPlan.Name,

                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<ArrivalType>(name)!;
        }
    }
}
