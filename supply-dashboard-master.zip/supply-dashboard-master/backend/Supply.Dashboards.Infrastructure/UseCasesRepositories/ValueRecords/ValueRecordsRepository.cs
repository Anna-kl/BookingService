﻿using Common.Extensions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Supply.Dashboards.App.UseCases.ValueRecords;
using Supply.Dashboards.Domain.AggregatesModel.ValueRecords;
using Supply.Dashboards.Domain.Types;
using Supply.Dashboards.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Supply.Dashboards.Domain.AggregatesModel.Locations;

namespace Supply.Dashboards.Infrastructure.UseCasesRepositories
{
    public sealed class ValueRecordsRepository : IValueRecords
    {
        private readonly ILogger<ValueRecordsRepository> _logger;
        private readonly DashboardsContext _dashboardsContext;

        public ValueRecordsRepository(
            ILogger<ValueRecordsRepository> logger,
            DashboardsContext dashboardsContext)
        {
            _logger = logger;
            _dashboardsContext = dashboardsContext;
        }

        public IQueryable<ValueRecord> GetRecords(
            List<ValueRecordType> recordsTypes,
            LocationType? locationType,
            Guid? parentLocationId,
            List<Guid>? locationsIds,
            List<Guid>? customersIds,
            List<Guid>? mtrTypesIds,
            List<StatusType> statusTypes,
            CancellationToken cancellationToken)
        {

            var queryable = _dashboardsContext
                .ValueRecords
                .AsNoTracking()
                .Include(record => record.Payload.Location)
                .Include(record => record.Payload.Location!.DestinationEdges)
                .Include(record => record.Payload.Customer)
                .Include(record => record.Payload.MtrType)
                .Where(record => record.Payload.Customer == null || record.Payload.Customer.Status == StatusType.Active)
                .Where(record => record.Payload.MtrType == null || record.Payload.MtrType.Status == StatusType.Active)
                .Where(record => recordsTypes.Contains(record.Payload.Type));

            queryable = queryable.Where(_ =>
                statusTypes.Contains(_.Payload.Location!.Status)
                && (statusTypes.Contains(_.Payload.Customer!.Status) || _.Payload.Customer == null)
                && (statusTypes.Contains(_.Payload.MtrType!.Status) || _.Payload.MtrType == null)
                );

            if (locationType != null)
            {
                queryable = queryable.Where(_ => _.Payload.Location!.Payload.Type == locationType);
            }

            if (parentLocationId != null)
            {
                var locations = _dashboardsContext
                    .Locations
                    .AsNoTracking()
                    .Include(location => location.SourceEdges)
                    .Include(location => location.DestinationEdges)
                    .ThenInclude(edge => edge.Destination)
                    .Where(location => location.Status == StatusType.Active)
                    .Where(location => location.SourceEdges!.Any(edge => edge.Source.Status == StatusType.Active))
                    .Where(location => location.DestinationEdges!.Any(edge => edge.Destination.Status == StatusType.Active))
                    .Where(location => location.SourceEdges!.Any(edge => edge.SourceInnerId == parentLocationId))
                    .ToList();

                var allLocations = new List<Location>();
                foreach (var location in locations)
                {
                    allLocations.AddRange(location.DepthFirstSearch<Location, LocationEdge>(
                        edge => edge.Destination,
                        customer => customer.DestinationEdges, _ => { }));
                }

                queryable = queryable.Where(_ => allLocations.Contains(_.Payload.Location!));
            }
            else if (locationsIds != null && locationsIds.Any())
            {
                queryable = queryable.Where(_ => locationsIds.Contains(_.Payload.Location!.InnerId));
            }

            if (customersIds != null && customersIds.Any())
            {
                queryable = queryable.Where(_ => customersIds.Contains(_.Payload.Customer!.InnerId));
            }

            if (mtrTypesIds != null && mtrTypesIds.Any())
            {
                queryable = queryable.Where(_ => mtrTypesIds.Contains(_.Payload.MtrType!.InnerId));
            }

            return queryable;

        }

        public async Task<IEnumerable<ValueRecord>> GetRecordsWithDateFilter(
            List<ValueRecordType> recordsTypes,
            DateTime startPeriod,
            DateTime endPeriod,
            LocationType? locationType,
            Guid? parentLocationId,
            List<Guid>? locationsIds,
            List<Guid>? customersIds,
            List<Guid>? mtrTypesIds,
            List<StatusType> statusTypes,
            bool? includeSubDateValues,
            bool? includeInsideDateValues,
            CancellationToken cancellationToken)
        {

            var queryable = GetRecords(recordsTypes, locationType, parentLocationId, locationsIds, customersIds, mtrTypesIds, statusTypes, cancellationToken);

            var predicate = PredicateBuilder.False<ValueRecord>();

            predicate = predicate.Or(record =>
                record.Payload.StartPeriod == startPeriod
                && record.Payload.EndPeriod == endPeriod);

            if (includeSubDateValues == true)
            {
                predicate = predicate.Or(record =>
                    record.Payload.StartPeriod >= startPeriod
                    && record.Payload.EndPeriod <= endPeriod);
            }

            if (includeInsideDateValues == true)
            {
                predicate = predicate.Or(record =>
                    record.Payload.StartPeriod <= startPeriod
                    && record.Payload.EndPeriod >= endPeriod);
            }
            queryable = queryable.Where(predicate);

            var records = (await queryable.ToListAsync(cancellationToken));

            return records;
        }

    }
}
