﻿using FluentValidation;

using Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Input;

namespace Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Validator
{
    public sealed class ImportDirectoriesValidator
        : AbstractValidator<ImportDirectoriesCommand>
    {
        public ImportDirectoriesValidator()
        {
            ValidateCustomers();
            ValidateCustomersEdge();
            ValidateLocations();
            ValidateLocationsEdge();
            ValidateMtrTypes();
            ValidateMtrTypesEdge();
        }

        private void ValidateCustomers() =>
            RuleForEach(_ => _.Customers)
                .SetValidator(new ImportDirectoriesCustomerValidator());

        private void ValidateCustomersEdge() =>
            RuleForEach(_ => _.CustomersEdges)
                .SetValidator(new ImportDirectoriesCustomerEdgeValidator());

        private void ValidateLocations() =>
            RuleForEach(_ => _.Locations)
                .SetValidator(new ImportDirectoriesLocationValidator());

        private void ValidateLocationsEdge() =>
            RuleForEach(_ => _.LocationsEdges)
                .SetValidator(new ImportDirectoriesLocationEdgeValidator());

        private void ValidateMtrTypes() =>
            RuleForEach(_ => _.MtrTypes)
                .SetValidator(new ImportDirectoriesMtrTypeValidator());

        private void ValidateMtrTypesEdge() =>
            RuleForEach(_ => _.MtrTypesEdges)
                .SetValidator(new ImportDirectoriesMtrTypeEdgeValidator());
    }
}
