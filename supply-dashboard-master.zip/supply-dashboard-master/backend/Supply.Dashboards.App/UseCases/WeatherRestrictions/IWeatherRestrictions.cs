﻿using Common.SeedWork;
using Supply.Dashboards.Domain.AggregatesModel.WeatherRestrictions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.WeatherRestrictions
{
    public interface IWeatherRestrictions
    {
        IQueryable<WeatherRestriction> GetWeatherRestrictionsAsQueryable(
            DateTime startDate,
            DateTime endDate,
            IEnumerable<Guid?> customerIds,
            IEnumerable<Guid>? locationIds);

    }
}
