﻿namespace Supply.Dashboards.Shared.ViewModels.Charts.HseIndicators
{
    public sealed class HseIndicatorsUnitResponseViewModel
    {
        public HseIndicatorEnum Type { get; set; }
        public int Count { get; set; }
    }
}
