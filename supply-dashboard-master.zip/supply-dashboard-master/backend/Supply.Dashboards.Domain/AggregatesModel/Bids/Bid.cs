﻿using Common.SeedWork;
using Supply.Dashboards.Domain.Exceptions;
using Supply.Dashboards.Domain.Types;
using System;

namespace Supply.Dashboards.Domain.AggregatesModel.Bids
{
    public sealed class Bid : Aggregate
    {
        #region c'tors

        public Bid(BidPayload payload)
        {
            Id = default;
            InnerId = Guid.NewGuid();
            XMin = default;
            CreateAt = DateTime.UtcNow;
            UpdateAt = DateTime.UtcNow;
            Payload = payload
                      ?? throw new DomainException($"{nameof(payload)} can't be null.");

            AddDomainEvent(new Event(InnerId.ToString(), StatusType.Active, Payload));
        }

#pragma warning disable 8618
        // ReSharper disable once UnusedMember.Local
        private Bid()
        {
        }
#pragma warning restore 8618

        #endregion

        #region props

        public uint XMin { get; private set; }
        public DateTime CreateAt { get; init; }
        public DateTime UpdateAt { get; private set; }
        public BidPayload Payload { get; private set; }

        #endregion

        #region methods

        public void Update(BidPayload payload)
        {
            UpdateAt = DateTime.UtcNow;
            Payload = payload
                      ?? throw new DomainException($"{nameof(payload)} can't be null.");

            AddDomainEvent(new Event(InnerId.ToString(), StatusType.Active, Payload));
        }

        #endregion
    }
}
