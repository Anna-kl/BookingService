﻿using Supply.Dashboards.App.UseCases.Imports.ImportMtr.Types;
using Supply.Dashboards.Domain.AggregatesModel.Bids;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.HseIncidents;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;
using Supply.Dashboards.Domain.AggregatesModel.ValueRecords;
using Supply.Dashboards.Domain.Types;

using System;

namespace Supply.Dashboards.App.UseCases.Imports.ImportMtr.Input
{
    public sealed class ImportMtrItemInput
    {
        public ImportMtrItemInput(
            uint rowVersion,
            DateTime? startPeriod,
            DateTime? endPeriod,
            Guid? customerId,
            Guid? locationId,
            Guid? mtrTypeId,
            ImportMtrType? type,
            double? value)
        {
            XMin = rowVersion;
            StartPeriod = startPeriod ?? default;
            EndPeriod = endPeriod ?? default;
            CustomerId = customerId;
            LocationId = locationId;
            MtrTypeId = mtrTypeId;
            Type = type ?? ImportMtrType.Default;
            Value = value;
        }

        public uint XMin { get; }
        public DateTime StartPeriod { get; }
        public DateTime EndPeriod { get; }
        public Guid? CustomerId { get; }
        public Guid? LocationId { get; }
        public Guid? MtrTypeId { get; }
        public ImportMtrType Type { get; }
        public double? Value { get; }

        internal ValueRecord ToValueRecord(
            Customer? customer,
            Location? location,
            MtrType? mtrType,
            InputType inputType) =>
            new(new ValueRecordPayload(
                StartPeriod,
                EndPeriod,
                ImportMtrType.GetValueRecordType(Type),
                customer,
                location,
                mtrType,
                Value ?? throw new NullReferenceException(nameof(Value)),
                inputType));

        internal HseIncident ToHseIncident(
            Customer? customer,
            Location? location,
            InputType inputType) =>
            new(new HseIncidentPayload(
                StartPeriod,
                ImportMtrType.GetHseIncidentType(Type),
                customer,
                location,
                string.Empty,
                inputType));

        internal Bid ToBid(
            Customer? customer,
            Location? location,
            InputType inputType) =>
            new(new BidPayload(
                StartPeriod,
                ImportMtrType.GetBidType(Type),
                customer,
                location,
                inputType));
    }
}
