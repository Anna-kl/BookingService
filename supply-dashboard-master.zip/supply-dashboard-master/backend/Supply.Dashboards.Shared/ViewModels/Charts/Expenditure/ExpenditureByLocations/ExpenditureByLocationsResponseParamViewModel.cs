﻿using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Charts.ExpenditureByLocations
{
    public sealed class ExpenditureByLocationsResponseParamViewModel
    {
        public Guid LocationId { get; set; }
        public string? LocationTitle { get; set; }

        public List<ExpenditureByLocationsResponseUnitViewModel>? Units { get; set; }
    }
}
