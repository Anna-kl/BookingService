﻿using Common.SeedWork;

namespace Supply.Dashboards.Domain.Types
{
    public sealed class HseIncidentType : Enumeration
    {
        public static HseIncidentType Death = new(1, "Death");
        public static HseIncidentType Disability = new(2, "Disability");
        public static HseIncidentType MedicalCare = new(3, "MedicalCare");
        public static HseIncidentType NearMiss = new(4, "NearMiss");
        public static HseIncidentType DangerWarning = new(5, "DangerWarning");

        public HseIncidentType(int id, string name) : base(id, name)
        {
        }
    }
}
