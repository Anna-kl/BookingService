﻿using FluentValidation.Results;

using MediatR;

using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.Contexts.GetContextList.Input;
using Supply.Dashboards.App.UseCases.Contexts.GetContextList.Output;
using Supply.Dashboards.App.UseCases.Customers.GetCustomerList;
using Supply.Dashboards.Domain.Types;

using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.Contexts.GetContextList
{
    public sealed class GetContextListUseCase
        : IRequestHandler<GetContextListQuery, (ValidationResult validationResult, GetContextListOutput? output)>
    {
        private readonly ILogger<GetCustomerListUseCase> _logger;
        private readonly IGetContextList _getContextList;

        public GetContextListUseCase(
            ILogger<GetCustomerListUseCase> logger,
            IGetContextList getContextList)
        {
            _logger = logger;
            _getContextList = getContextList;
        }

        public async Task<(ValidationResult validationResult, GetContextListOutput? output)> Handle(
            GetContextListQuery request,
            CancellationToken cancellationToken)
        {
            // If the statuses r not contained in the request, then add the "Active" status.
            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            var statuses = request
                .Statuses
                .Select(AppStatusType.GetStatusType)
                .Distinct()
                .ToList();

            // If the statuses r not contained in the request, then add the "Active" status.
            if (!statuses.Any())
                statuses.Add(StatusType.Active);

            var contexts = (await _getContextList.Get(
                statuses,
                request.Ids?.ToList(),
                cancellationToken)).ToList();

            return !contexts.Any()
                ? (request.ValidationResult, null)
                : (request.ValidationResult, new GetContextListOutput(contexts));
        }
    }
}
