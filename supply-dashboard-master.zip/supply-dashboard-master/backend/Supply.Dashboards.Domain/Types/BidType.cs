﻿using Common.SeedWork;

namespace Supply.Dashboards.Domain.Types
{
    public sealed class BidType : Enumeration
    {
#pragma warning disable CA2211 // Non-constant fields should not be visible
        public static BidType Plan = new(1, "Plan");
        public static BidType Forecast = new(2, "Forecast");
        public static BidType TotalFact = new(3, "TotalFact");
        public static BidType ScheduledFact = new(4, "ScheduledFact");
        public static BidType Unplanned = new(5, "Unplanned");
#pragma warning restore CA2211 // Non-constant fields should not be visible

        public BidType(int id, string name) : base(id, name)
        {
        }
    }
}
