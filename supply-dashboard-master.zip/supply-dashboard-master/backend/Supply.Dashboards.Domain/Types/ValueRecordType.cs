﻿using Common.SeedWork;

namespace Supply.Dashboards.Domain.Types
{
    public sealed class ValueRecordType : Enumeration
    {
#pragma warning disable CA2211 // Non-constant fields should not be visible
        public static ValueRecordType CargoHandlingFact = new(1, "CargoHandlingFact");
        public static ValueRecordType CargoHandlingPlan = new(2, "CargoHandlingPlan");
        public static ValueRecordType CargoHandlingAdjustedPlan = new(3, "CargoHandlingAdjustedPlan");
        public static ValueRecordType CargoHandlingDailyPlan = new(19, "CargoHandlingDailyPlan");

        public static ValueRecordType FreightTurnoverFact = new(5, "FreightTurnoverFact");
        public static ValueRecordType FreightTurnoverPlan = new(6, "FreightTurnoverPlan");
        public static ValueRecordType FreightTurnoverAdjustedPlan = new(7, "FreightTurnoverAdjustedPlan");
        public static ValueRecordType FreightTurnoverDailyPlan = new(20, "FreightTurnoverDailyPlan");

        public static ValueRecordType ArrivalFact = new(204, "ArrivalFact");
        public static ValueRecordType ArrivalPlan = new(205, "ArrivalPlan");
        public static ValueRecordType ArrivalAdjustedPlan = new(206, "ArrivalAdjustedPlan");
        public static ValueRecordType ArrivalDailyPlan = new(207, "ArrivalDailyPlan");

        public static ValueRecordType ExpenditureFact = new(208, "ExpenditureFact");
        public static ValueRecordType ExpenditurePlan = new(209, "ExpenditurePlan");
        public static ValueRecordType ExpenditureAdjustedPlan = new(210, "ExpenditureAdjustedPlan");
        public static ValueRecordType ExpenditureDailyPlan = new(211, "ExpenditureDailyPlan");

        public static ValueRecordType SeasonalDeliveryFact = new(9, "SeasonalDeliveryFact");
        public static ValueRecordType SeasonalDeliveryPlan = new(10, "SeasonalDeliveryPlan");
        public static ValueRecordType SeasonalDeliveryAdjustedPlan = new(11, "SeasonalDeliveryAdjustedPlan");
        public static ValueRecordType SeasonalDeliveryDailyPlan = new(21, "SeasonalDeliveryDailyPlan");

        public static ValueRecordType AccountingMtrTotalSupplies = new(15, "AccountingMtrTotalSupplies");
        public static ValueRecordType AccountingMtrProcessing = new(23, "AccountingMtrProcessing");
        public static ValueRecordType AccountingMtrUncapitalize0_14 = new(24, "AccountingMtrUncapitalize0_14");
        public static ValueRecordType AccountingMtrUncapitalize15_30 = new(25, "AccountingMtrUncapitalize15_30");
        public static ValueRecordType AccountingMtrUncapitalize31_60 = new(26, "AccountingMtrUncapitalize31_60");
        public static ValueRecordType AccountingMtrUncapitalize61More = new(27, "AccountingMtrUncapitalize61More");

        public static ValueRecordType TransportPlan = new(701, "TransportPlan");
        public static ValueRecordType TransportFact = new(702, "TransportFact");
        public static ValueRecordType GPMPlan = new(703, "GPMPlan");
        public static ValueRecordType GPMFact = new(704, "GPMFact");
        public static ValueRecordType LaborResourcesPlan = new(705, "LaborResourcesPlan");
        public static ValueRecordType LaborResourcesFact = new(706, "LaborResourcesFact");

        public static ValueRecordType FullnessBasesTotalSquare = new(801, "FullnessBasesTotalSquare");
        public static ValueRecordType FullnessBasesLoaded = new(802, "FullnessBasesLoaded");
        public static ValueRecordType FullnessBasesLoadedRubles = new(803, "FullnessBasesLoadedRubles");
        public static ValueRecordType FullnessBasesLoadedWeight = new(804, "FullnessBasesLoadedWeight");
#pragma warning restore CA2211 // Non-constant fields should not be visible

        public ValueRecordType(int id, string name) : base(id, name)
        {
        }
    }
}
