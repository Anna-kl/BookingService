﻿using Supply.Dashboards.App.Types;

using System;

namespace Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Output
{
    public sealed class ImportDirectoriesMtrTypeOutput
    {
        public ImportDirectoriesMtrTypeOutput(
            Guid id,
            uint xMin,
            AppStatusType status,
            string title)
        {
            Id = id;
            RowVersion = xMin;
            Status = status;
            Title = title;
        }

        public Guid Id { get; }
        public uint RowVersion { get; }

        public AppStatusType Status { get; }
        public string Title { get; set; }
    }
}
