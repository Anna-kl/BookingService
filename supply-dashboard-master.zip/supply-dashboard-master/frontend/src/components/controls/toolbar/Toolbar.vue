<template>
  <DxToolbar>
    <DxItem
      widget="dxButton"
      location="before"
      :options="homeButtonOptions"
      :disabled="locationId === ''"
      v-if="config.columns === 'location'"
    />
    <DxItem
      widget="dxButton"
      location="before"
      :options="backButtonOptions"
      :disabled="locationId === ''"
      v-if="config.columns === 'location'"
    />
    <DxItem location="after" v-if="config.columns === 'location'">
      <template #default>
        <DxDateBox
          width="150px"
          hint="Выбор даты данных"
          type="date"
          picker-type="calendar"
          displayFormat="dd.MM.yyyy"
          :on-value-changed="dateChanged"
          :value.sync="currentDate"
        />
      </template>
    </DxItem>
    <DxItem
      widget="dxButton"
      location="after"
      :options="prevButtonOptions"
      v-if="!isDayChart"
    />
    <DxItem location="after" :text="periodText()" v-if="!isDayChart" />
    <DxItem
      widget="dxButton"
      location="after"
      :options="nextButtonOptions"
      v-if="!isDayChart"
    />
  </DxToolbar>
</template>
<script lang="ts">
import { ChartPeriodEnum, IModuleConfig } from "@/dto/Dashboards";
import { Component, Prop, Watch } from "vue-property-decorator";
import DxToolbar, { DxItem } from "devextreme-vue/toolbar";
import { addMonth, yesterdayDate } from "@/helpers/utils";
import DxDateBox from "devextreme-vue/date-box";
import DxButton from "devextreme-vue/button";
import Vue from "vue";

@Component({
  components: {
    DxButton,
    DxToolbar,
    DxItem,
    DxDateBox,
  },
})
export default class Toolbar extends Vue {
  @Prop({ type: Date, required: true, default: yesterdayDate() })
  public curDate!: Date;
  @Prop({ type: Object, required: false }) public config!: IModuleConfig;
  @Prop({ type: String, required: false })
  public selectedOnChartLocationId!: string;
  @Prop({ type: Boolean, required: true }) public isDayChart!: boolean;

  private navigateHistory: string[] = [];
  private currentDate: Date = this.curDate;
  private locationId: string = this.selectedOnChartLocationId;

  @Watch("currentDate")
  private updateDate() {
    this.$emit("update:curDate", this.currentDate);
  }

  @Watch("locationId")
  private updateLocation() {
    this.$emit("update:selectedOnChartLocationId", this.locationId);
  }

  @Watch("selectedOnChartLocationId")
  private setLocation() {
    if (this.locationId !== this.selectedOnChartLocationId) {
      this.locationId = this.selectedOnChartLocationId;
    }

    if (
      this.navigateHistory[this.navigateHistory.length] !==
        this.selectedOnChartLocationId &&
      this.selectedOnChartLocationId !== ""
    ) {
      this.navigateHistory.push(this.selectedOnChartLocationId);
    }
  }

  private navigateToHome() {
    this.locationId = "";
    this.navigateHistory = [];
    this.update();
  }

  private navigateToBack() {
    if (this.navigateHistory.length <= 1) {
      this.navigateToHome();
    } else {
      this.navigateHistory.pop();
      this.locationId = this.navigateHistory[this.navigateHistory.length - 1];
      this.update();
    }
  }

  private prevPeriod() {
    switch (this.config?.period) {
      case ChartPeriodEnum.Year:
        this.currentDate.setFullYear(this.currentDate.getFullYear() - 1);
        break;
      case ChartPeriodEnum.Month:
      default:
        this.currentDate = addMonth(this.currentDate, -1);
        break;
    }
    this.update();
  }

  private nextPeriod() {
    switch (this.config?.period) {
      case ChartPeriodEnum.Year:
        this.currentDate.setFullYear(this.currentDate.getFullYear() + 1);
        break;
      case ChartPeriodEnum.Month:
      default:
        this.currentDate = addMonth(this.currentDate, 1);
        break;
    }
    this.update();
  }

  private periodText() {
    let result: string;
    switch (this.config?.period) {
      case ChartPeriodEnum.Month:
        result = `${this.currentDate.toLocaleString("ru", {
          month: "long",
        })} ${this.currentDate.getFullYear()}`;
        break;
      case ChartPeriodEnum.Year:
      default:
        result = this.currentDate.getFullYear().toString();
        break;
    }
    return result;
  }

  private homeButtonOptions = {
    icon: "home",
    hint: "Отображить значения по умолчанию",
    onClick: () => this.navigateToHome(),
  };

  private backButtonOptions = {
    icon: "arrowleft",
    hint: "Назад",
    onClick: () => this.navigateToBack(),
  };

  private prevButtonOptions = {
    icon: "arrowleft",
    hint: "Предыдущий период",
    onClick: () => this.prevPeriod(),
  };

  private nextButtonOptions = {
    icon: "arrowright",
    hint: "Следующий период",
    onClick: () => this.nextPeriod(),
  };

  private dateChanged(args: any) {
    this.currentDate = args.value;
    this.update();
  }

  private update() {
    this.$emit("update:curDate", this.currentDate);
    this.$emit("update:selectedOnChartLocationId", this.locationId);
    this.$emit("update");
  }
}
</script>
<style scoped>
.dx-toolbar {
  background: none;
}
</style>
