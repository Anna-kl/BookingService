﻿using Supply.Dashboards.Shared.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supply.Dashboards.Shared.ViewModels.Charts.FullnessBases
{
    public sealed class FullnessBasesUnitResponseViewModel
    {
        public ValueRecordEnum Type { get; set; }
        public double Square { get; set; }
    }
}
