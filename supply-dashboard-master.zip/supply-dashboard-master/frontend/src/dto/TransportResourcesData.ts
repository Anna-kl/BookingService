import { ChartPeriodEnum, GraphLocationGroupEnum } from "./Dashboards";

export interface ITransportResourcesByPeriodDataResponse {
    periods: ITransportResourcesByPeriodResponse[];
}

export interface ITransportResourcesByPeriodResponse {
    period: ChartPeriodEnum;
    units: ITransportResourcesUnitResponse[];
}

export interface ITransportResourcesByLocationDataResponse {
    locations: ITransportResourcesByLocationResponse[];
}

export interface ITransportResourcesByLocationResponse {
    locationId: string;
    locationTitle: string;
    units: ITransportResourcesUnitResponse[];
}

export interface ITransportResourcesUnitResponse {
    tons: number;
    type: string;
}


export interface ITransportResourcesDataRequest {
    period: string;
    startPeriod: string;
    duration?: string;
    locationType?: string;
    parentLocationId?: string;
    locationsIds?: string[] | null;
    customersIds?: string[] | null;
}

export interface ITransportResourcesByLocationChartData {
    location: string;
    transportPlan?: number;
    transportFact?: number;
    GPMPlan?: number;
    GPMFact?: number;
    laborResourcesPlan?: number;
    laborResourcesFact?: number;
}

export interface ITransportResourcesChartData {
    month?: string;
    locationId?: string;
    location?: string;
    transportPlan?: number;
    transportFact?: number;
    GPMPlan?: number;
    GPMFact?: number;
    laborResourcesPlan?: number;
    laborResourcesFact?: number;
}
