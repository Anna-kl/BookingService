﻿using System;

namespace Supply.Dashboards.Domain.AggregatesModel.Customers
{
    public sealed class CustomerEdge
    {
        public CustomerEdge(
            Customer source,
            Customer destination)
        {
            SourceId = source.Id;
            SourceInnerId = source.InnerId;
            Source = source;

            DestinationId = destination.Id;
            DestinationInnerId = destination.InnerId;
            Destination = destination;
        }


#pragma warning disable 8618
        // ReSharper disable once UnusedMember.Local
        private CustomerEdge()
        {
        }
#pragma warning restore 8618

        public int SourceId { get; init; }
        public Guid SourceInnerId { get; init; }
        public Customer Source { get; init; }

        public int DestinationId { get; init; }
        public Guid DestinationInnerId { get; init; }
        public Customer Destination { get; init; }
    }
}
