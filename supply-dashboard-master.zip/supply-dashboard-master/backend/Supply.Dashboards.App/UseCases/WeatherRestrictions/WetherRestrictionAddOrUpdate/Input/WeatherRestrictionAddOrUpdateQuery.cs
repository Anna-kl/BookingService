﻿using FluentValidation.Results;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.WeatherRestrictions.WetherRestrictionAddOrUpdate.Input
{
    public sealed class WeatherRestrictionAddOrUpdateQuery : IRequest<(ValidationResult validationResult, bool result)>
    {
        public WeatherRestrictionAddOrUpdateQuery(
            Guid? id,
            DateTime date,
            Guid locationId,
            Guid? customerId,
            double temperature,
            double windSpeed,
            string? aktirovka)
        {
            Id = id;
            Date = date;
            LocationId = locationId;
            CustomerId = customerId;
            Temperature = temperature;
            WindSpeed = windSpeed;
            Aktirovka = aktirovka;

            ValidationResult = new WeatherRestrictionAddOrUpdateValidator()
                .Validate(this);
        }

        public Guid? Id { get; }
        public DateTime Date { get; }
        public Guid LocationId { get; }
        public Guid? CustomerId { get; }
        public double Temperature { get; }
        public double WindSpeed { get; }
        public string? Aktirovka { get; }


        public ValidationResult ValidationResult { get; }


    }
}
