<template>
  <DxPopup
    :visible="true"
    :drag-enabled="true"
    :close-on-outside-click="true"
    :show-title="true"
    :width="550"
    :height="180"
    title="Добавление информационного блока"
    @hidden="hide"
  >
    <template>
      <div class="dx-field">
        <div class="dx-field-label">Тип:</div>
        <div class="dx-field-value">
          <DxSelectBox
            :data-source="getAllModules"
            display-expr="name"
            value-expr="id"
            placeholder="Выберите.."
            @valueChanged="moduleChanged"
          />
        </div>
      </div>
      <p>Блок будет добавлен в низ списка</p>
    </template>
  </DxPopup>
</template>

<script lang='ts'>
import { IDashboardLayout, IModuleItem } from "@/dto/Dashboards";
import { Guid } from "@/helpers/guid";
import Vue from "vue";
import { Component, Watch, Prop } from "vue-property-decorator";
import DxTextBox from "devextreme-vue/text-box";
import { DxPopup } from "devextreme-vue/popup";
import DxSelectBox from "devextreme-vue/select-box";
import { DashboardsState } from "@/store";
import config from "@/config";
import { EventBus } from "@/event-bus";

@Component({
  components: { DxTextBox, DxPopup, DxSelectBox },
})
export default class AddDashboardItemDialog extends Vue {
  @Prop({ type: Function, required: true })
  public currentLayout!: () => IDashboardLayout;
  @Prop({ type: Function, required: true })
  public dashboardItemAdded!: (newId: string) => void;
  @Prop({ type: Function, required: true })
  public getModule!: (id: string) => IModuleItem;

  private get getAllModules() {
    return config.allDashboardModules;
  }

  private moduleChanged(e: any) {
    this.addDashboardItem(e.value);
  }
  private addDashboardItem(value: string) {
    const addModule = this.getModule(value)!;
    const newId = Guid.newGuid().toString();
    const maxY = Math.max(
      ...this.currentLayout()
        .items.filter((f) => f.y !== undefined)
        .map((s) => s.y!)
    );

    this.currentLayout().items.push({
      id: newId,
      x: 0,
      y: maxY + 2,
      moduleId: addModule.id,
      height: addModule.defaultHeight,
      width: addModule.defaultWidth,
      config:
        addModule.defaultConfig !== undefined
          ? JSON.parse(JSON.stringify(addModule.defaultConfig))
          : undefined,
      series:
        addModule.defaultSeries !== undefined
          ? JSON.parse(JSON.stringify(addModule.defaultSeries))
          : [],
    });
    this.dashboardItemAdded(newId);
  }

  private hide() {
    EventBus.$emit("hide-adddashboarditemdialog");
  }
}
</script>
<style lang="scss" scoped>
</style>