﻿namespace Supply.Dashboards.Shared.Types
{
    public enum ChartPeriodEnum
    {
        Day = 1,
        Week = 2,
        TwoWeeks = 3,
        Month = 4,
        Quarter = 5,
        HalfYear = 6,
        Year = 7
    }
}
