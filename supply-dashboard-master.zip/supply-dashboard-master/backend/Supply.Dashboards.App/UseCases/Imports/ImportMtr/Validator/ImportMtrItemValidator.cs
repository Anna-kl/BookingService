﻿using FluentValidation;

using Supply.Dashboards.App.UseCases.Imports.ImportMtr.Input;
using Supply.Dashboards.App.UseCases.Imports.ImportMtr.Types;
using Supply.Dashboards.Domain.Types;
using System;

namespace Supply.Dashboards.App.UseCases.Imports.ImportMtr.Validator
{
    public sealed class ImportMtrItemValidator
        : AbstractValidator<ImportMtrItemInput>
    {
        public ImportMtrItemValidator()
        {
            ValidateStartPeriod();
            ValidateEndPeriod();
            ValidateCustomerId();
            ValidateLocationId();
            ValidateMtrTypeId();
            ValidateImportType();
        }

        private void ValidateStartPeriod()
        {
            When(_ => ImportMtrType.IsPlanning(_.Type) || _.Type.Name == "BidForecast", () =>
            {
                RuleFor(_ => _.StartPeriod).NotEmpty();
            }).Otherwise(() =>
            {
                RuleFor(_ => _.StartPeriod)
                    .NotEmpty()
                    .Must(dateTime => dateTime.Date <= DateTime.UtcNow.Date)
                    .WithMessage((query, startPeriod) => $"{nameof(startPeriod)} shouldn't be in the future");
            });
        }

        private void ValidateEndPeriod() => 
            RuleFor(_ => _.EndPeriod);

        private void ValidateCustomerId() =>
            RuleFor(_ => _.CustomerId);

        private void ValidateLocationId() =>
            RuleFor(_ => _.LocationId);

        private void ValidateMtrTypeId() =>
            RuleFor(_ => _.MtrTypeId);

        private void ValidateImportType() =>
            RuleFor(_ => _.Type)
                .NotEmpty()
                .Must(_ => _.Id != 0); // TODO add description
    }
}
