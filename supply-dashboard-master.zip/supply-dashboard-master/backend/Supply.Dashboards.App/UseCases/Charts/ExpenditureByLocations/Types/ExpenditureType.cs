﻿using Common.SeedWork;
using Supply.Dashboards.App.Exceptions;
using Supply.Dashboards.Domain.Types;

namespace Supply.Dashboards.App.UseCases.Charts.ExpenditureByLocations.Types
{
    public sealed class ExpenditureType : Enumeration
    {
        public static ExpenditureType ExpenditureFact = new(208, "ExpenditureFact");
        public static ExpenditureType ExpenditurePlan = new(209, "ExpenditurePlan");
        public static ExpenditureType ExpenditureAdjustedPlan = new(210, "ExpenditureAdjustedPlan");
        public static ExpenditureType ExpenditureDailyPlan = new(211, "ExpenditureDailyPlan");

        public ExpenditureType(int id, string name) : base(id, name) {}

        internal static ExpenditureType GetExpenditureType(ValueRecordType type)
        {
            var name = type.Name switch
            {
                nameof(ValueRecordType.ExpenditureFact) => ExpenditureFact.Name,
                nameof(ValueRecordType.ExpenditurePlan) => ExpenditurePlan.Name,
                nameof(ValueRecordType.ExpenditureAdjustedPlan) => ExpenditureAdjustedPlan.Name,
                nameof(ValueRecordType.ExpenditureDailyPlan) => ExpenditureDailyPlan.Name,

                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<ExpenditureType>(name)!;
        }
    }
}
