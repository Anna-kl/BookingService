<template>
  <div v-if="series.length > 0">
    <h4>Отображение данных</h4>
    <div v-for="seriesItem in series" :key="seriesItem.id" class="checkbox">
      <DxCheckBox
        :text="seriesItem.name"
        :name="seriesItem.id"
        :value="seriesItem.value"
        :id="seriesItem.id"
        @value-changed="selectCheckBox"
      />
    </div>
  </div>
</template>

<script lang='ts'>
import Vue from "vue";
import { Component, Watch, Prop } from "vue-property-decorator";
import { DxCheckBox } from "devextreme-vue/check-box";
import config from "@/config";
import { EventBus } from "@/event-bus";
import { SettingsState } from "@/store";
import { IModuleSeries } from "@/dto/Dashboards";

@Component({
  components: {
    DxCheckBox,
  },
})
export default class SeriesFilter extends Vue {
  private series: IModuleSeries[] = [];
  private values = new Map();

  public mounted() {
    EventBus.$on("pick-module", this.refreshCheckboxes);
    this.refreshCheckboxes();
  }

  public refreshCheckboxes() {
    this.series = SettingsState.pickedDashboardItem?.series || [];

    this.series?.forEach((ser: IModuleSeries) => {
      const pickedDashboardItemSeries = SettingsState.pickedDashboardItem!.series?.find(
        (m) => m.id == ser.id
      );
      if (pickedDashboardItemSeries?.value) {
        ser.value = pickedDashboardItemSeries.value;
      } else {
        ser.value = false;
      }
    });
  }

  private selectCheckBox(e: any) {
    if (e.event !== undefined) {
      const pickedCheckbox = this.series.find((s) => s.id === e.element.id);
      pickedCheckbox!.value = e.value;
      SettingsState.setSeries(this.series);
    }
  }
}
</script>
<style scoped>
.checkbox {
  text-align: left;
}
</style>