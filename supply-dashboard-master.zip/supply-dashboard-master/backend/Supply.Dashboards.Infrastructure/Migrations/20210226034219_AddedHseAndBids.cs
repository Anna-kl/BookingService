﻿using Microsoft.EntityFrameworkCore.Migrations;

using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

using System;

namespace Supply.Dashboards.Infrastructure.Migrations
{
    public partial class AddedHseAndBids : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "bids",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    createat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    updateat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    payload_datetime = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    payload_type = table.Column<int>(type: "integer", nullable: false),
                    payload_customerid = table.Column<int>(type: "integer", nullable: true),
                    payload_locationid = table.Column<int>(type: "integer", nullable: true),
                    payload_inputtype = table.Column<int>(type: "integer", nullable: false),
                    contextid = table.Column<int>(type: "integer", nullable: false),
                    innerid = table.Column<Guid>(type: "uuid", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_bids", x => x.id);
                    table.UniqueConstraint("AK_bids_innerid", x => x.innerid);
                    table.ForeignKey(
                        name: "FK_bids_contexts_contextid",
                        column: x => x.contextid,
                        principalTable: "contexts",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_bids_customers_payload_customerid",
                        column: x => x.payload_customerid,
                        principalTable: "customers",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_bids_locations_payload_locationid",
                        column: x => x.payload_locationid,
                        principalTable: "locations",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "hse_incidents",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    createat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    updateat = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    payload_datetime = table.Column<DateTime>(type: "timestamp without time zone", nullable: false),
                    payload_type = table.Column<int>(type: "integer", nullable: false),
                    payload_customerid = table.Column<int>(type: "integer", nullable: true),
                    payload_locationid = table.Column<int>(type: "integer", nullable: true),
                    payload_text = table.Column<string>(type: "text", nullable: false),
                    payload_inputtype = table.Column<int>(type: "integer", nullable: false),
                    contextid = table.Column<int>(type: "integer", nullable: false),
                    innerid = table.Column<Guid>(type: "uuid", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_hse_incidents", x => x.id);
                    table.UniqueConstraint("AK_hse_incidents_innerid", x => x.innerid);
                    table.ForeignKey(
                        name: "FK_hse_incidents_contexts_contextid",
                        column: x => x.contextid,
                        principalTable: "contexts",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_hse_incidents_customers_payload_customerid",
                        column: x => x.payload_customerid,
                        principalTable: "customers",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_hse_incidents_locations_payload_locationid",
                        column: x => x.payload_locationid,
                        principalTable: "locations",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_bids_contextid",
                table: "bids",
                column: "contextid");

            migrationBuilder.CreateIndex(
                name: "IX_bids_payload_customerid",
                table: "bids",
                column: "payload_customerid");

            migrationBuilder.CreateIndex(
                name: "IX_bids_payload_locationid",
                table: "bids",
                column: "payload_locationid");

            migrationBuilder.CreateIndex(
                name: "IX_hse_incidents_contextid",
                table: "hse_incidents",
                column: "contextid");

            migrationBuilder.CreateIndex(
                name: "IX_hse_incidents_payload_customerid",
                table: "hse_incidents",
                column: "payload_customerid");

            migrationBuilder.CreateIndex(
                name: "IX_hse_incidents_payload_locationid",
                table: "hse_incidents",
                column: "payload_locationid");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "bids");

            migrationBuilder.DropTable(
                name: "hse_incidents");
        }
    }
}
