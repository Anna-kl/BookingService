﻿using Common.SeedWork;

using MediatR;

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Storage;

using Supply.Dashboards.App.UserInfo;
using Supply.Dashboards.Domain.AggregatesModel.Bids;
using Supply.Dashboards.Domain.AggregatesModel.Core;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.HseIncidents;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;
using Supply.Dashboards.Domain.AggregatesModel.ValueRecords;
using Supply.Dashboards.Domain.AggregatesModel.WeatherRestrictions;
using Supply.Dashboards.Infrastructure.Exceptions;
using Supply.Dashboards.Infrastructure.Extensions;
using Supply.Dashboards.Infrastructure.TypeConfigurations.AggregatesModel.Bids;
using Supply.Dashboards.Infrastructure.TypeConfigurations.AggregatesModel.Core;
using Supply.Dashboards.Infrastructure.TypeConfigurations.AggregatesModel.Customers;
using Supply.Dashboards.Infrastructure.TypeConfigurations.AggregatesModel.HseIncidents;
using Supply.Dashboards.Infrastructure.TypeConfigurations.AggregatesModel.Locations;
using Supply.Dashboards.Infrastructure.TypeConfigurations.AggregatesModel.MtrTypes;
using Supply.Dashboards.Infrastructure.TypeConfigurations.AggregatesModel.ValueRecords;
using Supply.Dashboards.Infrastructure.TypeConfigurations.AggregatesModel.WeatherRestrictions;
using Supply.Dashboards.Infrastructure.TypeConfigurations.AggregatesModel.ContextUserSettingTypeConfig;
using System;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Supply.Dashboards.Domain.AggregatesModel;
using Supply.Dashboards.Infrastructure.TypeConfigurations.AggregatesModel;
using Supply.Dashboards.Domain.AggregatesModel.ContextUserSettings;

namespace Supply.Dashboards.Infrastructure.Data
{
    public sealed class DashboardsContext : DbContext, IUnitOfWork
    {
        private readonly IMediator _mediator;
        private IDbContextTransaction? _currentTransaction;

        public DashboardsContext(
            DbContextOptions options,
            IMediator mediator)
            : base(options)
        {
            _mediator = mediator
                        ?? throw new ArgumentNullException(nameof(mediator));
        }

        protected override void OnConfiguring(DbContextOptionsBuilder builder)
        {
            base.OnConfiguring(builder);
        }

        public DbSet<Bid> Bids => Set<Bid>();
        public DbSet<Context> Contexts => Set<Context>();
        public DbSet<User> Users => Set<User>();
        public DbSet<ContextUser> ContextUsers => Set<ContextUser>();
        public DbSet<AliasId> AliasIds => Set<AliasId>();

        public DbSet<Customer> Customers => Set<Customer>();
        public DbSet<CustomerEdge> CustomersEdges => Set<CustomerEdge>();
        public DbSet<HseIncident> HseIncidents => Set<HseIncident>();
        public DbSet<Location> Locations => Set<Location>();
        public DbSet<LocationEdge> LocationEdges => Set<LocationEdge>();
        public DbSet<MtrType> MtrTypes => Set<MtrType>();
        public DbSet<MtrTypeEdge> MtrTypesEdges => Set<MtrTypeEdge>();
        public DbSet<ValueRecord> ValueRecords => Set<ValueRecord>();

        public DbSet<Event> Events => Set<Event>();

        public DbSet<WeatherRestriction> WeatherRestrictions => Set<WeatherRestriction>();

        public DbSet<ContextUserSetting> ContextUserSettings => Set<ContextUserSetting>();

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder
                .ApplyConfiguration(new BidTypeConfig())
                .ApplyConfiguration(new ContextTypeConfig())
                .ApplyConfiguration(new UserTypeConfig())
                .ApplyConfiguration(new ContextUserTypeConfig())
                .ApplyConfiguration(new CustomerTypeConfig())
                .ApplyConfiguration(new HseIncidentTypeConfig())
                .ApplyConfiguration(new CustomerEdgeTypeConfig())
                .ApplyConfiguration(new LocationTypeConfig())
                .ApplyConfiguration(new LocationEdgeTypeConfig())
                .ApplyConfiguration(new MtrTypeTypeConfig())
                .ApplyConfiguration(new MtrTypeEdgeTypeConfig())
                .ApplyConfiguration(new WeatherRestrictionTypeConfig())
                .ApplyConfiguration(new ValueRecordTypeConfig())
                .ApplyConfiguration(new EventTypeConfig())
                .ApplyConfiguration(new ContextUserSettingTypeConfig());

            foreach (var entity in builder.Model.GetEntityTypes())
            {
                entity.SetTableName(entity.GetTableName().ToLowerInvariant());

                foreach (var property in entity.GetProperties())
                    property?.SetColumnName(property.GetColumnName().ToLowerInvariant());
            }
        }

        #region SaveChanges

        /// <summary>
        /// Used only for seed DB.
        /// </summary>
        /// <param name="contextId"></param>
        /// <returns></returns>
        internal int SaveChanges(int contextId)
        {
            var addedEntries = ChangeTracker
                .Entries()
                .Where(_ => _.State == EntityState.Added);

            foreach (var entry in addedEntries)
            {
                if (entry.Metadata.FindProperty("ContextId") == null)
                    continue;

                entry.Property("ContextId").CurrentValue = contextId;
            }

            return SaveChanges();
        }

        public async Task<bool> SaveEntitiesAsync(CancellationToken cancellationToken = default)
        {
            await _mediator.DispatchDomainEventsAsync(this);
            var result = await SaveChangesAsync(cancellationToken);

            return result != 0;
        }

        public override Task<int> SaveChangesAsync(bool acceptAllChangesOnSuccess, CancellationToken cancellationToken = new())
        {
            var addedEntries = ChangeTracker
                .Entries()
                .Where(_ => _.State == EntityState.Added)
                .ToList();

            if (!addedEntries.Any())
                return base.SaveChangesAsync(acceptAllChangesOnSuccess, cancellationToken);

            foreach (var entry in addedEntries)
            {
                if (entry.Metadata.FindProperty("ContextId") == null)
                    continue;

                if (UserInfo.Context == null)
                    throw new InfraException($"{nameof(UserInfo.Context)} is null.");

                entry.Property("ContextId").CurrentValue = UserInfo.Context.Id;
            }

            return base.SaveChangesAsync(acceptAllChangesOnSuccess, cancellationToken);
        }

        #endregion

        #region Transaction

        public IDbContextTransaction? GetCurrentTransaction()
        {
            return _currentTransaction;
        }

        public bool HasActiveTransaction => _currentTransaction != null;

        public async Task<IDbContextTransaction?> BeginTransactionAsync()
        {
            _currentTransaction = await Database.BeginTransactionAsync(IsolationLevel.ReadCommitted);

            return _currentTransaction;
        }

        public IDbContextTransaction? BeginTransaction()
        {
            _currentTransaction = Database.BeginTransaction(IsolationLevel.ReadCommitted);

            return _currentTransaction;
        }

        public async Task CommitTransactionAsync(IDbContextTransaction transaction)
        {
            if (transaction == null)
                throw new ArgumentNullException(nameof(transaction));

            if (transaction != _currentTransaction)
                throw new InvalidOperationException($"Transaction {transaction.TransactionId} is not current");

            try
            {
                await SaveChangesAsync();
                await transaction.CommitAsync();
            }
            catch
            {
                RollbackTransaction();

                throw;
            }
            finally
            {
                _currentTransaction?.Dispose();
                _currentTransaction = null!;
            }
        }

        public void CommitTransaction(IDbContextTransaction transaction)
        {
            if (transaction == null)
                throw new ArgumentNullException(nameof(transaction));

            if (transaction != _currentTransaction)
                throw new InvalidOperationException($"Transaction {transaction.TransactionId} is not current");

            try
            {
                SaveChanges();
                transaction.Commit();
            }
            catch
            {
                RollbackTransaction();

                throw;
            }
            finally
            {
                _currentTransaction?.Dispose();
                _currentTransaction = null!;
            }
        }

        public void RollbackTransaction()
        {
            try
            {
                _currentTransaction?.Rollback();
            }
            finally
            {
                if (_currentTransaction != null)
                {
                    _currentTransaction.Dispose();
                    _currentTransaction = null!;
                }
            }
        }

        #endregion
    }
}
