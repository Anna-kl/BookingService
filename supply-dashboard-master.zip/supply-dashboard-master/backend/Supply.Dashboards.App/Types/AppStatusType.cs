﻿using Common.SeedWork;

using Supply.Dashboards.App.Exceptions;
using Supply.Dashboards.Domain.Types;

namespace Supply.Dashboards.App.Types
{
    public sealed class AppStatusType : Enumeration
    {
        public static AppStatusType Default = new(0, "Default");
        public static AppStatusType Active = new(1, "Active");
        public static AppStatusType Disable = new(2, "Disable");
        public static AppStatusType Archived = new(3, "Archived");

        public AppStatusType(int id, string name) : base(id, name)
        {
        }

        internal static StatusType GetStatusType(AppStatusType type)
        {
            var name = type.Name switch
            {
                nameof(Default) => throw new AppException(nameof(Default)),
                nameof(Active) => StatusType.Active.Name,
                nameof(Disable) => StatusType.Disable.Name,
                nameof(Archived) => StatusType.Archived.Name,
                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<StatusType>(name)!;
        }

        internal static AppStatusType GetAppStatusType(StatusType type)
        {
            var name = type.Name switch
            {
                nameof(StatusType.Active) => Active.Name,
                nameof(StatusType.Disable) => Disable.Name,
                nameof(StatusType.Archived) => Archived.Name,
                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<AppStatusType>(name)!;
        }
    }
}
