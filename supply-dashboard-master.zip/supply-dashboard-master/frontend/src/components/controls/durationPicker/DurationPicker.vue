<template>
  <div v-if="currentPeriod">
    <h4>Периоды выборки</h4>
    <DxRadioGroup
      :items="durations"
      :value="currentPeriod"
      @value-changed="valueChange"
    />
  </div>
</template>

<script lang='ts'>
import Vue from "vue";
import { Component, Watch, Prop } from "vue-property-decorator";
import config from "@/config";
import { EventBus } from "@/event-bus";
import { SettingsState } from "@/store";
import {
  ChartPeriodEnum,
  DurationPickerData,
  IModuleSeries,
} from "@/dto/Dashboards";
import DxRadioGroup from "devextreme-vue/radio-group";

@Component({
  components: {
    DxRadioGroup,
  },
})
export default class DurationPicker extends Vue {
  private durations: DurationPickerData[] = config.durationPickerValues;
  public mounted() {
    EventBus.$on("pick-module", this.refreshRadiogroup);
    this.refreshRadiogroup();
  }

  private refreshRadiogroup() {
    this.durations = [];
    const pickedDashboardItem = SettingsState.pickedDashboardItem;
    if (pickedDashboardItem?.config?.allowPeriods) {
      pickedDashboardItem?.config?.allowPeriods.forEach((allowPeriod) => {
        const duration = config.durationPickerValues.find(
          (s) => s.chartPeriod === allowPeriod
        );
        if (duration !== undefined) {
          this.durations.push(duration);
        }
      });
    } else {
      this.durations = config.durationPickerValues.filter(
        (s) => s.defaultPicker
      );
    }
  }

  private get currentPeriod() {
    const pickedDashboardItem = SettingsState.pickedDashboardItem;
    return this.durations.find(
      (d: DurationPickerData) =>
        d.chartPeriod === pickedDashboardItem?.config?.period
    );
  }

  private valueChange(e: any) {
    SettingsState.setSelectedDuration(e.value.chartPeriod);
  }
}
</script>
<style scoped>
.checkbox {
  text-align: left;
}
</style>