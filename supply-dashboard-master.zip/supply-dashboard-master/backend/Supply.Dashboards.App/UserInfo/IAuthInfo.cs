﻿using Supply.Dashboards.Domain.AggregatesModel.Core;

using System;

namespace Supply.Dashboards.App.UserInfo
{
    public interface IAuthInfo
    {
        void CreateUser(
            string userNameIdentifier,
            Context context);

        Context? GetContextByInnerId(Guid innerId);
        Context? GetContextById(int id);
        User? GetUserByNameIdentifier(string userNameIdentifier);
    }
}
