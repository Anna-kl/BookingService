﻿using Supply.Dashboards.Shared.Types;

namespace Supply.Dashboards.Shared.ViewModels.Charts.ArrivalByLocations
{
    public sealed class ArrivalByLocationsResponseUnitViewModel
    {
        public ValueRecordEnum Type { get; set; }
        public double Tons { get; set; }
    }
}
