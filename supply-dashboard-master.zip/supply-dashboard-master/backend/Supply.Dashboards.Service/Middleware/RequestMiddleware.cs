﻿
using Common.RequestInfo;

using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.UserInfo;

using System;
using System.Threading.Tasks;

namespace Supply.Dashboards.Service.Middleware
{
    public sealed class RequestMiddleware
    {
        private readonly ILogger<ServerErrorMiddleware> _logger;
        private readonly RequestDelegate _next;

        public RequestMiddleware(
            RequestDelegate next,
            ILoggerFactory loggerFactory)
        {
            _next = next
                    ?? throw new ArgumentNullException(nameof(next));

            _logger = loggerFactory.CreateLogger<ServerErrorMiddleware>()
                      ?? throw new ArgumentNullException(nameof(loggerFactory));
        }

        public async Task Invoke(HttpContext context, AuthInfo authInfo)
        {
            authInfo.CreateUser();

            UserInfo.SetValue(
                authInfo.GetCurrentUserContext(),
                authInfo.GetCurrentUserNameIdentifier()
            );

            RequestInfo.SetValues(context);
            await _next(context);
        }
    }
}
