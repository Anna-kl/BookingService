﻿using Supply.Dashboards.App.UseCases.Charts.AccountingMtrByPeriods.Types;

namespace Supply.Dashboards.App.UseCases.Charts.AccountingMtrByPeriods.Output
{
    public sealed class AccountingMtrByPeriodsUnitOutput
    {
        public AccountingMtrByPeriodsUnitOutput(
            AccountingMtrByPeriodsType type,
            double value)
        {
            Type = type;
            Value = value;
        }

        public AccountingMtrByPeriodsType Type { get; }
        public double Value { get; }
    }
}
