﻿using FluentValidation;

using Supply.Dashboards.App.UseCases.Imports.ImportMtr.Input;

namespace Supply.Dashboards.App.UseCases.Imports.ImportMtr.Validator
{
    public sealed class ImportMtrValidator
        : AbstractValidator<ImportMtrCommand>
    {
        public ImportMtrValidator()
        {
            ValidateInputs();
            ValidateInputType();
        }

        private void ValidateInputs() =>
            RuleForEach(_ => _.Items)
                .SetValidator(new ImportMtrItemValidator());

        private void ValidateInputType() =>
            RuleFor(_ => _.InputType)
                .NotEmpty()
                .Must(_ => _.Id != 0); // TODO add description
    }
}
