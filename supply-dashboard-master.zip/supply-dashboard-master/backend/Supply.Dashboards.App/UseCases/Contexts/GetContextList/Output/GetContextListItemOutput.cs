﻿using Supply.Dashboards.App.Types;
using Supply.Dashboards.Domain.AggregatesModel.Core;

using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.Contexts.GetContextList.Output
{
    public sealed class GetContextListItemOutput
    {
        private readonly List<GetContextListUserItemOutput> _users;

        public GetContextListItemOutput(
            int id,
            uint xmin,
            AppStatusType status,
            string title,
            IEnumerable<User> users)
        {
            Id = id;
            RowVersion = xmin;
            Status = status;
            Title = title;

            _users = users
                .Select(ToGetContextListUserItemOutput)
                .ToList();
        }

        public int Id { get; }
        public uint RowVersion { get; }
        public AppStatusType Status { get; }
        public string Title { get; }

        public IEnumerable<GetContextListUserItemOutput> Users =>
            _users.AsReadOnly();

        private static GetContextListUserItemOutput ToGetContextListUserItemOutput(User user) =>
            new(
                user.InnerId,
                AppStatusType.GetAppStatusType(user.Status),
                user.NameIdentifier,
                user.FullName);
    }
}
