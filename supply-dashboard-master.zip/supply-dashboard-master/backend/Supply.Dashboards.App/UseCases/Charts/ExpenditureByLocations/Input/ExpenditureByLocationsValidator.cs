﻿using FluentValidation;

namespace Supply.Dashboards.App.UseCases.Charts.ExpenditureByLocations.Input
{
    public sealed class ExpenditureByLocationsValidator
        : AbstractValidator<ExpenditureByLocationsQuery>
    {
        public ExpenditureByLocationsValidator()
        {
            ValidateLocationType();
            ValidateStartPeriod();
            ValidateEndPeriod();
            ValidateCustomersIds();
            ValidateLocationsIds();
            ValidateMtrTypesIds();
        }

        private void ValidateLocationType() =>
            RuleFor(_ => _.LocationType);

        private void ValidateStartPeriod() =>
            RuleFor(_ => _.StartPeriod)
                .NotEmpty();

        private void ValidateEndPeriod() =>
            RuleFor(_ => _.EndPeriod)
                .NotEmpty();

        private void ValidateCustomersIds() =>
            RuleForEach(_ => _.CustomersIds);

        private void ValidateLocationsIds() =>
            RuleForEach(_ => _.LocationsIds);

        private void ValidateMtrTypesIds() =>
            RuleForEach(_ => _.MtrTypesIds);
    }
}
