﻿using System;
using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.Charts.FullnessBases.Output
{
    public sealed class FullnessBasesByLocationsParamOutput
    {
        private readonly List<FullnessBasesUnitOutput> _units;

        internal FullnessBasesByLocationsParamOutput(
            Guid locationId,
            string locationTitle,
            List<FullnessBasesUnitOutput>? units)
        {
            LocationId = locationId;
            LocationTitle = locationTitle;
            _units = units ?? new List<FullnessBasesUnitOutput>();
        }

        public Guid LocationId { get; }
        public string LocationTitle { get; }

        public IEnumerable<FullnessBasesUnitOutput>? Units =>
            _units.AsReadOnly();
    }
}
