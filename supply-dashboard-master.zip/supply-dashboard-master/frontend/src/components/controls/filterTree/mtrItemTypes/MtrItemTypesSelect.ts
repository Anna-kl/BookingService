import { MtrItemTypeEnum } from "@/dto/InputData";

export interface ITreeListMtrItemDataType {
    id: string;
    parentId: string;
    name: string;
    selected?: boolean;
    type?: MtrItemTypeEnum;
}