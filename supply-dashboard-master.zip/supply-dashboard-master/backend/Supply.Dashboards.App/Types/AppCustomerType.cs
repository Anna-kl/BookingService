﻿using Common.SeedWork;

using Supply.Dashboards.App.Exceptions;
using Supply.Dashboards.Domain.Types;

namespace Supply.Dashboards.App.Types
{
    public sealed class AppCustomerType : Enumeration
    {
        public static AppCustomerType Default = new(0, "Default");
        public static AppCustomerType Inner = new(1, "Inner");
        public static AppCustomerType External = new(2, "External");

        public AppCustomerType(int id, string name) : base(id, name)
        {
        }

        internal static CustomerType GetCustomerType(AppCustomerType type)
        {
            var name = type.Name switch
            {
                nameof(Default) => throw new AppException(nameof(Default)),
                nameof(Inner) => CustomerType.Inner.Name,
                nameof(External) => CustomerType.External.Name,
                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<CustomerType>(name)!;
        }

        internal static AppCustomerType GetAppCustomerType(CustomerType type)
        {
            var name = type.Name switch
            {
                nameof(CustomerType.Inner) => Inner.Name,
                nameof(CustomerType.External) => External.Name,
                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<AppCustomerType>(name)!;
        }
    }
}
