﻿using Microsoft.EntityFrameworkCore.Storage;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Common.SeedWork
{
    public interface IUnitOfWork : IDisposable
    {
        Task<int> SaveChangesAsync(
            CancellationToken cancellationToken);

        Task<bool> SaveEntitiesAsync(
            CancellationToken cancellationToken);

        IDbContextTransaction? GetCurrentTransaction();
        Task<IDbContextTransaction?> BeginTransactionAsync();
        IDbContextTransaction? BeginTransaction();
        Task CommitTransactionAsync(IDbContextTransaction transaction);
        void CommitTransaction(IDbContextTransaction transaction);
        void RollbackTransaction();
    }
}
