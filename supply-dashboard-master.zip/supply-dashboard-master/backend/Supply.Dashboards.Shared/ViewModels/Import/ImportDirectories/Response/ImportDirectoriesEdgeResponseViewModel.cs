﻿using System;

namespace Supply.Dashboards.Shared.ViewModels.Import.ImportDirectories.Response
{
    public sealed class ImportDirectoriesEdgeResponseViewModel
    {
        public Guid SourceId { get; set; }
        public Guid DestinationId { get; set; }
    }
}
