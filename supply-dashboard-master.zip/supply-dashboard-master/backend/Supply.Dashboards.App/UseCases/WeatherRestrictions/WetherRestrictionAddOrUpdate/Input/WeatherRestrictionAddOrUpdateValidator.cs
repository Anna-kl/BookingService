﻿using FluentValidation;
using System;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.WeatherRestrictions.WetherRestrictionAddOrUpdate.Input
{
    public sealed class WeatherRestrictionAddOrUpdateValidator
        : AbstractValidator<WeatherRestrictionAddOrUpdateQuery>
    {
        public WeatherRestrictionAddOrUpdateValidator()
        {
            ValidateLocationId();
            ValidateAktirovka();
            ValidateTemperature();
            ValidateWindSpeed();
            ValidateDate();
        }

        private void ValidateDate()
        {
            RuleFor(_ => _.Date)
                .Must(_ => _ != default)
                .Must(_ => _ > DateTime.UtcNow.AddMonths(-6) && _ < DateTime.UtcNow.AddMonths(6));
        }

        private void ValidateAktirovka()
        {
            RuleFor(_ => _.Aktirovka)
                .Must(_ => !String.IsNullOrEmpty(_) && _.Length < 1000);
        }

        private void ValidateTemperature()
        {
            RuleFor(_ => _.Temperature)
                .Must(_ => _ > -100 && _ < 100);
        }

        private void ValidateWindSpeed()
        {
            RuleFor(_ => _.WindSpeed)
                .Must(_ => _ >= 0 && _ < 100);
        }

        private void ValidateLocationId()
        {
            RuleFor(_ => _.LocationId)
                .Must(_ => _ != default);
        }
    }
}
