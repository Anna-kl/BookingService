﻿using System;
using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.Charts.SeasonalDelivery.Output
{
    public sealed class SeasonalDeliveryParamOutput
    {

        private readonly List<SeasonalDeliveryUnitOutput> _units;

        internal SeasonalDeliveryParamOutput(
            Guid locationId,
            string locationTitle,
            List<SeasonalDeliveryUnitOutput>? units)
        {
            LocationId = locationId;
            LocationTitle = locationTitle;
            _units = units ?? new List<SeasonalDeliveryUnitOutput>();
        }

        public Guid LocationId { get; }
        public string LocationTitle { get; }

        public IEnumerable<SeasonalDeliveryUnitOutput> Units =>
            _units.AsReadOnly();

    }
}
