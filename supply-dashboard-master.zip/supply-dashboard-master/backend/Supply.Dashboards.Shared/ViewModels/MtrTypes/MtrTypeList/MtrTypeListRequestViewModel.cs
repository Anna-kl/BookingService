﻿using Supply.Dashboards.Shared.Types;
using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.MtrTypes.MtrTypeList
{
    public sealed class MtrTypeListRequestViewModel
    {
        public List<StatusEnum>? Statuses { get; set; }
        public List<Guid?>? ParentIds { get; set; }
        public List<Guid>? Ids { get; set; }
    }
}
