﻿using Supply.Dashboards.App.Types;

using System;

namespace Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Output
{
    public sealed class ImportDirectoriesLocationOutput
    {
        internal ImportDirectoriesLocationOutput(
            Guid id,
            uint xMin,
            AppStatusType status,
            AppLocationType type,
            string title,
            string? description,
            double? longitude,
            double? latitude,
            double? diameter)
        {
            Id = id;
            RowVersion = xMin;
            Status = status;
            Type = type;
            Title = title;
            Description = description;
            Longitude = longitude;
            Latitude = latitude;
            Diameter = diameter;
        }

        public Guid Id { get; }
        public uint RowVersion { get; }

        public AppStatusType Status { get; }
        public AppLocationType Type { get; }

        public string Title { get; }
        public string? Description { get; }

        public double? Longitude { get; }
        public double? Latitude { get; }
        public double? Diameter { get; }
    }
}
