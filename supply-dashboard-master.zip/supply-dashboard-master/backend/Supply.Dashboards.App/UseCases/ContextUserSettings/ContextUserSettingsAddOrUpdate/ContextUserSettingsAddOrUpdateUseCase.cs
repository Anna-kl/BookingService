﻿using FluentValidation.Results;

using MediatR;

using Microsoft.Extensions.Logging;
using Supply.Dashboards.App.UseCases.ContextUserSettings.ContextUserSettingsAddOrUpdate.Input;
using Supply.Dashboards.Domain.AggregatesModel.ContextUserSettings;
using Supply.Dashboards.Domain.AggregatesModel.Core;
using Supply.Dashboards.Domain.Types;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.ContextUserSettings.ContextUserSettingsAddOrUpdate
{
    public sealed class ContextUserSettingsAddOrUpdateUseCase
        : IRequestHandler<ContextUserSettingsAddOrUpdateQuery, (ValidationResult validationResult, bool result)>
    {
        private readonly ILogger<ContextUserSettingsAddOrUpdateUseCase> _logger;
        private readonly IBaseUseCase _baseRepo;

        private ValidationResult _validationResult;

        public ContextUserSettingsAddOrUpdateUseCase(
            ILogger<ContextUserSettingsAddOrUpdateUseCase> logger,
            IBaseUseCase baseRepo)
        {
            _logger = logger;
            _baseRepo = baseRepo;
            _validationResult = new ValidationResult();
        }

        public async Task<(ValidationResult validationResult, bool result)> Handle(
            ContextUserSettingsAddOrUpdateQuery request,
            CancellationToken cancellationToken)
        {
            _validationResult = request.ValidationResult;

            if (!_validationResult.IsValid) return (_validationResult, false);

            var contextUserSetting = _baseRepo.GetFirstOrDefault<ContextUserSetting>(_ => _.ContextId == request.ContextId && _.UserId == request.UserId);

            if (contextUserSetting == null)
            {
                contextUserSetting = new ContextUserSetting(
                    request.ContextId,
                    request.UserId,
                    request.DashboardsState
                       );
                _baseRepo.Create<ContextUserSetting>(contextUserSetting);
                await _baseRepo.UnitOfWork.SaveChangesAsync(cancellationToken);

            }
            else
            {
                contextUserSetting.Change(
                        request.DashboardsState);
                await _baseRepo.UnitOfWork.SaveChangesAsync(cancellationToken);
            }

            return (_validationResult, true);
        }

    }
}
