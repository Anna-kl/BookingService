﻿using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Charts.TransportResources
{
    public sealed class TransportResourcesByPeriodsParamResponseViewModel
    {
        public string? Period { get; set; }
        public List<TransportResourcesUnitResponseViewModel>? Units { get; set; }
    }
}
