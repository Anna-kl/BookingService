﻿using FluentValidation.Results;

using MediatR;

using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.Imports.ImportMtr.Output;
using Supply.Dashboards.App.UseCases.Imports.ImportMtr.Validator;

using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.Imports.ImportMtr.Input
{
    public sealed class ImportMtrCommand
        : IRequest<(ValidationResult validationResult, ImportMtrOutput? output)>
    {
        private readonly List<ImportMtrItemInput> _items;

        public ImportMtrCommand(
            List<ImportMtrItemInput>? items,
            AppInputType inputType)
        {
            _items = items ?? new List<ImportMtrItemInput>();
            InputType = inputType;

            ValidationResult = new ImportMtrValidator()
                .Validate(this);
        }

        public IEnumerable<ImportMtrItemInput> Items =>
            _items.AsReadOnly();

        public AppInputType InputType { get; }

        public ValidationResult ValidationResult { get; }
    }
}
