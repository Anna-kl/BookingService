﻿using Supply.Dashboards.Shared.Types;
using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Customers.CustomerList
{
    public sealed class CustomerListResponseViewModel
    {
        public Guid Id { get; set; }
        public uint RowVersion { get; set; }
        public List<Guid>? ParentIds { get; set; }
        public List<Guid>? ChildrenIds { get; set; }
        public CustomerTypeEnum Type { get; set; }

        public string? Title { get; set; }
        public string? Description { get; set; }
    }
}
