﻿using FluentValidation.Results;

using MediatR;

using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.UseCases.Charts.FullnessBases.Input;
using Supply.Dashboards.App.UseCases.Charts.FullnessBases.Output;
using Supply.Dashboards.App.UseCases.Charts.FullnessBases.Types;
using Supply.Dashboards.Domain.Types;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Supply.Dashboards.App.UseCases.ValueRecords;
using Supply.Dashboards.App.UseCases.Locations.GetLocationList;
using Common.Extensions;

namespace Supply.Dashboards.App.UseCases.Charts.FullnessBasesByLocations
{
    public sealed class FullnessBasesByLocationsUseCase
        : IRequestHandler<FullnessBasesByLocationsQuery, (ValidationResult validationResult, FullnessBasesByLocationsOutput? output)>
    {
        private readonly ILogger<FullnessBasesByLocationsUseCase> _logger;
        private readonly IMediator _mediator;
        private readonly IValueRecords _valueRecordsRepo;
        private readonly IGetLocationList _locationsRepo;

        private ValidationResult _validationResult;
        private readonly List<StatusType> _selectStatus;

        public FullnessBasesByLocationsUseCase(
            ILogger<FullnessBasesByLocationsUseCase> logger,
            IMediator mediator,
            IValueRecords valueRecordsRepo,
            IGetLocationList locationsRepo)
        {
            _logger = logger;
            _mediator = mediator;
            _valueRecordsRepo = valueRecordsRepo;
            _locationsRepo = locationsRepo;

            _validationResult = new ValidationResult();
            _selectStatus = new List<StatusType> { StatusType.Active };
        }

        public async Task<(ValidationResult validationResult, FullnessBasesByLocationsOutput? output)> Handle(
            FullnessBasesByLocationsQuery request,
            CancellationToken cancellationToken)
        {
            _validationResult = request.ValidationResult;

            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            var records = await _valueRecordsRepo.GetRecordsWithDateFilter(
                new List<ValueRecordType>
                {
                    ValueRecordType.FullnessBasesTotalSquare,
                    ValueRecordType.FullnessBasesLoaded,
                    ValueRecordType.FullnessBasesLoadedRubles,
                    ValueRecordType.FullnessBasesLoadedWeight
                },
                request.StartPeriod,
                request.EndPeriod,
                null,
                request.ParentLocationId,
                request.LocationsIds,
                request.CustomersIds,
                request.MtrTypesIds,
                _selectStatus,
                false,
                false,
                cancellationToken);
            var recordsByLocations = records.GroupBy(_ => _.Payload.Location);

            var resultItems = new List<FullnessBasesByLocationsParamOutput>();

            var divisionsWithAllChildrensLocations = _locationsRepo.GetActiveDivisionsWithChildrenLocations();

            foreach (var divisionWithLocations in divisionsWithAllChildrensLocations)
            {
                // записи сгруппированные по локациям дивизиона
                var locationsWithRecords = recordsByLocations.Where(locationWithRecords =>
                    divisionWithLocations.Value.Select(_ => _.InnerId).Contains(locationWithRecords.Key!.InnerId)
                    || divisionWithLocations.Key.InnerId == locationWithRecords.Key!.InnerId
                    );

                // если запрос с группировкой(суммой всех локаций) дивизиона
                if (request.LocationType == LocationType.Division)
                {

                    resultItems.Add(new FullnessBasesByLocationsParamOutput(
                        divisionWithLocations.Key.InnerId,
                        divisionWithLocations.Key.Payload.Title,
                        locationsWithRecords.SelectMany(_ => _).GroupBy(gType =>
                           gType.Payload.Type)
                         .Select(gTypeValues =>
                         new FullnessBasesUnitOutput(
                             FullnessBasesType.GetFullnessBasesType(gTypeValues.Key),
                             gTypeValues.Sum(r => r.Payload.Value))
                             ).ToList()
                        ));
                }
                else
                {
                    foreach (var locationWithRecords in locationsWithRecords)
                    {
                        resultItems.Add(new FullnessBasesByLocationsParamOutput(
                        locationWithRecords.Key!.InnerId,
                        locationWithRecords.Key.Payload.Title,
                        locationWithRecords.GroupBy(gType =>
                           gType.Payload.Type)
                         .Select(gTypeValues =>
                         new FullnessBasesUnitOutput(
                             FullnessBasesType.GetFullnessBasesType(gTypeValues.Key),
                             gTypeValues.Sum(r => r.Payload.Value))
                             ).ToList()
                        ));
                    }
                }
            }

            return (_validationResult, new FullnessBasesByLocationsOutput(resultItems.DistinctBy(_ => _.LocationId).ToList()));

        }

    }
}
