﻿namespace Supply.Dashboards.Shared.ViewModels.Charts.CargoGroupByPeriods
{
    public sealed class CargoGroupByPeriodsResponseParamViewModel
    {
        public string? Period { get; set; }

        public CargoGroupByPeriodsResponseUnitViewModel? FactUnit { get; set; }
        public CargoGroupByPeriodsResponseUnitViewModel? PlanUnit { get; set; }
        public CargoGroupByPeriodsResponseUnitViewModel? AdjustedPlanUnit { get; set; }
        public CargoGroupByPeriodsResponseUnitViewModel? DailyPlanUnit { get; set; }
    }
}
