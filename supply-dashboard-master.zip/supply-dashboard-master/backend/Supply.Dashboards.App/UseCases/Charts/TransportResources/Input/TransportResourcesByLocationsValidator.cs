﻿using FluentValidation;

namespace Supply.Dashboards.App.UseCases.Charts.TransportResources.Input
{
    public sealed class TransportResourcesByLocationsValidator
        : AbstractValidator<TransportResourcesByLocationsQuery>
    {
        public TransportResourcesByLocationsValidator()
        {
            ValidateLocationType();
            ValidateStartPeriod();
            ValidateEndPeriod();
            ValidateCustomersIds();
            ValidateLocationsIds();
        }

        private void ValidateLocationType() =>
            RuleFor(_ => _.LocationType);
        private void ValidateStartPeriod() =>
            RuleFor(_ => _.StartPeriod)
                .NotEmpty();

        private void ValidateEndPeriod() =>
            RuleFor(_ => _.EndPeriod)
                .NotEmpty();

        private void ValidateCustomersIds() =>
            RuleForEach(_ => _.CustomersIds);

        private void ValidateLocationsIds() =>
            RuleForEach(_ => _.LocationsIds);
    }
}
