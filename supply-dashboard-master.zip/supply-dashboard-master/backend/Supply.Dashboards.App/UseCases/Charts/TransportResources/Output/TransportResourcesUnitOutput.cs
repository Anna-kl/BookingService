﻿using Supply.Dashboards.App.UseCases.Charts.TransportResources.Types;

namespace Supply.Dashboards.App.UseCases.Charts.TransportResources.Output
{
    public sealed class TransportResourcesUnitOutput
    {
        public TransportResourcesUnitOutput(
            TransportResourcesType type,
            double value)
        {
            Type = type;
            Value = value;
        }

        public TransportResourcesType Type { get; }
        public double Value { get; }
    }
}
