﻿using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Charts.ExpenditureByLocations
{
    public sealed class ExpenditureByLocationsResponseViewModel
    {
        public List<ExpenditureByLocationsResponseParamViewModel>? Locations { get; set; }
    }
}
