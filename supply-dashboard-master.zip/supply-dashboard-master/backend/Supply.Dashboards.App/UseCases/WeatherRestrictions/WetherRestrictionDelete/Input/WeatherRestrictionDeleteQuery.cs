﻿using FluentValidation.Results;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.WeatherRestrictions.WeatherRestrictionDelete.Input
{
    public sealed class WeatherRestrictionDeleteQuery : IRequest<(ValidationResult validationResult, bool result)>
    {
        public WeatherRestrictionDeleteQuery(
            Guid id)
        {
            Id = id;

            ValidationResult = new WeatherRestrictionDeleteValidator()
                .Validate(this);
        }

        public Guid Id { get; }

        public ValidationResult ValidationResult { get; }


    }
}
