﻿using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Charts.CargoGroupByPeriods
{
    public sealed class CargoGroupByPeriodsResponseViewModel
    {
        public List<CargoGroupByPeriodsResponseParamViewModel>? Periods { get; set; }
    }
}
