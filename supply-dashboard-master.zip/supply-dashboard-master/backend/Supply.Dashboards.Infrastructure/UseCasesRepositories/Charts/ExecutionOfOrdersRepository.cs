﻿using Common.Extensions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Supply.Dashboards.App.UseCases.Charts.ExecutionOfOrders;
using Supply.Dashboards.Domain.AggregatesModel.Bids;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;
using Supply.Dashboards.Domain.AggregatesModel.ValueRecords;
using Supply.Dashboards.Domain.Types;
using Supply.Dashboards.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.Infrastructure.UseCasesRepositories.Charts
{
    public class ExecutionOfOrdersRepository : IExecutionOfOrdersChart
    {
        private readonly ILogger<CargoGroupByLocationsRepository> _logger;
        private readonly DashboardsContext _dashboardsContext;

        public ExecutionOfOrdersRepository(
            ILogger<CargoGroupByLocationsRepository> logger,
            DashboardsContext dashboardsContext)
        {
            _logger = logger;
            _dashboardsContext = dashboardsContext;
        }

        #region customers

        public async Task<IEnumerable<Guid>> GetCustomersExistingIds(
            List<StatusType> statuses,
            List<Guid> ids,
            CancellationToken cancellationToken) =>
            await _dashboardsContext
                .Customers
                .AsNoTracking()
                .Where(_ => statuses.Contains(_.Status))
                .Where(_ => ids.Contains(_.InnerId))
                .Select(_ => _.InnerId)
                .ToListAsync(cancellationToken);

        public async Task<IEnumerable<Customer>> GetCustomers(
            List<StatusType> statuses,
            CancellationToken cancellationToken) =>
            await _dashboardsContext
                .Customers
                .AsNoTracking()
                .Where(_ => statuses.Contains(_.Status))
                .ToListAsync(cancellationToken);

        public async Task<IEnumerable<CustomerEdge>> GetCustomersEdges(
            List<Guid> ids,
            CancellationToken cancellationToken) =>
            await _dashboardsContext
                .CustomersEdges
                .AsNoTracking()
                .Where(_ => ids.Contains(_.SourceInnerId))
                .Where(_ => ids.Contains(_.DestinationInnerId))
                .ToListAsync(cancellationToken);

        #endregion

        #region locations

        public async Task<IEnumerable<Guid>> GetLocationsExistingIds(
            List<StatusType> statuses,
            List<Guid> ids,
            CancellationToken cancellationToken) =>
            await _dashboardsContext
                .Locations
                .AsNoTracking()
                .Where(_ => statuses.Contains(_.Status))
                .Where(_ => ids.Contains(_.InnerId))
                .Select(_ => _.InnerId)
                .ToListAsync(cancellationToken);

        public async Task<IEnumerable<Location>> GetLocations(
            List<StatusType> statuses,
            CancellationToken cancellationToken) =>
            await _dashboardsContext
                .Locations
                .AsNoTracking()
                .Where(_ => statuses.Contains(_.Status))
                .ToListAsync(cancellationToken);

        public async Task<IEnumerable<LocationEdge>> GetLocationsEdges(
            List<Guid> ids,
            CancellationToken cancellationToken) =>
            await _dashboardsContext
                .LocationEdges
                .AsNoTracking()
                .Where(_ => ids.Contains(_.SourceInnerId))
                .Where(_ => ids.Contains(_.DestinationInnerId))
                .ToListAsync(cancellationToken);

        #endregion

        #region mtr types

        public async Task<IEnumerable<Guid>> GetMtrTypesExistingIds(
            List<StatusType> statuses,
            List<Guid> ids, CancellationToken cancellationToken) =>
            await _dashboardsContext
                .MtrTypes
                .AsNoTracking()
                .Where(_ => statuses.Contains(_.Status))
                .Where(_ => ids.Contains(_.InnerId))
                .Select(_ => _.InnerId)
                .ToListAsync(cancellationToken);

        public async Task<IEnumerable<MtrType>> GetMtrTypes(
            List<StatusType> statuses,
            CancellationToken cancellationToken) =>
            await _dashboardsContext
                .MtrTypes
                .AsNoTracking()
                .Where(_ => statuses.Contains(_.Status))
                .ToListAsync(cancellationToken);


        public async Task<IEnumerable<MtrTypeEdge>> GetMtrTypesEdges(
            List<Guid> ids,
            CancellationToken cancellationToken) =>
            await _dashboardsContext
                .MtrTypesEdges
                .AsNoTracking()
                .Where(_ => ids.Contains(_.SourceInnerId))
                .Where(_ => ids.Contains(_.DestinationInnerId))
                .ToListAsync(cancellationToken);

        #endregion

        public async Task<IEnumerable<Bid>> GetRecords(
            DateTime startPeriod,
            DateTime endPeriod,
            List<Location>? locations,
            List<Customer>? customers,
            CancellationToken cancellationToken)
        {
            var types = new List<BidType>
            {
                BidType.Plan,
                BidType.Forecast,
                BidType.TotalFact
            };

            var queryable = _dashboardsContext
                .Bids
                .AsNoTracking()
                .Include(record => record.Payload.Location)
                .Include(record => record.Payload.Customer)
                .Where(_ => types.Contains(_.Payload.Type));

            if (locations != null && locations.Any())
                queryable = queryable.Where(_ => _.Payload.Location == null || locations.Contains(_.Payload.Location!));

            if (customers != null && customers.Any())
                queryable = queryable.Where(_ => _.Payload.Customer == null || customers.Contains(_.Payload.Customer!));

            return await queryable
                .Where(incident => incident.Payload.DateTime >= startPeriod && incident.Payload.DateTime <= endPeriod)
                .ToListAsync(cancellationToken);
        }
    }
}
