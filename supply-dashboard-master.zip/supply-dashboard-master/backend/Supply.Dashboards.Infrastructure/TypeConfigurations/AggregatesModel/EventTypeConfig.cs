﻿using Common.SeedWork;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Supply.Dashboards.Domain.AggregatesModel;
using Supply.Dashboards.Domain.Types;

namespace Supply.Dashboards.Infrastructure.TypeConfigurations.AggregatesModel
{
    public sealed class EventTypeConfig : IEntityTypeConfiguration<Event>
    {
        public void Configure(EntityTypeBuilder<Event> builder)
        {
            builder
                .Property<int>("id")
                .ValueGeneratedOnAdd();
            builder.HasKey("id");

            builder
                .Property(_ => _.PayloadStatus)
                .HasConversion(
                    type => type.Id,
                    key => Enumeration.FromValue<StatusType>(key)!);
        }
    }
}
