﻿using Common.SeedWork;

using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;
using Supply.Dashboards.Domain.Types;

using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Domain.AggregatesModel.ValueRecords
{
    public sealed class ValueRecordPerDay : ValueObject
    {
        public ValueRecordPerDay(
            DateTime dateTime,
            ValueRecord record,
            int? priority)
        {
            InnerId = record.InnerId;
            Priority = priority;
            CreateAt = record.CreateAt;
            UpdateAt = record.UpdateAt;
            DateTime = dateTime;
            Type = record.Payload.Type;
            Customer = record.Payload.Customer;
            Location = record.Payload.Location;
            MtrType = record.Payload.MtrType;
            Value = record.Payload.Value;
            InputType = record.Payload.InputType;

        }

        public Guid InnerId { get; init; }
        public int? Priority { get; init; }

        public DateTime CreateAt { get; init; }
        public DateTime UpdateAt { get; init; }

        public DateTime DateTime { get; init; }

        public ValueRecordType Type { get; init; }

        public Customer? Customer { get; init; }
        public MtrType? MtrType { get; init; }
        public Location? Location { get; init; }

        public double? Value { get; private set; }

        public InputType InputType { get; init; }


        public void UpdateValue(double? value)
        {
            Value = value;
        }

        protected override IEnumerable<object> GetAtomicValues()
        {
            yield return InnerId;
            yield return Priority!;
            yield return CreateAt;
            yield return UpdateAt;
            yield return DateTime;
            yield return Type;
            yield return Customer!;
            yield return MtrType!;
            yield return Location!;
            yield return Value!;
            yield return InputType;
        }
    }
}
