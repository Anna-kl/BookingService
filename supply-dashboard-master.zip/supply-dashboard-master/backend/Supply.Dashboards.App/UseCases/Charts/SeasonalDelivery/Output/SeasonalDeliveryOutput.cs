﻿using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.Charts.SeasonalDelivery.Output
{
    public sealed class SeasonalDeliveryOutput
    {
        private readonly List<SeasonalDeliveryParamOutput> _locations;

        internal SeasonalDeliveryOutput(List<SeasonalDeliveryParamOutput> locations)
        {
            _locations = locations;
        }
        public IEnumerable<SeasonalDeliveryParamOutput> Locations =>
            _locations.OrderBy(_ => _.LocationTitle).ToList().AsReadOnly();

    }
}
