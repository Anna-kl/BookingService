﻿using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;

using System;
using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.MtrTypes.GetMtrTypeList.Output
{
    public sealed class GetMtrTypeListOutput
    {
        private readonly List<GetMtrTypeListItemOutput> _locations;

        public GetMtrTypeListOutput(IEnumerable<MtrType>? locations)
        {
            _locations = locations
                ?.Select(ToGetMtrTypesListItemOutput)
                .ToList() ?? new List<GetMtrTypeListItemOutput>();
        }

        public IEnumerable<GetMtrTypeListItemOutput> Items =>
            _locations.AsReadOnly();

        private static GetMtrTypeListItemOutput ToGetMtrTypesListItemOutput(MtrType location)
        {
            return new(
                location.InnerId,
                location.XMin,
                location.SourceEdges?.Select(_ => _.SourceInnerId).ToList() ?? new List<Guid>(),
                location.DestinationEdges?.Select(_ => _.DestinationInnerId).ToList() ?? new List<Guid>(),
                location.Status,
                location.Payload.Title,
                location.Payload.Description);
        }
    }
}
