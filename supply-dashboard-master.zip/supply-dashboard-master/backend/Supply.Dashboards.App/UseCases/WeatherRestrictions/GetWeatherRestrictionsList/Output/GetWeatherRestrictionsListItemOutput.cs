﻿using Supply.Dashboards.App.Types;
using Supply.Dashboards.Domain.Types;

using System;
using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.WeatherRestrictions.GetWeatherRestrictionsList.Output
{
    public sealed class GetWeatherRestrictionsListItemOutput
    {
        public GetWeatherRestrictionsListItemOutput(
            Guid id,
            DateTime dateTime,
            Guid? customerId,
            Guid locationId,
            string locationTitle,
            double locationLatitude,
            double locationLongitude,
            double temperature,
            double windSpeed,
            string? aktirovka)
        {
            Id = id;
            DateTime = dateTime;
            CustomerId = customerId;
            LocationId = locationId;
            LocationTitle = locationTitle;
            LocationLatitude = locationLatitude;
            LocationLongitude = locationLongitude;
            Temperature = temperature;
            WindSpeed = windSpeed;
            Aktirovka = aktirovka;

        }

        public Guid Id { get; }

        public DateTime DateTime { get; init; }
        public Guid? CustomerId { get; init; }
        public Guid LocationId { get; init; }
        public string LocationTitle { get; init; }
        public double LocationLatitude { get; init; }
        public double LocationLongitude { get; init; }
        public double Temperature { get; init; }
        public double WindSpeed { get; init; }
        public string? Aktirovka { get; init; }
    }
}
