﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Supply.Dashboards.Domain.AggregatesModel.ContextUserSettings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supply.Dashboards.Infrastructure.TypeConfigurations.AggregatesModel.ContextUserSettingTypeConfig
{
    public sealed class ContextUserSettingTypeConfig : IEntityTypeConfiguration<ContextUserSetting>
    {
        public void Configure(EntityTypeBuilder<ContextUserSetting> builder)
        {
            builder.ToTable("context_user_settings");

            builder.HasKey(_ => new { _.ContextId, _.UserId });


        }
    }
}
