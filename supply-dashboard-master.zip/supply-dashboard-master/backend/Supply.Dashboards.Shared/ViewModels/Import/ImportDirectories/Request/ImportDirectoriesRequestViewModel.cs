﻿using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Import.ImportDirectories.Request
{
    public sealed class ImportDirectoriesRequestViewModel
    {
        public List<ImportDirectoriesCustomerRequestViewModel>? Customers { get; set; }
        public List<ImportDirectoriesEdgeRequestViewModel>? CustomersEdges { get; set; }
        public List<ImportDirectoriesLocationRequestViewModel>? Locations { get; set; }
        public List<ImportDirectoriesEdgeRequestViewModel>? LocationsEdges { get; set; }
        public List<ImportDirectoriesMtrTypeRequestViewModel>? MtrTypes { get; set; }

        // TODO разобраться
        public List<ImportDirectoriesEdgeRequestViewModel>? MtrTypesEdges { get; set; }
    }
}
