<template>
  <DxTreeList
    ref="directoryEdgesEditorTreeList"
    :data-source="directoryEdgesEditTreeDataSource"
    :word-wrap-enabled="true"
    key-expr="id"
    parent-id-expr="parentId"
    has-items-expr="hasItems"
    :show-column-headers="false"
    root-value=""
    :focused-row-enabled="false"
    height="150px"
    @selection-changed="selectionChanged"
    :loadPanel="{enabled: false}"
  >
    <DxSelection :recursive="false" mode="multiple" />
    <DxRemoteOperations :filtering="true" :sorting="true" :grouping="true" />
    <DxColumn
      :allow-sorting="true"
      :min-width="200"
      data-field="id"
      caption="Направление"
      cell-template="editTemplate"
    >
    </DxColumn>
    <template #editTemplate="{ data: options }">
      <div :title="options.data.description">
        {{ options.data.title }}
      </div>
    </template>
  </DxTreeList>
</template>

<script lang='ts'>
import Vue from "vue";

import { DxCheckBox } from "devextreme-vue/check-box";
import DxSortable from "devextreme-vue/sortable";
import DataSource from "devextreme/data/data_source";
import { Component, Watch, Prop } from "vue-property-decorator";
import { dxTreeViewNode } from "devextreme/ui/tree_view";
import DxTextBox from "devextreme-vue/text-box";
import { DxPopup } from "devextreme-vue/popup";
import DxButton from "devextreme-vue/button";
import { DxNumberBox } from "devextreme-vue/number-box";
import notify from "devextreme/ui/notify";
import { InputDataState } from "@/store";
import { InputDataService } from "@/services/inputDataService";
import { Guid } from "@/helpers/guid";
import {
  DxTreeList,
  DxColumn,
  DxColumnChooser,
  DxHeaderFilter,
  DxSearchPanel,
  DxSelection,
  DxLookup,
  DxRemoteOperations,
} from "devextreme-vue/tree-list";
import TreeList, { dxTreeListNode } from "devextreme/ui/tree_list";
import {
  IDirectoryDataItem,
  IDirectoryTreeDataItem,
  IRelation,
  ITreeEditItem,
  ITreeListItemRelation,
} from "./types";

@Component({
  components: {
    DxTreeList,
    DxCheckBox,
    DxSortable,
    DxPopup,
    DxTextBox,
    DxButton,
    DxNumberBox,
    DxColumn,
    DxRemoteOperations,
    DxSelection,
  },
})
export default class DirectoryEdgesEditor extends Vue {
  @Prop({ type: Object, required: true })
  public editedItem!: IDirectoryDataItem;
  @Prop({ type: Function, required: true })
  public loadDataItemFromApi!: (dbId: string) => Promise<IDirectoryDataItem>;
  @Prop({ type: Function, required: true })
  public loadDataItemsFromApi!: (
    parentIds: any[],
    types: string[]
  ) => Promise<IDirectoryDataItem[]>;

  public directoryEdges: IRelation[] = [];
  private dataItemIdWithTreeItemIdRelations: ITreeListItemRelation[] = [];

  private mounted() {}

  private get directoryEdgesEditTreeDataSource() {
    return new DataSource({
      loadMode: "processed",
      key: "id",
      load: this.loadDirectoryEdgesEditTree,
      onChanged: (isLoading) => {
        this.reSelectParents();
      },
    });
  }

  private get directoryEdgesEditorTreeList() {
    return (this.$refs["directoryEdgesEditorTreeList"] as DxTreeList).instance;
  }

  private selectItems(parentDbIds: string[]) {
    const relations = this.dataItemIdWithTreeItemIdRelations.filter((s) =>
      parentDbIds.includes(s.dbId)
    );
    if (relations !== undefined) {
      const parentIds = relations.map((d) => d.id);
      const allNodes = this.directoryEdgesEditorTreeList!.selectRows(
        parentIds,
        true
      );
    }
  }

  public getDirectoryEdges() {
    return this.directoryEdges;
  }

  public reSelectParents() {
    this.selectItems(this.editedItem.parentIds);
    this.editedItem.parentIds.forEach((parentId) => {
      this.updateDirectoryEdges(parentId, false);
    });
  }

  private createTreeItem(
    dataItem: IDirectoryDataItem,
    parentId: string,
    id?: string
  ): IDirectoryTreeDataItem {
    return {
      id: id ? id : Guid.newGuid(),
      rowVersion: dataItem.rowVersion,
      title: dataItem.title ?? "",
      description: dataItem.description ?? "",
      hasItems:
        dataItem.childrenIds && dataItem.childrenIds.length > 0 ? true : false,
      parentId: parentId,
    };
  }

  public async loadDirectoryEdgesEditTree(loadOptions: any) {
    const parentIds: string[] = [];
    const types: string[] = [];
    const retData: ITreeEditItem[] = [];

    if (loadOptions.parentIds === undefined) {
      let filterItemId = "";
      if (typeof loadOptions.filter[0] === "object") {
        filterItemId = loadOptions.filter[0][2];
      } else {
        filterItemId = loadOptions.filter[2];
      }
      const dbId = this.getTreeItemDbIdForId(filterItemId);
      const dataItem = await this.loadDataItemFromApi(dbId!);
      if (dataItem !== undefined) {
        const rel = this.getTreeItemRelation(filterItemId);

        retData.push(
          this.createTreeItem(
            dataItem!,
            rel.parentId,
            this.getTreeItemIdForDbId(dataItem.id, rel.parentId, dataItem.title)
          )
        );
      }
    } else {
      parentIds.push(...loadOptions.parentIds);
    }

    if (parentIds.length > 0) {
      const parentDbIds: any[] = [];
      parentIds.forEach((parentId) => {
        parentDbIds.push(
          parentId === "" ? null : this.getTreeItemDbIdForId(parentId)
        );
      });

      const dataItems = await this.loadDataItemsFromApi(parentDbIds, []);

      parentIds.forEach((parentId) => {
        if (dataItems && dataItems.length > 0) {
          dataItems.forEach((dataItem) => {
            const parentDbId =
              parentId === "" ? "" : this.getTreeItemDbIdForId(parentId);

            if (
              dataItem.parentIds?.includes(parentDbId) ||
              (dataItem.parentIds.length === 0 && parentId === "")
            ) {
              retData.push(
                this.createTreeItem(
                  dataItem,
                  parentId,
                  this.getTreeItemIdForDbId(
                    dataItem.id,
                    parentId,
                    dataItem.title
                  )
                )
              );
            }
          });
        }
      });
    }

    return retData;
  }

  private selectionChanged(e: any) {
    const selectedKeys: string[] = e.currentSelectedRowKeys;
    const deSelectedKeys: string[] = e.currentDeselectedRowKeys;

    if (deSelectedKeys !== undefined) {
      deSelectedKeys.forEach((deSelectedKey) => {
        const data = this.directoryEdgesEditorTreeList?.getNodeByKey(
          deSelectedKey
        ).data;
        this.updateDirectoryEdges(data.id, true);
      });
    }

    if (selectedKeys !== undefined) {
      selectedKeys.forEach((selectedKey) => {
        const data = this.directoryEdgesEditorTreeList?.getNodeByKey(
          selectedKey
        ).data;

        this.updateDirectoryEdges(data.id, false);
      });
    }
  }

  private updateDirectoryEdges(parentId: any, isObsolete: boolean) {
    const sourceId = this.getTreeItemDbIdForId(parentId);
    if (sourceId !== null) {
      const rel = {
        sourceId: sourceId,
        destinationId: this.editedItem.id,
        isObsolete: false,
      };

      const extRel = this.directoryEdges.find(
        (s) =>
          s.sourceId === rel.sourceId && s.destinationId === rel.destinationId
      );
      if (extRel !== undefined) {
        extRel.isObsolete = isObsolete;
      } else {
        this.directoryEdges.push(rel);
      }
    }
  }

  private updateTreeItemRelation(
    id: string,
    dbId: string,
    parentId: string,
    title: string
  ) {
    const item = this.dataItemIdWithTreeItemIdRelations.find(
      (s) => s.id === id
    );
    if (item === undefined) {
      this.dataItemIdWithTreeItemIdRelations.push({
        id: id,
        dbId: dbId,
        parentId: parentId,
        parentDbId: this.getTreeItemDbIdForId(parentId),
        title: title,
      });
    }
  }

  private getTreeItemRelation(id: string): any {
    return this.dataItemIdWithTreeItemIdRelations.find((s) => s.id === id);
  }

  private getTreeItemIdForDbId(
    dbId: string,
    parentId: string,
    title: string
  ): string {
    const relation = this.dataItemIdWithTreeItemIdRelations.find(
      (s) => s.dbId === dbId && s.parentId === parentId
    );
    if (relation) {
      return relation.id;
    } else {
      const newId = Guid.newGuid();
      this.updateTreeItemRelation(newId, dbId, parentId, title);
      return newId;
    }
  }

  private getTreeItemDbIdForId(id: string): string {
    const finedItem = this.dataItemIdWithTreeItemIdRelations.find(
      (s) => s.id === id
    );
    if (finedItem === undefined) {
      return "";
    } else {
      return finedItem!.dbId;
    }
  }

  private findNodeById(nodes: any, id: string) {
    for (var i = 0; i < nodes.length; i++) {
      if (nodes[i].itemData.id == id) {
        return nodes[i];
      }
      if (nodes[i].children) {
        const node: any = this.findNodeById(nodes[i].children, id);
        if (node != null) {
          return node;
        }
      }
    }
    return null;
  }
}
</script>