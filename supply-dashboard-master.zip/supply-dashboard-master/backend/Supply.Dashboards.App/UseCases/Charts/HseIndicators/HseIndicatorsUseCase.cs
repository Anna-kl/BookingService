﻿using FluentValidation.Results;

using MediatR;

using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.UseCases.Charts.HseIndicators.Input;
using Supply.Dashboards.App.UseCases.Charts.HseIndicators.Output;
using Supply.Dashboards.App.UseCases.Charts.HseIndicators.Types;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.Types;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Common.Extensions;

namespace Supply.Dashboards.App.UseCases.Charts.HseIndicators
{
    public sealed class HseIndicatorsUseCase
        : IRequestHandler<HseIndicatorsQuery, (ValidationResult validationResult, HseIndicatorsOutput? output)>
    {
        private readonly ILogger<HseIndicatorsUseCase> _logger;
        private readonly IMediator _mediator;
        private readonly IHseIndicators _hseIndicators;

        private List<Customer> _customers;
        private List<Location> _locations;
        private ValidationResult _validationResult;
        private readonly List<StatusType> _selectStatus;

        public HseIndicatorsUseCase(
            ILogger<HseIndicatorsUseCase> logger,
            IMediator mediator,
            IHseIndicators hseIndicators)
        {
            _logger = logger;
            _mediator = mediator;
            _hseIndicators = hseIndicators;

            _customers = new List<Customer>();
            _locations = new List<Location>();
            _validationResult = new ValidationResult();
            _selectStatus = new List<StatusType> { StatusType.Active };
        }

        public async Task<(ValidationResult validationResult, HseIndicatorsOutput? output)> Handle(
            HseIndicatorsQuery request,
            CancellationToken cancellationToken)
        {
            _validationResult = request.ValidationResult;

            // If there are validation errors, abort the method and return errors.
            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            await Customers(request, cancellationToken);
            await Locations(request, cancellationToken);

            // If there are validation errors, abort the method and return errors.
            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            var records = (await _hseIndicators.GetRecords(
                request.StartPeriod,
                request.EndPeriod,
                _locations,
                _customers,
                cancellationToken))
                .ToList();

            var lastIncidentTypes = request.LastIncidentTypes.Any()
                ? request.LastIncidentTypes
                : new List<HseIndicatorType>
                {
                    HseIndicatorType.Death,
                    HseIndicatorType.Disability,
                    HseIndicatorType.MedicalCare
                };

            var incidents = records
                .Where(_ => lastIncidentTypes.Contains(HseIndicatorType.GetHseIndicatorType(_.Payload.Type)))
                .OrderByDescending(_ => _.Payload.DateTime)
                .ToList();
            var lastIncident = incidents.FirstOrDefault();
            var daysWithoutIncident = lastIncident == null
                ? (DateTime.Now - request.StartPeriod).Days
                : (DateTime.Now - lastIncident.Payload.DateTime).Days;

            var death = (
                type: HseIncidentType.Death,
                count: records.Count(_ => _.Payload.Type == HseIncidentType.Death));
            var disability = (
                type: HseIncidentType.Disability,
                count: records.Count(_ => _.Payload.Type == HseIncidentType.Disability) + death.count);
            var medicalCare = (
                type: HseIncidentType.MedicalCare,
                count: records.Count(_ => _.Payload.Type == HseIncidentType.MedicalCare) + disability.count);
            var nearMiss = (
                type: HseIncidentType.NearMiss,
                count: records.Count(_ => _.Payload.Type == HseIncidentType.NearMiss) + medicalCare.count);
            var dangerWarning = (
                type: HseIncidentType.DangerWarning,
                count: records.Count(_ => _.Payload.Type == HseIncidentType.DangerWarning) + nearMiss.count + medicalCare.count + disability.count + death.count);

            var units = new Dictionary<HseIncidentType, int>
            {
                {death.type, death.count},
                {disability.type, disability.count},
                {medicalCare.type, medicalCare.count},
                {nearMiss.type, nearMiss.count},
                {dangerWarning.type, dangerWarning.count}
            };

            var result = new HseIndicatorsOutput(
                daysWithoutIncident,
                lastIncident == null
                    ? null
                    : new HseIndicatorIncidentOutput(
                        lastIncident.Payload.DateTime,
                        HseIndicatorType.GetHseIndicatorType(lastIncident.Payload.Type),
                        lastIncident.Payload.Text),
                units
                    .Select(_ => new HseIndicatorsUnitOutput(
                        HseIndicatorType.GetHseIndicatorType(_.Key),
                        _.Value))
                    .ToList());

            return (_validationResult, result);
        }

        private async Task Customers(
            HseIndicatorsQuery query,
            CancellationToken cancellationToken)
        {
            var existingIdsFromFilter = (await _hseIndicators.GetCustomersExistingIds(
                _selectStatus,
                query.CustomersIds.ToList(),
                cancellationToken)).ToList();
            var nonExistentIdsFromFilter = query
                .CustomersIds
                .Except(existingIdsFromFilter)
                .ToList();

            if (nonExistentIdsFromFilter.Any())
            {
                foreach (var id in nonExistentIdsFromFilter)
                    _validationResult.Errors.Add(new ValidationFailure(
                        "CustomerId",
                        $"{nameof(Customer)} with id \"{id}\" is not exist."));

                return;
            }

            var allCustomers = (await _hseIndicators.GetCustomers(
                _selectStatus,
                cancellationToken))
                .Where(_ => _.SourceEdges == null || !_.SourceEdges.Any())
                .SelectMany(_ => _.DepthFirstSearch(
                    edge => edge.Destination,
                    customer => customer.DestinationEdges,
                    _ => { }))
                .ToList();
            var allCustomersIds = allCustomers
                .Select(_ => _.InnerId)
                .ToList();
            var allCustomersEdges = (await _hseIndicators.GetCustomersEdges(
                allCustomersIds,
                cancellationToken)).ToList();

            foreach (var customer in allCustomers)
            {
                var sourceIds = allCustomersEdges
                    .Where(_ => _.DestinationId == customer.Id)
                    .Select(_ => _.SourceId);
                var sourcesVertex = allCustomers.Where(_ => sourceIds.Contains(_.Id));
                customer.AddSourceEdges(sourcesVertex.Select(_ => new CustomerEdge(_, customer)));

                var destinationIds = allCustomersEdges
                    .Where(_ => _.SourceId == customer.Id)
                    .Select(_ => _.DestinationId);
                var destinationVertex = allCustomers.Where(_ => destinationIds.Contains(_.Id));
                customer.AddDestinationEdges(destinationVertex.Select(_ => new CustomerEdge(customer, _)));
            }

            if (!query.CustomersIds.Any())
            {
                _customers = allCustomers;
                return;
            }

            var customersFromFilter = new List<Customer>();

            foreach (var customer in allCustomers)
            {
                customer.DepthFirstSearch(
                    _ => _.Destination,
                    _ => _.DestinationEdges!,
                    _ =>
                    {
                        if (existingIdsFromFilter.Contains(_.InnerId))
                            customersFromFilter.Add(_);
                    });
            }

            var customers = new List<Customer>();

            foreach (var customer in customersFromFilter)
            {
                customers.AddRange(customer.DepthFirstSearch(
                    _ => _.Destination,
                    _ => _.DestinationEdges!,
                    _ => { }));
            }

            if (!customers.Any())
                customers = allCustomers;

            _customers = customers
                .Distinct()
                .ToList();
        }

        private async Task Locations(
            HseIndicatorsQuery query,
           CancellationToken cancellationToken)
        {
            var existingIdsFromFilter = (await _hseIndicators.GetLocationsExistingIds(
                _selectStatus,
                query.LocationsIds.ToList(),
                cancellationToken)).ToList();
            var nonExistentIdsFromFilter = query
                .LocationsIds
                .Except(existingIdsFromFilter)
                .ToList();

            if (nonExistentIdsFromFilter.Any())
            {
                foreach (var id in nonExistentIdsFromFilter)
                    _validationResult.Errors.Add(new ValidationFailure(
                        "LocationId",
                        $"{nameof(Location)} with id \"{id}\" is not exist."));

                return;
            }

            var allLocations = (await _hseIndicators.GetLocations(
                _selectStatus,
                cancellationToken))
                .Where(_ => _.SourceEdges == null || !_.SourceEdges.Any())
                .SelectMany(_ => _.DepthFirstSearch(
                    edge => edge.Destination,
                    location => location.DestinationEdges,
                    _ => { }))
                .ToList();
            var allLocationsIds = allLocations
                .Select(_ => _.InnerId)
                .ToList();
            var allLocationsEdges = (await _hseIndicators.GetLocationsEdges(
                allLocationsIds,
                cancellationToken)).ToList();

            foreach (var location in allLocations)
            {
                var sourceIds = allLocationsEdges
                    .Where(_ => _.DestinationId == location.Id)
                    .Select(_ => _.SourceId);
                var sourcesVertex = allLocations.Where(_ => sourceIds.Contains(_.Id));
                location.AddSourceEdges(sourcesVertex.Select(_ => new LocationEdge(_, location)));

                var destinationIds = allLocationsEdges
                    .Where(_ => _.SourceId == location.Id)
                    .Select(_ => _.DestinationId);
                var destinationVertex = allLocations.Where(_ => destinationIds.Contains(_.Id));
                location.AddDestinationEdges(destinationVertex.Select(_ => new LocationEdge(location, _)));
            }

            if (!query.LocationsIds.Any())
            {
                _locations = allLocations;
                return;
            }

            var locationsFromFilter = new List<Location>();

            foreach (var location in allLocations)
            {
                location.DepthFirstSearch(
                    _ => _.Destination,
                    _ => _.DestinationEdges!,
                    _ =>
                    {
                        if (existingIdsFromFilter.Contains(_.InnerId))
                            locationsFromFilter.Add(_);
                    });
            }

            var locations = new List<Location>();

            foreach (var location in locationsFromFilter)
            {
                locations.AddRange(location.DepthFirstSearch(
                    _ => _.Destination,
                    _ => _.DestinationEdges!,
                    _ => { }));
            }

            if (!locations.Any())
                locations = allLocations;

            _locations = locations
                .Distinct()
                .ToList();
        }
    }
}
