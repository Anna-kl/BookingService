﻿using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.Charts.CargoGroupByPeriods.Output
{
    public sealed class CargoGroupByPeriodsOutput
    {
        private readonly List<CargoGroupByPeriodsParamOutput> _periods;

        internal CargoGroupByPeriodsOutput(List<CargoGroupByPeriodsParamOutput> periods)
        {
            _periods = periods;
        }

        public IEnumerable<CargoGroupByPeriodsParamOutput> Periods =>
            _periods.OrderBy(_ => _.Period).ToList().AsReadOnly();
    }
}
