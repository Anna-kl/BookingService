﻿using Microsoft.Extensions.DependencyInjection;

namespace Supply.Dashboards.App.Extensions
{
    public static class StartupAppExtensions
    {
        public static IServiceCollection AddStartupAppExtensions(
            this IServiceCollection services)
        {
            return services;
        }
    }
}
