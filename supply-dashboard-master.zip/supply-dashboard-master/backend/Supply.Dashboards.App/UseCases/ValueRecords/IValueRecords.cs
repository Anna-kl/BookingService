﻿using Supply.Dashboards.Domain.AggregatesModel.ValueRecords;
using Supply.Dashboards.Domain.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.ValueRecords
{
    public interface IValueRecords
    {
        IQueryable<ValueRecord> GetRecords(
            List<ValueRecordType> recordsTypes,
            LocationType? locationType,
            Guid? parentLocationId,
            List<Guid>? locationsIds,
            List<Guid>? customersIds,
            List<Guid>? mtrTypesIds,
            List<StatusType> statusTypes,
            CancellationToken cancellationToken);

        public Task<IEnumerable<ValueRecord>>
            GetRecordsWithDateFilter(
                List<ValueRecordType> recordsTypes,
                DateTime startPeriod,
                DateTime endPeriod,
                LocationType? locationType,
                Guid? parentLocationId,
                List<Guid>? locationsIds,
                List<Guid>? customersIds,
                List<Guid>? mtrTypesIds,
                List<StatusType> statusTypes,
                bool? includeSubvalues,
                bool? includeInsideDateValues,
                CancellationToken cancellationToken);

    }
}
