﻿using FluentValidation.Results;

using MediatR;

using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.Customers.GetCustomerList.Output;

using System;
using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.Customers.GetCustomerList.Input
{
    public sealed class GetCustomerListQuery
        : IRequest<(ValidationResult validationResult, GetCustomerListOutput? output)>
    {
        private readonly List<AppStatusType>? _statuses;
        private readonly List<Guid?>? _sourceIds;
        private readonly List<Guid>? _ids;
        private readonly List<AppCustomerType>? _types;

        public GetCustomerListQuery(
            IEnumerable<AppStatusType>? statuses,
            IEnumerable<Guid?>? sourceIds,
            IEnumerable<Guid>? ids,
            IEnumerable<AppCustomerType>? types)
        {
            _statuses = statuses?.ToList()
                        ?? new List<AppStatusType>();
            _sourceIds = sourceIds?.ToList();
            _ids = ids?.ToList();
            _types = types?.ToList();

            ValidationResult = new GetCustomerListValidator()
                .Validate(this);
        }

        public IEnumerable<AppStatusType> Statuses => _statuses!.AsReadOnly();
        public IEnumerable<Guid?>? SourceIds => _sourceIds?.AsReadOnly();
        public IEnumerable<Guid>? Ids => _ids?.AsReadOnly();
        public IEnumerable<AppCustomerType>? Types => _types?.AsReadOnly();

        public ValidationResult ValidationResult { get; }
    }
}
