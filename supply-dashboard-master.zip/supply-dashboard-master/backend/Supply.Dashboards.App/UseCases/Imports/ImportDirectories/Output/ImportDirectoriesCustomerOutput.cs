﻿using Supply.Dashboards.App.Types;

using System;

namespace Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Output
{
    public sealed class ImportDirectoriesCustomerOutput
    {
        public ImportDirectoriesCustomerOutput(
            Guid id,
            uint xMin,
            AppStatusType status,
            AppCustomerType type,
            string title,
            string? description)
        {
            Id = id;
            RowVersion = xMin;
            Status = status;
            Type = type;
            Title = title;
            Description = description;
        }

        public Guid Id { get; }
        public uint RowVersion { get; }

        public AppStatusType Status { get; }
        public AppCustomerType Type { get; }
        public string Title { get; set; }
        public string? Description { get; set; }
    }
}
