﻿using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Charts.ArrivalByLocations
{
    public sealed class ArrivalByLocationsResponseParamViewModel
    {
        public Guid LocationId { get; set; }
        public string? LocationTitle { get; set; }

        public List<ArrivalByLocationsResponseUnitViewModel>? Units { get; set; }
    }
}
