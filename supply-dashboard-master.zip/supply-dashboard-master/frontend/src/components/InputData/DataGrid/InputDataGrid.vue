<template>
  <div class="dataTable" v-if="!isLoading">
    <DxDataGrid
      ref="inputDataGrid"
      v-if="!isLoading"
      v-bind="tableConfig"
      style="min-height: 500px; width: 100%"
      @contentReady="onContentReady"
    />
  </div>
</template>

<script lang='ts'>
import Vue from "vue";

import { Component, Watch } from "vue-property-decorator";
import { InputDataState } from "@/store";
import { DxDataGrid, DxFormItem } from "devextreme-vue/data-grid";
import "devextreme-vue/text-area";
import { dxDataGridOptions } from "devextreme/ui/data_grid";
import { InputDataTypeEnum } from "../common/models";
import { CommonTableData } from "./CommonTableData";
import { WeatherRestrictionsTableData } from "./WeatherRestrictionsTableData";

@Component({
  components: {
    DxDataGrid,
    DxFormItem,
  },
})
export default class InputDataGrid extends Vue {
  private tableConfig!: dxDataGridOptions;
  private isLoading: boolean = true;

  private mounted(): void {
    this.loadData();
  }

  private get selectedLocations() {
    return InputDataState.selectedLocations;
  }

  private updateIsLoadingProperty() {
    this.$emit('update-is-loading', this.isLoading);
  }

  @Watch("selectedLocations")
  private onSelectedLocationsChanged() {
    this.updateView();
  }

  private get selectedCustomers() {
    return InputDataState.selectedCustomers;
  }

  @Watch("selectedCustomers")
  private onSlectedCustomersChanged() {
    this.updateView();
  }

  private get currentInputDataType() {
    return InputDataState.currentInputDataType;
  }

  @Watch("currentInputDataType")
  private onCurrentInputDataTypeChanged() {
    this.updateView();
  }

  private get selectedTimeSpans() {
    return InputDataState.selectedTimeSpans;
  }

  @Watch("selectedTimeSpans")
  private onSelectedTimeSpansChanged() {
    this.updateView();
  }

  private get selectedCommonTableDataTypes() {
    return InputDataState.selectedCommonTableDataTypes;
  }

  @Watch("selectedCommonTableDataTypes")
  private onSelectedCommonTableDataTypesChanged() {
    this.updateView();
  }

  private get selectedDate() {
    return InputDataState.selectedDate;
  }

  @Watch("selectedDate")
  private onSelectedDateChanged() {
    this.updateView();
  }

  private updateView() {
    this.loadData();
  }
  private async loadData() {
    this.isLoading = true;
    this.updateIsLoadingProperty();
    if (
      this.selectedLocations.length > 0 &&
      this.selectedCustomers.length > 0
    ) {
      switch (this.currentInputDataType!.id) {
        case InputDataTypeEnum.CommonTable:
          this.tableConfig = new CommonTableData(
            this.selectedDate,
            this.selectedLocations,
            this.selectedCustomers,
            this.selectedCommonTableDataTypes,
            this.selectedTimeSpans
          ).tableConfig;
          break;
        case InputDataTypeEnum.WeatherRestrictions:
          this.tableConfig = new WeatherRestrictionsTableData(
            this.selectedDate,
            this.selectedLocations,
            this.selectedCustomers
          ).tableConfig;
          break;

        default:
          break;
      }

      this.isLoading = false;
    }
  }

  private onContentReady(el: any) {
    this.updateIsLoadingProperty();
    let timerId: any;

    if (el.component.getCombinedFilter() !== undefined) {
      el.component.option("haveFilters", true);
    } else {
      el.component.option("haveFilters", false);
    }

    function getBoundingRect($headerContent: any) {
      const $transparentCell = $headerContent
        .parent()
        .find(".dx-header-row > td.dx-pointer-events-none");
      const boundingElement = $transparentCell.length
        ? $transparentCell.get(0)
        : $headerContent.get(0);
      return boundingElement.getBoundingClientRect();
    }
    function scrollTo(grid: any, diff: any) {
      const scrollable = grid.getScrollable();
      let scrollLeft = scrollable.scrollLeft();
      const scrollWidth = scrollable.scrollWidth();
      const $separator = grid.element().find(".dx-datagrid-columns-separator");
      const step = diff === 0 ? -10 : 10;

      $separator.addClass("dx-datagrid-columns-separator-transparent");

      timerId = setInterval(() => {
        const dragHeader = document.getElementsByClassName(
          "s-controls"
        )[0] as HTMLElement;

        if (
          scrollWidth - scrollLeft === diff ||
          !(dragHeader.offsetWidth > 0 && dragHeader.offsetHeight > 0)
        ) {
          clearInterval(timerId);
        } else {
          scrollLeft += step;

          const dragOptions = grid.getView("draggingHeaderView")._dragOptions;

          if (dragOptions) {
            dragOptions.pointsByTarget = null;
          }

          grid.getController("draggingHeader").hideSeparators();

          scrollable.scrollTo({ left: scrollLeft });
        }
      });
    }
    function dragHandler(e: any) {
      const grid = e.data.grid;
      const $headerContent = grid
        .element()
        .find(
          ".dx-datagrid-headers > .dx-datagrid-content:not(.dx-datagrid-content-fixed)"
        );
      const headerContentWidth = $headerContent.width();
      const boundingClientRect = getBoundingRect($headerContent);

      clearInterval(timerId);

      if (e.pageX > boundingClientRect.right) {
        scrollTo(grid, headerContentWidth);
      } else if (e.pageX < boundingClientRect.left) {
        scrollTo(grid, 0);
      }
    }
  }
}
</script>

<style>
.dataTable {
  height: 100%;
}

.vert-text {
  writing-mode: vertical-rl;
  transform: rotate(180deg);
  text-align: left;
  height: 180px;
}
</style>