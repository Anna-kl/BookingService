﻿using FluentValidation;

using Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Input;

namespace Supply.Dashboards.App.UseCases.Imports.ImportDirectories.Validator
{
    public sealed class ImportDirectoriesLocationValidator
        : AbstractValidator<ImportDirectoriesLocationInput>
    {
        public ImportDirectoriesLocationValidator()
        {
            ValidateId();
            ValidateType();
            ValidateTitle();
            ValidateDescription();
            ValidateLongitude();
            ValidateLatitude();
            ValidateDiameter();
        }

        private void ValidateId() =>
            RuleFor(_ => _.Id)
                .Must(_ => _ != default); // TODO add description

        private void ValidateType() =>
            RuleFor(_ => _.Type)
                .NotEmpty()
                .Must(_ => _.Id != 0); // TODO add description

        private void ValidateTitle() =>
            RuleFor(_ => _.Title)
                .NotEmpty();

        private void ValidateDescription() =>
            RuleFor(_ => _.Description);

        private void ValidateLongitude() =>
            RuleFor(_ => _.Longitude)
                .Must(_ => _ == null || _.Value > -180.0 || _.Value < 180.0)
                .WithMessage("Longitude is not a valid.");

        private void ValidateLatitude() =>
            RuleFor(_ => _.Latitude)
                .Must(_ => _ == null || _.Value > -90.0 || _.Value < 90.0)
                .WithMessage("Latitude is not a valid.");

        private void ValidateDiameter() =>
            RuleFor(_ => _.Diameter)
                .Must(_ => _ == null || _!.Value > 0)
                .WithMessage("Diameter must be null or more zero.");
    }
}
