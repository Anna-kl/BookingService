﻿using Common.SeedWork;

using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;
using Supply.Dashboards.Domain.Exceptions;
using Supply.Dashboards.Domain.Types;

using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Domain.AggregatesModel.ValueRecords
{
    public sealed class ValueRecordPayload : ValueObject
    {
        public ValueRecordPayload(
            DateTime startPeriod,
            DateTime endPeriod,
            ValueRecordType type,
            Customer? customer,
            Location? location,
            MtrType? mtrType,
            double value,
            InputType inputType)
        {
            if (startPeriod == default)
                throw new DomainException($"{nameof(startPeriod)} can't be a default value");

            if (endPeriod == default)
                throw new DomainException($"{nameof(endPeriod)} can't be a default value");

            StartPeriod = startPeriod;
            EndPeriod = endPeriod;
            Type = type
                   ?? throw new DomainException($"{nameof(type)} can't be null.");
            Customer = customer;
            Location = location;
            MtrType = mtrType;
            Value = value;
            InputType = inputType;
        }

#pragma warning disable 8618
        // ReSharper disable once UnusedMember.Local
        private ValueRecordPayload()
        {
        }
#pragma warning restore 8618

        public DateTime StartPeriod { get; init; }
        public DateTime EndPeriod { get; init; }

        public ValueRecordType Type { get; init; }

        public Customer? Customer { get; init; }
        public Location? Location { get; init; }
        public MtrType? MtrType { get; init; }

        public double Value { get; init; }

        public InputType InputType { get; init; }

        protected override IEnumerable<object> GetAtomicValues()
        {
            yield return StartPeriod;
            yield return EndPeriod;
            yield return Type;
            yield return Customer!;
            yield return Location!;
            yield return MtrType!;
            yield return Value;
            yield return InputType;

        }
    }
}
