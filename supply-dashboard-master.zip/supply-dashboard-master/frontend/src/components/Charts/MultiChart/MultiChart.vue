<template>
  <DxChart
    class="chart-module"
    :data-source="dataSource"
    :customize-point="functions.customizePoint"
    :argument-axis="config.customizeArgumentAxis"
    @pointClick="functions.onPointClick"
  >
    <DxCommonSeriesSettings
      :argument-field="config.columns"
      :type="config.type"
      :hover-mode="settings.hoverMode"
      :selection-mode="settings.selectionMode"
    >
      <DxLabel
        :visible="label.visible"
        :backgroundColor="label.backgroundColor"
        :rotationAngle="label.rotationAngle"
      >
        <DxFormat :precision="label.formatPrecision" :type="label.formatType" />
        <DxFont :color="label.fontColor" />
      </DxLabel>
    </DxCommonSeriesSettings>
    <DxSeries
      v-for="seriesItem in series.filter((s) => s.value)"
      :key="seriesItem.id"
      :value-field="seriesItem.id"
      :name="seriesItem.name"
      :color="seriesItem.color"
    />
    <DxTitle
      v-if="config.titleText"
      :text="config.titleText"
      :horizontalAlignment="title.horizontalAlignment"
    >
      <DxSubtitle v-if="config.subtitleText" :text="config.subtitleText">
        <DxFont :color="subtitle.fontColor" />
      </DxSubtitle>
    </DxTitle>
    <DxLegend
      :vertical-alignment="legend.verticalAlignment"
      :horizontal-alignment="legend.horizontalAlignment"
    />
    <DxTooltip
      :enabled="tooltip.enabled"
      :customize-tooltip="functions.customizeTooltip"
    >
      <DxFormat
        :precision="tooltip.formatPrecision"
        :type="tooltip.formatType"
      />
    </DxTooltip>
  </DxChart>
</template>
<script lang='ts'>
import Vue from "vue";
import {
  DxChart,
  DxSeries,
  DxCommonSeriesSettings,
  DxLabel,
  DxFormat,
  DxLegend,
  DxTooltip,
  DxTitle,
  DxSubtitle,
  DxFont,
} from "devextreme-vue/chart";
import IMultiChartConfig from "@/dto/IMultiChartConfig";
import defaultMultichartConfig from "./defaultMultichartConfig";
import { Component, Prop } from "vue-property-decorator";
@Component({
  components: {
    DxChart,
    DxSeries,
    DxCommonSeriesSettings,
    DxLabel,
    DxFormat,
    DxLegend,
    DxTooltip,
    DxTitle,
    DxSubtitle,
    DxFont,
  },
})
export default class MultiChartComponent extends Vue {
  @Prop({ type: Object, required: false })
  public dynamicConfig!: IMultiChartConfig;

  private get config(): Partial<IMultiChartConfig> {
    return Object.assign(defaultMultichartConfig(), this.dynamicConfig);
  }

  // Config part getters
  private get dataSource() {
    return this.config.dataSource;
  }

  private get functions() {
    return this.config.functions;
  }

  private get label() {
    return this.config.label;
  }

  private get legend() {
    return this.config.legend;
  }

  private get series() {
    return this.config.series;
  }

  private get settings() {
    return this.config.settings;
  }

  private get subtitle() {
    return this.config.title!.subtitle;
  }

  private get title() {
    return this.config.title;
  }

  private get tooltip() {
    return this.config.tooltip;
  }
}
</script>