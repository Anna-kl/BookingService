﻿using System;
using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.Charts.CargoGroupByLocations.Output
{
    public sealed class CargoGroupByLocationsParamOutput
    {

        private readonly List<CargoGroupByLocationsUnitOutput> _units;

        internal CargoGroupByLocationsParamOutput(
            Guid locationId,
            string locationTitle,
            List<CargoGroupByLocationsUnitOutput>? units)
        {
            LocationId = locationId;
            LocationTitle = locationTitle;
            _units = units ?? new List<CargoGroupByLocationsUnitOutput>();
        }

        public Guid LocationId { get; }
        public string LocationTitle { get; }

        public IEnumerable<CargoGroupByLocationsUnitOutput>? Units =>
            _units.AsReadOnly();

    }
}

