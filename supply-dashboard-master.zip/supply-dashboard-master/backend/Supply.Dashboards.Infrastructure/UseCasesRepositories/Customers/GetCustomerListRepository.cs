﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.UseCases.Customers.GetCustomerList;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.Types;
using Supply.Dashboards.Infrastructure.Data;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.Infrastructure.UseCasesRepositories.Customers
{
    public sealed class GetCustomerListRepository : IGetCustomerList
    {
        private readonly ILogger<GetCustomerListRepository> _logger;
        private readonly DashboardsContext _dashboardsContext;

        public GetCustomerListRepository(
            ILogger<GetCustomerListRepository> logger,
            DashboardsContext dashboardsContext)
        {
            _logger = logger;
            _dashboardsContext = dashboardsContext;
        }

        public async Task<IEnumerable<Customer>> Get(
            List<StatusType> statuses,
            List<Customer>? sourceList,
            List<Guid>? ids,
            List<CustomerType>? types,
            bool includeRoot,
            CancellationToken cancellationToken)
        {
            var queryable = _dashboardsContext
                .Customers
                .Include(_ => _.SourceEdges!.Where(edge => edge.Source.Status == StatusType.Active))
                .ThenInclude(_ => _.Source)
                .Include(_ => _.DestinationEdges!.Where(edge => edge.Destination.Status == StatusType.Active))
                .ThenInclude(_ => _.Destination)
                .Where(_ => _.Status == StatusType.Active);

            queryable = includeRoot switch
            {
                true => queryable.Where(_ => sourceList != null && sourceList.Any()
                    ? _.SourceEdges!.Any(edge => sourceList.Select(location => location.Id).Contains(edge.SourceId)) |
                      !_.SourceEdges!.Any()
                    : !_.SourceEdges!.Any()),
                _ => (sourceList != null && sourceList.Any())
                    ? queryable.Where(_ =>
                        _.SourceEdges!.Any(edge => sourceList.Select(location => location.Id).Contains(edge.SourceId)))
                    : queryable
            };

            if (ids != null && ids.Any())
                queryable = queryable.Where(_ => ids.Contains(_.InnerId));

            if (types != null && types.Any())
                queryable = queryable.Where(_ => types.Contains(_.Payload.Type));

            return (await queryable.ToListAsync(cancellationToken))
                .Distinct()
                .ToList()
                .AsReadOnly();
        }

        public async Task<IEnumerable<Customer>> GetByIds(
            List<StatusType> statuses,
            List<Guid> ids,
            CancellationToken cancellationToken) =>
            (await _dashboardsContext
                .Customers
                .Where(_ => ids.Contains(_.InnerId))
                .Where(_ => statuses.Contains(_.Status))
                .ToListAsync(cancellationToken)).AsReadOnly();
    }
}
