<template>
  <div class="module-inner-container">
    <DxToolbar>
      <DxItem location="after">
        <template #default>
          <DxDateBox
            width="150px"
            hint="Выбор даты данных"
            type="date"
            picker-type="calendar"
            displayFormat="dd.MM.yyyy"
            :on-value-changed="dateChanged"
            :value.sync="curDate"
          />
        </template>
      </DxItem>
    </DxToolbar>
    <div class="list-header">Погодные ограничения</div>
    <DxList
      class="weather-module"
      :data-source="dataSource"
      noDataText="Ограничений нет"
      selection-mode="none"
    >
      <template #item="{ data: item }">
        <div style="restriction-item">
          <div>
            <b>Направление: </b>
            <a
              :href="`https://www.windy.com/?${item.locationLongitude},${item.locationLatitude},11`"
              target="_blank"
              >{{ item.locationTitle }}</a
            >
          </div>
          <div><b>Температура: </b> {{ item.temperature }} &#176;C</div>
          <div><b>Скорость ветра: </b> {{ item.windSpeed }} м/с</div>
          <div><b>Актировка: </b>{{ item.aktirovka }}</div>
        </div>
      </template>
    </DxList>
  </div>
</template>

<script lang='ts'>
import { Component, Prop, Vue } from "vue-property-decorator";
import config from "@/config";
import notify from "devextreme/ui/notify";
import { IModuleConfig, IModuleSeries } from "@/dto/Dashboards";

import { ChartDataService } from "@/services/chartDataService";
import DxButton from "devextreme-vue/button";
import DxToolbar, { DxItem } from "devextreme-vue/toolbar";
import { roundDate, utcFromLocalDate, yesterdayDate } from "@/helpers";
import DxDateBox from "devextreme-vue/date-box";
import DxList from "devextreme-vue/list";
import {
  IWeatherRestrictionsRequest,
  IWeatherRestrictionsResponse,
  IWeatherRestrictionsWorkboardData,
} from "@/dto/WeatherRestrictionsData";
import { IFullnessBasesDataRequest } from "@/dto/FullnessBasesData";

@Component({
  components: {
    DxButton,
    DxToolbar,
    DxItem,
    DxDateBox,
    DxList,
  },
})
export default class WeatherRestrictionsList extends Vue {
  @Prop({ type: Object, required: false }) public config!: IModuleConfig;
  @Prop({ type: Array, required: false }) public series!: IModuleSeries[];

  private url: string =
    config.remoteHost + "/api/dashboards/weather-restrictions";
  private dataSource: IWeatherRestrictionsWorkboardData[] = [];
  private curDate: Date = yesterdayDate();
  private _chartDataService!: ChartDataService;

  public update() {
    this.getData(this.curDate);
  }

  private created() {
    this._chartDataService = new ChartDataService();
  }

  private mounted(): void {
    this.getData(this.curDate);
  }

  private dateChanged(args: any) {
    this.curDate = args.value;
    this.update();
  }

  private async getData(curDate: Date) {
    this.dataSource = [];
    const selectedDay = utcFromLocalDate(curDate);
    const request: IWeatherRestrictionsRequest = {
      startDate: selectedDay,
      endDate: selectedDay,
      locationIds: this.config.locationsIds
        ?.filter((f) => f.selected)
        .map<string>((s) => s.dbId),
      customerIds: this.config.customersIds,
    };
    await this._chartDataService
      .getWeatherRestrictions(this.url, request)
      .then((data) => {
        if (data) {
          this.loadToDataSource(data);
        }
      })
      .catch((error: any) => {
        notify(error, "error", 2000);
        throw new Error(error);
      });
  }

  private loadToDataSource(data: IWeatherRestrictionsResponse) {
    const retData: IWeatherRestrictionsWorkboardData[] = [];
    if (data !== undefined) {
      data.items.forEach((item) => {
        retData.push({
          id: item.id,
          aktirovka: item.aktirovka,
          locationTitle: item.locationTitle,
          locationLatitude: item.locationLatitude,
          locationLongitude: item.locationLongitude,
          temperature: item.temperature,
          windSpeed: item.windSpeed,
        });
      });
    }

    this.dataSource.push(...retData);
  }

  private getLink(item: IWeatherRestrictionsWorkboardData): string {
    return `https://www.windy.com/?${item.locationLongitude},${item.locationLatitude},11`;
  }
}
</script>
<style scoped>
.dx-toolbar {
  background: none;
}

.list-header {
  white-space: pre;
  font-size: 28px;
  font-family: "Segoe UI Light", "Helvetica Neue Light", "Segoe UI",
    "Helvetica Neue", "Trebuchet MS", Verdana, sans-serif;
  font-weight: 200;
  fill: #fff;
}

.dx-list:not(.dx-list-select-decorator-enabled)
  .dx-list-item.dx-state-focused
  a {
  color: black;
}

.weather-module {
  width: 100%;
  height: 100%;
  padding-bottom: 74px;
}
</style>