﻿using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.Charts.HseIndicators.Output
{
    public sealed class HseIndicatorsOutput
    {
        private readonly List<HseIndicatorsUnitOutput> _units;

        public HseIndicatorsOutput(
            int daysWithoutIncident,
            HseIndicatorIncidentOutput? lastIncident,
            List<HseIndicatorsUnitOutput>? units)
        {
            DaysWithoutIncident = daysWithoutIncident;
            LastIncident = lastIncident;

            _units = units ?? new List<HseIndicatorsUnitOutput>();
        }

        public int DaysWithoutIncident { get; }
        public HseIndicatorIncidentOutput? LastIncident { get; }

        public IEnumerable<HseIndicatorsUnitOutput> Units => _units
            .AsReadOnly();
    }
}
