﻿using System;
using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.Charts.AccountingMtrByPeriods.Output
{
    public sealed class AccountingMtrByPeriodsParamOutput
    {
        private readonly List<AccountingMtrByPeriodsUnitOutput> _units;

        internal AccountingMtrByPeriodsParamOutput(
            DateTime period,
            List<AccountingMtrByPeriodsUnitOutput>? units)
        {
            Period = period;
            _units = units ?? new List<AccountingMtrByPeriodsUnitOutput>();
        }

        public DateTime Period { get; }
        public IEnumerable<AccountingMtrByPeriodsUnitOutput> Units =>
            _units.AsReadOnly();
    }
}
