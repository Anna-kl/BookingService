﻿using Supply.Dashboards.Shared.Types;
using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Customers.CustomerList
{
    public sealed class CustomerListRequestViewModel
    {
        public List<StatusEnum>? Statuses { get; set; }
        public List<Guid?>? ParentIds { get; set; }
        public List<Guid>? Ids { get; set; }
        public List<CustomerTypeEnum>? Types { get; set; }
    }
}
