﻿
using Common.SeedWork;

namespace Supply.Dashboards.Domain.Types
{
    public sealed class StatusType : Enumeration
    {
        public static StatusType Active = new(1, "Active");
        public static StatusType Disable = new(2, "Disable");
        public static StatusType Archived = new(3, "Archived");

        public StatusType(int id, string name) : base(id, name)
        {
        }
    }
}
