﻿using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.Imports.ImportMtr.Output
{
    public class ImportMtrOutput
    {
        private readonly List<ImportMtrItemOutput> _added;
        private readonly List<ImportMtrItemOutput> _updated;
        private readonly List<ImportMtrItemOutput> _removed;


        public ImportMtrOutput(
            IEnumerable<ImportMtrItemOutput>? added,
            IEnumerable<ImportMtrItemOutput>? updated,
            IEnumerable<ImportMtrItemOutput>? removed)
        {
            _added = added?.ToList() ?? new List<ImportMtrItemOutput>();
            _updated = updated?.ToList() ?? new List<ImportMtrItemOutput>();
            _removed = removed?.ToList() ?? new List<ImportMtrItemOutput>();
        }

        public IEnumerable<ImportMtrItemOutput> Added =>
            _added.AsReadOnly();

        public IEnumerable<ImportMtrItemOutput> Updated =>
            _updated.AsReadOnly();

        public IEnumerable<ImportMtrItemOutput> Removed =>
            _removed.AsReadOnly();
    }
}
