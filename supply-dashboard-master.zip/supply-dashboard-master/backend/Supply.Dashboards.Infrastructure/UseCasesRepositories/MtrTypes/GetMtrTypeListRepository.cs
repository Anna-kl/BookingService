﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.UseCases.MtrTypes.GetMtrTypeList;
using Supply.Dashboards.Domain.AggregatesModel.MtrTypes;
using Supply.Dashboards.Domain.Types;
using Supply.Dashboards.Infrastructure.Data;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.Infrastructure.UseCasesRepositories.MtrTypes
{
    public sealed class GetMtrTypeListRepository : IGetMtrTypeList
    {
        private readonly ILogger<GetMtrTypeListRepository> _logger;
        private readonly DashboardsContext _dashboardsContext;

        public GetMtrTypeListRepository(
            ILogger<GetMtrTypeListRepository> logger,
            DashboardsContext dashboardsContext)
        {
            _logger = logger;
            _dashboardsContext = dashboardsContext;
        }

        public async Task<IEnumerable<MtrType>> Get(
            List<StatusType> statuses,
            List<MtrType>? sourceList,
            List<Guid>? ids,
            bool includeRoot,
            CancellationToken cancellationToken)
        {
            var queryable = _dashboardsContext
                .MtrTypes
                .Include(_ => _.SourceEdges!.Where(edge => edge.Source.Status == StatusType.Active))
                .ThenInclude(_ => _.Source)
                .Include(_ => _.DestinationEdges!.Where(edge => edge.Destination.Status == StatusType.Active))
                .ThenInclude(_ => _.Destination)
                .Where(_ => _.Status == StatusType.Active);

            queryable = includeRoot switch
            {
                true => queryable.Where(_ => sourceList != null && sourceList.Any()
                    ? _.SourceEdges!.Any(edge => sourceList.Select(location => location.Id).Contains(edge.SourceId)) |
                      !_.SourceEdges!.Any()
                    : !_.SourceEdges!.Any()),
                _ => (sourceList != null && sourceList.Any())
                    ? queryable.Where(_ =>
                        _.SourceEdges!.Any(edge => sourceList.Select(location => location.Id).Contains(edge.SourceId)))
                    : queryable
            };

            if (ids != null && ids.Any())
                queryable = queryable.Where(_ => ids.Contains(_.InnerId));

            return (await queryable.ToListAsync(cancellationToken))
                .Distinct()
                .ToList()
                .AsReadOnly();
        }

        public async Task<IEnumerable<MtrType>> GetByIds(
            List<StatusType> statuses,
            List<Guid> ids,
            CancellationToken cancellationToken) =>
            (await _dashboardsContext
                .MtrTypes
                .Where(_ => ids.Contains(_.InnerId))
                .Where(_ => statuses.Contains(_.Status))
                .ToListAsync(cancellationToken)).AsReadOnly();
    }
}
