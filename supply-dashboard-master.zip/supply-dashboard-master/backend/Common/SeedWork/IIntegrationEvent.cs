﻿namespace Common.SeedWork
{
    public interface IIntegrationEvent
    {
    }
}
