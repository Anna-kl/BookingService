﻿namespace Supply.Dashboards.Shared.Types
{
    public enum ValueRecordEnum
    {
        CargoHandlingFact = 100,
        CargoHandlingPlan = 101,
        CargoHandlingAdjustedPlan = 102,
        CargoHandlingDailyPlan = 103,

        FreightTurnoverFact = 200,
        FreightTurnoverPlan = 201,
        FreightTurnoverAdjustedPlan = 202,
        FreightTurnoverDailyPlan = 203,

        ArrivalFact = 204,
        ArrivalPlan = 205,
        ArrivalAdjustedPlan = 206,
        ArrivalDailyPlan = 207,

        ExpenditureFact = 208,
        ExpenditurePlan = 209,
        ExpenditureAdjustedPlan = 210,
        ExpenditureDailyPlan = 211,

        SeasonalDeliveryFact = 300,
        SeasonalDeliveryPlan = 301,
        SeasonalDeliveryAdjustedPlan = 302,
        SeasonalDeliveryDailyPlan = 303,

        AccountingMtrTotalSupplies = 400,
        AccountingMtrProcessing = 401,
        AccountingMtrUncapitalize0_14 = 402,
        AccountingMtrUncapitalize15_30 = 403,
        AccountingMtrUncapitalize31_60 = 404,
        AccountingMtrUncapitalize61More = 405,

        BidPlan = 500,
        BidForecast = 501,
        BidTotalFact = 502,
        BidScheduledFact = 503,
        BidUnplanned = 504,
        BidOTIF = 505,
        OtifApplicationsPlan = 506,
        OtifApplicationsFactTotal = 507,
        OtifApplicationsFactOnTime = 508,

        HseDeath = 600,
        HseDisability = 601,
        HseMedicalCare = 602,
        HseNearMiss = 603,
        HseDangerWarning = 604,

        TransportPlan = 701,
        TransportFact = 702,
        GPMPlan = 703,
        GPMFact = 704,
        LaborResourcesPlan = 705,
        LaborResourcesFact = 706,

        FullnessBasesTotalSquare = 801,
        FullnessBasesLoaded = 802,
        FullnessBasesLoadedRubles = 803,
        FullnessBasesLoadedWeight = 804
    }
}