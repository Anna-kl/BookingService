﻿namespace Supply.Dashboards.Shared.Types
{
    public enum ChartDataEnum
    {
        CargoHandling = 1,
        FreightTurnover = 2,
        SeasonalDelivery = 3
    }
}
