
import Vue from "vue";
import { Prop } from "vue-property-decorator";
import { IDirectoryDataItem, IRelation } from "./types";
import { InputDataService } from "@/services/inputDataService";

export default class DirectoryEdit<T extends IDirectoryDataItem> extends Vue {
    @Prop({ type: Function, required: true }) public reloadTree!: any;
    @Prop({ type: Function, required: true })
    public loadDataItemFromApi!: (dbId: string) => Promise<T>;
    @Prop({ type: Function, required: true })
    public loadDataItemsFromApi!: (
        parentIds: any[],
        types: string[]
    ) => Promise<T[]>;

    public popupVisible: boolean = false;
    public _inputDataService!: InputDataService;
    public itemRelations!: IRelation[];
    public editedItem!: IDirectoryDataItem;
    public currentData!: T;

    public setEditedItem(item: IDirectoryDataItem) {
        this.editedItem = {
            id: item.id,
            rowVersion: item.rowVersion,
            parentIds: item.parentIds,
            childrenIds: item.childrenIds,
            title: item.title === undefined ? "" : item.title,
        };
    }

    public edit(editedItem: T) {
        this.currentData = editedItem;
        this.itemRelations = [];
        this.setEditedItem(editedItem);
        this.popupVisible = true;
    }

    public add(newItem: T) {
        this.currentData = newItem;
        this.itemRelations = [];
        this.setEditedItem(newItem);
        this.popupVisible = true;
    }

    private closeOnClick() {
        this.popupVisible = false;
    }

}