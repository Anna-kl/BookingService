﻿using Supply.Dashboards.Service.Authentication;

namespace Supply.Dashboards.Service.Types
{
	public sealed class ClientSettingsType
	{
		public string AuthenticationHost { get; set; }
	}
}