﻿namespace Supply.Dashboards.Shared.Types
{
    public enum CustomerTypeEnum
    {
        Inner = 1,
        External = 2
    }
}
