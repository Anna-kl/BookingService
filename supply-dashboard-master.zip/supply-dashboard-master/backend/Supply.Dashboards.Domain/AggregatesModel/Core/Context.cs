﻿using Common.SeedWork;
using Supply.Dashboards.Domain.Exceptions;
using Supply.Dashboards.Domain.Types;
using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Domain.AggregatesModel.Core
{
    public sealed class Context : Aggregate
    {
        private readonly List<AliasId> _aliasIds = new();
        private readonly List<ContextUser> _contextUsers = new();

        #region c'tors

        public Context(
            Guid id,
            string title)
        {
            Id = default;
            InnerId = id == default
                ? throw new DomainException($"{nameof(id)} can't be null.")
                : id;
            XMin = default;
            CreateAt = DateTime.UtcNow;
            UpdateAt = DateTime.UtcNow;
            Status = StatusType.Active;
            Title = string.IsNullOrWhiteSpace(title)
                ? throw new DomainException($"{nameof(title)} can't be null or white-space.")
                : title;

            _aliasIds = new List<AliasId>();
            _contextUsers = new List<ContextUser>();

            AddDomainEvent(new Event(InnerId.ToString(), Status, (Title, AliasIds, ContextUsers)));
        }

#pragma warning disable 8618
        // ReSharper disable once UnusedMember.Local
        private Context()
        {
        }
#pragma warning restore 8618

        #endregion

        #region props

        public uint XMin { get; private set; }
        public DateTime CreateAt { get; init; }
        public DateTime UpdateAt { get; private set; }
        public StatusType Status { get; private set; }

        public string Title { get; private set; }

        public IEnumerable<AliasId> AliasIds => _aliasIds.AsReadOnly();
        public IEnumerable<ContextUser> ContextUsers => _contextUsers.AsReadOnly();

        #endregion

        #region methods

        public void ChangeStatus(StatusType status)
        {
            UpdateAt = DateTime.UtcNow;
            Status = status
                     ?? throw new DomainException($"{nameof(status)} can't be null.");

            AddDomainEvent(new Event(InnerId.ToString(), Status, (Title, AliasIds, ContextUsers)));
        }

        public void UpdateTitle(string title)
        {
            UpdateAt = DateTime.UtcNow;
            Title = string.IsNullOrWhiteSpace(title)
                ? throw new DomainException($"{nameof(title)} can't be null or white-space.")
                : title;

            AddDomainEvent(new Event(InnerId.ToString(), Status, (Title, AliasIds, ContextUsers)));
        }

        #endregion
    }
}
