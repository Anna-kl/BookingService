﻿namespace Supply.Dashboards.App.UseCases.Charts.OtifChart.Output
{
    public sealed class OtifChartOutput
    {
        public OtifChartOutput(
            double otif,
            double notOtif)
        {
            Otif = otif;
            NotOtif = notOtif;
        }

        public double Otif { get; }
        public double NotOtif { get; }
    }
}
