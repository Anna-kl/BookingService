﻿using Common.SeedWork;

using Supply.Dashboards.App.Exceptions;
using Supply.Dashboards.Domain.Types;

namespace Supply.Dashboards.App.UseCases.Charts.TransportResources.Types
{
    public sealed class TransportResourcesType : Enumeration
    {
#pragma warning disable CA2211 // Non-constant fields should not be visible
        public static TransportResourcesType TransportPlan = new(701, "TransportPlan");
        public static TransportResourcesType TransportFact = new(702, "TransportFact");
        public static TransportResourcesType GPMPlan = new(703, "GPMPlan");
        public static TransportResourcesType GPMFact = new(704, "GPMFact");
        public static TransportResourcesType LaborResourcesPlan = new(705, "LaborResourcesPlan");
        public static TransportResourcesType LaborResourcesFact = new(706, "LaborResourcesFact");
#pragma warning restore CA2211 // Non-constant fields should not be visible

        public TransportResourcesType(int id, string name) : base(id, name)
        {
        }

        internal static TransportResourcesType GetTransportResourcesType(ValueRecordType type)
        {
            var name = type.Name switch
            {
                nameof(ValueRecordType.TransportPlan) => TransportPlan.Name,
                nameof(ValueRecordType.TransportFact) => TransportFact.Name,
                nameof(ValueRecordType.GPMPlan) => GPMPlan.Name,
                nameof(ValueRecordType.GPMFact) => GPMFact.Name,
                nameof(ValueRecordType.LaborResourcesPlan) => LaborResourcesPlan.Name,
                nameof(ValueRecordType.LaborResourcesFact) => LaborResourcesFact.Name,

                _ => throw new AppException($"invalid enum value: {nameof(type)}.")
            };

            return FromDisplayName<TransportResourcesType>(name)!;
        }
    }
}
