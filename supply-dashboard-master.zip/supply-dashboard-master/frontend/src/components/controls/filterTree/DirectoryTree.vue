<template>
  <DxTreeList
    :ref="treeRef"
    :data-source="directoryTreeDataSource"
    :word-wrap-enabled="true"
    key-expr="id"
    parent-id-expr="parentId"
    has-items-expr="hasItems"
    :show-column-headers="false"
    :select-nodes-recursive="false"
    root-value=""
    v-bind="treeConfig"
    :loadPanel="{enabled: false}"
  >
    <DxRemoteOperations :filtering="true" :grouping="true" />
    <DxColumn
      :allow-sorting="true"
      sort-order="asc"
      :min-width="200"
      data-field="title"
      cell-template="itemTemplate"
    />
    <template #itemTemplate="{ data: options }">
      <div class="item-container">
        <div class="box">
          <div>
            <div v-if="options.data.id === currentVisibleCheck">
              <DxCheckBox
                v-if="options.data.hasItems"
                :ref="`chkbox_${options.data.id}`"
                hint="Показать информацию по дочерним элементам"
                :value="
                  `chkbox_${options.data.id}` === currentCheckedLocation
                    ? true
                    : false
                "
                @value-changed="itemChecked($event, options.data)"
                :visible="!IsReadOnly"
              />
            </div>
          </div>
          <div
            :class="IsReadOnly ? 'item-title' : 'item-title-edit'"
            :title="getTitle(options.data)"
          >
            {{ options.data.title }}
          </div>
        </div>
        <div class="action-buttons">
          <div v-if="options.data.id === focusedRowKey">
            <DxButton
              title="Добавить"
              cssClass="action-button"
              icon="plus"
              :visible="!IsReadOnly"
              @click="addClick(options.data.id)"
            />
          </div>
          <div
            v-if="
              options.data.id === focusedRowKey &&
              options.data.id !== rootTreeListId
            "
          >
            <DxButton
              icon="edit"
              cssClass="action-button"
              title="Изменить"
              :visible="!IsReadOnly"
              @click="edit(options.data.id)"
            />
          </div>
          <div
            v-if="
              options.data.id === focusedRowKey &&
              options.data.id !== rootTreeListId
            "
          >
            <DxButton
              icon="trash"
              cssClass="action-button"
              title="Удалить"
              :visible="!IsReadOnly"
              @click="showDeleteDialog(options.data.id)"
            />
          </div>
        </div>
      </div>
    </template>
  </DxTreeList>
</template>

<script lang='ts'>
import Vue from "vue";

import { EventBus } from "@/event-bus";
import { DxCheckBox } from "devextreme-vue/check-box";
import DxSortable from "devextreme-vue/sortable";
import DataSource from "devextreme/data/data_source";
import { Component, Prop, Watch } from "vue-property-decorator";
import DxButton from "devextreme-vue/button";
import { Guid } from "@/helpers/guid";
import { confirm } from "devextreme/ui/dialog";
import {
  DxTreeList,
  DxColumn,
  DxColumnChooser,
  DxHeaderFilter,
  DxSearchPanel,
  DxSelection,
  DxLookup,
  DxRemoteOperations,
} from "devextreme-vue/tree-list";
import {
  IDirectoryDataItem,
  IDirectoryTreeDataItem,
  ITreeListItemRelation,
  ITreeListSelectedItem,
} from "./types";
import { InputDataState, SettingsState } from "@/store";
import { dxTreeListOptions } from "devextreme/ui/tree_list";

@Component({
  components: {
    DxCheckBox,
    DxSortable,
    DxButton,
    DxTreeList,
    DxColumn,
    DxColumnChooser,
    DxHeaderFilter,
    DxSearchPanel,
    DxSelection,
    DxLookup,
    DxRemoteOperations,
  },
})
export default class DirectoryTree extends Vue {
  @Prop({ type: String, required: true }) public treeRef!: string;
  @Prop({ type: Function, required: true })
  public createRootItem!: (
    id: string,
    childrenIds: string[]
  ) => IDirectoryTreeDataItem;
  @Prop({ type: Function, required: true })
  public loadDataItemFromApi!: (dbId: string) => Promise<IDirectoryDataItem>;
  @Prop({ type: Function, required: true })
  public loadDataItemsFromApi!: (
    dbIds: any[],
    types: string[]
  ) => Promise<IDirectoryDataItem[]>;
  @Prop({ type: Function, required: true })
  public deleteDataItem!: (dbId: string) => void;
  @Prop({ type: Function, required: true })
  public addDataItem!: (parentDbId: string) => void;
  @Prop({ type: Function, required: true })
  public editDataItem!: (dbId: string) => void;
  @Prop({ type: Function, required: true })
  public setSelectedDataItems!: (items: ITreeListSelectedItem[]) => void;
  @Prop({ type: String, required: true }) public pageType!: string;

  private rootTreeListId = Guid.newGuid();
  private currentVisibleCheck: string = "";
  private currentCheckedLocation: string = "";
  private dataItemIdWithTreeItemIdRelations: ITreeListItemRelation[] = [];
  private focusedRowKey: string = "";
  private deletedItemId: string = "";
  private treeConfig: dxTreeListOptions = {};

  private beforeCreate() {}

  private mounted() {
    if (this.pageType === "inputData") {
      this.treeConfig = {
        onFocusedRowChanged: this.focusedRowChanged,
        focusedRowEnabled: true,
      };
    }
    if (this.pageType === "graph") {
      this.treeConfig = {
        onSelectionChanged: this.selectionChanged,
        selection: {
          recursive: false,
          mode: "multiple",
        },
      };
    }
  }

  public get directoryTree() {
    return (this.$refs[this.treeRef] as DxTreeList).instance!;
  }

  public reloadTree(): any {
    this.directoryTreeDataSource.reload();
  }

  private addClick(parentId: string) {
    const finedItem = this.getTreeItemDbIdForId(parentId);
    if (finedItem !== null) {
      this.addDataItem(finedItem);
    }
  }

  private async edit(id: string) {
    const finedItem = this.getTreeItemDbIdForId(id);
    if (finedItem !== null) {
      this.editDataItem(finedItem);
    }
  }

  private async showDeleteDialog(id: string) {
    let result = confirm("<i>Вы уверены?</i>", "Подтверждение");

    await result.then((dialogResult) => {
      if (dialogResult) {
        this.delete(id);
      }
    });
  }

  private async delete(id: string) {
    const finedItem = this.getTreeItemDbIdForId(id);
    if (finedItem !== null) {
      this.deletedItemId = id;
      this.deleteDataItem(finedItem);
    }
  }

  private get directoryTreeDataSource() {
    return new DataSource({
      loadMode: "processed",
      key: "id",
      load: this.loadData,
    });
  }

  public async loadData(loadOptions: any) {
    const parentIds: string[] = [];
    const types: string[] = [];
    const retData: IDirectoryTreeDataItem[] = [];
    let rootInDBDataItems: IDirectoryDataItem[] = [];

    if (loadOptions.parentIds === undefined) {
      let filterItemId = "";
      if (typeof loadOptions.filter[0] === "object") {
        filterItemId = loadOptions.filter[0][2];
      } else {
        filterItemId = loadOptions.filter[2];
      }
      if (filterItemId !== this.deletedItemId) {
        const dbId = this.getTreeItemDbIdForId(filterItemId);
        if (dbId != null) {
          const dataItem = await this.loadDataItemFromApi(dbId);

          if (dataItem !== null) {
            const rel = this.getTreeItemRelation(filterItemId);

            retData.push(
              this.createTreeItem(
                dataItem!,
                rel.parentId,
                this.getTreeItemIdForDbId(
                  dataItem.id,
                  rel.parentId,
                  dataItem.title
                )
              )
            );
          }
        }
      }
    } else {
      parentIds.push(...loadOptions.parentIds);
    }

    if (parentIds.length > 0) {
      if (parentIds.includes("")) {
        rootInDBDataItems = await this.loadDataItemsFromApi([null], []);
      }

      const parentDbIds: string[] = [];
      parentIds.forEach((parentId) => {
        if (parentId === "") {
          const rootElement: IDirectoryTreeDataItem = this.createRootItem(
            this.rootTreeListId,
            rootInDBDataItems !== undefined && rootInDBDataItems.length > 0
              ? rootInDBDataItems.map((l) => l.id)
              : []
          );
          retData.push(rootElement);

          const afterRootTreeDataItems: IDirectoryTreeDataItem[] = [];

          if (rootInDBDataItems.length > 0) {
            rootInDBDataItems.forEach((element) => {
              const afterRootTreeDataItem = this.createTreeItem(
                element,
                this.rootTreeListId,
                this.getTreeItemIdForDbId(
                  element.id,
                  this.rootTreeListId,
                  element.title
                )
              );

              afterRootTreeDataItems.push(afterRootTreeDataItem);
            });

            retData.push(...afterRootTreeDataItems);
          }
          this.updateTreeItemRelation(
            this.rootTreeListId,
            "",
            "",
            rootElement.title
          );
        } else {
          const finedItem = this.getTreeItemDbIdForId(parentId);
          if (finedItem != null) {
            parentDbIds.push(finedItem);
          }
        }
      });

      let dataItems: any[] = [];
      if (parentDbIds.length > 0) {
        dataItems = await this.loadDataItemsFromApi(parentDbIds, []);
      }

      parentIds.forEach((parentId) => {
        if (
          parentId !== "" &&
          parentId !== this.rootTreeListId &&
          dataItems != undefined &&
          dataItems.length > 0
        ) {
          dataItems.forEach((dataItem) => {
            const parentDbId =
              parentId === "" ? "" : this.getTreeItemDbIdForId(parentId);

            if (
              parentDbId !== null &&
              (dataItem.parentIds?.includes(parentDbId) ||
                (dataItem.parentIds.length === 0 && parentId === ""))
            ) {
              retData.push(
                this.createTreeItem(
                  dataItem,
                  parentId,
                  this.getTreeItemIdForDbId(
                    dataItem.id,
                    parentId,
                    dataItem.title
                  )
                )
              );
            }
          });
        }
      });
    }

    return retData;
  }

  private createTreeItem(
    dataItem: IDirectoryDataItem,
    parentId: string,
    id?: string
  ): IDirectoryTreeDataItem {
    return {
      id: id ? id : Guid.newGuid(),
      rowVersion: dataItem.rowVersion,
      title: dataItem.title ?? "",
      description: dataItem.description ?? "",
      hasItems:
        dataItem.childrenIds && dataItem.childrenIds.length > 0 ? true : false,
      parentId: parentId,
    };
  }

  private updateTreeItemRelation(
    id: string,
    dbId: string,
    parentId: string,
    title: string
  ) {
    const item = this.dataItemIdWithTreeItemIdRelations.find(
      (s) => s.id === id
    );
    if (item === undefined) {
      this.dataItemIdWithTreeItemIdRelations.push({
        id: id,
        dbId: dbId,
        parentId: parentId,
        parentDbId: this.getTreeItemDbIdForId(parentId),
        title: title,
      });
    }
  }

  private getTreeItemRelation(id: string): any {
    return this.dataItemIdWithTreeItemIdRelations.find((s) => s.id === id);
  }

  private getTreeItemIdForDbId(
    dbId: string,
    parentId: string,
    title: string
  ): string {
    const relation = this.dataItemIdWithTreeItemIdRelations.find(
      (s) => s.dbId === dbId && s.parentId === parentId
    );
    if (relation) {
      return relation.id;
    } else {
      const newId = Guid.newGuid();
      this.updateTreeItemRelation(newId, dbId, parentId, title);
      return newId;
    }
  }

  public getTreeItemIdByDbId(dbId: string): string | null {
    const finedItem = this.dataItemIdWithTreeItemIdRelations.find(
      (s) => s.dbId === dbId
    );
    if (finedItem === undefined) {
      return null;
    } else {
      return finedItem!.id;
    }
  }

  private getTreeItemDbIdForId(id: string): string {
    const finedItem = this.dataItemIdWithTreeItemIdRelations.find(
      (s) => s.id === id
    );
    if (finedItem === undefined) {
      return "";
    } else {
      return finedItem!.dbId;
    }
  }

  private focusedRowChanged(e: any) {
    const rowData = e.row && e.row.data;

    if (rowData) {
      this.focusedRowKey = rowData.id;
      this.currentVisibleCheck = rowData.id;
      const finedItem = this.dataItemIdWithTreeItemIdRelations.find(
        (s) => s.id === rowData.id
      );
      if (finedItem !== undefined) {
        this.setSelectedDataItems([
          {
            id: finedItem.id,
            dbId: finedItem.dbId,
            parentId: finedItem.parentId,
            parentDbId: finedItem.parentDbId,
            selected: true,
            title: finedItem.title,
          },
        ]);
      }
    }
  }

  private selectionChanged(e: any) {
    const items: ITreeListSelectedItem[] = [];
    if (e.selectedRowKeys) {
      e.selectedRowKeys.forEach((element: string) => {
        const finedItem = this.dataItemIdWithTreeItemIdRelations.find(
          (s) => s.id === element
        );
        if (finedItem !== undefined) {
          items.push({
            id: finedItem.id,
            dbId: finedItem.dbId,
            parentId: finedItem.parentId,
            parentDbId: finedItem.parentDbId,
            selected: true,
            title: finedItem.title,
          });
          items.push(
            ...this.createTreeNodeSelectedStateToRoot(finedItem.parentId)
          );
        }
      });

      this.setSelectedDataItems(items);
    }
  }

  private createTreeNodeSelectedStateToRoot(
    parentId: string
  ): ITreeListSelectedItem[] {
    let state = true;
    const retItems: ITreeListSelectedItem[] = [];
    let currentParentId = parentId;

    while (state) {
      const finedItem = this.dataItemIdWithTreeItemIdRelations.find(
        (s) => s.id === currentParentId
      );
      retItems.push({
        id: finedItem!.id,
        dbId: finedItem!.dbId,
        parentId: finedItem!.parentId,
        parentDbId: finedItem!.parentDbId,
        selected: false,
        title: finedItem!.title,
      });

      if (finedItem!.parentDbId === "") {
        state = false;
      } else {
        currentParentId = finedItem!.parentId;
      }
    }
    return retItems;
  }

  private selectSubItems(nodeId: string) {
    const items: ITreeListSelectedItem[] = [];
    const currentNode = this.directoryTree.getNodeByKey(nodeId);
    currentNode?.children!.forEach((element) => {
      const finedItem = this.dataItemIdWithTreeItemIdRelations.find(
        (s) => s.id === element.data.id
      );
      if (finedItem !== undefined) {
        items.push({
          id: finedItem!.id,
          dbId: finedItem!.dbId,
          parentId: finedItem!.parentId,
          parentDbId: finedItem!.parentDbId,
          selected: true,
          title: finedItem.title,
        });
        items.push(
          ...this.createTreeNodeSelectedStateToRoot(finedItem.parentId)
        );
      }
    });
    this.setSelectedDataItems(items);
  }

  private itemChecked(e: any, data: any) {
    if (e.value) {
      if (this.directoryTree.isRowExpanded(data.id) === false) {
        this.directoryTree.expandRow(data.id).then(() => {
          this.currentCheckedLocation = `chkbox_${data.id}`;
        });
      } else {
        this.selectSubItems(data.id);
      }
    } else {
      const currentNode = this.directoryTree.getNodeByKey(data.id);
      const finedItem = this.dataItemIdWithTreeItemIdRelations.find(
        (s) => s.id === currentNode.data.id
      );
      if (finedItem !== undefined) {
        this.setSelectedDataItems([
          {
            id: finedItem.id,
            dbId: finedItem.dbId,
            parentId: finedItem.parentId,
            parentDbId: finedItem.parentDbId,
            selected: true,
            title: finedItem.title,
          },
        ]);
      }
    }
  }

  private getTitle(data: IDirectoryDataItem) {
    if (data.description !== "" && data.description !== undefined) {
      return `${data.title} | ${data.description}`;
    } else {
      return data.title;
    }
  }

  private get IsReadOnly(): boolean {
    return InputDataState.isReadOnly;
  }
}
</script>

<style scoped>
.item-container {
  overflow: hidden;
  width: 100%;
  height: 26px;
}
.box {
  white-space: inherit;
}
.box div {
  width: 34px;
  float: left;
}
.box div.item-title {
  width: 300px;
  float: left;
}

.box div.item-title-edit {
  width: 300px;
  float: left;
  padding-left: 34px;
}

.action-buttons {
  position: absolute;
  left: 320px;
  width: 110px;
  margin-top: -5px;
}

.action-buttons div {
  float: left;
}
</style>