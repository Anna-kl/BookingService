﻿using Common.SeedWork;
using Supply.Dashboards.Domain.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supply.Dashboards.Domain.AggregatesModel.WeatherRestrictions
{
    public sealed class WeatherRestriction : Entity, IAggregateRoot
    {
        #region c'tors

        public WeatherRestriction(WeatherRestrictionPayload payload)
        {
            Id = default;
            InnerId = Guid.NewGuid();
            CreateAt = DateTime.UtcNow;
            UpdateAt = DateTime.UtcNow;
            Payload = payload
                      ?? throw new DomainException($"{nameof(payload)} can't be null.");
        }

        public void ChangePayload(WeatherRestrictionPayload payload)
        {
            UpdateAt = DateTime.UtcNow;
            Payload = payload;
        }

        private WeatherRestriction()
        {

        }


        #endregion

        #region props

        public DateTime CreateAt { get; init; }
        public DateTime UpdateAt { get; private set; }
        public WeatherRestrictionPayload Payload { get; private set; }

        #endregion

    }
}
