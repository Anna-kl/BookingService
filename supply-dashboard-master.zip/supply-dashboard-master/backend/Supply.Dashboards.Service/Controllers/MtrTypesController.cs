﻿using Common.SeedWork;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.MtrTypes.GetMtrTypeList.Input;
using Supply.Dashboards.Shared.ViewModels.MtrTypes.MtrTypeList;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.Service.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public sealed class MtrTypesController : ControllerBase
    {
        private readonly ILogger<MtrTypesController> _logger;
        private readonly IMediator _mediator;

        public MtrTypesController(
            ILogger<MtrTypesController> logger,
            IMediator mediator)
        {
            _logger = logger;
            _mediator = mediator;
        }

        /// <summary>
        /// Get a list of MTR type with optional filtering
        /// Actual data has the status "actual".
        /// If you do not pass the status, all data types will be returned, including deleted ones.
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        [HttpPost("list")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status502BadGateway)]
        public async Task<ActionResult<List<MtrTypeListResponseViewModel>>> GetList(
            [FromBody] MtrTypeListRequestViewModel request,
            CancellationToken cancellationToken)
        {
            var query = new GetMtrTypeListQuery(
                request.Statuses?.Select(_ => Enumeration.IsDefined<AppStatusType>(_.ToString())
                    ? Enumeration.FromDisplayName<AppStatusType>(_.ToString())!
                    : AppStatusType.Active),
                request.ParentIds,
                request.Ids);

            if (!query.ValidationResult.IsValid)
                return BadRequest(
                    query
                        .ValidationResult
                        .Errors
                        .Select(failure => new
                        {
                            failure.ErrorCode,
                            failure.ErrorMessage
                        }));

            var (validationResult, output) = await _mediator.Send(
                query,
                cancellationToken);

            if (!validationResult.IsValid)
                return BadRequest(
                    query
                        .ValidationResult
                        .Errors
                        .Select(failure => new
                        {
                            failure.ErrorCode,
                            failure.ErrorMessage
                        }));

            if (output == null || !output.Items.Any())
                return NoContent();

            var viewModels = output.Items.Select(_ => new MtrTypeListResponseViewModel
            {
                Id = _.Id,
                RowVersion = _.RowVersion,
                ParentIds = _.SourceIds,
                ChildrenIds = _.DestinationIds,
                Title = _.Title,
                Description = _.Description
            }).ToList();

            return viewModels;
        }
    }
}
