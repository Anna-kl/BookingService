﻿using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Import.ImportDirectories.Response
{
    public sealed class ImportDirectoriesResponseViewModel
    {
        public List<ImportDirectoriesCustomerResponseViewModel>? AddedCustomers { get; set; }
        public List<ImportDirectoriesCustomerResponseViewModel>? UpdatedCustomers { get; set; }
        public List<ImportDirectoriesCustomerResponseViewModel>? RemovedCustomersIds { get; set; }
        public List<ImportDirectoriesEdgeResponseViewModel>? AddedCustomersRelations { get; set; }
        public List<ImportDirectoriesEdgeResponseViewModel>? RemovedCustomersRelations { get; set; }

        public List<ImportDirectoriesLocationResponseViewModel>? AddedLocations { get; set; }
        public List<ImportDirectoriesLocationResponseViewModel>? UpdatedLocations { get; set; }
        public List<ImportDirectoriesLocationResponseViewModel>? RemovedLocations { get; set; }
        public List<ImportDirectoriesEdgeResponseViewModel>? AddedLocationsRelations { get; set; }
        public List<ImportDirectoriesEdgeResponseViewModel>? RemovedLocationsRelations { get; set; }

        public List<ImportDirectoriesMtrTypeResponseViewModel>? AddedMtrTypes { get; set; }
        public List<ImportDirectoriesMtrTypeResponseViewModel>? UpdatedMtrTypes { get; set; }
        public List<ImportDirectoriesMtrTypeResponseViewModel>? RemovedMtrTypes { get; set; }
        public List<ImportDirectoriesEdgeResponseViewModel>? AddedMtrTypesRelations { get; set; }
        public List<ImportDirectoriesEdgeResponseViewModel>? RemovedMtrTypesRelations { get; set; }
    }
}
