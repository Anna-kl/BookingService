﻿using FluentValidation.Results;

using MediatR;

using Supply.Dashboards.App.UseCases.Charts.SeasonalDelivery.Output;

using System;
using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.Charts.SeasonalDelivery.Input
{
    public sealed class SeasonalDeliveryQuery
        : IRequest<(ValidationResult validationResult, SeasonalDeliveryOutput? output)>
    {
        public SeasonalDeliveryQuery(
            DateTime dateTime,
            Guid? parentLocationId,
            List<Guid>? locationsIds,
            List<Guid>? customersIds,
            List<Guid>? mtrTypesIds)
        {
            DateTime = dateTime;

            ParentLocationId = parentLocationId;
            LocationsIds = locationsIds;
            CustomersIds = customersIds;
            MtrTypesIds = mtrTypesIds;

            ValidationResult = new SeasonalDeliveryValidator()
                .Validate(this);
        }

        public DateTime DateTime { get; }

        public Guid? ParentLocationId { get; set; }
        public List<Guid>? LocationsIds { get; }

        public List<Guid>? CustomersIds { get; }

        public List<Guid>? MtrTypesIds { get; }

        public ValidationResult ValidationResult { get; }
    }
}
