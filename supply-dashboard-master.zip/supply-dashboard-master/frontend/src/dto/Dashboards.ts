import { ITreeListSelectedItem } from "@/components/controls/filterTree/types";

export interface IDashboard {
    id: number;
    name: string;
    layouts: IDashboardLayout[];

}

//  Vue-Responsive-Dash Layout сomponent Interface, default property in component
//
// Name	            Type	            Required	Default	        Description
// breakpoint	    string	            yes		                    typically describing the breakpoint Size (i.e. xl, lg etc)
// numberOfCols	    number	            no	        12	            Number of columns allowed
// margin	        object	            no	        { x:10, y:10 }	Distance in pixels between DashItems
// breakpointWidth	number	            no		                    Width used to determine which layout is most appropriate for the screen size
// useCssTransforms	boolean	            no	        false	        Use translate3d instead of direct top left css properties
// compact	        boolean	            no	        true	        Automatically move items up if there is space available
// colWidth	        boolean | number	no	        false	        When set to a number the column width is statically set to this value
// maxColWidth	    boolean | number	no	        false	        When set to a number the colWidth will never be greater than this number
// minColWidth	    boolean | number	no	        false	        When set to a number the colWidth will never be less than this number
// rowHeight	    boolean | number	no	        false	        When set to a number the row height will be set to this number (as opposed to being set to the colWidth to keep the items square)
// maxRowHeight	    boolean | number	no	        false	        When set to a number the rowHeight will never be greater than this number
// minRowHeight	    boolean | number	no	        false	        When set to a number the rowHeight will never be less than this number
export interface IDashboardLayout {
    breakpoint: string;
    numberOfCols?: number;
    margin?: object;
    breakpointWidth?: number;
    useCssTransforms?: boolean;
    compact?: boolean;
    colWidth?: boolean | number;
    maxColWidth?: boolean | number;
    minColWidth?: boolean | number;
    rowHeight?: boolean | number;
    maxRowHeight?: boolean | number;
    minRowHeight?: boolean | number;
    items: IDashboardItem[];
}

//  Vue-Responsive-Dash DashboardItem сomponent Interface, default property in component
// Name	            Type	            Required	Default	        Description
// id	            [Number, String]	true		                UUID for the item
// x	            Number	            false	    0	
// y	            Number	            false	    0	
// width	        Number	            false	    1	            Width (in col units)
// maxWidth	        [Number, Boolean]	false	    false	        Max Width (in col units). When not a number it is ignored
// minWidth	        [Number, Boolean]	false	    1	            Min Width (in col units). When not a number it is ignored
// height	        Number	            false	    1	            Height (in row units)
// maxHeight	    [Number, Boolean]	false	    false	        Max Height (in row units). When not a number it is ignored
// minHeight	    [Number, Boolean]	false	    1	            Min Height (in row units). When not a number it is ignored
// draggable	    Boolean	            false	    true	        If the item can be dragged
// resizable	    Boolean	            false	    true	        If the item can be resized
// resizeEdges	    String	            false	    "bottom right"	The edges it can be resized (experimental for all options apart from bottom right)
// resizeHandleSize	Number	            false	    8	            The area where resize can be selected on the item
// draggableZIndex	Number	            false	    1	            The zIndex applied to the draggable area to make sure it is above the items in the slot
// resizableZIndex	Number          	false	    1	            The zIndex applied to each resizeable area to make sure it is above the items in the main slot
// moveHold	        Number	            false	    0	            The amount of time in ms required to hold the item before it can be moved
// resizeHold	    Number	            false	    0	            The amount of time in ms required to hold the item before it can be resized
// dragAllowFrom	String	            false	    null	        Custom Selector which the drag/move event can start from
// dragIgnoreFrom	String	            false	    null	        Custom Selector to prevent actions from starting if the pointer went down on an element matching the given selector or HTMLElement.
// locked	        Boolean	            false	    false	        A Locked item will remain in position and will not move up when there is space above. It is also not possible to move or resize a locked item
export interface IDashboardItem {
    id: string;
    x: number;
    y: number;
    width?: number;
    maxWidth?: boolean | number;
    minWidth?: boolean | number;
    height?: number;
    maxHeight?: boolean | number;
    minHeight?: boolean | number;
    draggable?: boolean;
    resizable?: boolean;
    resizeEdges?: string;
    resizeHandleSize?: number;
    draggableZIndex?: number;
    resizableZIndex?: number;
    moveHold?: number;
    resizeHold?: number;
    dragAllowFrom?: string;
    dragIgnoreFrom?: string;
    locked?: boolean;
    moduleId: string;
    config?: IModuleConfig;
    series?: IModuleSeries[];
}

export interface IDashboardItemConfig {
    dashboardItemId: string;
    config: IModuleConfig;
    series?: IModuleSeries[];
}

export interface IModuleItem {
    id: string;
    name: string;
    defaultMinHeight: number;
    defaultMinWidth: number;
    defaultHeight: number;
    defaultWidth: number;
    type: string;
    defaultConfig?: IModuleConfig;
    defaultSeries?: IModuleSeries[];
}

export interface IModuleConfig {
    columns?: string;
    type?: string;
    position?: number;
    period?: ChartPeriodEnum;
    startPeriod?: string;
    duration?: string;
    locationsIds?: ITreeListSelectedItem[];
    customersIds?: string[];
    mtrTypesIds?: string[];
    allowPeriods?: ChartPeriodEnum[];
    defaultLocationsGroup?: GraphLocationGroupEnum;
}

export interface IModuleSeries {
    id: string,
    value?: boolean;
    name: string;
    color?: string;
    stack?: string;
}

export enum ChartPeriodEnum {
    Day = 1,
    Week = 2,
    TwoWeeks = 3,
    Month = 4,
    Quarter = 5,
    HalfYear = 6,
    Year = 7
}

export interface DurationPickerData {
    text: string;
    chartPeriod: ChartPeriodEnum;
    groupBy: ChartPeriodEnum;
    defaultPicker?: boolean;
}

export enum GraphLocationGroupEnum {
    Division = 1,
    AllLocationsWithData = 2
}

export interface GraphLocationGroupData {
    text: string;
    locationsGroup: GraphLocationGroupEnum;
    defaultPicker?: boolean;
}

export enum ModuleTypeEnum {
    ArrivalChart = "ArrivalChart",
    ExpenditureChart = "ExpenditureChart",
    CargoChart = "CargoChart",
    HSEValues = "HSEValues",
    OTIFValues = "OTIFValues",
    SeasonalDeliveryChart = "SeasonalDeliveryChart",
    AccountingMtr = "AccountingMtr",
    TransportResourceChart = "TransportResourceChart",
    GPMResourceChart = "GPMResourceChart",
    LaborResourceChart = "LaborResourceChart",
    ExecutionOfOrdersChart = "ExecutionOfOrdersChart",
    FullnessBasesChart = "FullnessBasesChart",
    FullnessBasesByCurrencyChart = "FullnessBasesByCurrencyChart",
    FullnessBasesByWeightChart = "FullnessBasesByWeightChart",
    WeatherRestrictionsList = "WeatherRestrictionsList"
}