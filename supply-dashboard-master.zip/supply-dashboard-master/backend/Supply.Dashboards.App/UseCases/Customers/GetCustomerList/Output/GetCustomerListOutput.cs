﻿using Supply.Dashboards.App.Types;
using Supply.Dashboards.Domain.AggregatesModel.Customers;

using System;
using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.Customers.GetCustomerList.Output
{
    public sealed class GetCustomerListOutput
    {
        private readonly List<GetCustomerListItemOutput> _customers;

        internal GetCustomerListOutput(IEnumerable<Customer> customers)
        {
            _customers = customers
                .Select(ToGetCustomerListItemOutput)
                .ToList();
        }

        public IEnumerable<GetCustomerListItemOutput> Items =>
            _customers.AsReadOnly();

        private static GetCustomerListItemOutput ToGetCustomerListItemOutput(Customer customer)
        {
            return new(
                customer.InnerId,
                customer.XMin,
                customer.SourceEdges?.Select(_ => _.SourceInnerId).ToList() ?? new List<Guid>(),
                customer.DestinationEdges?.Select(_ => _.DestinationInnerId).ToList() ?? new List<Guid>(),
                customer.Status,
                AppCustomerType.GetAppCustomerType(customer.Payload.Type),
                customer.Payload.Title,
                customer.Payload.Description);
        }
    }
}
