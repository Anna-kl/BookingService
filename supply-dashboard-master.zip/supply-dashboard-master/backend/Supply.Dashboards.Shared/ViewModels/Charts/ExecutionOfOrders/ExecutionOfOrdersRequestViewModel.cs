﻿using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Charts.ExecutionOfOrders
{
    public sealed class ExecutionOfOrdersRequestViewModel
    {
        public DateTime StartPeriod { get; set; }
        public DateTime? EndPeriod { get; set; }

        public List<Guid>? LocationsIds { get; set; }
        public List<Guid>? CustomersIds { get; set; }
    }
}
