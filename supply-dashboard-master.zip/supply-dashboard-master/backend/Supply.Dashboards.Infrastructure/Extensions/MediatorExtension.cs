﻿using Common.SeedWork;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace Supply.Dashboards.Infrastructure.Extensions
{
    public static class MediatorExtension
    {
        public static async Task DispatchDomainEventsAsync<TContext>(
            this IMediator mediator,
            TContext context)
            where TContext : DbContext
        {
            var domainEntities = context
                .ChangeTracker
                .Entries<Aggregate>()
                .Where(entryEntity => entryEntity.Entity.DomainEvents.Any())
                .ToList();

            var domainEvents = domainEntities
                .SelectMany(entryEntity => entryEntity.Entity.DomainEvents)
                .ToList();

            var tasks = domainEvents
                .Select(async notification => await mediator.Publish(notification));

            await Task.WhenAll(tasks);

            domainEntities
                .ToList()
                .ForEach(entryEntity => entryEntity.Entity.ClearDomainEvents());
        }
    }
}
