﻿using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

using Polly;

using Supply.Dashboards.Infrastructure.Data;

using System;

namespace Supply.Dashboards.Infrastructure.Extensions
{
    public static class MigrationExtensions
    {
        public static IApplicationBuilder ApplyMigrations(this IApplicationBuilder app)
        {
            using var serviceScope = app
                .ApplicationServices
                .GetService<IServiceScopeFactory>()
                ?.CreateScope();

            if (serviceScope == null)
                throw new ApplicationException(nameof(serviceScope));

            var logger = app
                .ApplicationServices
                .GetRequiredService<ILoggerFactory>()
                .CreateLogger(nameof(MigrationExtensions));

            Policy
                .Handle<Exception>()
                .WaitAndRetry(new[]
                {
                    TimeSpan.FromSeconds(5),
                    TimeSpan.FromSeconds(15),
                    TimeSpan.FromSeconds(20),
                    TimeSpan.FromSeconds(40)
                })
                .Execute(() =>
                {
                    try
                    {
                        // ReSharper disable once AccessToDisposedClosure
                        serviceScope
                            .ServiceProvider
                            .GetRequiredService<DashboardsContext>()
                            .Database
                            .Migrate();
                    }
                    catch (Exception e)
                    {
                        logger.LogError(e, e.Message);
                    }
                });

            return app;
        }
    }
}
