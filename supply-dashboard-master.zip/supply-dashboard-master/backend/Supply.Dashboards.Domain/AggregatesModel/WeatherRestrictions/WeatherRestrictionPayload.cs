﻿using Common.SeedWork;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.Exceptions;
using Supply.Dashboards.Domain.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supply.Dashboards.Domain.AggregatesModel.WeatherRestrictions
{
    public sealed class WeatherRestrictionPayload : ValueObject
    {
        public WeatherRestrictionPayload(
           DateTime dateTime,
           Customer? customer,
           Location? location,
           InputType inputType,
           double temperature,
           double windSpeed,
           string? aktirovka
           )
        {
            DateTime = dateTime == default
                ? throw new DomainException($"{nameof(dateTime)} can't be a default value")
                : dateTime;
            Customer = customer;
            Location = location;
            InputType = inputType;
            Temperature = temperature;
            WindSpeed = windSpeed;
            Aktirovka = aktirovka;
        }

        private WeatherRestrictionPayload()
        {
        }

        public DateTime DateTime { get; init; }
        public Customer? Customer { get; init; }
        public Location? Location { get; init; }
        public InputType InputType { get; init; }

        public double Temperature { get; init; }
        public double WindSpeed { get; init; }
        public string? Aktirovka { get; init; }

        protected override IEnumerable<object> GetAtomicValues()
        {
            yield return DateTime;
            yield return Customer!;
            yield return Location!;
            yield return InputType;
            yield return Temperature;
            yield return WindSpeed;
            yield return Aktirovka!;
        }
    }
}
