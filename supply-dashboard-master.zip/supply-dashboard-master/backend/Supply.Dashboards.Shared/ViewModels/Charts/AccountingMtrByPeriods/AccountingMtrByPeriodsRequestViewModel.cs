﻿using Supply.Dashboards.Shared.Types;

using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Charts.AccountingMtrByPeriods
{
    public sealed class AccountingMtrByPeriodsRequestViewModel
    {
        /// <summary>
        /// Period type (Day, Week, TwoWeeks, Month, Quarter, HalfYear, Year)
        /// </summary>
        public ChartPeriodEnum Period { get; set; }

        /// <summary>
        /// Start period (required)
        /// </summary>
        public DateTime StartPeriod { get; set; }

        /// <summary>
        /// Duration (optional)
        /// </summary>
        public TimeSpan? Duration { get; set; }

        /// <summary>
        /// Locations ids (optional)
        /// </summary>
        public List<Guid>? LocationsIds { get; set; }

        /// <summary>
        /// Customers ids (optional)
        /// </summary>
        public List<Guid>? CustomersIds { get; set; }

        /// <summary>
        /// Classifier MTR types ids (optional)
        /// </summary>
        public List<Guid>? MtrTypesIds { get; set; }
    }
}
