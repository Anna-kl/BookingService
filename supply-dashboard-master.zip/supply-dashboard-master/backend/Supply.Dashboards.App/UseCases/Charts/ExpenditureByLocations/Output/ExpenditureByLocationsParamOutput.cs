﻿using System;
using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.Charts.ExpenditureByLocations.Output
{
    public class ExpenditureByLocationsParamOutput
    {
        private readonly List<ExpenditureByLocationsUnitOutput> _units;

        internal ExpenditureByLocationsParamOutput(
            Guid locationId,
            string locationTitle,
            List<ExpenditureByLocationsUnitOutput>? units)
        {
            LocationId = locationId;
            LocationTitle = locationTitle;
            _units = units ?? new List<ExpenditureByLocationsUnitOutput>();
        }

        public Guid LocationId { get; }
        public string LocationTitle { get; }

        public IEnumerable<ExpenditureByLocationsUnitOutput>? Units =>
            _units.AsReadOnly();
    }
}
