﻿using FluentValidation.Results;

using MediatR;

using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.Locations.GetLocationList.Output;

using System;
using System.Collections.Generic;
using System.Linq;

namespace Supply.Dashboards.App.UseCases.Locations.GetLocationList.Input
{
    public sealed class GetLocationListQuery
        : IRequest<(ValidationResult validationResult, GetLocationListOutput? output)>
    {
        private readonly List<AppStatusType>? _statuses;
        private readonly List<Guid?>? _sourceIds;
        private readonly List<Guid>? _ids;
        private readonly List<AppLocationType>? _types;

        public GetLocationListQuery(
            IEnumerable<AppStatusType>? statuses,
            IEnumerable<Guid?>? sourceIds,
            IEnumerable<Guid>? ids,
            IEnumerable<AppLocationType>? types)
        {
            _statuses = statuses?.ToList() ?? new List<AppStatusType> { AppStatusType.Active };
            _sourceIds = sourceIds?.ToList();
            _ids = ids?.ToList();
            _types = types?.ToList();

            ValidationResult = new GetLocationListValidator()
                .Validate(this);
        }

        public IEnumerable<AppStatusType> Statuses => _statuses!.AsReadOnly();
        public IEnumerable<Guid?>? SourceIds => _sourceIds?.AsReadOnly();
        public IEnumerable<Guid>? Ids => _ids?.AsReadOnly();
        public IEnumerable<AppLocationType>? Types => _types?.AsReadOnly();

        public ValidationResult ValidationResult { get; }
    }
}
