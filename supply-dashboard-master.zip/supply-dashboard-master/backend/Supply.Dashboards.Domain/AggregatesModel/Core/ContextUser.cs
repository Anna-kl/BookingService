﻿using System;

namespace Supply.Dashboards.Domain.AggregatesModel.Core
{
    public sealed class ContextUser
    {
        public ContextUser(
            Context context,
            User user)
        {
            ContextId = context.Id;
            ContextInnerId = context.InnerId;
            Context = context;

            UserId = user.Id;
            UserInnerId = user.InnerId;
            User = user;
        }


#pragma warning disable 8618
        // ReSharper disable once UnusedMember.Local
        private ContextUser()
        {
        }
#pragma warning restore 8618

        public int ContextId { get; init; }
        public Guid ContextInnerId { get; init; }
        public Context Context { get; init; }

        public int UserId { get; init; }
        public Guid UserInnerId { get; init; }
        public User User { get; init; }
    }
}
