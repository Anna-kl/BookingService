﻿using FluentValidation.Results;

using MediatR;

using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.Types;
using Supply.Dashboards.App.UseCases.Customers.GetCustomerList.Input;
using Supply.Dashboards.App.UseCases.Customers.GetCustomerList.Output;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.Types;

using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.Customers.GetCustomerList
{
    public sealed class GetCustomerListUseCase
        : IRequestHandler<GetCustomerListQuery, (ValidationResult validationResult, GetCustomerListOutput? output)>
    {
        private readonly ILogger<GetCustomerListUseCase> _logger;
        private readonly IGetCustomerList _getCustomerList;

        public GetCustomerListUseCase(
            ILogger<GetCustomerListUseCase> logger,
            IGetCustomerList getCustomerList)
        {
            _logger = logger;
            _getCustomerList = getCustomerList;
        }

        public async Task<(ValidationResult validationResult, GetCustomerListOutput? output)> Handle(
            GetCustomerListQuery request,
            CancellationToken cancellationToken)
        {
            // If the statuses r not contained in the request, then add the "Active" status.
            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            var statuses = request
                .Statuses
                .Select(AppStatusType.GetStatusType)
                .Distinct()
                .ToList();

            // If the statuses r not contained in the request, then add the "Active" status.
            if (!statuses.Any())
                statuses.Add(StatusType.Active);

            var sourceCustomers = new List<Customer>();

            if (request.SourceIds != null && request.SourceIds.Any(_ => _ != null))
                sourceCustomers = (await _getCustomerList.GetByIds(
                    statuses,
                    request.SourceIds?.Where(_ => _ != null).Select(_ => _!.Value).ToList()!,
                    cancellationToken)).ToList();

            if (!sourceCustomers.Any() || request.SourceIds?.Count() != sourceCustomers.Count)
                request.SourceIds
                    ?.Where(_ => _ != null)
                    .Select(_ => _.Value)
                    .Except(sourceCustomers.Select(_ => _.InnerId)).ToList().ForEach(id =>
                    {
                        request.ValidationResult.Errors.Add(new ValidationFailure(
                            "CustomerId",
                            $"{nameof(Customer)} with id \"{id}\" is not exist."));
                    });

            // If the statuses r not contained in the request, then add the "Active" status.
            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            var types = request
                .Types
                ?.Select(AppCustomerType.GetCustomerType)
                .Distinct()
                .ToList();

            var customers = (await _getCustomerList.Get(
                statuses,
                sourceCustomers,
                request.Ids?.ToList(),
                types,
                request.SourceIds != null && request.SourceIds.Any(_ => _ == null),
                cancellationToken)).ToList();

            return !customers.Any()
                ? (request.ValidationResult, null)
                : (request.ValidationResult, new GetCustomerListOutput(customers));
        }
    }
}
