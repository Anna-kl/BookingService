﻿using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Import.ImportMtr
{
    public sealed class ImportMtrRequestViewModel
    {
        public List<ImportMtrItemRequestViewModel>? Items { get; set; }
    }
}
