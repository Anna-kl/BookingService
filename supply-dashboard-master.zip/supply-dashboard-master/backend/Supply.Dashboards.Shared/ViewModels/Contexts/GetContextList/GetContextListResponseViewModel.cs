﻿using Supply.Dashboards.Shared.Types;
using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Contexts.GetContextList
{
    public sealed class GetContextListResponseViewModel
    {
        public int Id { get; set; }
        public uint RowVersion { get; set; }
        public StatusEnum Status { get; set; }
        public string Title { get; set; } = string.Empty;
        public List<GetContextListResponseUsersViewModel> Users { get; set; } = new();
    }
}
