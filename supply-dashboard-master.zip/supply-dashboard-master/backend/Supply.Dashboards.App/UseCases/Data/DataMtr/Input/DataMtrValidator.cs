﻿using FluentValidation;

namespace Supply.Dashboards.App.UseCases.Data.DataMtr.Input
{
    public sealed class DataMtrValidator
        : AbstractValidator<DataMtrQuery>
    {
        public DataMtrValidator()
        {
            ValidateStartPeriod();
            ValidateEndPeriod();
            ValidateCustomersIds();
            ValidateLocationsIds();
            ValidateMtrTypesIds();
            ValidateImportTypes();
        }

        private void ValidateStartPeriod() =>
            RuleFor(_ => _.StartPeriod)
                .NotEmpty();

        private void ValidateEndPeriod() =>
            RuleFor(_ => _.EndPeriod)
                .NotEmpty();

        private void ValidateCustomersIds() =>
            RuleForEach(_ => _.CustomersIds);

        private void ValidateLocationsIds() =>
            RuleForEach(_ => _.LocationsIds);

        private void ValidateMtrTypesIds() =>
            RuleForEach(_ => _.MtrTypesIds);

        private void ValidateImportTypes() =>
            RuleForEach(_ => _.Types);
    }
}
