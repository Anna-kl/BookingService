﻿namespace Supply.Dashboards.Domain.AggregatesModel.LogisticNotifications
{
    public sealed class LogisticNotification //: ValueObject
    {
        //public int Id { get; }

        //public DateTime CreateAt { get; }

        //public string Title { get; }
        //public string Text { get; }
        //public Location TerrainUnit { get; }

        //public Uri? Link { get; }
        //public LogisticNotificationsType Type { get; }

        //protected override IEnumerable<object> GetAtomicValues()
        //{
        //    yield return Id;
        //    yield return CreateAt;
        //    yield return Title;
        //    yield return Text;
        //    yield return TerrainUnit;
        //    yield return Link!;
        //    yield return Type;
        //}
    }
}
