﻿using FluentValidation.Results;

using MediatR;

using Microsoft.Extensions.Logging;

using Supply.Dashboards.App.UseCases.ContextUserSettings.GetContextUserSettings.Input;
using Supply.Dashboards.App.UseCases.ContextUserSettings.GetContextUserSettings.Output;
using Supply.Dashboards.Domain.AggregatesModel.ContextUserSettings;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Supply.Dashboards.App.UseCases.ContextUserSettings.GetContextUserSettings
{
    public sealed class GetContextUserSettingsUseCase
        : IRequestHandler<GetContextUserSettingsQuery, (ValidationResult validationResult, GetContextUserSettingsOutput? output)>
    {
        private readonly ILogger<GetContextUserSettingsUseCase> _logger;
        private readonly IBaseUseCase _baseRepo;

        public GetContextUserSettingsUseCase(
            ILogger<GetContextUserSettingsUseCase> logger,
            IBaseUseCase baseRepo)
        {
            _logger = logger;
            _baseRepo = baseRepo;
        }

        public async Task<(ValidationResult validationResult, GetContextUserSettingsOutput? output)> Handle(
            GetContextUserSettingsQuery request,
            CancellationToken cancellationToken)
        {
            if (!request.ValidationResult.IsValid)
                return (request.ValidationResult, null);

            var contextUserSettings = _baseRepo.GetSingleOrDefault<ContextUserSetting>(_ => _.ContextId == request.ContextId && _.UserId == request.UserId);

            return contextUserSettings == null
                ? (request.ValidationResult, null)
                : (request.ValidationResult, new GetContextUserSettingsOutput(contextUserSettings.DashboardsState));
        }
    }
}
