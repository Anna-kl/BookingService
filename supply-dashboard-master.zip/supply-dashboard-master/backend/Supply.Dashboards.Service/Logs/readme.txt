﻿﻿DO NOT REMOVE THIS FILE.

log{DateTime}.txt - main application log.
stdout_xxx.log - kestrel stdout log.