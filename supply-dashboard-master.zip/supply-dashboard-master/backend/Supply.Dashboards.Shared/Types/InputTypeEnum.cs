﻿namespace Supply.Dashboards.Shared.Types
{
    public enum InputTypeEnum
    {
        ManualInput = 1,
        Xlsx = 2,
        Json = 3
    }
}
