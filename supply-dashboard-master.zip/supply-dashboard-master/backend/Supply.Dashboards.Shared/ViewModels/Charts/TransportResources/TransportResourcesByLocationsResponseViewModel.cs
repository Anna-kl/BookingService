﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supply.Dashboards.Shared.ViewModels.Charts.TransportResources
{
    public sealed class TransportResourcesByLocationsResponseViewModel
    {
        public List<TransportResourcesByLocationsParamResponseViewModel>? Locations { get; set; }
    }
}
