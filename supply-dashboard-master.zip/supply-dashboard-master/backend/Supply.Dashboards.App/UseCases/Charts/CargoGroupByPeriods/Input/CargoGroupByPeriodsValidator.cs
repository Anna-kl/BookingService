﻿using FluentValidation;

namespace Supply.Dashboards.App.UseCases.Charts.CargoGroupByPeriods.Input
{
    public sealed class CargoGroupByPeriodsValidator
        : AbstractValidator<CargoGroupByPeriodsQuery>
    {
        public CargoGroupByPeriodsValidator()
        {
            ValidateLocationType();
            ValidateDataType();
            ValidateStartPeriod();
            ValidateEndPeriod();
            ValidateCustomersIds();
            ValidateLocationsIds();
            ValidateMtrTypesIds();
        }

        private void ValidateLocationType() =>
            RuleFor(_ => _.PeriodType)
                .NotEmpty()
                .Must(_ => _.Id != 0); // TODO add description

        private void ValidateDataType() =>
            RuleFor(_ => _.DataType)
                .NotEmpty()
                .Must(_ => _.Id != 0); // TODO add description

        private void ValidateStartPeriod() =>
            RuleFor(_ => _.StartPeriod)
                .NotEmpty();

        private void ValidateEndPeriod() =>
            RuleFor(_ => _.EndPeriod)
                .NotEmpty();

        private void ValidateCustomersIds() =>
            RuleForEach(_ => _.CustomersIds);

        private void ValidateLocationsIds() =>
            RuleForEach(_ => _.LocationsIds);

        private void ValidateMtrTypesIds() =>
            RuleForEach(_ => _.MtrTypesIds);
    }
}