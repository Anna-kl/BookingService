﻿using FluentValidation.Results;

using MediatR;

using Supply.Dashboards.App.UseCases.Charts.OtifChart.Output;

using System;
using System.Collections.Generic;

namespace Supply.Dashboards.App.UseCases.Charts.OtifChart.Input
{
    public sealed class OtifChartQuery
        : IRequest<(ValidationResult validationResult, OtifChartOutput? output)>
    {
        private readonly List<Guid> _locationsIds;
        private readonly List<Guid> _customersIds;

        public OtifChartQuery(
            DateTime startPeriod,
            DateTime? endPeriod,
            List<Guid> locationsIds,
            List<Guid> customersIds)
        {
            StartPeriod = startPeriod;
            EndPeriod = endPeriod;
            _locationsIds = locationsIds;
            _customersIds = customersIds;

            ValidationResult = new OtifChartValidator()
                .Validate(this);
        }

        public DateTime StartPeriod { get; }
        public DateTime? EndPeriod { get; }

        public IEnumerable<Guid> LocationsIds =>
            _locationsIds.AsReadOnly();

        public IEnumerable<Guid> CustomersIds =>
            _customersIds.AsReadOnly();

        public ValidationResult ValidationResult { get; }
    }
}
