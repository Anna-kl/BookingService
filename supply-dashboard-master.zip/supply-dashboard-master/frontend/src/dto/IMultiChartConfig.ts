import { IModuleSeries } from './Dashboards';

export default interface IMultiChartConfig {
    columns?: string;
    dataSource?: any;
    settings: ICommonSeriesSettings;
    customizeArgumentAxis?: ICustomizeArgumentAxis;
    series?: IModuleSeries[];
    functions: IChartFunctions;
    type?: string;
    title: ITitle;
    titleText?: string;
    subtitleText?: string;
    label: ISeriesLabel;
    legend: ILegend;
    tooltip: ITooltip
}

export interface ITitle {
    horizontalAlignment?: string;
    subtitle: ISubtitle;
}

export interface ITooltip {
    enabled: boolean;
    formatPrecision: number;
    formatType: string;
}

export interface ISubtitle {
    fontColor?: string;
}

export interface ILegend {
    verticalAlignment: string;
    horizontalAlignment: string;
}

export interface ICommonSeriesSettings {
    hoverMode: string;
    selectionMode: string;
}

export interface ICustomizeArgumentAxis {
    label: {
        overlappingBehavior: string,
        textOverflow: string
    }
};

export interface IChartFunctions {
    onPointClick?: ({ target }: any) => void;
    customizePoint?: (column: any) => any;
    customizeTooltip?: (pointInfo: any) => any;
}

export interface ISeriesLabel {
    visible: boolean;
    backgroundColor: string;
    rotationAngle: number;
    formatPrecision: number;
    formatType: string;
    fontColor: string;
}