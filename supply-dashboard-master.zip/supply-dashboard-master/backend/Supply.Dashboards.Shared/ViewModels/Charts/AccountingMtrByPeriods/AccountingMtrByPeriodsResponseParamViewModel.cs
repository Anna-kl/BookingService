﻿using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Charts.AccountingMtrByPeriods
{
    public sealed class AccountingMtrByPeriodsResponseParamViewModel
    {
        public string? Period { get; set; }
        public List<AccountingMtrByPeriodsUnitViewModel>? Units { get; set; }
    }
}
