﻿using Common.SeedWork;
using Supply.Dashboards.Domain.AggregatesModel.Customers;
using Supply.Dashboards.Domain.AggregatesModel.Locations;
using Supply.Dashboards.Domain.Exceptions;
using Supply.Dashboards.Domain.Types;
using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Domain.AggregatesModel.Bids
{
    public sealed class BidPayload : ValueObject
    {
        public BidPayload(
            DateTime dateTime,
            BidType type,
            Customer? customer,
            Location? location,
            InputType inputType)
        {
            DateTime = dateTime == default
                ? throw new DomainException($"{nameof(dateTime)} can't be a default value")
                : dateTime;
            Type = type; // TODO
                         // ?? throw new DomainException($"{nameof(type)} can't be null.");
            Customer = customer;
            Location = location;
            InputType = inputType;
        }

#pragma warning disable 8618
        // ReSharper disable once UnusedMember.Local
        private BidPayload()
        {
        }
#pragma warning restore 8618

        public DateTime DateTime { get; init; }

        public BidType Type { get; init; }

        public Customer? Customer { get; init; }
        public Location? Location { get; init; }

        public InputType InputType { get; init; }

        protected override IEnumerable<object> GetAtomicValues()
        {
            yield return DateTime;
            yield return Type;
            yield return Customer!;
            yield return Location!;
            yield return InputType;
        }
    }
}
