﻿using System;
using System.Collections.Generic;

namespace Supply.Dashboards.Shared.ViewModels.Charts.SeasonalDelivery
{
    public sealed class SeasonalDeliveryParamResponse
    {
        public Guid LocationId { get; set; }
        public string? LocationTitle { get; set; }

        public List<SeasonalDeliveryUnitResponse>? Units { get; set; }
    }
}
