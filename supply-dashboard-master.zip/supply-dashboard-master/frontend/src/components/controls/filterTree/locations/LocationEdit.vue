<template>
  <div v-if="popupVisible">
    <DxPopup
      :visible.sync="popupVisible"
      ref="locationTreeEditPopup"
      :drag-enabled="false"
      :close-on-outside-click="true"
      :show-title="true"
      width="600px"
      height="auto"
      @hidden="closeOnClick"
      title="Направление"
    >
      <div class="field">
        <div class="label">Название</div>
        <div class="value">
          <DxTextBox v-model="currentData.title" />
        </div>
      </div>
      <div class="field">
        <div class="label">Описание</div>
        <div class="value">
          <DxTextBox v-model="currentData.description" />
        </div>
      </div>
      <div class="field">
        <div class="label">Тип</div>
        <div class="value">
          <DxSelectBox
            :items="locationTypes"
            :value.sync="currentData.type"
            display-expr="name"
            value-expr="id"
          />
        </div>
      </div>
      <div class="field">
        <div class="label">Широта</div>
        <div class="value">
          <DxNumberBox v-model="currentData.latitude" />
        </div>
      </div>
      <div class="field">
        <div class="label">Долгота</div>
        <div class="value">
          <DxNumberBox v-model="currentData.longitude" />
        </div>
      </div>
      <div class="field">
        <div class="label">Диаметр</div>
        <div class="value">
          <DxNumberBox v-model="currentData.diameter" />
        </div>
      </div>
      <div class="field">
        <div class="label">Родители</div>
        <div class="value tree-container">
          <DirectoryEdgesEditor
            v-if="popupVisible"
            ref="locationEdgesEditor"
            :editedItem="editedItem"
            :loadDataItemFromApi="loadDataItemFromApi"
            :loadDataItemsFromApi="loadDataItemsFromApi"
          />
        </div>
      </div>
      <DxButton
        icon="save"
        type="success"
        text="Сохранить"
        @click="saveClick()"
      />
    </DxPopup>
  </div>
</template>

<script lang='ts'>
import { DxCheckBox } from "devextreme-vue/check-box";
import { Component, Watch, Prop } from "vue-property-decorator";
import DxTextBox from "devextreme-vue/text-box";
import DxSelectBox from "devextreme-vue/select-box";
import { DxPopup } from "devextreme-vue/popup";
import DxButton from "devextreme-vue/button";
import { DxNumberBox } from "devextreme-vue/number-box";
import notify from "devextreme/ui/notify";
import { InputDataState } from "@/store";
import { InputDataService } from "@/services/inputDataService";
import { Guid } from "@/helpers/guid";
import DirectoryEdit from "../DirectoryEdit";
import DirectoryEdgesEditor from "../DirectoryEdgesEditor.vue";
import {
  ILocationDataItem,
  ILocation,
  LocationTypeEnum,
  IRelation,
} from "../types";

@Component({
  components: {
    DxCheckBox,
    DxPopup,
    DxTextBox,
    DxButton,
    DxNumberBox,
    DirectoryEdgesEditor,
    DxSelectBox,
  },
})
export default class LocationTreeEdit extends DirectoryEdit<ILocationDataItem> {
  private created() {
    this._inputDataService = new InputDataService();
    this.currentData = {
      id: Guid.newGuid(),
      rowVersion: 0,
      type: LocationTypeEnum.Direction,
      parentIds: [],
      title: "",
      description: "",
      longitude: 0,
      latitude: 0,
      diameter: 1,
      childrenIds: [],
    };
    this.itemRelations = [];
  }

  private get locationTypes() {
    return [
      { id: LocationTypeEnum.Division, name: "Дивизион" },
      { id: LocationTypeEnum.Direction, name: "Направление" },
    ];
  }

  private saveClick() {
    const location: ILocation = {
      id: this.currentData.id,
      rowVersion: this.currentData.rowVersion,
      type: this.currentData.type,
      title: this.currentData.title,
      description: this.currentData.description,
      longitude: this.currentData.longitude,
      latitude: this.currentData.latitude,
      diameter: this.currentData.diameter,
      childrenIds: this.currentData.childrenIds,
    };

    this.itemRelations = (this.$refs[
      "locationEdgesEditor"
    ] as DirectoryEdgesEditor).getDirectoryEdges();

    this._inputDataService
      .saveLocation(location, this.itemRelations)
      .then((data) => {
        this.popupVisible = false;
        notify("Данные успешно сохранены.", "success", 3000);
        this.reloadTree();
      })
      .catch((error) => {
        notify("При сохранении произошла ошибка!", "error", 3000);
      });
  }
}
</script>

<style scoped>
.label {
  font-size: small;
}
.tree-container {
  margin: 5px;
  border-style: ridge;
  border-width: 1px;
}
</style>